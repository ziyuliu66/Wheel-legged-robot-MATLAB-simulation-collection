#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "series_link_blance_leg_ad6bcbee_1_geometries.h"
PmfMessageId series_link_blance_leg_ad6bcbee_1_compDerivs ( const
RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const double
* state , const int * modeVector , const double * input , const double *
inputDot , const double * inputDdot , const double * discreteState , double *
deriv , double * errorResult , NeuDiagnosticManager * neDiagMgr ) { const
double * rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv ->
mInts . mValues ; boolean_T bb [ 1 ] ; int ii [ 4 ] ; double xx [ 585 ] ; (
void ) rtdvd ; ( void ) rtdvi ; ( void ) eqnEnableFlags ; ( void ) modeVector
; ( void ) inputDot ; ( void ) inputDdot ; ( void ) discreteState ; ( void )
neDiagMgr ; xx [ 0 ] = 0.7071067811865476 ; xx [ 1 ] = 0.5 ; xx [ 2 ] = xx [
1 ] * state [ 6 ] ; xx [ 3 ] = xx [ 0 ] * cos ( xx [ 2 ] ) ; xx [ 4 ] = xx [
3 ] * xx [ 3 ] ; xx [ 5 ] = 2.0 ; xx [ 6 ] = 1.0 ; xx [ 7 ] = xx [ 0 ] * sin
( xx [ 2 ] ) ; xx [ 2 ] = xx [ 3 ] * xx [ 7 ] ; xx [ 8 ] = xx [ 5 ] * ( xx [
2 ] - xx [ 2 ] ) ; xx [ 9 ] = ( xx [ 2 ] + xx [ 2 ] ) * xx [ 5 ] ; xx [ 2 ] =
xx [ 7 ] * xx [ 7 ] ; xx [ 10 ] = ( xx [ 4 ] + xx [ 2 ] ) * xx [ 5 ] - xx [ 6
] ; xx [ 11 ] = ( xx [ 4 ] + xx [ 4 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 12 ] =
xx [ 8 ] ; xx [ 13 ] = xx [ 9 ] ; xx [ 14 ] = xx [ 9 ] ; xx [ 15 ] = xx [ 10
] ; xx [ 16 ] = xx [ 5 ] * ( xx [ 2 ] - xx [ 4 ] ) ; xx [ 17 ] = xx [ 8 ] ;
xx [ 18 ] = ( xx [ 2 ] + xx [ 4 ] ) * xx [ 5 ] ; xx [ 19 ] = xx [ 10 ] ; xx [
2 ] = 0.4090518191766045 ; xx [ 4 ] = xx [ 1 ] * state [ 8 ] ; xx [ 8 ] = cos
( xx [ 4 ] ) ; xx [ 9 ] = xx [ 2 ] * xx [ 8 ] ; xx [ 10 ] =
0.5767812490262756 ; xx [ 20 ] = 0.9437336767246086 ; xx [ 21 ] = sin ( xx [
4 ] ) ; xx [ 4 ] = xx [ 20 ] * xx [ 21 ] ; xx [ 22 ] = xx [ 10 ] * xx [ 4 ] ;
xx [ 23 ] = 0.3307064369132422 ; xx [ 24 ] = xx [ 23 ] * xx [ 21 ] ; xx [ 21
] = xx [ 2 ] * xx [ 24 ] ; xx [ 25 ] = xx [ 9 ] - ( xx [ 22 ] - xx [ 21 ] ) ;
xx [ 26 ] = xx [ 25 ] * xx [ 25 ] ; xx [ 27 ] = xx [ 10 ] * xx [ 24 ] ; xx [
24 ] = xx [ 10 ] * xx [ 8 ] ; xx [ 8 ] = xx [ 2 ] * xx [ 4 ] ; xx [ 2 ] = xx
[ 27 ] - xx [ 24 ] + xx [ 8 ] ; xx [ 4 ] = xx [ 8 ] + xx [ 24 ] + xx [ 27 ] ;
xx [ 8 ] = xx [ 4 ] * xx [ 2 ] ; xx [ 10 ] = xx [ 9 ] - xx [ 21 ] + xx [ 22 ]
; xx [ 9 ] = xx [ 10 ] * xx [ 25 ] ; xx [ 21 ] = xx [ 10 ] * xx [ 2 ] ; xx [
22 ] = xx [ 4 ] * xx [ 25 ] ; xx [ 24 ] = xx [ 10 ] * xx [ 4 ] ; xx [ 27 ] =
xx [ 2 ] * xx [ 25 ] ; xx [ 28 ] = ( xx [ 26 ] + xx [ 2 ] * xx [ 2 ] ) * xx [
5 ] - xx [ 6 ] ; xx [ 29 ] = - ( xx [ 5 ] * ( xx [ 8 ] + xx [ 9 ] ) ) ; xx [
30 ] = ( xx [ 21 ] - xx [ 22 ] ) * xx [ 5 ] ; xx [ 31 ] = ( xx [ 9 ] - xx [ 8
] ) * xx [ 5 ] ; xx [ 32 ] = ( xx [ 26 ] + xx [ 4 ] * xx [ 4 ] ) * xx [ 5 ] -
xx [ 6 ] ; xx [ 33 ] = - ( xx [ 5 ] * ( xx [ 24 ] + xx [ 27 ] ) ) ; xx [ 34 ]
= xx [ 5 ] * ( xx [ 21 ] + xx [ 22 ] ) ; xx [ 35 ] = ( xx [ 27 ] - xx [ 24 ]
) * xx [ 5 ] ; xx [ 36 ] = ( xx [ 26 ] + xx [ 10 ] * xx [ 10 ] ) * xx [ 5 ] -
xx [ 6 ] ; xx [ 8 ] = 0.1186026172512557 ; xx [ 9 ] = xx [ 1 ] * state [ 24 ]
; xx [ 21 ] = sin ( xx [ 9 ] ) ; xx [ 22 ] = 0.6970892476441968 ; xx [ 24 ] =
cos ( xx [ 9 ] ) ; xx [ 9 ] = xx [ 8 ] * xx [ 21 ] - xx [ 22 ] * xx [ 24 ] ;
xx [ 26 ] = xx [ 9 ] * xx [ 9 ] ; xx [ 27 ] = xx [ 8 ] * xx [ 24 ] ; xx [ 24
] = xx [ 22 ] * xx [ 21 ] ; xx [ 21 ] = xx [ 27 ] + xx [ 24 ] ; xx [ 37 ] = (
xx [ 26 ] + xx [ 21 ] * xx [ 21 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 38 ] = xx [
24 ] + xx [ 27 ] ; xx [ 24 ] = xx [ 38 ] * xx [ 9 ] ; xx [ 27 ] = xx [ 21 ] *
xx [ 9 ] ; xx [ 39 ] = xx [ 5 ] * ( xx [ 24 ] - xx [ 27 ] ) ; xx [ 40 ] = xx
[ 21 ] * xx [ 38 ] ; xx [ 41 ] = ( xx [ 40 ] + xx [ 26 ] ) * xx [ 5 ] ; xx [
42 ] = xx [ 27 ] + xx [ 24 ] ; xx [ 43 ] = xx [ 42 ] * xx [ 5 ] ; xx [ 44 ] =
( xx [ 26 ] + xx [ 26 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 45 ] = xx [ 5 ] * ( xx
[ 27 ] - xx [ 24 ] ) ; xx [ 46 ] = xx [ 40 ] - xx [ 26 ] ; xx [ 40 ] = xx [ 5
] * xx [ 46 ] ; xx [ 47 ] = ( xx [ 24 ] + xx [ 27 ] ) * xx [ 5 ] ; xx [ 24 ]
= ( xx [ 26 ] + xx [ 38 ] * xx [ 38 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 48 ] =
xx [ 37 ] ; xx [ 49 ] = xx [ 39 ] ; xx [ 50 ] = xx [ 41 ] ; xx [ 51 ] = - xx
[ 43 ] ; xx [ 52 ] = xx [ 44 ] ; xx [ 53 ] = xx [ 45 ] ; xx [ 54 ] = xx [ 40
] ; xx [ 55 ] = - xx [ 47 ] ; xx [ 56 ] = xx [ 24 ] ; xx [ 26 ] = 0.135 ; xx
[ 27 ] = 0.03394634084866131 ; xx [ 57 ] = xx [ 26 ] * xx [ 37 ] ; xx [ 58 ]
= - ( xx [ 26 ] * xx [ 43 ] ) ; xx [ 59 ] = xx [ 26 ] * xx [ 40 ] ; xx [ 60 ]
= xx [ 27 ] * xx [ 39 ] ; xx [ 61 ] = xx [ 27 ] * xx [ 44 ] ; xx [ 62 ] = - (
xx [ 27 ] * xx [ 47 ] ) ; xx [ 63 ] = xx [ 26 ] * xx [ 41 ] ; xx [ 64 ] = xx
[ 26 ] * xx [ 45 ] ; xx [ 65 ] = xx [ 26 ] * xx [ 24 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 48 , xx + 57 , xx + 66 ) ; xx [ 57 ] = xx
[ 1 ] * state [ 22 ] ; xx [ 58 ] = sin ( xx [ 57 ] ) ; xx [ 59 ] = cos ( xx [
57 ] ) ; xx [ 57 ] = xx [ 8 ] * xx [ 58 ] - xx [ 22 ] * xx [ 59 ] ; xx [ 60 ]
= xx [ 57 ] * xx [ 57 ] ; xx [ 61 ] = xx [ 8 ] * xx [ 59 ] ; xx [ 59 ] = xx [
22 ] * xx [ 58 ] ; xx [ 58 ] = xx [ 61 ] + xx [ 59 ] ; xx [ 62 ] = ( xx [ 60
] + xx [ 58 ] * xx [ 58 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 63 ] = xx [ 59 ] +
xx [ 61 ] ; xx [ 59 ] = xx [ 63 ] * xx [ 57 ] ; xx [ 61 ] = xx [ 58 ] * xx [
57 ] ; xx [ 64 ] = xx [ 5 ] * ( xx [ 59 ] - xx [ 61 ] ) ; xx [ 65 ] = xx [ 58
] * xx [ 63 ] ; xx [ 75 ] = ( xx [ 65 ] + xx [ 60 ] ) * xx [ 5 ] ; xx [ 76 ]
= xx [ 61 ] + xx [ 59 ] ; xx [ 77 ] = xx [ 76 ] * xx [ 5 ] ; xx [ 78 ] = ( xx
[ 60 ] + xx [ 60 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 79 ] = xx [ 5 ] * ( xx [ 61
] - xx [ 59 ] ) ; xx [ 80 ] = xx [ 65 ] - xx [ 60 ] ; xx [ 65 ] = xx [ 5 ] *
xx [ 80 ] ; xx [ 81 ] = ( xx [ 59 ] + xx [ 61 ] ) * xx [ 5 ] ; xx [ 59 ] = (
xx [ 60 ] + xx [ 63 ] * xx [ 63 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 82 ] = xx [
62 ] ; xx [ 83 ] = xx [ 64 ] ; xx [ 84 ] = xx [ 75 ] ; xx [ 85 ] = - xx [ 77
] ; xx [ 86 ] = xx [ 78 ] ; xx [ 87 ] = xx [ 79 ] ; xx [ 88 ] = xx [ 65 ] ;
xx [ 89 ] = - xx [ 81 ] ; xx [ 90 ] = xx [ 59 ] ; xx [ 91 ] = xx [ 26 ] * xx
[ 62 ] ; xx [ 92 ] = - ( xx [ 26 ] * xx [ 77 ] ) ; xx [ 93 ] = xx [ 26 ] * xx
[ 65 ] ; xx [ 94 ] = xx [ 27 ] * xx [ 64 ] ; xx [ 95 ] = xx [ 27 ] * xx [ 78
] ; xx [ 96 ] = - ( xx [ 27 ] * xx [ 81 ] ) ; xx [ 97 ] = xx [ 26 ] * xx [ 75
] ; xx [ 98 ] = xx [ 26 ] * xx [ 79 ] ; xx [ 99 ] = xx [ 26 ] * xx [ 59 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 82 , xx + 91 , xx + 100 ) ; xx [ 27 ] =
xx [ 1 ] * state [ 16 ] ; xx [ 60 ] = cos ( xx [ 27 ] ) ; xx [ 61 ] = sin (
xx [ 27 ] ) ; xx [ 27 ] = xx [ 22 ] * xx [ 60 ] - xx [ 8 ] * xx [ 61 ] ; xx [
91 ] = xx [ 27 ] * xx [ 27 ] ; xx [ 92 ] = xx [ 8 ] * xx [ 60 ] ; xx [ 60 ] =
xx [ 22 ] * xx [ 61 ] ; xx [ 61 ] = xx [ 92 ] + xx [ 60 ] ; xx [ 93 ] = ( xx
[ 91 ] + xx [ 61 ] * xx [ 61 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 94 ] = xx [ 61
] * xx [ 27 ] ; xx [ 95 ] = xx [ 60 ] + xx [ 92 ] ; xx [ 60 ] = xx [ 95 ] *
xx [ 27 ] ; xx [ 92 ] = xx [ 5 ] * ( xx [ 94 ] - xx [ 60 ] ) ; xx [ 96 ] = xx
[ 61 ] * xx [ 95 ] ; xx [ 97 ] = ( xx [ 96 ] + xx [ 91 ] ) * xx [ 5 ] ; xx [
98 ] = xx [ 94 ] + xx [ 60 ] ; xx [ 99 ] = xx [ 98 ] * xx [ 5 ] ; xx [ 109 ]
= ( xx [ 91 ] + xx [ 91 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 110 ] = xx [ 5 ] * (
xx [ 60 ] - xx [ 94 ] ) ; xx [ 111 ] = xx [ 96 ] - xx [ 91 ] ; xx [ 96 ] = xx
[ 5 ] * xx [ 111 ] ; xx [ 112 ] = xx [ 60 ] + xx [ 94 ] ; xx [ 60 ] = xx [
112 ] * xx [ 5 ] ; xx [ 94 ] = ( xx [ 91 ] + xx [ 95 ] * xx [ 95 ] ) * xx [ 5
] - xx [ 6 ] ; xx [ 113 ] = xx [ 93 ] ; xx [ 114 ] = xx [ 92 ] ; xx [ 115 ] =
xx [ 97 ] ; xx [ 116 ] = xx [ 99 ] ; xx [ 117 ] = xx [ 109 ] ; xx [ 118 ] =
xx [ 110 ] ; xx [ 119 ] = xx [ 96 ] ; xx [ 120 ] = xx [ 60 ] ; xx [ 121 ] =
xx [ 94 ] ; xx [ 91 ] = 0.1412831853071796 ; xx [ 122 ] = xx [ 1 ] * state [
18 ] ; xx [ 123 ] = xx [ 0 ] * sin ( xx [ 122 ] ) ; xx [ 124 ] = xx [ 0 ] *
cos ( xx [ 122 ] ) ; xx [ 122 ] = xx [ 123 ] - xx [ 124 ] ; xx [ 125 ] = xx [
122 ] * xx [ 122 ] ; xx [ 126 ] = xx [ 5 ] * xx [ 125 ] - xx [ 6 ] ; xx [ 127
] = 0.2762831853071796 ; xx [ 128 ] = 1.18628318530718 ; xx [ 129 ] = xx [ 1
] * state [ 20 ] ; xx [ 130 ] = cos ( xx [ 129 ] ) ; xx [ 131 ] = xx [ 130 ]
* xx [ 130 ] ; xx [ 132 ] = xx [ 5 ] * xx [ 131 ] - xx [ 6 ] ; xx [ 133 ] =
xx [ 128 ] * xx [ 132 ] ; xx [ 134 ] = xx [ 133 ] * xx [ 132 ] ; xx [ 135 ] =
sin ( xx [ 129 ] ) ; xx [ 129 ] = xx [ 5 ] * xx [ 130 ] * xx [ 135 ] ; xx [
136 ] = xx [ 128 ] * xx [ 129 ] ; xx [ 137 ] = xx [ 136 ] * xx [ 129 ] ; xx [
138 ] = xx [ 134 ] + xx [ 137 ] ; xx [ 139 ] = xx [ 127 ] + xx [ 138 ] ; xx [
140 ] = 0.1339025647286604 ; xx [ 141 ] = xx [ 136 ] * xx [ 132 ] ; xx [ 136
] = xx [ 133 ] * xx [ 129 ] ; xx [ 133 ] = xx [ 141 ] - xx [ 136 ] ; xx [ 142
] = xx [ 140 ] * xx [ 133 ] ; xx [ 143 ] = 0.02913743527133955 ; xx [ 144 ] =
xx [ 142 ] + xx [ 143 ] * xx [ 133 ] ; xx [ 145 ] = 1.04926519013724e-3 ; xx
[ 146 ] = xx [ 137 ] + xx [ 134 ] ; xx [ 134 ] = xx [ 146 ] * xx [ 140 ] ; xx
[ 137 ] = xx [ 145 ] + xx [ 140 ] * xx [ 134 ] ; xx [ 147 ] = xx [ 137 ] + xx
[ 143 ] * xx [ 134 ] ; xx [ 148 ] = xx [ 127 ] + xx [ 146 ] ; xx [ 149 ] = xx
[ 134 ] + xx [ 148 ] * xx [ 143 ] ; xx [ 150 ] = xx [ 147 ] + xx [ 149 ] * xx
[ 143 ] ; ii [ 0 ] = factorSymmetricPosDef ( xx + 150 , 1 , xx + 151 ) ; if (
ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint3' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 151 ] = xx [ 144 ] / xx [ 150 ] ; xx [ 152 ] = xx [
139 ] - xx [ 144 ] * xx [ 151 ] ; xx [ 153 ] = xx [ 123 ] + xx [ 124 ] ; xx [
123 ] = xx [ 153 ] * xx [ 122 ] ; xx [ 124 ] = xx [ 5 ] * xx [ 123 ] ; xx [
154 ] = xx [ 149 ] * xx [ 151 ] ; xx [ 155 ] = xx [ 133 ] - xx [ 154 ] ; xx [
156 ] = xx [ 152 ] * xx [ 126 ] + xx [ 124 ] * xx [ 155 ] ; xx [ 157 ] = xx [
136 ] - xx [ 141 ] ; xx [ 136 ] = xx [ 157 ] - xx [ 154 ] ; xx [ 141 ] = xx [
149 ] / xx [ 150 ] ; xx [ 154 ] = xx [ 148 ] - xx [ 149 ] * xx [ 141 ] ; xx [
158 ] = xx [ 126 ] * xx [ 136 ] + xx [ 124 ] * xx [ 154 ] ; xx [ 159 ] = xx [
126 ] * xx [ 156 ] + xx [ 124 ] * xx [ 158 ] ; xx [ 160 ] = xx [ 91 ] + xx [
159 ] ; xx [ 161 ] = ( xx [ 125 ] + xx [ 153 ] * xx [ 153 ] ) * xx [ 5 ] - xx
[ 6 ] ; xx [ 125 ] = xx [ 142 ] - xx [ 147 ] * xx [ 151 ] ; xx [ 162 ] = xx [
134 ] - xx [ 147 ] * xx [ 141 ] ; xx [ 163 ] = xx [ 161 ] * ( xx [ 125 ] * xx
[ 126 ] + xx [ 124 ] * xx [ 162 ] ) ; xx [ 164 ] = xx [ 153 ] * xx [ 143 ] ;
xx [ 165 ] = xx [ 164 ] * xx [ 122 ] ; xx [ 166 ] = xx [ 5 ] * xx [ 165 ] ;
xx [ 167 ] = 0.1078490312466243 ; xx [ 168 ] = xx [ 5 ] * xx [ 153 ] * xx [
164 ] ; xx [ 164 ] = xx [ 167 ] - xx [ 168 ] ; xx [ 169 ] = xx [ 126 ] * xx [
155 ] - xx [ 124 ] * xx [ 152 ] ; xx [ 152 ] = xx [ 154 ] * xx [ 126 ] - xx [
124 ] * xx [ 136 ] ; xx [ 136 ] = xx [ 169 ] * xx [ 126 ] + xx [ 152 ] * xx [
124 ] ; xx [ 154 ] = xx [ 166 ] * xx [ 159 ] + xx [ 164 ] * xx [ 136 ] ; xx [
155 ] = xx [ 163 ] + xx [ 154 ] ; xx [ 159 ] = 0.08603840402471528 ; xx [ 170
] = xx [ 155 ] + xx [ 159 ] * xx [ 136 ] ; xx [ 171 ] = 3.489385797727083e-4
; xx [ 172 ] = xx [ 147 ] / xx [ 150 ] ; xx [ 173 ] = ( xx [ 162 ] * xx [ 126
] - xx [ 124 ] * xx [ 125 ] ) * xx [ 161 ] ; xx [ 125 ] = xx [ 166 ] * xx [
163 ] + xx [ 164 ] * xx [ 173 ] ; xx [ 162 ] = xx [ 126 ] * xx [ 158 ] - xx [
124 ] * xx [ 156 ] ; xx [ 156 ] = xx [ 152 ] * xx [ 126 ] - xx [ 169 ] * xx [
124 ] ; xx [ 152 ] = xx [ 162 ] * xx [ 166 ] + xx [ 156 ] * xx [ 164 ] ; xx [
158 ] = xx [ 171 ] + ( xx [ 137 ] - xx [ 147 ] * xx [ 172 ] ) * xx [ 161 ] *
xx [ 161 ] + xx [ 125 ] + xx [ 125 ] + xx [ 152 ] * xx [ 164 ] + xx [ 154 ] *
xx [ 166 ] ; xx [ 125 ] = xx [ 173 ] + xx [ 152 ] ; xx [ 137 ] = xx [ 158 ] +
xx [ 125 ] * xx [ 159 ] ; xx [ 152 ] = xx [ 91 ] + xx [ 156 ] ; xx [ 154 ] =
xx [ 125 ] + xx [ 152 ] * xx [ 159 ] ; xx [ 156 ] = xx [ 137 ] + xx [ 154 ] *
xx [ 159 ] ; ii [ 0 ] = factorSymmetricPosDef ( xx + 156 , 1 , xx + 163 ) ;
if ( ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint1' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 163 ] = xx [ 170 ] / xx [ 156 ] ; xx [ 169 ] = xx [
160 ] - xx [ 170 ] * xx [ 163 ] ; xx [ 173 ] = xx [ 154 ] * xx [ 163 ] ; xx [
174 ] = xx [ 136 ] - xx [ 173 ] ; xx [ 175 ] = xx [ 162 ] - xx [ 173 ] ; xx [
173 ] = xx [ 154 ] / xx [ 156 ] ; xx [ 176 ] = xx [ 152 ] - xx [ 154 ] * xx [
173 ] ; xx [ 177 ] = ( xx [ 131 ] + xx [ 135 ] * xx [ 135 ] ) * xx [ 5 ] - xx
[ 6 ] ; xx [ 131 ] = xx [ 128 ] * xx [ 177 ] * xx [ 177 ] ; xx [ 177 ] = xx [
127 ] + xx [ 131 ] ; xx [ 178 ] = xx [ 177 ] * xx [ 161 ] * xx [ 161 ] ; xx [
179 ] = xx [ 91 ] + xx [ 178 ] ; xx [ 180 ] = xx [ 169 ] * xx [ 93 ] + xx [
92 ] * xx [ 174 ] ; xx [ 181 ] = xx [ 99 ] * xx [ 169 ] + xx [ 109 ] * xx [
174 ] ; xx [ 182 ] = xx [ 96 ] * xx [ 169 ] + xx [ 60 ] * xx [ 174 ] ; xx [
183 ] = xx [ 175 ] * xx [ 93 ] + xx [ 92 ] * xx [ 176 ] ; xx [ 184 ] = xx [
99 ] * xx [ 175 ] + xx [ 176 ] * xx [ 109 ] ; xx [ 185 ] = xx [ 96 ] * xx [
175 ] + xx [ 60 ] * xx [ 176 ] ; xx [ 186 ] = xx [ 179 ] * xx [ 97 ] ; xx [
187 ] = xx [ 179 ] * xx [ 110 ] ; xx [ 188 ] = xx [ 179 ] * xx [ 94 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 113 , xx + 180 , xx + 189 ) ; xx [ 169 ]
= 10.02513274122872 ; xx [ 174 ] = xx [ 1 ] * state [ 10 ] ; xx [ 175 ] = cos
( xx [ 174 ] ) ; xx [ 176 ] = sin ( xx [ 174 ] ) ; xx [ 174 ] = xx [ 22 ] *
xx [ 175 ] - xx [ 8 ] * xx [ 176 ] ; xx [ 180 ] = xx [ 174 ] * xx [ 174 ] ;
xx [ 181 ] = xx [ 8 ] * xx [ 175 ] ; xx [ 8 ] = xx [ 22 ] * xx [ 176 ] ; xx [
22 ] = xx [ 181 ] + xx [ 8 ] ; xx [ 175 ] = ( xx [ 180 ] + xx [ 22 ] * xx [
22 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 176 ] = xx [ 22 ] * xx [ 174 ] ; xx [ 182
] = xx [ 8 ] + xx [ 181 ] ; xx [ 8 ] = xx [ 182 ] * xx [ 174 ] ; xx [ 181 ] =
xx [ 5 ] * ( xx [ 176 ] - xx [ 8 ] ) ; xx [ 183 ] = xx [ 22 ] * xx [ 182 ] ;
xx [ 184 ] = ( xx [ 183 ] + xx [ 180 ] ) * xx [ 5 ] ; xx [ 185 ] = xx [ 176 ]
+ xx [ 8 ] ; xx [ 186 ] = xx [ 185 ] * xx [ 5 ] ; xx [ 187 ] = ( xx [ 180 ] +
xx [ 180 ] ) * xx [ 5 ] - xx [ 6 ] ; xx [ 188 ] = xx [ 5 ] * ( xx [ 8 ] - xx
[ 176 ] ) ; xx [ 198 ] = xx [ 183 ] - xx [ 180 ] ; xx [ 183 ] = xx [ 5 ] * xx
[ 198 ] ; xx [ 199 ] = xx [ 8 ] + xx [ 176 ] ; xx [ 8 ] = xx [ 199 ] * xx [ 5
] ; xx [ 176 ] = ( xx [ 180 ] + xx [ 182 ] * xx [ 182 ] ) * xx [ 5 ] - xx [ 6
] ; xx [ 200 ] = xx [ 175 ] ; xx [ 201 ] = xx [ 181 ] ; xx [ 202 ] = xx [ 184
] ; xx [ 203 ] = xx [ 186 ] ; xx [ 204 ] = xx [ 187 ] ; xx [ 205 ] = xx [ 188
] ; xx [ 206 ] = xx [ 183 ] ; xx [ 207 ] = xx [ 8 ] ; xx [ 208 ] = xx [ 176 ]
; xx [ 180 ] = xx [ 1 ] * state [ 12 ] ; xx [ 209 ] = xx [ 0 ] * sin ( xx [
180 ] ) ; xx [ 210 ] = xx [ 0 ] * cos ( xx [ 180 ] ) ; xx [ 180 ] = xx [ 209
] - xx [ 210 ] ; xx [ 211 ] = xx [ 180 ] * xx [ 180 ] ; xx [ 212 ] = xx [ 5 ]
* xx [ 211 ] - xx [ 6 ] ; xx [ 213 ] = xx [ 1 ] * state [ 14 ] ; xx [ 1 ] =
cos ( xx [ 213 ] ) ; xx [ 214 ] = xx [ 1 ] * xx [ 1 ] ; xx [ 215 ] = xx [ 5 ]
* xx [ 214 ] - xx [ 6 ] ; xx [ 216 ] = xx [ 128 ] * xx [ 215 ] ; xx [ 217 ] =
xx [ 216 ] * xx [ 215 ] ; xx [ 218 ] = sin ( xx [ 213 ] ) ; xx [ 213 ] = xx [
5 ] * xx [ 1 ] * xx [ 218 ] ; xx [ 219 ] = xx [ 128 ] * xx [ 213 ] ; xx [ 220
] = xx [ 219 ] * xx [ 213 ] ; xx [ 221 ] = xx [ 217 ] + xx [ 220 ] ; xx [ 222
] = xx [ 127 ] + xx [ 221 ] ; xx [ 223 ] = xx [ 219 ] * xx [ 215 ] ; xx [ 219
] = xx [ 216 ] * xx [ 213 ] ; xx [ 216 ] = xx [ 223 ] - xx [ 219 ] ; xx [ 224
] = xx [ 140 ] * xx [ 216 ] ; xx [ 225 ] = xx [ 224 ] + xx [ 143 ] * xx [ 216
] ; xx [ 226 ] = xx [ 220 ] + xx [ 217 ] ; xx [ 217 ] = xx [ 226 ] * xx [ 140
] ; xx [ 220 ] = xx [ 145 ] + xx [ 140 ] * xx [ 217 ] ; xx [ 227 ] = xx [ 220
] + xx [ 143 ] * xx [ 217 ] ; xx [ 228 ] = xx [ 127 ] + xx [ 226 ] ; xx [ 229
] = xx [ 217 ] + xx [ 228 ] * xx [ 143 ] ; xx [ 230 ] = xx [ 227 ] + xx [ 229
] * xx [ 143 ] ; ii [ 0 ] = factorSymmetricPosDef ( xx + 230 , 1 , xx + 231 )
; if ( ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint2' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 231 ] = xx [ 225 ] / xx [ 230 ] ; xx [ 232 ] = xx [
222 ] - xx [ 225 ] * xx [ 231 ] ; xx [ 233 ] = xx [ 209 ] + xx [ 210 ] ; xx [
209 ] = xx [ 233 ] * xx [ 180 ] ; xx [ 210 ] = xx [ 5 ] * xx [ 209 ] ; xx [
234 ] = xx [ 229 ] * xx [ 231 ] ; xx [ 235 ] = xx [ 216 ] - xx [ 234 ] ; xx [
236 ] = xx [ 232 ] * xx [ 212 ] + xx [ 210 ] * xx [ 235 ] ; xx [ 237 ] = xx [
219 ] - xx [ 223 ] ; xx [ 219 ] = xx [ 237 ] - xx [ 234 ] ; xx [ 223 ] = xx [
229 ] / xx [ 230 ] ; xx [ 234 ] = xx [ 228 ] - xx [ 229 ] * xx [ 223 ] ; xx [
238 ] = xx [ 212 ] * xx [ 219 ] + xx [ 210 ] * xx [ 234 ] ; xx [ 239 ] = xx [
212 ] * xx [ 236 ] + xx [ 210 ] * xx [ 238 ] ; xx [ 240 ] = xx [ 91 ] + xx [
239 ] ; xx [ 241 ] = ( xx [ 211 ] + xx [ 233 ] * xx [ 233 ] ) * xx [ 5 ] - xx
[ 6 ] ; xx [ 211 ] = xx [ 224 ] - xx [ 227 ] * xx [ 231 ] ; xx [ 242 ] = xx [
217 ] - xx [ 227 ] * xx [ 223 ] ; xx [ 243 ] = xx [ 241 ] * ( xx [ 211 ] * xx
[ 212 ] + xx [ 210 ] * xx [ 242 ] ) ; xx [ 244 ] = xx [ 233 ] * xx [ 143 ] ;
xx [ 245 ] = xx [ 244 ] * xx [ 180 ] ; xx [ 246 ] = xx [ 5 ] * xx [ 245 ] ;
xx [ 247 ] = xx [ 5 ] * xx [ 233 ] * xx [ 244 ] ; xx [ 244 ] = xx [ 167 ] -
xx [ 247 ] ; xx [ 167 ] = xx [ 212 ] * xx [ 235 ] - xx [ 210 ] * xx [ 232 ] ;
xx [ 232 ] = xx [ 234 ] * xx [ 212 ] - xx [ 210 ] * xx [ 219 ] ; xx [ 219 ] =
xx [ 167 ] * xx [ 212 ] + xx [ 232 ] * xx [ 210 ] ; xx [ 234 ] = xx [ 246 ] *
xx [ 239 ] + xx [ 244 ] * xx [ 219 ] ; xx [ 235 ] = xx [ 243 ] + xx [ 234 ] ;
xx [ 239 ] = xx [ 235 ] + xx [ 159 ] * xx [ 219 ] ; xx [ 248 ] = xx [ 227 ] /
xx [ 230 ] ; xx [ 249 ] = ( xx [ 242 ] * xx [ 212 ] - xx [ 210 ] * xx [ 211 ]
) * xx [ 241 ] ; xx [ 211 ] = xx [ 246 ] * xx [ 243 ] + xx [ 244 ] * xx [ 249
] ; xx [ 242 ] = xx [ 212 ] * xx [ 238 ] - xx [ 210 ] * xx [ 236 ] ; xx [ 236
] = xx [ 232 ] * xx [ 212 ] - xx [ 167 ] * xx [ 210 ] ; xx [ 167 ] = xx [ 242
] * xx [ 246 ] + xx [ 236 ] * xx [ 244 ] ; xx [ 232 ] = xx [ 171 ] + ( xx [
220 ] - xx [ 227 ] * xx [ 248 ] ) * xx [ 241 ] * xx [ 241 ] + xx [ 211 ] + xx
[ 211 ] + xx [ 167 ] * xx [ 244 ] + xx [ 234 ] * xx [ 246 ] ; xx [ 211 ] = xx
[ 249 ] + xx [ 167 ] ; xx [ 167 ] = xx [ 232 ] + xx [ 211 ] * xx [ 159 ] ; xx
[ 220 ] = xx [ 91 ] + xx [ 236 ] ; xx [ 234 ] = xx [ 211 ] + xx [ 220 ] * xx
[ 159 ] ; xx [ 236 ] = xx [ 167 ] + xx [ 234 ] * xx [ 159 ] ; ii [ 0 ] =
factorSymmetricPosDef ( xx + 236 , 1 , xx + 238 ) ; if ( ii [ 0 ] != 0 ) {
return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 238 ] = xx [ 239 ] / xx [ 236 ] ; xx [ 243 ] = xx [
240 ] - xx [ 239 ] * xx [ 238 ] ; xx [ 249 ] = xx [ 234 ] * xx [ 238 ] ; xx [
250 ] = xx [ 219 ] - xx [ 249 ] ; xx [ 251 ] = xx [ 242 ] - xx [ 249 ] ; xx [
249 ] = xx [ 234 ] / xx [ 236 ] ; xx [ 252 ] = xx [ 220 ] - xx [ 234 ] * xx [
249 ] ; xx [ 253 ] = ( xx [ 214 ] + xx [ 218 ] * xx [ 218 ] ) * xx [ 5 ] - xx
[ 6 ] ; xx [ 214 ] = xx [ 128 ] * xx [ 253 ] * xx [ 253 ] ; xx [ 253 ] = xx [
127 ] + xx [ 214 ] ; xx [ 127 ] = xx [ 253 ] * xx [ 241 ] * xx [ 241 ] ; xx [
254 ] = xx [ 91 ] + xx [ 127 ] ; xx [ 255 ] = xx [ 243 ] * xx [ 175 ] + xx [
181 ] * xx [ 250 ] ; xx [ 256 ] = xx [ 186 ] * xx [ 243 ] + xx [ 187 ] * xx [
250 ] ; xx [ 257 ] = xx [ 183 ] * xx [ 243 ] + xx [ 8 ] * xx [ 250 ] ; xx [
258 ] = xx [ 251 ] * xx [ 175 ] + xx [ 181 ] * xx [ 252 ] ; xx [ 259 ] = xx [
186 ] * xx [ 251 ] + xx [ 252 ] * xx [ 187 ] ; xx [ 260 ] = xx [ 183 ] * xx [
251 ] + xx [ 8 ] * xx [ 252 ] ; xx [ 261 ] = xx [ 254 ] * xx [ 184 ] ; xx [
262 ] = xx [ 254 ] * xx [ 188 ] ; xx [ 263 ] = xx [ 254 ] * xx [ 176 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 200 , xx + 255 , xx + 264 ) ; xx [ 91 ] =
xx [ 66 ] + xx [ 100 ] + xx [ 189 ] + xx [ 169 ] + xx [ 264 ] ; xx [ 243 ] =
0.03010502338364002 ; xx [ 250 ] = 0.03007944796046594 ; xx [ 251 ] = xx [
250 ] * xx [ 134 ] ; xx [ 252 ] = xx [ 146 ] * xx [ 250 ] ; xx [ 146 ] = xx [
251 ] + xx [ 143 ] * xx [ 252 ] ; xx [ 255 ] = xx [ 250 ] * xx [ 133 ] ; xx [
256 ] = xx [ 146 ] * xx [ 151 ] - xx [ 255 ] ; xx [ 257 ] = xx [ 146 ] * xx [
141 ] - xx [ 252 ] ; xx [ 258 ] = xx [ 256 ] * xx [ 126 ] + xx [ 124 ] * xx [
257 ] ; xx [ 259 ] = xx [ 138 ] * xx [ 250 ] ; xx [ 138 ] = xx [ 250 ] * xx [
142 ] ; xx [ 260 ] = xx [ 250 ] * xx [ 157 ] ; xx [ 261 ] = xx [ 138 ] + xx [
143 ] * xx [ 260 ] ; xx [ 262 ] = xx [ 259 ] - xx [ 261 ] * xx [ 151 ] ; xx [
263 ] = xx [ 260 ] - xx [ 261 ] * xx [ 141 ] ; xx [ 273 ] = xx [ 262 ] * xx [
126 ] + xx [ 124 ] * xx [ 263 ] ; xx [ 274 ] = xx [ 126 ] * xx [ 258 ] + xx [
124 ] * xx [ 273 ] ; xx [ 275 ] = xx [ 146 ] / xx [ 150 ] ; xx [ 276 ] = xx [
147 ] * xx [ 275 ] ; xx [ 277 ] = ( xx [ 276 ] - xx [ 251 ] ) * xx [ 161 ] ;
xx [ 251 ] = xx [ 261 ] / xx [ 150 ] ; xx [ 278 ] = xx [ 147 ] * xx [ 251 ] ;
xx [ 279 ] = xx [ 161 ] * ( xx [ 138 ] - xx [ 278 ] ) ; xx [ 138 ] = xx [ 257
] * xx [ 126 ] - xx [ 124 ] * xx [ 256 ] ; xx [ 256 ] = xx [ 263 ] * xx [ 126
] - xx [ 124 ] * xx [ 262 ] ; xx [ 257 ] = xx [ 138 ] * xx [ 126 ] + xx [ 256
] * xx [ 124 ] ; xx [ 262 ] = xx [ 166 ] * xx [ 274 ] + xx [ 164 ] * xx [ 257
] ; xx [ 263 ] = xx [ 277 ] * xx [ 126 ] + xx [ 124 ] * xx [ 279 ] + xx [ 262
] ; xx [ 280 ] = xx [ 263 ] + xx [ 159 ] * xx [ 257 ] ; xx [ 281 ] = xx [ 274
] - xx [ 280 ] * xx [ 163 ] ; xx [ 282 ] = xx [ 257 ] - xx [ 280 ] * xx [ 173
] ; xx [ 283 ] = xx [ 140 ] * xx [ 131 ] ; xx [ 131 ] = xx [ 283 ] * xx [ 161
] ; xx [ 284 ] = xx [ 124 ] * xx [ 131 ] ; xx [ 285 ] = xx [ 166 ] * xx [ 178
] ; xx [ 286 ] = xx [ 284 ] + xx [ 285 ] ; xx [ 287 ] = xx [ 126 ] * xx [ 273
] - xx [ 124 ] * xx [ 258 ] ; xx [ 258 ] = xx [ 256 ] * xx [ 126 ] - xx [ 138
] * xx [ 124 ] ; xx [ 138 ] = xx [ 287 ] * xx [ 166 ] + xx [ 258 ] * xx [ 164
] ; xx [ 256 ] = xx [ 279 ] * xx [ 126 ] - xx [ 124 ] * xx [ 277 ] + xx [ 138
] ; xx [ 273 ] = xx [ 256 ] + xx [ 258 ] * xx [ 159 ] ; xx [ 277 ] = xx [ 287
] - xx [ 273 ] * xx [ 163 ] ; xx [ 279 ] = xx [ 258 ] - xx [ 273 ] * xx [ 173
] ; xx [ 288 ] = xx [ 131 ] * xx [ 126 ] ; xx [ 131 ] = xx [ 164 ] * xx [ 178
] ; xx [ 178 ] = xx [ 288 ] + xx [ 131 ] ; xx [ 289 ] = xx [ 155 ] - xx [ 137
] * xx [ 163 ] ; xx [ 290 ] = xx [ 125 ] - xx [ 137 ] * xx [ 173 ] ; xx [ 291
] = xx [ 93 ] * xx [ 281 ] + xx [ 92 ] * xx [ 282 ] - xx [ 97 ] * xx [ 286 ]
; xx [ 292 ] = xx [ 99 ] * xx [ 281 ] + xx [ 109 ] * xx [ 282 ] - xx [ 110 ]
* xx [ 286 ] ; xx [ 293 ] = xx [ 96 ] * xx [ 281 ] + xx [ 60 ] * xx [ 282 ] -
xx [ 94 ] * xx [ 286 ] ; xx [ 294 ] = xx [ 277 ] * xx [ 93 ] + xx [ 92 ] * xx
[ 279 ] - xx [ 178 ] * xx [ 97 ] ; xx [ 295 ] = xx [ 99 ] * xx [ 277 ] + xx [
279 ] * xx [ 109 ] - xx [ 178 ] * xx [ 110 ] ; xx [ 296 ] = xx [ 96 ] * xx [
277 ] + xx [ 60 ] * xx [ 279 ] - xx [ 178 ] * xx [ 94 ] ; xx [ 297 ] = xx [
289 ] * xx [ 93 ] + xx [ 92 ] * xx [ 290 ] ; xx [ 298 ] = xx [ 99 ] * xx [
289 ] + xx [ 290 ] * xx [ 109 ] ; xx [ 299 ] = xx [ 96 ] * xx [ 289 ] + xx [
60 ] * xx [ 290 ] ; pm_math_Matrix3x3_compose_ra ( xx + 113 , xx + 291 , xx +
300 ) ; xx [ 92 ] = 0.175 ; xx [ 93 ] = xx [ 159 ] * xx [ 27 ] ; xx [ 94 ] =
xx [ 93 ] * xx [ 27 ] ; xx [ 97 ] = xx [ 95 ] * xx [ 159 ] ; xx [ 110 ] = xx
[ 95 ] * xx [ 97 ] ; xx [ 277 ] = 0.02318121863740014 ; xx [ 279 ] = xx [ 97
] * xx [ 27 ] ; xx [ 281 ] = ( xx [ 279 ] + xx [ 61 ] * xx [ 93 ] ) * xx [ 5
] ; xx [ 93 ] = 0.06593894011863007 ; xx [ 282 ] = xx [ 5 ] * ( xx [ 94 ] -
xx [ 61 ] * xx [ 97 ] ) ; xx [ 289 ] = xx [ 92 ] - ( ( xx [ 94 ] + xx [ 110 ]
) * xx [ 5 ] - xx [ 159 ] ) ; xx [ 290 ] = xx [ 277 ] + xx [ 281 ] ; xx [ 291
] = - ( xx [ 93 ] + xx [ 282 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 189
, xx + 289 , xx + 309 ) ; xx [ 94 ] = 2.887984947699861e-3 ; xx [ 97 ] = xx [
94 ] * xx [ 39 ] ; xx [ 189 ] = xx [ 97 ] * xx [ 45 ] ; xx [ 292 ] = 0.085075
; xx [ 293 ] = xx [ 292 ] * xx [ 9 ] ; xx [ 294 ] = xx [ 293 ] * xx [ 9 ] ;
xx [ 295 ] = xx [ 38 ] * xx [ 292 ] ; xx [ 296 ] = xx [ 38 ] * xx [ 295 ] ;
xx [ 297 ] = 0.04846143235075162 ; xx [ 298 ] = xx [ 295 ] * xx [ 9 ] ; xx [
299 ] = ( xx [ 298 ] + xx [ 21 ] * xx [ 293 ] ) * xx [ 5 ] ; xx [ 293 ] =
0.03147761383263407 ; xx [ 318 ] = xx [ 5 ] * ( xx [ 294 ] - xx [ 21 ] * xx [
295 ] ) ; xx [ 319 ] = - ( xx [ 92 ] + ( xx [ 294 ] + xx [ 296 ] ) * xx [ 5 ]
- xx [ 292 ] ) ; xx [ 320 ] = - ( xx [ 297 ] + xx [ 299 ] ) ; xx [ 321 ] = -
( xx [ 293 ] + xx [ 318 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 66 , xx +
319 , xx + 322 ) ; xx [ 66 ] = xx [ 94 ] * xx [ 64 ] ; xx [ 294 ] = xx [ 66 ]
* xx [ 79 ] ; xx [ 295 ] = xx [ 292 ] * xx [ 57 ] ; xx [ 331 ] = xx [ 295 ] *
xx [ 57 ] ; xx [ 332 ] = xx [ 63 ] * xx [ 292 ] ; xx [ 333 ] = xx [ 63 ] * xx
[ 332 ] ; xx [ 334 ] = xx [ 332 ] * xx [ 57 ] ; xx [ 335 ] = ( xx [ 334 ] +
xx [ 58 ] * xx [ 295 ] ) * xx [ 5 ] ; xx [ 295 ] = xx [ 5 ] * ( xx [ 331 ] -
xx [ 58 ] * xx [ 332 ] ) ; xx [ 336 ] = xx [ 92 ] - ( ( xx [ 331 ] + xx [ 333
] ) * xx [ 5 ] - xx [ 292 ] ) ; xx [ 337 ] = - ( xx [ 297 ] + xx [ 335 ] ) ;
xx [ 338 ] = - ( xx [ 293 ] + xx [ 295 ] ) ; pm_math_Matrix3x3_postCross_ra (
xx + 100 , xx + 336 , xx + 339 ) ; xx [ 100 ] = xx [ 250 ] * xx [ 216 ] ; xx
[ 293 ] = xx [ 250 ] * xx [ 217 ] ; xx [ 297 ] = xx [ 226 ] * xx [ 250 ] ; xx
[ 226 ] = xx [ 293 ] + xx [ 143 ] * xx [ 297 ] ; xx [ 331 ] = xx [ 100 ] - xx
[ 226 ] * xx [ 231 ] ; xx [ 332 ] = xx [ 297 ] - xx [ 226 ] * xx [ 223 ] ; xx
[ 348 ] = xx [ 331 ] * xx [ 212 ] + xx [ 210 ] * xx [ 332 ] ; xx [ 349 ] = xx
[ 250 ] * xx [ 224 ] ; xx [ 350 ] = xx [ 250 ] * xx [ 237 ] ; xx [ 351 ] = xx
[ 349 ] + xx [ 143 ] * xx [ 350 ] ; xx [ 352 ] = xx [ 221 ] * xx [ 250 ] ; xx
[ 221 ] = xx [ 351 ] * xx [ 231 ] - xx [ 352 ] ; xx [ 353 ] = xx [ 351 ] * xx
[ 223 ] - xx [ 350 ] ; xx [ 354 ] = xx [ 212 ] * xx [ 221 ] + xx [ 210 ] * xx
[ 353 ] ; xx [ 355 ] = xx [ 212 ] * xx [ 348 ] + xx [ 210 ] * xx [ 354 ] ; xx
[ 356 ] = xx [ 226 ] / xx [ 230 ] ; xx [ 357 ] = xx [ 227 ] * xx [ 356 ] ; xx
[ 358 ] = ( xx [ 293 ] - xx [ 357 ] ) * xx [ 241 ] ; xx [ 293 ] = xx [ 351 ]
/ xx [ 230 ] ; xx [ 359 ] = xx [ 227 ] * xx [ 293 ] ; xx [ 360 ] = xx [ 241 ]
* ( xx [ 359 ] - xx [ 349 ] ) ; xx [ 349 ] = xx [ 332 ] * xx [ 212 ] - xx [
210 ] * xx [ 331 ] ; xx [ 331 ] = xx [ 212 ] * xx [ 353 ] - xx [ 210 ] * xx [
221 ] ; xx [ 221 ] = xx [ 349 ] * xx [ 212 ] + xx [ 331 ] * xx [ 210 ] ; xx [
332 ] = xx [ 246 ] * xx [ 355 ] + xx [ 244 ] * xx [ 221 ] ; xx [ 353 ] = xx [
358 ] * xx [ 212 ] + xx [ 210 ] * xx [ 360 ] + xx [ 332 ] ; xx [ 361 ] = xx [
353 ] + xx [ 159 ] * xx [ 221 ] ; xx [ 362 ] = xx [ 355 ] - xx [ 361 ] * xx [
238 ] ; xx [ 363 ] = xx [ 221 ] - xx [ 361 ] * xx [ 249 ] ; xx [ 364 ] = xx [
140 ] * xx [ 214 ] ; xx [ 214 ] = xx [ 364 ] * xx [ 241 ] ; xx [ 365 ] = xx [
210 ] * xx [ 214 ] ; xx [ 366 ] = xx [ 246 ] * xx [ 127 ] ; xx [ 367 ] = xx [
365 ] + xx [ 366 ] ; xx [ 368 ] = xx [ 212 ] * xx [ 354 ] - xx [ 210 ] * xx [
348 ] ; xx [ 348 ] = xx [ 331 ] * xx [ 212 ] - xx [ 349 ] * xx [ 210 ] ; xx [
331 ] = xx [ 368 ] * xx [ 246 ] + xx [ 348 ] * xx [ 244 ] ; xx [ 349 ] = xx [
360 ] * xx [ 212 ] - xx [ 210 ] * xx [ 358 ] + xx [ 331 ] ; xx [ 354 ] = xx [
349 ] + xx [ 348 ] * xx [ 159 ] ; xx [ 358 ] = xx [ 368 ] - xx [ 354 ] * xx [
238 ] ; xx [ 360 ] = xx [ 348 ] - xx [ 354 ] * xx [ 249 ] ; xx [ 369 ] = xx [
214 ] * xx [ 212 ] ; xx [ 214 ] = xx [ 244 ] * xx [ 127 ] ; xx [ 127 ] = xx [
369 ] + xx [ 214 ] ; xx [ 370 ] = xx [ 235 ] - xx [ 167 ] * xx [ 238 ] ; xx [
371 ] = xx [ 211 ] - xx [ 167 ] * xx [ 249 ] ; xx [ 372 ] = xx [ 175 ] * xx [
362 ] + xx [ 181 ] * xx [ 363 ] - xx [ 184 ] * xx [ 367 ] ; xx [ 373 ] = xx [
186 ] * xx [ 362 ] + xx [ 187 ] * xx [ 363 ] - xx [ 188 ] * xx [ 367 ] ; xx [
374 ] = xx [ 183 ] * xx [ 362 ] + xx [ 8 ] * xx [ 363 ] - xx [ 176 ] * xx [
367 ] ; xx [ 375 ] = xx [ 358 ] * xx [ 175 ] + xx [ 181 ] * xx [ 360 ] - xx [
127 ] * xx [ 184 ] ; xx [ 376 ] = xx [ 186 ] * xx [ 358 ] + xx [ 360 ] * xx [
187 ] - xx [ 127 ] * xx [ 188 ] ; xx [ 377 ] = xx [ 183 ] * xx [ 358 ] + xx [
8 ] * xx [ 360 ] - xx [ 127 ] * xx [ 176 ] ; xx [ 378 ] = xx [ 370 ] * xx [
175 ] + xx [ 181 ] * xx [ 371 ] ; xx [ 379 ] = xx [ 186 ] * xx [ 370 ] + xx [
371 ] * xx [ 187 ] ; xx [ 380 ] = xx [ 183 ] * xx [ 370 ] + xx [ 8 ] * xx [
371 ] ; pm_math_Matrix3x3_compose_ra ( xx + 200 , xx + 372 , xx + 381 ) ; xx
[ 175 ] = xx [ 159 ] * xx [ 174 ] ; xx [ 176 ] = xx [ 175 ] * xx [ 174 ] ; xx
[ 181 ] = xx [ 182 ] * xx [ 159 ] ; xx [ 184 ] = xx [ 182 ] * xx [ 181 ] ; xx
[ 188 ] = xx [ 181 ] * xx [ 174 ] ; xx [ 358 ] = ( xx [ 188 ] + xx [ 22 ] *
xx [ 175 ] ) * xx [ 5 ] ; xx [ 175 ] = xx [ 5 ] * ( xx [ 176 ] - xx [ 22 ] *
xx [ 181 ] ) ; xx [ 370 ] = - ( xx [ 92 ] + ( xx [ 176 ] + xx [ 184 ] ) * xx
[ 5 ] - xx [ 159 ] ) ; xx [ 371 ] = xx [ 277 ] + xx [ 358 ] ; xx [ 372 ] = -
( xx [ 93 ] + xx [ 175 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 264 , xx +
370 , xx + 390 ) ; xx [ 92 ] = xx [ 303 ] - xx [ 310 ] - ( xx [ 189 ] + xx [
323 ] + xx [ 294 ] + xx [ 340 ] ) + xx [ 384 ] - xx [ 391 ] ; xx [ 93 ] = xx
[ 97 ] * xx [ 24 ] ; xx [ 176 ] = xx [ 66 ] * xx [ 59 ] ; xx [ 181 ] = xx [
306 ] - xx [ 311 ] - ( xx [ 93 ] + xx [ 324 ] + xx [ 176 ] + xx [ 341 ] ) +
xx [ 387 ] - xx [ 392 ] ; xx [ 264 ] = xx [ 91 ] * xx [ 243 ] - ( xx [ 92 ] *
xx [ 20 ] + xx [ 181 ] * xx [ 23 ] ) ; xx [ 277 ] = 5.062499999999979e-6 ; xx
[ 360 ] = 3.28230253125e-4 ; xx [ 362 ] = 2.456953194255657e-4 ; xx [ 399 ] =
xx [ 277 ] * xx [ 37 ] ; xx [ 400 ] = - ( xx [ 277 ] * xx [ 43 ] ) ; xx [ 401
] = xx [ 277 ] * xx [ 40 ] ; xx [ 402 ] = xx [ 360 ] * xx [ 39 ] ; xx [ 403 ]
= xx [ 360 ] * xx [ 44 ] ; xx [ 404 ] = - ( xx [ 360 ] * xx [ 47 ] ) ; xx [
405 ] = xx [ 362 ] * xx [ 41 ] ; xx [ 406 ] = xx [ 362 ] * xx [ 45 ] ; xx [
407 ] = xx [ 362 ] * xx [ 24 ] ; pm_math_Matrix3x3_compose_ra ( xx + 48 , xx
+ 399 , xx + 408 ) ; xx [ 37 ] = xx [ 41 ] * xx [ 97 ] ; xx [ 39 ] = xx [ 94
] * xx [ 44 ] ; xx [ 40 ] = xx [ 41 ] * xx [ 39 ] ; xx [ 43 ] = xx [ 94 ] *
xx [ 47 ] ; xx [ 44 ] = xx [ 41 ] * xx [ 43 ] ; xx [ 41 ] = xx [ 39 ] * xx [
45 ] ; xx [ 47 ] = xx [ 43 ] * xx [ 45 ] ; xx [ 45 ] = xx [ 39 ] * xx [ 24 ]
; xx [ 39 ] = xx [ 43 ] * xx [ 24 ] ; xx [ 48 ] = - xx [ 37 ] ; xx [ 49 ] = -
xx [ 40 ] ; xx [ 50 ] = xx [ 44 ] ; xx [ 51 ] = - xx [ 189 ] ; xx [ 52 ] = -
xx [ 41 ] ; xx [ 53 ] = xx [ 47 ] ; xx [ 54 ] = - xx [ 93 ] ; xx [ 55 ] = -
xx [ 45 ] ; xx [ 56 ] = xx [ 39 ] ; pm_math_Matrix3x3_postCross_ra ( xx + 48
, xx + 319 , xx + 399 ) ; pm_math_Matrix3x3_preCross_ra ( xx + 322 , xx + 319
, xx + 48 ) ; xx [ 417 ] = xx [ 277 ] * xx [ 62 ] ; xx [ 418 ] = - ( xx [ 277
] * xx [ 77 ] ) ; xx [ 419 ] = xx [ 277 ] * xx [ 65 ] ; xx [ 420 ] = xx [ 360
] * xx [ 64 ] ; xx [ 421 ] = xx [ 360 ] * xx [ 78 ] ; xx [ 422 ] = - ( xx [
360 ] * xx [ 81 ] ) ; xx [ 423 ] = xx [ 362 ] * xx [ 75 ] ; xx [ 424 ] = xx [
362 ] * xx [ 79 ] ; xx [ 425 ] = xx [ 362 ] * xx [ 59 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 82 , xx + 417 , xx + 426 ) ; xx [ 24 ] =
xx [ 75 ] * xx [ 66 ] ; xx [ 43 ] = xx [ 94 ] * xx [ 78 ] ; xx [ 62 ] = xx [
75 ] * xx [ 43 ] ; xx [ 64 ] = xx [ 94 ] * xx [ 81 ] ; xx [ 65 ] = xx [ 75 ]
* xx [ 64 ] ; xx [ 66 ] = xx [ 43 ] * xx [ 79 ] ; xx [ 75 ] = xx [ 64 ] * xx
[ 79 ] ; xx [ 77 ] = xx [ 43 ] * xx [ 59 ] ; xx [ 43 ] = xx [ 64 ] * xx [ 59
] ; xx [ 81 ] = - xx [ 24 ] ; xx [ 82 ] = - xx [ 62 ] ; xx [ 83 ] = xx [ 65 ]
; xx [ 84 ] = - xx [ 294 ] ; xx [ 85 ] = - xx [ 66 ] ; xx [ 86 ] = xx [ 75 ]
; xx [ 87 ] = - xx [ 176 ] ; xx [ 88 ] = - xx [ 77 ] ; xx [ 89 ] = xx [ 43 ]
; pm_math_Matrix3x3_postCross_ra ( xx + 81 , xx + 336 , xx + 417 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 339 , xx + 336 , xx + 81 ) ; xx [ 59 ] =
5.429019142918786e-6 ; xx [ 64 ] = 1.049151914291881e-5 ; xx [ 78 ] =
1.978272748043166e-3 ; xx [ 79 ] = xx [ 78 ] * xx [ 132 ] ; xx [ 90 ] = xx [
79 ] * xx [ 132 ] ; xx [ 93 ] = xx [ 78 ] * xx [ 129 ] ; xx [ 94 ] = xx [ 93
] * xx [ 129 ] ; xx [ 97 ] = xx [ 64 ] + xx [ 90 ] + xx [ 94 ] + xx [ 250 ] *
xx [ 252 ] ; xx [ 176 ] = xx [ 97 ] - xx [ 146 ] * xx [ 275 ] ; xx [ 189 ] =
xx [ 93 ] * xx [ 132 ] ; xx [ 93 ] = xx [ 79 ] * xx [ 129 ] ; xx [ 79 ] = xx
[ 189 ] - xx [ 93 ] - xx [ 250 ] * xx [ 260 ] ; xx [ 129 ] = xx [ 261 ] * xx
[ 275 ] ; xx [ 132 ] = xx [ 79 ] + xx [ 129 ] ; xx [ 294 ] = xx [ 176 ] * xx
[ 126 ] + xx [ 132 ] * xx [ 124 ] ; xx [ 323 ] = xx [ 93 ] - xx [ 189 ] - xx
[ 250 ] * xx [ 255 ] ; xx [ 93 ] = xx [ 323 ] + xx [ 129 ] ; xx [ 129 ] =
1.0493175500148e-3 ; xx [ 189 ] = xx [ 129 ] + xx [ 94 ] + xx [ 90 ] + xx [
250 ] * xx [ 259 ] + xx [ 140 ] * xx [ 283 ] ; xx [ 90 ] = xx [ 189 ] - xx [
261 ] * xx [ 251 ] ; xx [ 94 ] = xx [ 93 ] * xx [ 126 ] + xx [ 124 ] * xx [
90 ] ; xx [ 324 ] = xx [ 166 ] * xx [ 284 ] ; xx [ 340 ] = xx [ 59 ] + xx [
126 ] * xx [ 294 ] + xx [ 124 ] * xx [ 94 ] + xx [ 324 ] + xx [ 324 ] + xx [
166 ] * xx [ 285 ] ; xx [ 324 ] = xx [ 280 ] / xx [ 156 ] ; xx [ 341 ] = xx [
132 ] * xx [ 126 ] - xx [ 124 ] * xx [ 176 ] ; xx [ 132 ] = xx [ 90 ] * xx [
126 ] - xx [ 93 ] * xx [ 124 ] ; xx [ 90 ] = xx [ 164 ] * xx [ 284 ] ; xx [
93 ] = xx [ 166 ] * xx [ 288 ] ; xx [ 176 ] = xx [ 341 ] * xx [ 126 ] + xx [
132 ] * xx [ 124 ] + xx [ 90 ] + xx [ 93 ] + xx [ 131 ] * xx [ 166 ] ; xx [
284 ] = xx [ 273 ] * xx [ 324 ] ; xx [ 362 ] = xx [ 137 ] * xx [ 324 ] ; xx [
363 ] = xx [ 94 ] * xx [ 126 ] - xx [ 124 ] * xx [ 294 ] + xx [ 93 ] + xx [
90 ] + xx [ 164 ] * xx [ 285 ] ; xx [ 90 ] = 3.489909396502681e-4 ; xx [ 93 ]
= xx [ 164 ] * xx [ 288 ] ; xx [ 94 ] = xx [ 90 ] + xx [ 132 ] * xx [ 126 ] -
xx [ 341 ] * xx [ 124 ] + xx [ 93 ] + xx [ 93 ] + xx [ 164 ] * xx [ 131 ] ;
xx [ 93 ] = xx [ 273 ] / xx [ 156 ] ; xx [ 131 ] = xx [ 137 ] * xx [ 93 ] ;
xx [ 132 ] = xx [ 140 ] * xx [ 252 ] ; xx [ 285 ] = xx [ 276 ] - xx [ 132 ] ;
xx [ 276 ] = xx [ 140 ] * xx [ 260 ] ; xx [ 288 ] = xx [ 276 ] - xx [ 278 ] ;
xx [ 278 ] = xx [ 161 ] * ( xx [ 285 ] * xx [ 126 ] + xx [ 124 ] * xx [ 288 ]
) + xx [ 262 ] ; xx [ 262 ] = ( xx [ 288 ] * xx [ 126 ] - xx [ 124 ] * xx [
285 ] ) * xx [ 161 ] + xx [ 138 ] ; xx [ 138 ] = xx [ 137 ] / xx [ 156 ] ; xx
[ 435 ] = xx [ 340 ] - xx [ 280 ] * xx [ 324 ] ; xx [ 436 ] = xx [ 176 ] - xx
[ 284 ] ; xx [ 437 ] = xx [ 263 ] - xx [ 362 ] ; xx [ 438 ] = xx [ 363 ] - xx
[ 284 ] ; xx [ 439 ] = xx [ 94 ] - xx [ 273 ] * xx [ 93 ] ; xx [ 440 ] = xx [
256 ] - xx [ 131 ] ; xx [ 441 ] = xx [ 278 ] - xx [ 362 ] ; xx [ 442 ] = xx [
262 ] - xx [ 131 ] ; xx [ 443 ] = xx [ 158 ] - xx [ 137 ] * xx [ 138 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 435 , xx + 113 , xx + 444 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 113 , xx + 444 , xx + 435 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 300 , xx + 289 , xx + 113 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 309 , xx + 289 , xx + 444 ) ; xx [ 131 ]
= 0.1028383952748681 ; xx [ 158 ] = xx [ 78 ] * xx [ 215 ] ; xx [ 161 ] = xx
[ 158 ] * xx [ 215 ] ; xx [ 256 ] = xx [ 78 ] * xx [ 213 ] ; xx [ 263 ] = xx
[ 256 ] * xx [ 213 ] ; xx [ 284 ] = xx [ 64 ] + xx [ 161 ] + xx [ 263 ] + xx
[ 250 ] * xx [ 297 ] ; xx [ 285 ] = xx [ 284 ] - xx [ 226 ] * xx [ 356 ] ; xx
[ 288 ] = xx [ 256 ] * xx [ 215 ] ; xx [ 215 ] = xx [ 158 ] * xx [ 213 ] ; xx
[ 158 ] = xx [ 288 ] - xx [ 215 ] - xx [ 250 ] * xx [ 350 ] ; xx [ 213 ] = xx
[ 351 ] * xx [ 356 ] ; xx [ 256 ] = xx [ 158 ] + xx [ 213 ] ; xx [ 294 ] = xx
[ 285 ] * xx [ 212 ] + xx [ 256 ] * xx [ 210 ] ; xx [ 303 ] = xx [ 215 ] - xx
[ 288 ] - xx [ 250 ] * xx [ 100 ] ; xx [ 215 ] = xx [ 303 ] + xx [ 213 ] ; xx
[ 213 ] = xx [ 129 ] + xx [ 263 ] + xx [ 161 ] + xx [ 250 ] * xx [ 352 ] + xx
[ 140 ] * xx [ 364 ] ; xx [ 161 ] = xx [ 213 ] - xx [ 351 ] * xx [ 293 ] ; xx
[ 263 ] = xx [ 215 ] * xx [ 212 ] + xx [ 210 ] * xx [ 161 ] ; xx [ 288 ] = xx
[ 246 ] * xx [ 365 ] ; xx [ 306 ] = xx [ 59 ] + xx [ 212 ] * xx [ 294 ] + xx
[ 210 ] * xx [ 263 ] + xx [ 288 ] + xx [ 288 ] + xx [ 246 ] * xx [ 366 ] ; xx
[ 288 ] = xx [ 361 ] / xx [ 236 ] ; xx [ 310 ] = xx [ 256 ] * xx [ 212 ] - xx
[ 210 ] * xx [ 285 ] ; xx [ 256 ] = xx [ 161 ] * xx [ 212 ] - xx [ 215 ] * xx
[ 210 ] ; xx [ 161 ] = xx [ 244 ] * xx [ 365 ] ; xx [ 215 ] = xx [ 246 ] * xx
[ 369 ] ; xx [ 285 ] = xx [ 310 ] * xx [ 212 ] + xx [ 256 ] * xx [ 210 ] + xx
[ 161 ] + xx [ 215 ] + xx [ 214 ] * xx [ 246 ] ; xx [ 311 ] = xx [ 354 ] * xx
[ 288 ] ; xx [ 341 ] = xx [ 167 ] * xx [ 288 ] ; xx [ 362 ] = xx [ 263 ] * xx
[ 212 ] - xx [ 210 ] * xx [ 294 ] + xx [ 215 ] + xx [ 161 ] + xx [ 244 ] * xx
[ 366 ] ; xx [ 161 ] = xx [ 244 ] * xx [ 369 ] ; xx [ 215 ] = xx [ 90 ] + xx
[ 256 ] * xx [ 212 ] - xx [ 310 ] * xx [ 210 ] + xx [ 161 ] + xx [ 161 ] + xx
[ 244 ] * xx [ 214 ] ; xx [ 161 ] = xx [ 354 ] / xx [ 236 ] ; xx [ 214 ] = xx
[ 167 ] * xx [ 161 ] ; xx [ 256 ] = xx [ 140 ] * xx [ 297 ] ; xx [ 263 ] = xx
[ 256 ] - xx [ 357 ] ; xx [ 294 ] = xx [ 140 ] * xx [ 350 ] ; xx [ 310 ] = xx
[ 359 ] - xx [ 294 ] ; xx [ 357 ] = xx [ 241 ] * ( xx [ 263 ] * xx [ 212 ] +
xx [ 210 ] * xx [ 310 ] ) + xx [ 332 ] ; xx [ 332 ] = ( xx [ 212 ] * xx [ 310
] - xx [ 210 ] * xx [ 263 ] ) * xx [ 241 ] + xx [ 331 ] ; xx [ 241 ] = xx [
167 ] / xx [ 236 ] ; xx [ 453 ] = xx [ 306 ] - xx [ 361 ] * xx [ 288 ] ; xx [
454 ] = xx [ 285 ] - xx [ 311 ] ; xx [ 455 ] = xx [ 353 ] - xx [ 341 ] ; xx [
456 ] = xx [ 362 ] - xx [ 311 ] ; xx [ 457 ] = xx [ 215 ] - xx [ 354 ] * xx [
161 ] ; xx [ 458 ] = xx [ 349 ] - xx [ 214 ] ; xx [ 459 ] = xx [ 357 ] - xx [
341 ] ; xx [ 460 ] = xx [ 332 ] - xx [ 214 ] ; xx [ 461 ] = xx [ 232 ] - xx [
167 ] * xx [ 241 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 453 , xx +
200 , xx + 462 ) ; pm_math_Matrix3x3_compose_ra ( xx + 200 , xx + 462 , xx +
453 ) ; pm_math_Matrix3x3_postCross_ra ( xx + 381 , xx + 370 , xx + 200 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 390 , xx + 370 , xx + 462 ) ; xx [ 214 ]
= xx [ 412 ] - xx [ 403 ] - xx [ 403 ] - xx [ 52 ] + xx [ 430 ] - xx [ 421 ]
- xx [ 421 ] - xx [ 85 ] + xx [ 439 ] - xx [ 117 ] - xx [ 117 ] - xx [ 448 ]
+ xx [ 131 ] + xx [ 457 ] - xx [ 204 ] - xx [ 204 ] - xx [ 466 ] ; xx [ 232 ]
= xx [ 413 ] - xx [ 404 ] - xx [ 406 ] - xx [ 53 ] + xx [ 431 ] - xx [ 422 ]
- xx [ 424 ] - xx [ 86 ] + xx [ 440 ] - xx [ 118 ] - xx [ 120 ] - xx [ 449 ]
+ xx [ 458 ] - xx [ 205 ] - xx [ 207 ] - xx [ 467 ] ; xx [ 263 ] = xx [ 92 ]
* xx [ 243 ] - ( xx [ 214 ] * xx [ 20 ] + xx [ 232 ] * xx [ 23 ] ) ; xx [ 310
] = xx [ 415 ] - xx [ 406 ] - xx [ 404 ] - xx [ 55 ] + xx [ 433 ] - xx [ 424
] - xx [ 422 ] - xx [ 88 ] + xx [ 442 ] - xx [ 120 ] - xx [ 118 ] - xx [ 451
] + xx [ 460 ] - xx [ 207 ] - xx [ 205 ] - xx [ 469 ] ; xx [ 311 ] =
0.1028074313979146 ; xx [ 331 ] = xx [ 416 ] - xx [ 407 ] - xx [ 407 ] - xx [
56 ] + xx [ 434 ] - xx [ 425 ] - xx [ 425 ] - xx [ 89 ] + xx [ 443 ] - xx [
121 ] - xx [ 121 ] - xx [ 452 ] + xx [ 311 ] + xx [ 461 ] - xx [ 208 ] - xx [
208 ] - xx [ 470 ] ; xx [ 341 ] = xx [ 181 ] * xx [ 243 ] - ( xx [ 310 ] * xx
[ 20 ] + xx [ 331 ] * xx [ 23 ] ) ; xx [ 349 ] = xx [ 264 ] * xx [ 243 ] - (
xx [ 263 ] * xx [ 20 ] + xx [ 341 ] * xx [ 23 ] ) ; ii [ 0 ] =
factorSymmetricPosDef ( xx + 349 , 1 , xx + 353 ) ; if ( ii [ 0 ] != 0 ) {
return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Roll' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 353 ] = xx [ 264 ] / xx [ 349 ] ; xx [ 359 ] = xx [ 67
] + xx [ 101 ] + xx [ 190 ] + xx [ 265 ] ; xx [ 67 ] = xx [ 69 ] + xx [ 103 ]
+ xx [ 192 ] + xx [ 267 ] ; xx [ 69 ] = xx [ 304 ] - xx [ 313 ] - ( xx [ 41 ]
+ xx [ 326 ] + xx [ 66 ] + xx [ 343 ] ) + xx [ 385 ] - xx [ 394 ] ; xx [ 41 ]
= xx [ 307 ] - xx [ 314 ] - ( xx [ 45 ] + xx [ 327 ] + xx [ 77 ] + xx [ 344 ]
) + xx [ 388 ] - xx [ 395 ] ; xx [ 45 ] = xx [ 67 ] * xx [ 243 ] - ( xx [ 69
] * xx [ 20 ] + xx [ 41 ] * xx [ 23 ] ) ; xx [ 66 ] = xx [ 45 ] * xx [ 353 ]
; xx [ 77 ] = xx [ 68 ] + xx [ 102 ] + xx [ 191 ] + xx [ 266 ] ; xx [ 68 ] =
xx [ 72 ] + xx [ 106 ] + xx [ 195 ] + xx [ 270 ] ; xx [ 72 ] = xx [ 47 ] - xx
[ 329 ] + xx [ 75 ] - xx [ 346 ] + xx [ 305 ] - xx [ 316 ] + xx [ 386 ] - xx
[ 397 ] ; xx [ 47 ] = xx [ 39 ] - xx [ 330 ] + xx [ 43 ] - xx [ 347 ] + xx [
308 ] - xx [ 317 ] + xx [ 389 ] - xx [ 398 ] ; xx [ 39 ] = xx [ 68 ] * xx [
243 ] - ( xx [ 72 ] * xx [ 20 ] + xx [ 47 ] * xx [ 23 ] ) ; xx [ 43 ] = xx [
39 ] * xx [ 353 ] ; xx [ 75 ] = xx [ 70 ] + xx [ 104 ] + xx [ 193 ] + xx [
169 ] + xx [ 268 ] ; xx [ 70 ] = xx [ 45 ] / xx [ 349 ] ; xx [ 101 ] = xx [
71 ] + xx [ 105 ] + xx [ 194 ] + xx [ 269 ] ; xx [ 71 ] = xx [ 39 ] * xx [ 70
] ; xx [ 102 ] = xx [ 73 ] + xx [ 107 ] + xx [ 196 ] + xx [ 271 ] ; xx [ 73 ]
= xx [ 74 ] + xx [ 108 ] + xx [ 197 ] + xx [ 169 ] + xx [ 272 ] ; xx [ 74 ] =
xx [ 39 ] / xx [ 349 ] ; xx [ 471 ] = xx [ 91 ] - xx [ 264 ] * xx [ 353 ] ;
xx [ 472 ] = xx [ 359 ] - xx [ 66 ] ; xx [ 473 ] = xx [ 77 ] - xx [ 43 ] ; xx
[ 474 ] = xx [ 67 ] - xx [ 66 ] ; xx [ 475 ] = xx [ 75 ] - xx [ 45 ] * xx [
70 ] ; xx [ 476 ] = xx [ 101 ] - xx [ 71 ] ; xx [ 477 ] = xx [ 68 ] - xx [ 43
] ; xx [ 478 ] = xx [ 102 ] - xx [ 71 ] ; xx [ 479 ] = xx [ 73 ] - xx [ 39 ]
* xx [ 74 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 471 , xx + 28 , xx
+ 480 ) ; pm_math_Matrix3x3_compose_ra ( xx + 28 , xx + 480 , xx + 471 ) ; xx
[ 43 ] = xx [ 300 ] - xx [ 309 ] - ( xx [ 37 ] + xx [ 322 ] + xx [ 24 ] + xx
[ 339 ] ) + xx [ 381 ] - xx [ 390 ] ; xx [ 24 ] = xx [ 409 ] - xx [ 400 ] -
xx [ 402 ] - xx [ 49 ] + xx [ 427 ] - xx [ 418 ] - xx [ 420 ] - xx [ 82 ] +
xx [ 436 ] - xx [ 114 ] - xx [ 116 ] - xx [ 445 ] + xx [ 454 ] - xx [ 201 ] -
xx [ 203 ] - xx [ 463 ] ; xx [ 37 ] = xx [ 410 ] - xx [ 401 ] - xx [ 405 ] -
xx [ 50 ] + xx [ 428 ] - xx [ 419 ] - xx [ 423 ] - xx [ 83 ] + xx [ 437 ] -
xx [ 115 ] - xx [ 119 ] - xx [ 446 ] + xx [ 455 ] - xx [ 202 ] - xx [ 206 ] -
xx [ 464 ] ; xx [ 66 ] = xx [ 43 ] * xx [ 243 ] - ( xx [ 24 ] * xx [ 20 ] +
xx [ 37 ] * xx [ 23 ] ) ; xx [ 71 ] = xx [ 301 ] - xx [ 312 ] - ( xx [ 40 ] +
xx [ 325 ] + xx [ 62 ] + xx [ 342 ] ) + xx [ 382 ] - xx [ 393 ] ; xx [ 40 ] =
xx [ 44 ] - xx [ 328 ] + xx [ 65 ] - xx [ 345 ] + xx [ 302 ] - xx [ 315 ] +
xx [ 383 ] - xx [ 396 ] ; xx [ 373 ] = xx [ 43 ] - xx [ 66 ] * xx [ 353 ] ;
xx [ 374 ] = xx [ 71 ] - xx [ 66 ] * xx [ 70 ] ; xx [ 375 ] = xx [ 40 ] - xx
[ 66 ] * xx [ 74 ] ; xx [ 376 ] = xx [ 92 ] - xx [ 263 ] * xx [ 353 ] ; xx [
377 ] = xx [ 69 ] - xx [ 263 ] * xx [ 70 ] ; xx [ 378 ] = xx [ 72 ] - xx [
263 ] * xx [ 74 ] ; xx [ 379 ] = xx [ 181 ] - xx [ 341 ] * xx [ 353 ] ; xx [
380 ] = xx [ 41 ] - xx [ 341 ] * xx [ 70 ] ; xx [ 381 ] = xx [ 47 ] - xx [
341 ] * xx [ 74 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 373 , xx +
28 , xx + 382 ) ; pm_math_Matrix3x3_compose_ra ( xx + 28 , xx + 382 , xx +
373 ) ; xx [ 44 ] = 9.889425053924039e-3 ; xx [ 62 ] = 0.0284344275538308 ;
xx [ 65 ] = xx [ 10 ] * xx [ 44 ] - xx [ 62 ] * xx [ 4 ] ; xx [ 103 ] = - xx
[ 4 ] ; xx [ 104 ] = xx [ 2 ] ; xx [ 105 ] = xx [ 103 ] ; xx [ 106 ] = xx [
10 ] ; xx [ 107 ] = xx [ 62 ] * xx [ 2 ] ; xx [ 108 ] = xx [ 44 ] * xx [ 2 ]
; xx [ 190 ] = xx [ 65 ] ; xx [ 191 ] = - xx [ 107 ] ; xx [ 192 ] = - xx [
108 ] ; pm_math_Vector3_cross_ra ( xx + 104 , xx + 190 , xx + 193 ) ; xx [
169 ] = ( xx [ 65 ] * xx [ 25 ] + xx [ 193 ] ) * xx [ 5 ] ; xx [ 65 ] = xx [
62 ] + ( xx [ 195 ] - xx [ 108 ] * xx [ 25 ] ) * xx [ 5 ] ; xx [ 190 ] = - xx
[ 169 ] ; xx [ 191 ] = - ( xx [ 5 ] * ( xx [ 194 ] - xx [ 107 ] * xx [ 25 ] )
- xx [ 44 ] ) ; xx [ 192 ] = - xx [ 65 ] ; pm_math_Matrix3x3_postCross_ra (
xx + 471 , xx + 190 , xx + 382 ) ; xx [ 44 ] = xx [ 376 ] - xx [ 383 ] ; xx [
62 ] = 0.05410477075644175 ; xx [ 107 ] = xx [ 408 ] - xx [ 399 ] - xx [ 399
] - xx [ 48 ] + xx [ 426 ] - xx [ 417 ] - xx [ 417 ] - xx [ 81 ] + xx [ 435 ]
- xx [ 113 ] - xx [ 113 ] - xx [ 444 ] + xx [ 62 ] + xx [ 453 ] - xx [ 200 ]
- xx [ 200 ] - xx [ 462 ] ; xx [ 108 ] = xx [ 66 ] / xx [ 349 ] ; xx [ 113 ]
= xx [ 263 ] * xx [ 108 ] ; xx [ 117 ] = xx [ 341 ] * xx [ 108 ] ; xx [ 118 ]
= xx [ 411 ] - xx [ 402 ] - xx [ 400 ] - xx [ 51 ] + xx [ 429 ] - xx [ 420 ]
- xx [ 418 ] - xx [ 84 ] + xx [ 438 ] - xx [ 116 ] - xx [ 114 ] - xx [ 447 ]
+ xx [ 456 ] - xx [ 203 ] - xx [ 201 ] - xx [ 465 ] ; xx [ 114 ] = xx [ 263 ]
/ xx [ 349 ] ; xx [ 116 ] = xx [ 341 ] * xx [ 114 ] ; xx [ 48 ] = xx [ 414 ]
- xx [ 405 ] - xx [ 401 ] - xx [ 54 ] + xx [ 432 ] - xx [ 423 ] - xx [ 419 ]
- xx [ 87 ] + xx [ 441 ] - xx [ 119 ] - xx [ 115 ] - xx [ 450 ] + xx [ 459 ]
- xx [ 206 ] - xx [ 202 ] - xx [ 468 ] ; xx [ 49 ] = xx [ 341 ] / xx [ 349 ]
; xx [ 81 ] = xx [ 107 ] - xx [ 66 ] * xx [ 108 ] ; xx [ 82 ] = xx [ 24 ] -
xx [ 113 ] ; xx [ 83 ] = xx [ 37 ] - xx [ 117 ] ; xx [ 84 ] = xx [ 118 ] - xx
[ 113 ] ; xx [ 85 ] = xx [ 214 ] - xx [ 263 ] * xx [ 114 ] ; xx [ 86 ] = xx [
232 ] - xx [ 116 ] ; xx [ 87 ] = xx [ 48 ] - xx [ 117 ] ; xx [ 88 ] = xx [
310 ] - xx [ 116 ] ; xx [ 89 ] = xx [ 331 ] - xx [ 341 ] * xx [ 49 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 81 , xx + 28 , xx + 200 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 28 , xx + 200 , xx + 81 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 373 , xx + 190 , xx + 28 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 382 , xx + 190 , xx + 200 ) ; xx [ 50 ]
= xx [ 85 ] - xx [ 32 ] - xx [ 32 ] - xx [ 204 ] ; memcpy ( xx + 51 , xx + 50
, 1 * sizeof ( double ) ) ; ii [ 0 ] = factorSymmetricPosDef ( xx + 51 , 1 ,
xx + 52 ) ; if ( ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/pitch' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 52 ] = xx [ 44 ] / xx [ 51 ] ; xx [ 53 ] = xx [ 377 ]
- xx [ 386 ] ; xx [ 54 ] = xx [ 52 ] * xx [ 53 ] ; xx [ 55 ] = xx [ 378 ] -
xx [ 389 ] ; xx [ 56 ] = xx [ 52 ] * xx [ 55 ] ; xx [ 113 ] = xx [ 53 ] / xx
[ 51 ] ; xx [ 115 ] = xx [ 113 ] * xx [ 55 ] ; xx [ 116 ] = xx [ 55 ] / xx [
51 ] ; xx [ 391 ] = xx [ 471 ] - xx [ 52 ] * xx [ 44 ] ; xx [ 392 ] = xx [
472 ] - xx [ 54 ] ; xx [ 393 ] = xx [ 473 ] - xx [ 56 ] ; xx [ 394 ] = xx [
474 ] - xx [ 54 ] ; xx [ 395 ] = xx [ 475 ] - xx [ 113 ] * xx [ 53 ] ; xx [
396 ] = xx [ 476 ] - xx [ 115 ] ; xx [ 397 ] = xx [ 477 ] - xx [ 56 ] ; xx [
398 ] = xx [ 478 ] - xx [ 115 ] ; xx [ 399 ] = xx [ 479 ] - xx [ 116 ] * xx [
55 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 391 , xx + 11 , xx + 400
) ; pm_math_Matrix3x3_compose_ra ( xx + 11 , xx + 400 , xx + 391 ) ; xx [ 400
] = xx [ 391 ] ; xx [ 401 ] = xx [ 392 ] ; xx [ 402 ] = xx [ 393 ] ; xx [ 403
] = xx [ 392 ] ; xx [ 404 ] = xx [ 395 ] ; xx [ 405 ] = xx [ 396 ] ; xx [ 406
] = xx [ 393 ] ; xx [ 407 ] = xx [ 396 ] ; xx [ 408 ] = xx [ 399 ] ; ii [ 0 ]
= factorSymmetricPosDef ( xx + 400 , 3 , xx + 119 ) ; if ( ii [ 0 ] != 0 ) {
return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Cartesian Joint1' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 193 ] = xx [ 3 ] ; xx [ 194 ] = xx [ 3 ] ; xx [ 195 ]
= xx [ 7 ] ; xx [ 196 ] = xx [ 7 ] ; xx [ 265 ] = xx [ 25 ] ; xx [ 266 ] = xx
[ 2 ] ; xx [ 267 ] = xx [ 103 ] ; xx [ 268 ] = xx [ 10 ] ; xx [ 269 ] = xx [
9 ] ; xx [ 270 ] = - xx [ 21 ] ; xx [ 271 ] = xx [ 9 ] ; xx [ 272 ] = - xx [
38 ] ; xx [ 54 ] = xx [ 10 ] * state [ 7 ] ; xx [ 56 ] = xx [ 2 ] * state [ 7
] ; xx [ 103 ] = ( xx [ 54 ] * xx [ 25 ] - xx [ 56 ] * xx [ 4 ] ) * xx [ 5 ]
; xx [ 115 ] = state [ 7 ] - ( xx [ 10 ] * xx [ 54 ] + xx [ 56 ] * xx [ 2 ] )
* xx [ 5 ] ; xx [ 117 ] = xx [ 20 ] * state [ 9 ] ; xx [ 119 ] = xx [ 115 ] -
xx [ 117 ] ; xx [ 120 ] = xx [ 5 ] * ( xx [ 54 ] * xx [ 4 ] + xx [ 56 ] * xx
[ 25 ] ) ; xx [ 54 ] = xx [ 23 ] * state [ 9 ] ; xx [ 56 ] = xx [ 120 ] + xx
[ 54 ] ; xx [ 300 ] = xx [ 103 ] ; xx [ 301 ] = xx [ 119 ] ; xx [ 302 ] = -
xx [ 56 ] ; pm_math_Vector3_cross_ra ( xx + 300 , xx + 319 , xx + 307 ) ;
pm_math_Vector3_cross_ra ( xx + 300 , xx + 307 , xx + 312 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 312 , xx + 307 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 300 , xx + 312 ) ; xx [
121 ] = xx [ 314 ] + state [ 25 ] ; xx [ 197 ] = xx [ 292 ] * state [ 25 ] ;
xx [ 304 ] = xx [ 26 ] * ( xx [ 307 ] - ( xx [ 314 ] + xx [ 121 ] ) * xx [
197 ] ) ; xx [ 305 ] = xx [ 26 ] * xx [ 308 ] ; xx [ 315 ] = 0.011485125 ; xx
[ 316 ] = xx [ 143 ] - xx [ 168 ] ; xx [ 325 ] = xx [ 61 ] ; xx [ 326 ] = xx
[ 27 ] ; xx [ 327 ] = xx [ 95 ] ; xx [ 317 ] = xx [ 95 ] * xx [ 166 ] ; xx [
322 ] = xx [ 166 ] * xx [ 27 ] ; xx [ 328 ] = xx [ 61 ] * xx [ 316 ] - xx [
322 ] ; xx [ 342 ] = - ( xx [ 95 ] * xx [ 316 ] ) ; xx [ 343 ] = xx [ 317 ] ;
xx [ 344 ] = xx [ 328 ] ; pm_math_Vector3_cross_ra ( xx + 325 , xx + 342 , xx
+ 345 ) ; xx [ 329 ] = xx [ 317 ] * xx [ 27 ] ; xx [ 330 ] = xx [ 153 ] * xx
[ 27 ] ; xx [ 339 ] = xx [ 95 ] * xx [ 122 ] - xx [ 330 ] ; xx [ 342 ] =
0.06918743527133955 ; xx [ 343 ] = xx [ 339 ] * xx [ 342 ] ; xx [ 344 ] = xx
[ 61 ] * xx [ 122 ] - xx [ 330 ] ; xx [ 330 ] = xx [ 344 ] * xx [ 342 ] ; xx
[ 365 ] = ( xx [ 339 ] * xx [ 343 ] + xx [ 344 ] * xx [ 330 ] ) * xx [ 5 ] ;
xx [ 366 ] = xx [ 316 ] + xx [ 5 ] * ( xx [ 346 ] + xx [ 329 ] ) + xx [ 365 ]
- xx [ 342 ] ; xx [ 369 ] = xx [ 366 ] / xx [ 150 ] ; xx [ 376 ] = xx [ 149 ]
* xx [ 369 ] ; xx [ 377 ] = xx [ 153 ] * xx [ 376 ] ; xx [ 378 ] = xx [ 144 ]
* xx [ 369 ] ; xx [ 383 ] = xx [ 153 ] * xx [ 378 ] ; xx [ 386 ] = xx [ 5 ] *
( xx [ 153 ] * xx [ 377 ] + xx [ 383 ] * xx [ 122 ] ) - xx [ 376 ] ; xx [ 376
] = ( xx [ 153 ] * xx [ 383 ] - xx [ 377 ] * xx [ 122 ] ) * xx [ 5 ] - xx [
378 ] ; xx [ 377 ] = xx [ 164 ] * xx [ 386 ] + xx [ 166 ] * xx [ 376 ] - xx [
147 ] * xx [ 369 ] ; xx [ 378 ] = xx [ 61 ] * xx [ 164 ] - xx [ 322 ] ; xx [
409 ] = - ( xx [ 95 ] * xx [ 164 ] ) ; xx [ 410 ] = xx [ 317 ] ; xx [ 411 ] =
xx [ 378 ] ; pm_math_Vector3_cross_ra ( xx + 325 , xx + 409 , xx + 412 ) ; xx
[ 317 ] = xx [ 61 ] * xx [ 159 ] ; xx [ 322 ] = 0.01685096875337573 ; xx [
383 ] = xx [ 164 ] + ( xx [ 329 ] + xx [ 413 ] ) * xx [ 5 ] - ( xx [ 110 ] +
xx [ 61 ] * xx [ 317 ] ) * xx [ 5 ] + xx [ 365 ] + xx [ 322 ] ; xx [ 110 ] =
( xx [ 377 ] + xx [ 159 ] * xx [ 386 ] + xx [ 383 ] ) / xx [ 156 ] ; xx [ 409
] = xx [ 324 ] ; xx [ 410 ] = xx [ 93 ] ; xx [ 411 ] = xx [ 138 ] ; xx [ 415
] = xx [ 27 ] ; xx [ 416 ] = xx [ 61 ] ; xx [ 417 ] = xx [ 27 ] ; xx [ 418 ]
= xx [ 95 ] ; xx [ 93 ] = xx [ 146 ] * xx [ 369 ] ; xx [ 138 ] = xx [ 261 ] *
xx [ 369 ] ; xx [ 324 ] = xx [ 153 ] * xx [ 138 ] ; xx [ 329 ] = xx [ 153 ] *
xx [ 93 ] ; xx [ 419 ] = xx [ 93 ] - xx [ 5 ] * ( xx [ 324 ] * xx [ 122 ] +
xx [ 153 ] * xx [ 329 ] ) - xx [ 280 ] * xx [ 110 ] ; xx [ 420 ] = ( xx [ 153
] * xx [ 324 ] - xx [ 329 ] * xx [ 122 ] ) * xx [ 5 ] - xx [ 138 ] - xx [ 273
] * xx [ 110 ] ; xx [ 421 ] = xx [ 377 ] - xx [ 137 ] * xx [ 110 ] ;
pm_math_Quaternion_xform_ra ( xx + 415 , xx + 419 , xx + 422 ) ; xx [ 93 ] =
xx [ 376 ] - xx [ 170 ] * xx [ 110 ] ; xx [ 138 ] = xx [ 386 ] - xx [ 154 ] *
xx [ 110 ] ; xx [ 324 ] = xx [ 95 ] * xx [ 138 ] ; xx [ 329 ] = xx [ 95 ] *
xx [ 93 ] ; xx [ 365 ] = xx [ 61 ] * xx [ 138 ] - xx [ 27 ] * xx [ 93 ] ; xx
[ 419 ] = - xx [ 324 ] ; xx [ 420 ] = xx [ 329 ] ; xx [ 421 ] = xx [ 365 ] ;
pm_math_Vector3_cross_ra ( xx + 325 , xx + 419 , xx + 425 ) ; xx [ 376 ] = xx
[ 93 ] + xx [ 5 ] * ( xx [ 425 ] - xx [ 324 ] * xx [ 27 ] ) ; xx [ 93 ] = xx
[ 138 ] + ( xx [ 329 ] * xx [ 27 ] + xx [ 426 ] ) * xx [ 5 ] ; xx [ 138 ] = (
xx [ 365 ] * xx [ 27 ] + xx [ 427 ] ) * xx [ 5 ] ; xx [ 419 ] = xx [ 376 ] ;
xx [ 420 ] = xx [ 93 ] ; xx [ 421 ] = xx [ 138 ] ; pm_math_Vector3_cross_ra (
xx + 289 , xx + 419 , xx + 425 ) ; xx [ 324 ] = 0.17015 ; xx [ 329 ] = xx [
58 ] * xx [ 292 ] ; xx [ 365 ] = ( xx [ 333 ] + xx [ 58 ] * xx [ 329 ] ) * xx
[ 5 ] ; xx [ 333 ] = xx [ 324 ] - ( xx [ 365 ] + xx [ 365 ] ) ; xx [ 365 ] =
1.3053272625e-3 ; xx [ 377 ] = xx [ 333 ] / xx [ 365 ] ; xx [ 386 ] = xx [
360 ] * xx [ 377 ] ; xx [ 389 ] = xx [ 386 ] * xx [ 57 ] ; xx [ 419 ] = xx [
389 ] * xx [ 57 ] ; xx [ 420 ] = xx [ 58 ] * xx [ 386 ] ; xx [ 421 ] = xx [
315 ] * xx [ 377 ] ; xx [ 428 ] = xx [ 63 ] * xx [ 421 ] ; xx [ 429 ] = xx [
428 ] * xx [ 57 ] ; xx [ 430 ] = xx [ 58 ] * xx [ 421 ] ; xx [ 431 ] = xx [
430 ] * xx [ 57 ] ; xx [ 432 ] = xx [ 5 ] * ( xx [ 429 ] - xx [ 431 ] ) ; xx
[ 433 ] = xx [ 421 ] - ( xx [ 63 ] * xx [ 428 ] + xx [ 58 ] * xx [ 430 ] ) *
xx [ 5 ] ; xx [ 421 ] = ( xx [ 431 ] + xx [ 429 ] ) * xx [ 5 ] ; xx [ 428 ] =
xx [ 432 ] ; xx [ 429 ] = xx [ 433 ] ; xx [ 430 ] = - xx [ 421 ] ;
pm_math_Vector3_cross_ra ( xx + 336 , xx + 428 , xx + 434 ) ; xx [ 428 ] = xx
[ 376 ] + xx [ 432 ] ; xx [ 376 ] = xx [ 423 ] + xx [ 426 ] + xx [ 5 ] * ( xx
[ 420 ] * xx [ 57 ] - xx [ 63 ] * xx [ 389 ] ) + xx [ 435 ] ; xx [ 389 ] = xx
[ 424 ] + xx [ 427 ] + xx [ 386 ] - ( xx [ 58 ] * xx [ 420 ] + xx [ 419 ] ) *
xx [ 5 ] + xx [ 436 ] ; xx [ 386 ] = ( xx [ 428 ] * xx [ 243 ] - ( xx [ 376 ]
* xx [ 20 ] + xx [ 389 ] * xx [ 23 ] ) ) / xx [ 349 ] ; xx [ 429 ] = xx [ 422
] + xx [ 425 ] + ( xx [ 419 ] + xx [ 63 ] * xx [ 420 ] ) * xx [ 5 ] + xx [
434 ] - xx [ 66 ] * xx [ 386 ] ; xx [ 430 ] = xx [ 376 ] - xx [ 263 ] * xx [
386 ] ; xx [ 431 ] = xx [ 389 ] - xx [ 341 ] * xx [ 386 ] ;
pm_math_Quaternion_xform_ra ( xx + 265 , xx + 429 , xx + 422 ) ; xx [ 424 ] =
xx [ 428 ] - xx [ 264 ] * xx [ 386 ] ; xx [ 425 ] = xx [ 93 ] + xx [ 433 ] -
xx [ 45 ] * xx [ 386 ] ; xx [ 426 ] = xx [ 138 ] - xx [ 421 ] - xx [ 39 ] *
xx [ 386 ] ; pm_math_Quaternion_xform_ra ( xx + 265 , xx + 424 , xx + 419 ) ;
pm_math_Vector3_cross_ra ( xx + 190 , xx + 419 , xx + 424 ) ; xx [ 93 ] = (
xx [ 423 ] + xx [ 425 ] ) / xx [ 51 ] ; xx [ 422 ] = xx [ 52 ] ; xx [ 423 ] =
xx [ 113 ] ; xx [ 424 ] = xx [ 116 ] ; xx [ 425 ] = xx [ 419 ] - xx [ 93 ] *
xx [ 44 ] ; xx [ 426 ] = xx [ 420 ] - xx [ 93 ] * xx [ 53 ] ; xx [ 427 ] = xx
[ 421 ] - xx [ 93 ] * xx [ 55 ] ; pm_math_Quaternion_xform_ra ( xx + 193 , xx
+ 425 , xx + 419 ) ; xx [ 425 ] = - xx [ 419 ] ; xx [ 426 ] = - xx [ 420 ] ;
xx [ 427 ] = - xx [ 421 ] ; solveSymmetricPosDef ( xx + 400 , xx + 425 , 3 ,
1 , xx + 419 , xx + 428 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 193 ,
xx + 419 , xx + 425 ) ; xx [ 138 ] = xx [ 93 ] + pm_math_Vector3_dot_ra ( xx
+ 422 , xx + 425 ) ; xx [ 93 ] = xx [ 10 ] * xx [ 138 ] ; xx [ 376 ] = xx [
138 ] * xx [ 2 ] ; xx [ 389 ] = - ( ( xx [ 93 ] * xx [ 25 ] - xx [ 376 ] * xx
[ 4 ] ) * xx [ 5 ] ) ; xx [ 419 ] = ( xx [ 10 ] * xx [ 93 ] + xx [ 376 ] * xx
[ 2 ] ) * xx [ 5 ] - xx [ 138 ] ; xx [ 428 ] = xx [ 108 ] ; xx [ 429 ] = xx [
114 ] ; xx [ 430 ] = xx [ 49 ] ; xx [ 49 ] = xx [ 5 ] * ( xx [ 376 ] * xx [
25 ] + xx [ 93 ] * xx [ 4 ] ) ; xx [ 431 ] = xx [ 389 ] ; xx [ 432 ] = xx [
419 ] ; xx [ 433 ] = xx [ 49 ] ; xx [ 434 ] = xx [ 353 ] ; xx [ 435 ] = xx [
70 ] ; xx [ 436 ] = xx [ 74 ] ; xx [ 437 ] = xx [ 425 ] + xx [ 65 ] * xx [
138 ] ; xx [ 438 ] = xx [ 426 ] ; xx [ 439 ] = xx [ 427 ] - xx [ 138 ] * xx [
169 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx + 437 , xx + 425 )
; xx [ 70 ] = xx [ 386 ] + pm_math_Vector3_dot_ra ( xx + 428 , xx + 431 ) +
pm_math_Vector3_dot_ra ( xx + 434 , xx + 425 ) ; xx [ 431 ] = xx [ 389 ] ; xx
[ 432 ] = xx [ 419 ] + xx [ 70 ] * xx [ 20 ] ; xx [ 433 ] = xx [ 49 ] + xx [
70 ] * xx [ 23 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 431 ,
xx + 419 ) ; xx [ 49 ] = xx [ 425 ] - xx [ 70 ] * xx [ 243 ] ;
pm_math_Vector3_cross_ra ( xx + 431 , xx + 289 , xx + 437 ) ; xx [ 440 ] = xx
[ 49 ] + xx [ 437 ] ; xx [ 441 ] = xx [ 426 ] + xx [ 438 ] ; xx [ 442 ] = xx
[ 427 ] + xx [ 439 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx +
440 , xx + 437 ) ; xx [ 70 ] = xx [ 110 ] + pm_math_Vector3_dot_ra ( xx + 409
, xx + 419 ) + xx [ 163 ] * xx [ 437 ] + xx [ 173 ] * xx [ 438 ] ; xx [ 439 ]
= - xx [ 275 ] ; xx [ 440 ] = xx [ 251 ] ; xx [ 441 ] = xx [ 172 ] ; xx [ 74
] = xx [ 153 ] * xx [ 420 ] ; xx [ 93 ] = xx [ 153 ] * xx [ 419 ] ; xx [ 108
] = xx [ 421 ] - xx [ 70 ] ; xx [ 442 ] = xx [ 419 ] - xx [ 5 ] * ( xx [ 74 ]
* xx [ 122 ] + xx [ 153 ] * xx [ 93 ] ) ; xx [ 443 ] = xx [ 420 ] - ( xx [
153 ] * xx [ 74 ] - xx [ 93 ] * xx [ 122 ] ) * xx [ 5 ] ; xx [ 444 ] = xx [
108 ] ; xx [ 74 ] = xx [ 437 ] + xx [ 166 ] * xx [ 108 ] ; xx [ 93 ] = xx [
438 ] - xx [ 70 ] * xx [ 159 ] + xx [ 164 ] * xx [ 108 ] ; xx [ 108 ] = xx [
153 ] * xx [ 93 ] ; xx [ 110 ] = xx [ 74 ] * xx [ 153 ] ; xx [ 114 ] =
0.2514543766567505 ; xx [ 445 ] = xx [ 57 ] ; xx [ 446 ] = - xx [ 58 ] ; xx [
447 ] = xx [ 57 ] ; xx [ 448 ] = - xx [ 63 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 431 , xx + 419 ) ; xx [
138 ] = 8.798655578527764 ; pm_math_Vector3_cross_ra ( xx + 431 , xx + 336 ,
xx + 449 ) ; xx [ 431 ] = xx [ 49 ] + xx [ 449 ] ; xx [ 432 ] = xx [ 426 ] +
xx [ 450 ] ; xx [ 433 ] = xx [ 427 ] + xx [ 451 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 431 , xx + 425 ) ; xx [
49 ] = xx [ 27 ] * xx [ 122 ] ; xx [ 172 ] = xx [ 49 ] + xx [ 95 ] * xx [ 153
] ; xx [ 251 ] = xx [ 49 ] + xx [ 61 ] * xx [ 153 ] ; xx [ 49 ] = ( xx [ 330
] * xx [ 172 ] + xx [ 343 ] * xx [ 251 ] ) * xx [ 5 ] ; xx [ 275 ] = ( xx [
328 ] * xx [ 27 ] + xx [ 347 ] ) * xx [ 5 ] - xx [ 49 ] ; xx [ 328 ] = xx [
275 ] / xx [ 150 ] ; xx [ 330 ] = xx [ 149 ] * xx [ 328 ] ; xx [ 343 ] = xx [
153 ] * xx [ 330 ] ; xx [ 345 ] = xx [ 144 ] * xx [ 328 ] ; xx [ 346 ] = xx [
153 ] * xx [ 345 ] ; xx [ 347 ] = xx [ 5 ] * ( xx [ 153 ] * xx [ 343 ] + xx [
346 ] * xx [ 122 ] ) - xx [ 330 ] ; xx [ 330 ] = ( xx [ 153 ] * xx [ 346 ] -
xx [ 343 ] * xx [ 122 ] ) * xx [ 5 ] - xx [ 345 ] ; xx [ 343 ] = xx [ 164 ] *
xx [ 347 ] + xx [ 166 ] * xx [ 330 ] - xx [ 147 ] * xx [ 328 ] ; xx [ 345 ] =
( xx [ 378 ] * xx [ 27 ] + xx [ 414 ] ) * xx [ 5 ] + ( xx [ 317 ] * xx [ 27 ]
+ xx [ 279 ] ) * xx [ 5 ] - xx [ 49 ] ; xx [ 49 ] = ( xx [ 343 ] + xx [ 159 ]
* xx [ 347 ] + xx [ 345 ] ) / xx [ 156 ] ; xx [ 279 ] = xx [ 146 ] * xx [ 328
] ; xx [ 317 ] = xx [ 261 ] * xx [ 328 ] ; xx [ 346 ] = xx [ 153 ] * xx [ 317
] ; xx [ 353 ] = xx [ 153 ] * xx [ 279 ] ; xx [ 412 ] = xx [ 279 ] - xx [ 5 ]
* ( xx [ 346 ] * xx [ 122 ] + xx [ 153 ] * xx [ 353 ] ) - xx [ 280 ] * xx [
49 ] ; xx [ 413 ] = ( xx [ 153 ] * xx [ 346 ] - xx [ 353 ] * xx [ 122 ] ) *
xx [ 5 ] - xx [ 317 ] - xx [ 273 ] * xx [ 49 ] ; xx [ 414 ] = xx [ 343 ] - xx
[ 137 ] * xx [ 49 ] ; pm_math_Quaternion_xform_ra ( xx + 415 , xx + 412 , xx
+ 431 ) ; xx [ 279 ] = xx [ 330 ] - xx [ 170 ] * xx [ 49 ] ; xx [ 317 ] = xx
[ 347 ] - xx [ 154 ] * xx [ 49 ] ; xx [ 330 ] = xx [ 95 ] * xx [ 317 ] ; xx [
343 ] = xx [ 95 ] * xx [ 279 ] ; xx [ 346 ] = xx [ 61 ] * xx [ 317 ] - xx [
27 ] * xx [ 279 ] ; xx [ 412 ] = - xx [ 330 ] ; xx [ 413 ] = xx [ 343 ] ; xx
[ 414 ] = xx [ 346 ] ; pm_math_Vector3_cross_ra ( xx + 325 , xx + 412 , xx +
449 ) ; xx [ 347 ] = xx [ 279 ] + xx [ 5 ] * ( xx [ 449 ] - xx [ 330 ] * xx [
27 ] ) ; xx [ 279 ] = xx [ 317 ] + ( xx [ 343 ] * xx [ 27 ] + xx [ 450 ] ) *
xx [ 5 ] ; xx [ 317 ] = ( xx [ 346 ] * xx [ 27 ] + xx [ 451 ] ) * xx [ 5 ] ;
xx [ 412 ] = xx [ 347 ] ; xx [ 413 ] = xx [ 279 ] ; xx [ 414 ] = xx [ 317 ] ;
pm_math_Vector3_cross_ra ( xx + 289 , xx + 412 , xx + 449 ) ; xx [ 330 ] = (
xx [ 329 ] * xx [ 57 ] + xx [ 334 ] ) * xx [ 5 ] ; xx [ 329 ] = xx [ 330 ] +
xx [ 330 ] ; xx [ 330 ] = xx [ 329 ] / xx [ 365 ] ; xx [ 334 ] = xx [ 315 ] *
xx [ 330 ] ; xx [ 343 ] = xx [ 58 ] * xx [ 334 ] ; xx [ 346 ] = xx [ 343 ] *
xx [ 57 ] ; xx [ 353 ] = xx [ 63 ] * xx [ 334 ] ; xx [ 376 ] = xx [ 353 ] *
xx [ 57 ] ; xx [ 378 ] = xx [ 5 ] * ( xx [ 346 ] - xx [ 376 ] ) ; xx [ 386 ]
= ( xx [ 63 ] * xx [ 353 ] + xx [ 58 ] * xx [ 343 ] ) * xx [ 5 ] - xx [ 334 ]
; xx [ 334 ] = ( xx [ 346 ] + xx [ 376 ] ) * xx [ 5 ] ; xx [ 412 ] = xx [ 378
] ; xx [ 413 ] = xx [ 386 ] ; xx [ 414 ] = xx [ 334 ] ;
pm_math_Vector3_cross_ra ( xx + 336 , xx + 412 , xx + 452 ) ; xx [ 343 ] = xx
[ 360 ] * xx [ 330 ] ; xx [ 346 ] = xx [ 343 ] * xx [ 57 ] ; xx [ 353 ] = xx
[ 346 ] * xx [ 57 ] ; xx [ 376 ] = xx [ 58 ] * xx [ 343 ] ; xx [ 389 ] = xx [
347 ] + xx [ 378 ] ; xx [ 347 ] = xx [ 432 ] + xx [ 450 ] + xx [ 5 ] * ( xx [
63 ] * xx [ 346 ] - xx [ 376 ] * xx [ 57 ] ) + xx [ 453 ] ; xx [ 57 ] = xx [
433 ] + xx [ 451 ] + ( xx [ 58 ] * xx [ 376 ] + xx [ 353 ] ) * xx [ 5 ] - xx
[ 343 ] + xx [ 454 ] ; xx [ 58 ] = ( xx [ 389 ] * xx [ 243 ] - ( xx [ 347 ] *
xx [ 20 ] + xx [ 57 ] * xx [ 23 ] ) ) / xx [ 349 ] ; xx [ 412 ] = xx [ 431 ]
+ xx [ 449 ] + xx [ 452 ] - ( xx [ 353 ] + xx [ 63 ] * xx [ 376 ] ) * xx [ 5
] - xx [ 66 ] * xx [ 58 ] ; xx [ 413 ] = xx [ 347 ] - xx [ 263 ] * xx [ 58 ]
; xx [ 414 ] = xx [ 57 ] - xx [ 341 ] * xx [ 58 ] ;
pm_math_Quaternion_xform_ra ( xx + 265 , xx + 412 , xx + 431 ) ; xx [ 412 ] =
xx [ 389 ] - xx [ 264 ] * xx [ 58 ] ; xx [ 413 ] = xx [ 279 ] + xx [ 386 ] -
xx [ 45 ] * xx [ 58 ] ; xx [ 414 ] = xx [ 317 ] + xx [ 334 ] - xx [ 39 ] * xx
[ 58 ] ; pm_math_Quaternion_xform_ra ( xx + 265 , xx + 412 , xx + 449 ) ;
pm_math_Vector3_cross_ra ( xx + 190 , xx + 449 , xx + 412 ) ; xx [ 57 ] = (
xx [ 432 ] + xx [ 413 ] ) / xx [ 51 ] ; xx [ 412 ] = xx [ 449 ] - xx [ 57 ] *
xx [ 44 ] ; xx [ 413 ] = xx [ 450 ] - xx [ 57 ] * xx [ 53 ] ; xx [ 414 ] = xx
[ 451 ] - xx [ 57 ] * xx [ 55 ] ; pm_math_Quaternion_xform_ra ( xx + 193 , xx
+ 412 , xx + 431 ) ; xx [ 412 ] = - xx [ 431 ] ; xx [ 413 ] = - xx [ 432 ] ;
xx [ 414 ] = - xx [ 433 ] ; solveSymmetricPosDef ( xx + 400 , xx + 412 , 3 ,
1 , xx + 431 , xx + 449 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 193 ,
xx + 431 , xx + 412 ) ; xx [ 63 ] = xx [ 57 ] + pm_math_Vector3_dot_ra ( xx +
422 , xx + 412 ) ; xx [ 57 ] = xx [ 10 ] * xx [ 63 ] ; xx [ 279 ] = xx [ 63 ]
* xx [ 2 ] ; xx [ 317 ] = - ( ( xx [ 57 ] * xx [ 25 ] - xx [ 279 ] * xx [ 4 ]
) * xx [ 5 ] ) ; xx [ 334 ] = ( xx [ 10 ] * xx [ 57 ] + xx [ 279 ] * xx [ 2 ]
) * xx [ 5 ] - xx [ 63 ] ; xx [ 343 ] = xx [ 5 ] * ( xx [ 279 ] * xx [ 25 ] +
xx [ 57 ] * xx [ 4 ] ) ; xx [ 431 ] = xx [ 317 ] ; xx [ 432 ] = xx [ 334 ] ;
xx [ 433 ] = xx [ 343 ] ; xx [ 449 ] = xx [ 412 ] + xx [ 65 ] * xx [ 63 ] ;
xx [ 450 ] = xx [ 413 ] ; xx [ 451 ] = xx [ 414 ] - xx [ 63 ] * xx [ 169 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx + 449 , xx + 412 ) ; xx [
57 ] = xx [ 58 ] + pm_math_Vector3_dot_ra ( xx + 428 , xx + 431 ) +
pm_math_Vector3_dot_ra ( xx + 434 , xx + 412 ) ; xx [ 431 ] = xx [ 317 ] ; xx
[ 432 ] = xx [ 334 ] + xx [ 57 ] * xx [ 20 ] ; xx [ 433 ] = xx [ 343 ] + xx [
57 ] * xx [ 23 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 431 ,
xx + 449 ) ; xx [ 58 ] = xx [ 412 ] - xx [ 57 ] * xx [ 243 ] ;
pm_math_Vector3_cross_ra ( xx + 431 , xx + 289 , xx + 452 ) ; xx [ 455 ] = xx
[ 58 ] + xx [ 452 ] ; xx [ 456 ] = xx [ 413 ] + xx [ 453 ] ; xx [ 457 ] = xx
[ 414 ] + xx [ 454 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx +
455 , xx + 452 ) ; xx [ 57 ] = xx [ 49 ] + pm_math_Vector3_dot_ra ( xx + 409
, xx + 449 ) + xx [ 163 ] * xx [ 452 ] + xx [ 173 ] * xx [ 453 ] ; xx [ 49 ]
= xx [ 153 ] * xx [ 450 ] ; xx [ 63 ] = xx [ 153 ] * xx [ 449 ] ; xx [ 279 ]
= xx [ 451 ] - xx [ 57 ] ; xx [ 454 ] = xx [ 449 ] - xx [ 5 ] * ( xx [ 49 ] *
xx [ 122 ] + xx [ 153 ] * xx [ 63 ] ) ; xx [ 455 ] = xx [ 450 ] - ( xx [ 153
] * xx [ 49 ] - xx [ 63 ] * xx [ 122 ] ) * xx [ 5 ] ; xx [ 456 ] = xx [ 279 ]
; xx [ 49 ] = xx [ 452 ] + xx [ 166 ] * xx [ 279 ] ; xx [ 63 ] = xx [ 453 ] -
xx [ 57 ] * xx [ 159 ] + xx [ 164 ] * xx [ 279 ] ; xx [ 279 ] = xx [ 153 ] *
xx [ 63 ] ; xx [ 317 ] = xx [ 49 ] * xx [ 153 ] ; xx [ 334 ] = xx [ 328 ] +
pm_math_Vector3_dot_ra ( xx + 439 , xx + 454 ) + ( xx [ 49 ] - xx [ 5 ] * (
xx [ 279 ] * xx [ 122 ] + xx [ 153 ] * xx [ 317 ] ) ) * xx [ 151 ] + xx [ 141
] * ( xx [ 63 ] - ( xx [ 153 ] * xx [ 279 ] - xx [ 317 ] * xx [ 122 ] ) * xx
[ 5 ] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 431 , xx + 449
) ; pm_math_Vector3_cross_ra ( xx + 431 , xx + 336 , xx + 452 ) ; xx [ 431 ]
= xx [ 58 ] + xx [ 452 ] ; xx [ 432 ] = xx [ 413 ] + xx [ 453 ] ; xx [ 433 ]
= xx [ 414 ] + xx [ 454 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 445 ,
xx + 431 , xx + 412 ) ; xx [ 49 ] = xx [ 330 ] + xx [ 114 ] * xx [ 451 ] + xx
[ 138 ] * xx [ 413 ] ; xx [ 58 ] = xx [ 57 ] * xx [ 383 ] + xx [ 334 ] * xx [
366 ] - xx [ 333 ] * xx [ 49 ] ; xx [ 449 ] = xx [ 174 ] ; xx [ 450 ] = xx [
22 ] ; xx [ 451 ] = xx [ 174 ] ; xx [ 452 ] = xx [ 182 ] ; xx [ 63 ] = xx [
143 ] - xx [ 247 ] ; xx [ 412 ] = xx [ 22 ] ; xx [ 413 ] = xx [ 174 ] ; xx [
414 ] = xx [ 182 ] ; xx [ 279 ] = xx [ 182 ] * xx [ 246 ] ; xx [ 317 ] = xx [
246 ] * xx [ 174 ] ; xx [ 328 ] = xx [ 22 ] * xx [ 63 ] - xx [ 317 ] ; xx [
431 ] = - ( xx [ 182 ] * xx [ 63 ] ) ; xx [ 432 ] = xx [ 279 ] ; xx [ 433 ] =
xx [ 328 ] ; pm_math_Vector3_cross_ra ( xx + 412 , xx + 431 , xx + 453 ) ; xx
[ 330 ] = xx [ 279 ] * xx [ 174 ] ; xx [ 343 ] = xx [ 233 ] * xx [ 174 ] ; xx
[ 346 ] = xx [ 182 ] * xx [ 180 ] - xx [ 343 ] ; xx [ 347 ] = xx [ 346 ] * xx
[ 342 ] ; xx [ 353 ] = xx [ 22 ] * xx [ 180 ] - xx [ 343 ] ; xx [ 343 ] = xx
[ 353 ] * xx [ 342 ] ; xx [ 376 ] = ( xx [ 346 ] * xx [ 347 ] + xx [ 353 ] *
xx [ 343 ] ) * xx [ 5 ] ; xx [ 378 ] = xx [ 63 ] + xx [ 5 ] * ( xx [ 454 ] +
xx [ 330 ] ) + xx [ 376 ] - xx [ 342 ] ; xx [ 386 ] = xx [ 378 ] / xx [ 230 ]
; xx [ 389 ] = xx [ 351 ] * xx [ 386 ] ; xx [ 419 ] = xx [ 233 ] * xx [ 389 ]
; xx [ 420 ] = xx [ 226 ] * xx [ 386 ] ; xx [ 425 ] = xx [ 233 ] * xx [ 420 ]
; xx [ 427 ] = xx [ 229 ] * xx [ 386 ] ; xx [ 431 ] = xx [ 233 ] * xx [ 427 ]
; xx [ 432 ] = xx [ 225 ] * xx [ 386 ] ; xx [ 433 ] = xx [ 233 ] * xx [ 432 ]
; xx [ 437 ] = xx [ 5 ] * ( xx [ 233 ] * xx [ 431 ] + xx [ 433 ] * xx [ 180 ]
) - xx [ 427 ] ; xx [ 427 ] = ( xx [ 233 ] * xx [ 433 ] - xx [ 431 ] * xx [
180 ] ) * xx [ 5 ] - xx [ 432 ] ; xx [ 431 ] = xx [ 244 ] * xx [ 437 ] + xx [
246 ] * xx [ 427 ] - xx [ 227 ] * xx [ 386 ] ; xx [ 432 ] = xx [ 22 ] * xx [
244 ] - xx [ 317 ] ; xx [ 456 ] = - ( xx [ 182 ] * xx [ 244 ] ) ; xx [ 457 ]
= xx [ 279 ] ; xx [ 458 ] = xx [ 432 ] ; pm_math_Vector3_cross_ra ( xx + 412
, xx + 456 , xx + 459 ) ; xx [ 279 ] = xx [ 22 ] * xx [ 159 ] ; xx [ 317 ] =
xx [ 244 ] + ( xx [ 330 ] + xx [ 460 ] ) * xx [ 5 ] - ( xx [ 184 ] + xx [ 22
] * xx [ 279 ] ) * xx [ 5 ] + xx [ 376 ] + xx [ 322 ] ; xx [ 184 ] = ( xx [
431 ] + xx [ 159 ] * xx [ 437 ] + xx [ 317 ] ) / xx [ 236 ] ; xx [ 456 ] = xx
[ 5 ] * ( xx [ 419 ] * xx [ 180 ] + xx [ 233 ] * xx [ 425 ] ) - xx [ 420 ] -
xx [ 361 ] * xx [ 184 ] ; xx [ 457 ] = ( xx [ 425 ] * xx [ 180 ] - xx [ 233 ]
* xx [ 419 ] ) * xx [ 5 ] + xx [ 389 ] - xx [ 354 ] * xx [ 184 ] ; xx [ 458 ]
= xx [ 431 ] - xx [ 167 ] * xx [ 184 ] ; pm_math_Quaternion_xform_ra ( xx +
449 , xx + 456 , xx + 462 ) ; xx [ 322 ] = xx [ 427 ] - xx [ 239 ] * xx [ 184
] ; xx [ 330 ] = xx [ 437 ] - xx [ 234 ] * xx [ 184 ] ; xx [ 376 ] = xx [ 182
] * xx [ 330 ] ; xx [ 389 ] = xx [ 182 ] * xx [ 322 ] ; xx [ 419 ] = xx [ 22
] * xx [ 330 ] - xx [ 174 ] * xx [ 322 ] ; xx [ 456 ] = - xx [ 376 ] ; xx [
457 ] = xx [ 389 ] ; xx [ 458 ] = xx [ 419 ] ; pm_math_Vector3_cross_ra ( xx
+ 412 , xx + 456 , xx + 465 ) ; xx [ 420 ] = xx [ 322 ] + xx [ 5 ] * ( xx [
465 ] - xx [ 376 ] * xx [ 174 ] ) ; xx [ 322 ] = xx [ 330 ] + ( xx [ 389 ] *
xx [ 174 ] + xx [ 466 ] ) * xx [ 5 ] ; xx [ 330 ] = ( xx [ 419 ] * xx [ 174 ]
+ xx [ 467 ] ) * xx [ 5 ] ; xx [ 456 ] = xx [ 420 ] ; xx [ 457 ] = xx [ 322 ]
; xx [ 458 ] = xx [ 330 ] ; pm_math_Vector3_cross_ra ( xx + 370 , xx + 456 ,
xx + 465 ) ; xx [ 376 ] = xx [ 21 ] * xx [ 292 ] ; xx [ 389 ] = ( xx [ 296 ]
+ xx [ 21 ] * xx [ 376 ] ) * xx [ 5 ] ; xx [ 296 ] = xx [ 324 ] - ( xx [ 389
] + xx [ 389 ] ) ; xx [ 389 ] = xx [ 296 ] / xx [ 365 ] ; xx [ 419 ] = xx [
360 ] * xx [ 389 ] ; xx [ 425 ] = xx [ 419 ] * xx [ 9 ] ; xx [ 427 ] = xx [
425 ] * xx [ 9 ] ; xx [ 431 ] = xx [ 21 ] * xx [ 419 ] ; xx [ 433 ] = xx [
315 ] * xx [ 389 ] ; xx [ 437 ] = xx [ 38 ] * xx [ 433 ] ; xx [ 438 ] = xx [
437 ] * xx [ 9 ] ; xx [ 456 ] = xx [ 21 ] * xx [ 433 ] ; xx [ 457 ] = xx [
456 ] * xx [ 9 ] ; xx [ 458 ] = xx [ 5 ] * ( xx [ 438 ] - xx [ 457 ] ) ; xx [
468 ] = xx [ 433 ] - ( xx [ 38 ] * xx [ 437 ] + xx [ 21 ] * xx [ 456 ] ) * xx
[ 5 ] ; xx [ 433 ] = ( xx [ 457 ] + xx [ 438 ] ) * xx [ 5 ] ; xx [ 469 ] = xx
[ 458 ] ; xx [ 470 ] = xx [ 468 ] ; xx [ 471 ] = - xx [ 433 ] ;
pm_math_Vector3_cross_ra ( xx + 319 , xx + 469 , xx + 472 ) ; xx [ 437 ] = xx
[ 420 ] + xx [ 458 ] ; xx [ 420 ] = xx [ 463 ] + xx [ 466 ] + xx [ 5 ] * ( xx
[ 431 ] * xx [ 9 ] - xx [ 38 ] * xx [ 425 ] ) + xx [ 473 ] ; xx [ 425 ] = xx
[ 464 ] + xx [ 467 ] + xx [ 419 ] - ( xx [ 21 ] * xx [ 431 ] + xx [ 427 ] ) *
xx [ 5 ] + xx [ 474 ] ; xx [ 419 ] = ( xx [ 437 ] * xx [ 243 ] - ( xx [ 420 ]
* xx [ 20 ] + xx [ 425 ] * xx [ 23 ] ) ) / xx [ 349 ] ; xx [ 456 ] = xx [ 462
] + xx [ 465 ] + ( xx [ 427 ] + xx [ 38 ] * xx [ 431 ] ) * xx [ 5 ] + xx [
472 ] - xx [ 66 ] * xx [ 419 ] ; xx [ 457 ] = xx [ 420 ] - xx [ 263 ] * xx [
419 ] ; xx [ 458 ] = xx [ 425 ] - xx [ 341 ] * xx [ 419 ] ;
pm_math_Quaternion_xform_ra ( xx + 265 , xx + 456 , xx + 462 ) ; xx [ 456 ] =
xx [ 437 ] - xx [ 264 ] * xx [ 419 ] ; xx [ 457 ] = xx [ 322 ] + xx [ 468 ] -
xx [ 45 ] * xx [ 419 ] ; xx [ 458 ] = xx [ 330 ] - xx [ 433 ] - xx [ 39 ] *
xx [ 419 ] ; pm_math_Quaternion_xform_ra ( xx + 265 , xx + 456 , xx + 464 ) ;
pm_math_Vector3_cross_ra ( xx + 190 , xx + 464 , xx + 456 ) ; xx [ 322 ] = (
xx [ 463 ] + xx [ 457 ] ) / xx [ 51 ] ; xx [ 456 ] = xx [ 464 ] - xx [ 322 ]
* xx [ 44 ] ; xx [ 457 ] = xx [ 465 ] - xx [ 322 ] * xx [ 53 ] ; xx [ 458 ] =
xx [ 466 ] - xx [ 322 ] * xx [ 55 ] ; pm_math_Quaternion_xform_ra ( xx + 193
, xx + 456 , xx + 462 ) ; xx [ 456 ] = - xx [ 462 ] ; xx [ 457 ] = - xx [ 463
] ; xx [ 458 ] = - xx [ 464 ] ; solveSymmetricPosDef ( xx + 400 , xx + 456 ,
3 , 1 , xx + 462 , xx + 465 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 193
, xx + 462 , xx + 456 ) ; xx [ 330 ] = xx [ 322 ] + pm_math_Vector3_dot_ra (
xx + 422 , xx + 456 ) ; xx [ 322 ] = xx [ 10 ] * xx [ 330 ] ; xx [ 420 ] = xx
[ 330 ] * xx [ 2 ] ; xx [ 425 ] = - ( ( xx [ 322 ] * xx [ 25 ] - xx [ 420 ] *
xx [ 4 ] ) * xx [ 5 ] ) ; xx [ 427 ] = ( xx [ 10 ] * xx [ 322 ] + xx [ 420 ]
* xx [ 2 ] ) * xx [ 5 ] - xx [ 330 ] ; xx [ 431 ] = xx [ 5 ] * ( xx [ 420 ] *
xx [ 25 ] + xx [ 322 ] * xx [ 4 ] ) ; xx [ 462 ] = xx [ 425 ] ; xx [ 463 ] =
xx [ 427 ] ; xx [ 464 ] = xx [ 431 ] ; xx [ 465 ] = xx [ 456 ] + xx [ 65 ] *
xx [ 330 ] ; xx [ 466 ] = xx [ 457 ] ; xx [ 467 ] = xx [ 458 ] - xx [ 330 ] *
xx [ 169 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx + 465 , xx +
456 ) ; xx [ 322 ] = xx [ 419 ] + pm_math_Vector3_dot_ra ( xx + 428 , xx +
462 ) + pm_math_Vector3_dot_ra ( xx + 434 , xx + 456 ) ; xx [ 462 ] = xx [
425 ] ; xx [ 463 ] = xx [ 427 ] + xx [ 322 ] * xx [ 20 ] ; xx [ 464 ] = xx [
431 ] + xx [ 322 ] * xx [ 23 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
415 , xx + 462 , xx + 465 ) ; xx [ 330 ] = xx [ 456 ] - xx [ 322 ] * xx [ 243
] ; pm_math_Vector3_cross_ra ( xx + 462 , xx + 289 , xx + 468 ) ; xx [ 471 ]
= xx [ 330 ] + xx [ 468 ] ; xx [ 472 ] = xx [ 457 ] + xx [ 469 ] ; xx [ 473 ]
= xx [ 458 ] + xx [ 470 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 ,
xx + 471 , xx + 468 ) ; xx [ 322 ] = pm_math_Vector3_dot_ra ( xx + 409 , xx +
465 ) + xx [ 163 ] * xx [ 468 ] + xx [ 173 ] * xx [ 469 ] ; xx [ 419 ] = xx [
153 ] * xx [ 466 ] ; xx [ 420 ] = xx [ 153 ] * xx [ 465 ] ; xx [ 425 ] = xx [
467 ] - xx [ 322 ] ; xx [ 470 ] = xx [ 465 ] - xx [ 5 ] * ( xx [ 419 ] * xx [
122 ] + xx [ 153 ] * xx [ 420 ] ) ; xx [ 471 ] = xx [ 466 ] - ( xx [ 153 ] *
xx [ 419 ] - xx [ 420 ] * xx [ 122 ] ) * xx [ 5 ] ; xx [ 472 ] = xx [ 425 ] ;
xx [ 419 ] = xx [ 468 ] + xx [ 166 ] * xx [ 425 ] ; xx [ 420 ] = xx [ 469 ] -
xx [ 322 ] * xx [ 159 ] + xx [ 164 ] * xx [ 425 ] ; xx [ 425 ] = xx [ 153 ] *
xx [ 420 ] ; xx [ 427 ] = xx [ 419 ] * xx [ 153 ] ; xx [ 431 ] =
pm_math_Vector3_dot_ra ( xx + 439 , xx + 470 ) + ( xx [ 419 ] - xx [ 5 ] * (
xx [ 425 ] * xx [ 122 ] + xx [ 153 ] * xx [ 427 ] ) ) * xx [ 151 ] + xx [ 141
] * ( xx [ 420 ] - ( xx [ 153 ] * xx [ 425 ] - xx [ 427 ] * xx [ 122 ] ) * xx
[ 5 ] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 462 , xx + 465
) ; pm_math_Vector3_cross_ra ( xx + 462 , xx + 336 , xx + 468 ) ; xx [ 471 ]
= xx [ 330 ] + xx [ 468 ] ; xx [ 472 ] = xx [ 457 ] + xx [ 469 ] ; xx [ 473 ]
= xx [ 458 ] + xx [ 470 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 445 ,
xx + 471 , xx + 468 ) ; xx [ 419 ] = xx [ 114 ] * xx [ 467 ] + xx [ 138 ] *
xx [ 469 ] ; xx [ 420 ] = xx [ 322 ] * xx [ 383 ] + xx [ 431 ] * xx [ 366 ] -
xx [ 419 ] * xx [ 333 ] ; xx [ 425 ] = xx [ 174 ] * xx [ 180 ] ; xx [ 427 ] =
xx [ 425 ] + xx [ 182 ] * xx [ 233 ] ; xx [ 433 ] = xx [ 425 ] + xx [ 22 ] *
xx [ 233 ] ; xx [ 425 ] = ( xx [ 343 ] * xx [ 427 ] + xx [ 347 ] * xx [ 433 ]
) * xx [ 5 ] ; xx [ 343 ] = ( xx [ 328 ] * xx [ 174 ] + xx [ 455 ] ) * xx [ 5
] - xx [ 425 ] ; xx [ 328 ] = xx [ 343 ] / xx [ 230 ] ; xx [ 347 ] = xx [ 351
] * xx [ 328 ] ; xx [ 437 ] = xx [ 233 ] * xx [ 347 ] ; xx [ 438 ] = xx [ 226
] * xx [ 328 ] ; xx [ 453 ] = xx [ 233 ] * xx [ 438 ] ; xx [ 454 ] = xx [ 229
] * xx [ 328 ] ; xx [ 455 ] = xx [ 233 ] * xx [ 454 ] ; xx [ 456 ] = xx [ 225
] * xx [ 328 ] ; xx [ 465 ] = xx [ 233 ] * xx [ 456 ] ; xx [ 466 ] = xx [ 5 ]
* ( xx [ 233 ] * xx [ 455 ] + xx [ 465 ] * xx [ 180 ] ) - xx [ 454 ] ; xx [
454 ] = ( xx [ 233 ] * xx [ 465 ] - xx [ 455 ] * xx [ 180 ] ) * xx [ 5 ] - xx
[ 456 ] ; xx [ 455 ] = xx [ 244 ] * xx [ 466 ] + xx [ 246 ] * xx [ 454 ] - xx
[ 227 ] * xx [ 328 ] ; xx [ 456 ] = ( xx [ 432 ] * xx [ 174 ] + xx [ 461 ] )
* xx [ 5 ] + ( xx [ 279 ] * xx [ 174 ] + xx [ 188 ] ) * xx [ 5 ] - xx [ 425 ]
; xx [ 188 ] = ( xx [ 455 ] + xx [ 159 ] * xx [ 466 ] + xx [ 456 ] ) / xx [
236 ] ; xx [ 459 ] = xx [ 5 ] * ( xx [ 437 ] * xx [ 180 ] + xx [ 233 ] * xx [
453 ] ) - xx [ 438 ] - xx [ 361 ] * xx [ 188 ] ; xx [ 460 ] = ( xx [ 453 ] *
xx [ 180 ] - xx [ 233 ] * xx [ 437 ] ) * xx [ 5 ] + xx [ 347 ] - xx [ 354 ] *
xx [ 188 ] ; xx [ 461 ] = xx [ 455 ] - xx [ 167 ] * xx [ 188 ] ;
pm_math_Quaternion_xform_ra ( xx + 449 , xx + 459 , xx + 467 ) ; xx [ 279 ] =
xx [ 454 ] - xx [ 239 ] * xx [ 188 ] ; xx [ 347 ] = xx [ 466 ] - xx [ 234 ] *
xx [ 188 ] ; xx [ 425 ] = xx [ 182 ] * xx [ 347 ] ; xx [ 432 ] = xx [ 182 ] *
xx [ 279 ] ; xx [ 437 ] = xx [ 22 ] * xx [ 347 ] - xx [ 174 ] * xx [ 279 ] ;
xx [ 453 ] = - xx [ 425 ] ; xx [ 454 ] = xx [ 432 ] ; xx [ 455 ] = xx [ 437 ]
; pm_math_Vector3_cross_ra ( xx + 412 , xx + 453 , xx + 459 ) ; xx [ 438 ] =
xx [ 279 ] + xx [ 5 ] * ( xx [ 459 ] - xx [ 425 ] * xx [ 174 ] ) ; xx [ 279 ]
= xx [ 347 ] + ( xx [ 432 ] * xx [ 174 ] + xx [ 460 ] ) * xx [ 5 ] ; xx [ 347
] = ( xx [ 437 ] * xx [ 174 ] + xx [ 461 ] ) * xx [ 5 ] ; xx [ 453 ] = xx [
438 ] ; xx [ 454 ] = xx [ 279 ] ; xx [ 455 ] = xx [ 347 ] ;
pm_math_Vector3_cross_ra ( xx + 370 , xx + 453 , xx + 459 ) ; xx [ 425 ] = (
xx [ 376 ] * xx [ 9 ] + xx [ 298 ] ) * xx [ 5 ] ; xx [ 298 ] = xx [ 425 ] +
xx [ 425 ] ; xx [ 376 ] = xx [ 298 ] / xx [ 365 ] ; xx [ 425 ] = xx [ 315 ] *
xx [ 376 ] ; xx [ 432 ] = xx [ 21 ] * xx [ 425 ] ; xx [ 437 ] = xx [ 432 ] *
xx [ 9 ] ; xx [ 453 ] = xx [ 38 ] * xx [ 425 ] ; xx [ 454 ] = xx [ 453 ] * xx
[ 9 ] ; xx [ 455 ] = xx [ 5 ] * ( xx [ 437 ] - xx [ 454 ] ) ; xx [ 465 ] = (
xx [ 38 ] * xx [ 453 ] + xx [ 21 ] * xx [ 432 ] ) * xx [ 5 ] - xx [ 425 ] ;
xx [ 425 ] = ( xx [ 437 ] + xx [ 454 ] ) * xx [ 5 ] ; xx [ 470 ] = xx [ 455 ]
; xx [ 471 ] = xx [ 465 ] ; xx [ 472 ] = xx [ 425 ] ;
pm_math_Vector3_cross_ra ( xx + 319 , xx + 470 , xx + 473 ) ; xx [ 432 ] = xx
[ 360 ] * xx [ 376 ] ; xx [ 437 ] = xx [ 432 ] * xx [ 9 ] ; xx [ 453 ] = xx [
437 ] * xx [ 9 ] ; xx [ 454 ] = xx [ 21 ] * xx [ 432 ] ; xx [ 466 ] = xx [
438 ] + xx [ 455 ] ; xx [ 438 ] = xx [ 468 ] + xx [ 460 ] + xx [ 5 ] * ( xx [
38 ] * xx [ 437 ] - xx [ 454 ] * xx [ 9 ] ) + xx [ 474 ] ; xx [ 9 ] = xx [
469 ] + xx [ 461 ] + ( xx [ 21 ] * xx [ 454 ] + xx [ 453 ] ) * xx [ 5 ] - xx
[ 432 ] + xx [ 475 ] ; xx [ 21 ] = ( xx [ 466 ] * xx [ 243 ] - ( xx [ 438 ] *
xx [ 20 ] + xx [ 9 ] * xx [ 23 ] ) ) / xx [ 349 ] ; xx [ 468 ] = xx [ 467 ] +
xx [ 459 ] + xx [ 473 ] - ( xx [ 453 ] + xx [ 38 ] * xx [ 454 ] ) * xx [ 5 ]
- xx [ 66 ] * xx [ 21 ] ; xx [ 469 ] = xx [ 438 ] - xx [ 263 ] * xx [ 21 ] ;
xx [ 470 ] = xx [ 9 ] - xx [ 341 ] * xx [ 21 ] ; pm_math_Quaternion_xform_ra
( xx + 265 , xx + 468 , xx + 453 ) ; xx [ 459 ] = xx [ 466 ] - xx [ 264 ] *
xx [ 21 ] ; xx [ 460 ] = xx [ 279 ] + xx [ 465 ] - xx [ 45 ] * xx [ 21 ] ; xx
[ 461 ] = xx [ 347 ] + xx [ 425 ] - xx [ 39 ] * xx [ 21 ] ;
pm_math_Quaternion_xform_ra ( xx + 265 , xx + 459 , xx + 465 ) ;
pm_math_Vector3_cross_ra ( xx + 190 , xx + 465 , xx + 459 ) ; xx [ 9 ] = ( xx
[ 454 ] + xx [ 460 ] ) / xx [ 51 ] ; xx [ 453 ] = xx [ 465 ] - xx [ 9 ] * xx
[ 44 ] ; xx [ 454 ] = xx [ 466 ] - xx [ 9 ] * xx [ 53 ] ; xx [ 455 ] = xx [
467 ] - xx [ 9 ] * xx [ 55 ] ; pm_math_Quaternion_xform_ra ( xx + 193 , xx +
453 , xx + 459 ) ; xx [ 453 ] = - xx [ 459 ] ; xx [ 454 ] = - xx [ 460 ] ; xx
[ 455 ] = - xx [ 461 ] ; solveSymmetricPosDef ( xx + 400 , xx + 453 , 3 , 1 ,
xx + 459 , xx + 465 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 193 , xx +
459 , xx + 453 ) ; xx [ 38 ] = xx [ 9 ] + pm_math_Vector3_dot_ra ( xx + 422 ,
xx + 453 ) ; xx [ 9 ] = xx [ 10 ] * xx [ 38 ] ; xx [ 279 ] = xx [ 38 ] * xx [
2 ] ; xx [ 347 ] = - ( ( xx [ 9 ] * xx [ 25 ] - xx [ 279 ] * xx [ 4 ] ) * xx
[ 5 ] ) ; xx [ 425 ] = ( xx [ 10 ] * xx [ 9 ] + xx [ 279 ] * xx [ 2 ] ) * xx
[ 5 ] - xx [ 38 ] ; xx [ 432 ] = xx [ 5 ] * ( xx [ 279 ] * xx [ 25 ] + xx [ 9
] * xx [ 4 ] ) ; xx [ 459 ] = xx [ 347 ] ; xx [ 460 ] = xx [ 425 ] ; xx [ 461
] = xx [ 432 ] ; xx [ 465 ] = xx [ 453 ] + xx [ 65 ] * xx [ 38 ] ; xx [ 466 ]
= xx [ 454 ] ; xx [ 467 ] = xx [ 455 ] - xx [ 38 ] * xx [ 169 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx + 465 , xx + 453 ) ; xx [
9 ] = xx [ 21 ] + pm_math_Vector3_dot_ra ( xx + 428 , xx + 459 ) +
pm_math_Vector3_dot_ra ( xx + 434 , xx + 453 ) ; xx [ 459 ] = xx [ 347 ] ; xx
[ 460 ] = xx [ 425 ] + xx [ 9 ] * xx [ 20 ] ; xx [ 461 ] = xx [ 432 ] + xx [
9 ] * xx [ 23 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 459 ,
xx + 465 ) ; xx [ 21 ] = xx [ 453 ] - xx [ 9 ] * xx [ 243 ] ;
pm_math_Vector3_cross_ra ( xx + 459 , xx + 289 , xx + 468 ) ; xx [ 471 ] = xx
[ 21 ] + xx [ 468 ] ; xx [ 472 ] = xx [ 454 ] + xx [ 469 ] ; xx [ 473 ] = xx
[ 455 ] + xx [ 470 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx +
471 , xx + 468 ) ; xx [ 9 ] = pm_math_Vector3_dot_ra ( xx + 409 , xx + 465 )
+ xx [ 163 ] * xx [ 468 ] + xx [ 173 ] * xx [ 469 ] ; xx [ 38 ] = xx [ 153 ]
* xx [ 466 ] ; xx [ 279 ] = xx [ 153 ] * xx [ 465 ] ; xx [ 347 ] = xx [ 467 ]
- xx [ 9 ] ; xx [ 470 ] = xx [ 465 ] - xx [ 5 ] * ( xx [ 38 ] * xx [ 122 ] +
xx [ 153 ] * xx [ 279 ] ) ; xx [ 471 ] = xx [ 466 ] - ( xx [ 153 ] * xx [ 38
] - xx [ 279 ] * xx [ 122 ] ) * xx [ 5 ] ; xx [ 472 ] = xx [ 347 ] ; xx [ 38
] = xx [ 468 ] + xx [ 166 ] * xx [ 347 ] ; xx [ 279 ] = xx [ 469 ] - xx [ 9 ]
* xx [ 159 ] + xx [ 164 ] * xx [ 347 ] ; xx [ 347 ] = xx [ 153 ] * xx [ 279 ]
; xx [ 425 ] = xx [ 38 ] * xx [ 153 ] ; xx [ 432 ] = pm_math_Vector3_dot_ra (
xx + 439 , xx + 470 ) + ( xx [ 38 ] - xx [ 5 ] * ( xx [ 347 ] * xx [ 122 ] +
xx [ 153 ] * xx [ 425 ] ) ) * xx [ 151 ] + xx [ 141 ] * ( xx [ 279 ] - ( xx [
153 ] * xx [ 347 ] - xx [ 425 ] * xx [ 122 ] ) * xx [ 5 ] ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 459 , xx + 465 ) ;
pm_math_Vector3_cross_ra ( xx + 459 , xx + 336 , xx + 468 ) ; xx [ 471 ] = xx
[ 21 ] + xx [ 468 ] ; xx [ 472 ] = xx [ 454 ] + xx [ 469 ] ; xx [ 473 ] = xx
[ 455 ] + xx [ 470 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx +
471 , xx + 468 ) ; xx [ 38 ] = xx [ 114 ] * xx [ 467 ] + xx [ 138 ] * xx [
469 ] ; xx [ 279 ] = xx [ 9 ] * xx [ 383 ] + xx [ 432 ] * xx [ 366 ] - xx [
38 ] * xx [ 333 ] ; xx [ 347 ] = xx [ 322 ] * xx [ 345 ] + xx [ 431 ] * xx [
275 ] + xx [ 329 ] * xx [ 419 ] ; xx [ 322 ] = xx [ 9 ] * xx [ 345 ] + xx [
432 ] * xx [ 275 ] + xx [ 329 ] * xx [ 38 ] ; xx [ 465 ] = xx [ 288 ] ; xx [
466 ] = xx [ 161 ] ; xx [ 467 ] = xx [ 241 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 462 , xx + 468 ) ;
pm_math_Vector3_cross_ra ( xx + 462 , xx + 370 , xx + 471 ) ; xx [ 474 ] = xx
[ 330 ] + xx [ 471 ] ; xx [ 475 ] = xx [ 457 ] + xx [ 472 ] ; xx [ 476 ] = xx
[ 458 ] + xx [ 473 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx +
474 , xx + 471 ) ; xx [ 9 ] = xx [ 184 ] + pm_math_Vector3_dot_ra ( xx + 465
, xx + 468 ) + xx [ 238 ] * xx [ 471 ] + xx [ 249 ] * xx [ 472 ] ; xx [ 473 ]
= xx [ 356 ] ; xx [ 474 ] = - xx [ 293 ] ; xx [ 475 ] = xx [ 248 ] ; xx [ 38
] = xx [ 233 ] * xx [ 469 ] ; xx [ 161 ] = xx [ 233 ] * xx [ 468 ] ; xx [ 184
] = xx [ 470 ] - xx [ 9 ] ; xx [ 476 ] = xx [ 468 ] - xx [ 5 ] * ( xx [ 38 ]
* xx [ 180 ] + xx [ 233 ] * xx [ 161 ] ) ; xx [ 477 ] = xx [ 469 ] - ( xx [
233 ] * xx [ 38 ] - xx [ 161 ] * xx [ 180 ] ) * xx [ 5 ] ; xx [ 478 ] = xx [
184 ] ; xx [ 38 ] = xx [ 471 ] + xx [ 246 ] * xx [ 184 ] ; xx [ 161 ] = xx [
472 ] - xx [ 9 ] * xx [ 159 ] + xx [ 244 ] * xx [ 184 ] ; xx [ 184 ] = xx [
233 ] * xx [ 161 ] ; xx [ 241 ] = xx [ 38 ] * xx [ 233 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 462 , xx + 468 ) ;
pm_math_Vector3_cross_ra ( xx + 462 , xx + 319 , xx + 479 ) ; xx [ 462 ] = xx
[ 330 ] + xx [ 479 ] ; xx [ 463 ] = xx [ 457 ] + xx [ 480 ] ; xx [ 464 ] = xx
[ 458 ] + xx [ 481 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx +
462 , xx + 479 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 459 ,
xx + 462 ) ; pm_math_Vector3_cross_ra ( xx + 459 , xx + 370 , xx + 481 ) ; xx
[ 484 ] = xx [ 21 ] + xx [ 481 ] ; xx [ 485 ] = xx [ 454 ] + xx [ 482 ] ; xx
[ 486 ] = xx [ 455 ] + xx [ 483 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
449 , xx + 484 , xx + 481 ) ; xx [ 248 ] = xx [ 188 ] +
pm_math_Vector3_dot_ra ( xx + 465 , xx + 462 ) + xx [ 238 ] * xx [ 481 ] + xx
[ 249 ] * xx [ 482 ] ; xx [ 188 ] = xx [ 233 ] * xx [ 463 ] ; xx [ 288 ] = xx
[ 233 ] * xx [ 462 ] ; xx [ 293 ] = xx [ 464 ] - xx [ 248 ] ; xx [ 483 ] = xx
[ 462 ] - xx [ 5 ] * ( xx [ 188 ] * xx [ 180 ] + xx [ 233 ] * xx [ 288 ] ) ;
xx [ 484 ] = xx [ 463 ] - ( xx [ 233 ] * xx [ 188 ] - xx [ 288 ] * xx [ 180 ]
) * xx [ 5 ] ; xx [ 485 ] = xx [ 293 ] ; xx [ 188 ] = xx [ 481 ] + xx [ 246 ]
* xx [ 293 ] ; xx [ 288 ] = xx [ 482 ] - xx [ 248 ] * xx [ 159 ] + xx [ 244 ]
* xx [ 293 ] ; xx [ 293 ] = xx [ 233 ] * xx [ 288 ] ; xx [ 330 ] = xx [ 188 ]
* xx [ 233 ] ; xx [ 356 ] = xx [ 328 ] + pm_math_Vector3_dot_ra ( xx + 473 ,
xx + 483 ) + ( xx [ 188 ] - xx [ 5 ] * ( xx [ 293 ] * xx [ 180 ] + xx [ 233 ]
* xx [ 330 ] ) ) * xx [ 231 ] + xx [ 223 ] * ( xx [ 288 ] - ( xx [ 233 ] * xx
[ 293 ] - xx [ 330 ] * xx [ 180 ] ) * xx [ 5 ] ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 459 , xx + 462 ) ;
pm_math_Vector3_cross_ra ( xx + 459 , xx + 319 , xx + 481 ) ; xx [ 457 ] = xx
[ 21 ] + xx [ 481 ] ; xx [ 458 ] = xx [ 454 ] + xx [ 482 ] ; xx [ 459 ] = xx
[ 455 ] + xx [ 483 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx +
457 , xx + 453 ) ; xx [ 21 ] = xx [ 376 ] + xx [ 114 ] * xx [ 464 ] + xx [
138 ] * xx [ 454 ] ; xx [ 188 ] = xx [ 248 ] * xx [ 317 ] + xx [ 356 ] * xx [
378 ] - xx [ 296 ] * xx [ 21 ] ; xx [ 481 ] = xx [ 70 ] * xx [ 383 ] + ( xx [
369 ] + pm_math_Vector3_dot_ra ( xx + 439 , xx + 442 ) + ( xx [ 74 ] - xx [ 5
] * ( xx [ 108 ] * xx [ 122 ] + xx [ 153 ] * xx [ 110 ] ) ) * xx [ 151 ] + xx
[ 141 ] * ( xx [ 93 ] - ( xx [ 153 ] * xx [ 108 ] - xx [ 110 ] * xx [ 122 ] )
* xx [ 5 ] ) ) * xx [ 366 ] + xx [ 333 ] * ( xx [ 377 ] - ( xx [ 114 ] * xx [
421 ] + xx [ 138 ] * xx [ 426 ] ) ) ; xx [ 482 ] = xx [ 58 ] ; xx [ 483 ] =
xx [ 420 ] ; xx [ 484 ] = xx [ 279 ] ; xx [ 485 ] = xx [ 58 ] ; xx [ 486 ] =
xx [ 57 ] * xx [ 345 ] + xx [ 334 ] * xx [ 275 ] + xx [ 329 ] * xx [ 49 ] ;
xx [ 487 ] = xx [ 347 ] ; xx [ 488 ] = xx [ 322 ] ; xx [ 489 ] = xx [ 420 ] ;
xx [ 490 ] = xx [ 347 ] ; xx [ 491 ] = xx [ 9 ] * xx [ 317 ] + ( xx [ 386 ] +
pm_math_Vector3_dot_ra ( xx + 473 , xx + 476 ) + ( xx [ 38 ] - xx [ 5 ] * (
xx [ 184 ] * xx [ 180 ] + xx [ 233 ] * xx [ 241 ] ) ) * xx [ 231 ] + xx [ 223
] * ( xx [ 161 ] - ( xx [ 233 ] * xx [ 184 ] - xx [ 241 ] * xx [ 180 ] ) * xx
[ 5 ] ) ) * xx [ 378 ] + xx [ 296 ] * ( xx [ 389 ] - ( xx [ 114 ] * xx [ 470
] + xx [ 138 ] * xx [ 480 ] ) ) ; xx [ 492 ] = xx [ 188 ] ; xx [ 493 ] = xx [
279 ] ; xx [ 494 ] = xx [ 322 ] ; xx [ 495 ] = xx [ 188 ] ; xx [ 496 ] = xx [
248 ] * xx [ 456 ] + xx [ 356 ] * xx [ 343 ] + xx [ 298 ] * xx [ 21 ] ; xx [
9 ] = 5.729577951308232e5 ; xx [ 21 ] = 0.4 ; xx [ 38 ] = 0.0 ; xx [ 49 ] =
state [ 16 ] + xx [ 21 ] ; if ( xx [ 38 ] > xx [ 49 ] ) xx [ 49 ] = xx [ 38 ]
; xx [ 57 ] = 572.9577951308231 ; xx [ 58 ] = 1.74532925199433e-3 ; xx [ 70 ]
= xx [ 49 ] / xx [ 58 ] ; if ( xx [ 6 ] < xx [ 70 ] ) xx [ 70 ] = xx [ 6 ] ;
xx [ 74 ] = 3.0 ; xx [ 93 ] = ( xx [ 9 ] * xx [ 49 ] + ( xx [ 49 ] == xx [ 38
] ? xx [ 38 ] : xx [ 57 ] * state [ 17 ] ) ) * xx [ 70 ] * xx [ 70 ] * ( xx [
74 ] - xx [ 5 ] * xx [ 70 ] ) ; if ( xx [ 38 ] > xx [ 93 ] ) xx [ 93 ] = xx [
38 ] ; xx [ 49 ] = input [ 1 ] - xx [ 93 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 300 , xx + 419 ) ; xx [
70 ] = xx [ 421 ] + state [ 17 ] ; xx [ 442 ] = xx [ 419 ] ; xx [ 443 ] = xx
[ 420 ] ; xx [ 444 ] = xx [ 70 ] ; xx [ 453 ] = xx [ 59 ] * xx [ 419 ] ; xx [
454 ] = xx [ 90 ] * xx [ 420 ] ; xx [ 455 ] = xx [ 70 ] * xx [ 171 ] ;
pm_math_Vector3_cross_ra ( xx + 442 , xx + 453 , xx + 457 ) ; xx [ 93 ] = xx
[ 153 ] * xx [ 420 ] ; xx [ 108 ] = xx [ 153 ] * xx [ 419 ] ; xx [ 110 ] = xx
[ 419 ] - xx [ 5 ] * ( xx [ 93 ] * xx [ 122 ] + xx [ 153 ] * xx [ 108 ] ) ;
xx [ 161 ] = xx [ 420 ] - ( xx [ 153 ] * xx [ 93 ] - xx [ 108 ] * xx [ 122 ]
) * xx [ 5 ] ; xx [ 93 ] = xx [ 70 ] + state [ 19 ] ; xx [ 453 ] = xx [ 110 ]
; xx [ 454 ] = xx [ 161 ] ; xx [ 455 ] = xx [ 93 ] ; xx [ 460 ] = xx [ 110 ]
* xx [ 64 ] ; xx [ 461 ] = xx [ 129 ] * xx [ 161 ] ; xx [ 462 ] = xx [ 93 ] *
xx [ 145 ] ; pm_math_Vector3_cross_ra ( xx + 453 , xx + 460 , xx + 468 ) ; xx
[ 108 ] = xx [ 135 ] * xx [ 161 ] ; xx [ 184 ] = xx [ 110 ] * xx [ 135 ] ; xx
[ 188 ] = xx [ 110 ] + xx [ 5 ] * ( xx [ 130 ] * xx [ 108 ] - xx [ 184 ] * xx
[ 135 ] ) ; xx [ 241 ] = xx [ 161 ] - ( xx [ 130 ] * xx [ 184 ] + xx [ 108 ]
* xx [ 135 ] ) * xx [ 5 ] ; xx [ 108 ] = xx [ 93 ] + state [ 21 ] ; xx [ 460
] = xx [ 188 ] ; xx [ 461 ] = xx [ 241 ] ; xx [ 462 ] = xx [ 108 ] ; xx [ 184
] = 3.776314159265359e-3 ; xx [ 476 ] = xx [ 188 ] * xx [ 78 ] ; xx [ 477 ] =
xx [ 78 ] * xx [ 241 ] ; xx [ 478 ] = xx [ 108 ] * xx [ 184 ] ;
pm_math_Vector3_cross_ra ( xx + 460 , xx + 476 , xx + 497 ) ; xx [ 500 ] = xx
[ 6 ] ; xx [ 501 ] = xx [ 38 ] ; xx [ 502 ] = xx [ 38 ] ; xx [ 503 ] = xx [
38 ] ; xx [ 504 ] = xx [ 38 ] ; xx [ 505 ] = xx [ 38 ] ; xx [ 506 ] = xx [ 38
] ; xx [ 248 ] = xx [ 0 ] * xx [ 7 ] ; xx [ 7 ] = xx [ 0 ] * xx [ 3 ] ; xx [
460 ] = xx [ 248 ] - xx [ 7 ] ; xx [ 461 ] = - ( xx [ 7 ] + xx [ 248 ] ) ; xx
[ 462 ] = - ( xx [ 248 ] + xx [ 7 ] ) ; xx [ 463 ] = xx [ 7 ] - xx [ 248 ] ;
pm_math_Quaternion_compose_ra ( xx + 460 , xx + 265 , xx + 476 ) ;
pm_math_Quaternion_compose_ra ( xx + 476 , xx + 415 , xx + 507 ) ; xx [ 0 ] =
xx [ 510 ] * xx [ 122 ] - xx [ 153 ] * xx [ 507 ] ; xx [ 3 ] = xx [ 507 ] *
xx [ 122 ] + xx [ 153 ] * xx [ 510 ] ; xx [ 7 ] = xx [ 0 ] * xx [ 135 ] - xx
[ 130 ] * xx [ 3 ] ; xx [ 248 ] = xx [ 508 ] * xx [ 122 ] - xx [ 153 ] * xx [
509 ] ; xx [ 279 ] = xx [ 509 ] * xx [ 122 ] + xx [ 153 ] * xx [ 508 ] ; xx [
288 ] = xx [ 248 ] * xx [ 130 ] + xx [ 135 ] * xx [ 279 ] ; xx [ 293 ] = xx [
248 ] * xx [ 135 ] - xx [ 130 ] * xx [ 279 ] ; xx [ 322 ] = xx [ 135 ] * xx [
3 ] + xx [ 0 ] * xx [ 130 ] ; xx [ 328 ] = xx [ 250 ] * xx [ 279 ] ; xx [ 511
] = xx [ 248 ] ; xx [ 512 ] = xx [ 279 ] ; xx [ 513 ] = xx [ 0 ] ; xx [ 330 ]
= xx [ 0 ] * xx [ 140 ] - xx [ 248 ] * xx [ 250 ] ; xx [ 0 ] = xx [ 140 ] *
xx [ 279 ] ; xx [ 514 ] = xx [ 328 ] ; xx [ 515 ] = xx [ 330 ] ; xx [ 516 ] =
- xx [ 0 ] ; pm_math_Vector3_cross_ra ( xx + 511 , xx + 514 , xx + 517 ) ; xx
[ 248 ] = xx [ 510 ] * xx [ 166 ] ; xx [ 279 ] = xx [ 164 ] * xx [ 510 ] ; xx
[ 334 ] = xx [ 508 ] * xx [ 166 ] + xx [ 164 ] * xx [ 509 ] ; xx [ 511 ] = xx
[ 248 ] ; xx [ 512 ] = xx [ 279 ] ; xx [ 513 ] = - xx [ 334 ] ;
pm_math_Vector3_cross_ra ( xx + 508 , xx + 511 , xx + 514 ) ;
pm_math_Quaternion_xform_ra ( xx + 476 , xx + 289 , xx + 508 ) ;
pm_math_Quaternion_xform_ra ( xx + 460 , xx + 190 , xx + 511 ) ; xx [ 347 ] =
xx [ 511 ] + state [ 2 ] ; xx [ 356 ] = 7.944796046594101e-5 ; xx [ 369 ] =
xx [ 356 ] * xx [ 293 ] ; xx [ 376 ] = xx [ 288 ] * xx [ 356 ] ; xx [ 377 ] =
xx [ 512 ] + state [ 1 ] ; xx [ 386 ] = xx [ 513 ] - state [ 0 ] + 0.8 ; xx [
520 ] = - xx [ 7 ] ; xx [ 521 ] = xx [ 288 ] ; xx [ 522 ] = - xx [ 293 ] ; xx
[ 523 ] = xx [ 322 ] ; xx [ 524 ] = ( xx [ 328 ] * xx [ 3 ] + xx [ 517 ] ) *
xx [ 5 ] + xx [ 164 ] + ( xx [ 507 ] * xx [ 248 ] + xx [ 514 ] ) * xx [ 5 ] +
xx [ 508 ] + xx [ 347 ] + xx [ 140 ] - ( xx [ 369 ] * xx [ 7 ] + xx [ 322 ] *
xx [ 376 ] ) * xx [ 5 ] ; xx [ 525 ] = xx [ 5 ] * ( xx [ 322 ] * xx [ 369 ] -
xx [ 376 ] * xx [ 7 ] ) + ( xx [ 330 ] * xx [ 3 ] + xx [ 518 ] ) * xx [ 5 ] +
( xx [ 507 ] * xx [ 279 ] + xx [ 515 ] ) * xx [ 5 ] - xx [ 166 ] + xx [ 509 ]
+ xx [ 377 ] ; xx [ 526 ] = ( xx [ 288 ] * xx [ 376 ] + xx [ 369 ] * xx [ 293
] ) * xx [ 5 ] - xx [ 356 ] + xx [ 5 ] * ( xx [ 519 ] - xx [ 0 ] * xx [ 3 ] )
+ xx [ 5 ] * ( xx [ 516 ] - xx [ 334 ] * xx [ 507 ] ) + xx [ 510 ] + xx [ 386
] + xx [ 250 ] ; bb [ 0 ] =
sm_core_compiler_computeProximityInfoBrickCylinder (
series_link_blance_leg_ad6bcbee_1_geometry_1 ( NULL ) ,
series_link_blance_leg_ad6bcbee_1_geometry_0 ( NULL ) , ( pm_math_Transform3
* ) ( xx + 500 ) , ( pm_math_Transform3 * ) ( xx + 520 ) , xx + 0 , (
pm_math_Vector3 * ) ( xx + 460 ) , ( pm_math_Vector3 * ) ( xx + 507 ) , (
pm_math_Vector3 * ) ( xx + 510 ) , ( pm_math_Vector3 * ) ( xx + 513 ) ) ; xx
[ 3 ] = - xx [ 6 ] ; xx [ 527 ] = xx [ 3 ] ; xx [ 528 ] = xx [ 38 ] ; xx [
529 ] = xx [ 38 ] ; xx [ 530 ] = xx [ 38 ] ; xx [ 531 ] = xx [ 38 ] ; xx [
532 ] = xx [ 38 ] ; xx [ 533 ] = - xx [ 356 ] ; xx [ 7 ] = xx [ 250 ] * xx [
161 ] ; xx [ 248 ] = xx [ 70 ] * xx [ 166 ] ; pm_math_Vector3_cross_ra ( xx +
300 , xx + 289 , xx + 516 ) ; xx [ 534 ] = state [ 3 ] ; xx [ 535 ] = state [
4 ] ; xx [ 536 ] = state [ 5 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
193 , xx + 534 , xx + 537 ) ; xx [ 279 ] = xx [ 65 ] * state [ 7 ] ; xx [ 288
] = xx [ 169 ] * state [ 7 ] ; xx [ 534 ] = xx [ 537 ] - xx [ 279 ] ; xx [
535 ] = xx [ 538 ] ; xx [ 536 ] = xx [ 288 ] + xx [ 539 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx + 534 , xx + 537 ) ; xx [
293 ] = xx [ 243 ] * state [ 9 ] ; xx [ 322 ] = xx [ 537 ] + xx [ 293 ] ; xx
[ 534 ] = xx [ 516 ] + xx [ 322 ] ; xx [ 535 ] = xx [ 517 ] + xx [ 538 ] ; xx
[ 536 ] = xx [ 518 ] + xx [ 539 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
415 , xx + 534 , xx + 540 ) ; xx [ 328 ] = xx [ 248 ] + xx [ 540 ] ; xx [ 330
] = xx [ 70 ] * xx [ 164 ] ; xx [ 334 ] = xx [ 159 ] * state [ 17 ] ; xx [
369 ] = xx [ 330 ] + xx [ 541 ] + xx [ 334 ] ; xx [ 376 ] = xx [ 369 ] * xx [
153 ] ; xx [ 389 ] = xx [ 328 ] * xx [ 153 ] ; xx [ 425 ] = xx [ 7 ] + xx [
328 ] - xx [ 5 ] * ( xx [ 376 ] * xx [ 122 ] + xx [ 153 ] * xx [ 389 ] ) ; xx
[ 328 ] = xx [ 93 ] * xx [ 140 ] - xx [ 110 ] * xx [ 250 ] ; xx [ 426 ] = xx
[ 143 ] * state [ 19 ] ; xx [ 431 ] = xx [ 328 ] + xx [ 369 ] - ( xx [ 153 ]
* xx [ 376 ] - xx [ 389 ] * xx [ 122 ] ) * xx [ 5 ] + xx [ 426 ] ; xx [ 369 ]
= xx [ 431 ] * xx [ 135 ] ; xx [ 376 ] = xx [ 425 ] * xx [ 135 ] ; xx [ 389 ]
= xx [ 419 ] * xx [ 166 ] + xx [ 164 ] * xx [ 420 ] ; xx [ 432 ] = xx [ 140 ]
* xx [ 161 ] ; xx [ 543 ] = xx [ 188 ] ; xx [ 544 ] = xx [ 241 ] ; xx [ 545 ]
= xx [ 108 ] ; xx [ 546 ] = xx [ 425 ] + xx [ 5 ] * ( xx [ 130 ] * xx [ 369 ]
- xx [ 376 ] * xx [ 135 ] ) ; xx [ 547 ] = xx [ 431 ] - ( xx [ 130 ] * xx [
376 ] + xx [ 369 ] * xx [ 135 ] ) * xx [ 5 ] ; xx [ 548 ] = xx [ 542 ] - xx [
389 ] - xx [ 432 ] ; xx [ 108 ] = 1.0e6 ; xx [ 369 ] = 1000.0 ; xx [ 376 ] =
1.0e-4 ; xx [ 425 ] = 0.3 ; xx [ 431 ] = 0.2119573811760597 ; xx [ 437 ] =
9.126024771145405e-4 ; sm_core_compiler_computeContactWrenches ( 0 , 1 , bb [
0 ] , xx + 0 , ( const pm_math_Vector3 * ) ( xx + 460 ) , ( const
pm_math_Vector3 * ) ( xx + 507 ) , ( const pm_math_Vector3 * ) ( xx + 510 ) ,
( const pm_math_Vector3 * ) ( xx + 513 ) , ( const pm_math_Transform3 * ) (
xx + 500 ) , ( const pm_math_Transform3 * ) ( xx + 527 ) , ( const
pm_math_Transform3 * ) ( xx + 500 ) , ( const pm_math_Transform3 * ) ( xx +
520 ) , NULL , ( const pm_math_SpatialVector * ) ( xx + 543 ) , 0 , 1 , xx [
108 ] , xx [ 369 ] , xx [ 376 ] , xx [ 425 ] , xx [ 431 ] , xx [ 437 ] , NULL
, NULL , NULL , ( pm_math_SpatialVector * ) ( xx + 549 ) ) ; xx [ 0 ] = xx [
499 ] - xx [ 551 ] ; xx [ 438 ] = input [ 3 ] - xx [ 0 ] ; xx [ 460 ] = xx [
7 ] ; xx [ 461 ] = xx [ 328 ] ; xx [ 462 ] = - xx [ 432 ] ;
pm_math_Vector3_cross_ra ( xx + 453 , xx + 460 , xx + 507 ) ; xx [ 7 ] = xx [
507 ] * xx [ 135 ] ; xx [ 328 ] = xx [ 508 ] * xx [ 135 ] ; xx [ 432 ] = xx [
128 ] * ( xx [ 508 ] - ( xx [ 130 ] * xx [ 7 ] + xx [ 328 ] * xx [ 135 ] ) *
xx [ 5 ] ) - xx [ 553 ] ; xx [ 453 ] = ( xx [ 507 ] + xx [ 5 ] * ( xx [ 130 ]
* xx [ 328 ] - xx [ 7 ] * xx [ 135 ] ) ) * xx [ 128 ] - xx [ 552 ] ; xx [ 7 ]
= xx [ 135 ] * xx [ 453 ] ; xx [ 328 ] = xx [ 135 ] * xx [ 432 ] ; xx [ 454 ]
= xx [ 432 ] + xx [ 5 ] * ( xx [ 130 ] * xx [ 7 ] - xx [ 328 ] * xx [ 135 ] )
; xx [ 432 ] = xx [ 454 ] * xx [ 140 ] ; xx [ 460 ] = xx [ 248 ] ; xx [ 461 ]
= xx [ 330 ] ; xx [ 462 ] = - xx [ 389 ] ; pm_math_Vector3_cross_ra ( xx +
442 , xx + 460 , xx + 510 ) ; xx [ 248 ] = xx [ 153 ] * xx [ 511 ] ; xx [ 330
] = xx [ 153 ] * xx [ 510 ] ; xx [ 389 ] = xx [ 510 ] - xx [ 5 ] * ( xx [ 248
] * xx [ 122 ] + xx [ 153 ] * xx [ 330 ] ) - ( xx [ 70 ] + xx [ 93 ] ) * xx [
426 ] ; xx [ 93 ] = xx [ 511 ] - ( xx [ 153 ] * xx [ 248 ] - xx [ 330 ] * xx
[ 122 ] ) * xx [ 5 ] ; xx [ 248 ] = xx [ 161 ] * state [ 19 ] ; xx [ 161 ] =
xx [ 110 ] * state [ 19 ] ; xx [ 330 ] = xx [ 142 ] * xx [ 389 ] + xx [ 134 ]
* xx [ 93 ] - ( xx [ 132 ] * xx [ 248 ] + xx [ 161 ] * xx [ 276 ] ) ; xx [
132 ] = xx [ 470 ] + xx [ 0 ] + xx [ 438 ] + xx [ 432 ] + xx [ 330 ] ; xx [
134 ] = xx [ 454 ] + xx [ 389 ] * xx [ 157 ] + xx [ 148 ] * xx [ 93 ] - ( xx
[ 252 ] * xx [ 248 ] + xx [ 161 ] * xx [ 260 ] ) ; xx [ 142 ] = xx [ 134 ] *
xx [ 143 ] ; xx [ 148 ] = ( xx [ 132 ] + xx [ 142 ] ) / xx [ 150 ] ; xx [ 157
] = xx [ 134 ] - xx [ 149 ] * xx [ 148 ] ; xx [ 276 ] = xx [ 453 ] - ( xx [
130 ] * xx [ 328 ] + xx [ 7 ] * xx [ 135 ] ) * xx [ 5 ] ; xx [ 7 ] = xx [ 276
] + xx [ 139 ] * xx [ 389 ] + xx [ 93 ] * xx [ 133 ] - ( xx [ 255 ] * xx [
248 ] + xx [ 161 ] * xx [ 259 ] ) ; xx [ 133 ] = xx [ 7 ] - xx [ 144 ] * xx [
148 ] ; xx [ 139 ] = xx [ 153 ] * xx [ 133 ] ; xx [ 328 ] = xx [ 153 ] * xx [
157 ] ; xx [ 442 ] = xx [ 157 ] - xx [ 5 ] * ( xx [ 139 ] * xx [ 122 ] + xx [
153 ] * xx [ 328 ] ) ; xx [ 157 ] = xx [ 133 ] - ( xx [ 153 ] * xx [ 139 ] -
xx [ 328 ] * xx [ 122 ] ) * xx [ 5 ] ; xx [ 133 ] = xx [ 420 ] * state [ 17 ]
; xx [ 139 ] = xx [ 419 ] * state [ 17 ] ; pm_math_Vector3_cross_ra ( xx +
300 , xx + 516 , xx + 460 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 415 ,
xx + 460 , xx + 513 ) ; xx [ 328 ] = xx [ 513 ] - ( xx [ 421 ] + xx [ 70 ] )
* xx [ 334 ] ; xx [ 70 ] = xx [ 278 ] * xx [ 133 ] - xx [ 262 ] * xx [ 139 ]
+ xx [ 155 ] * xx [ 328 ] + xx [ 125 ] * xx [ 514 ] ; xx [ 125 ] = xx [ 459 ]
+ xx [ 132 ] - xx [ 147 ] * xx [ 148 ] + xx [ 164 ] * xx [ 442 ] + xx [ 166 ]
* xx [ 157 ] + xx [ 70 ] ; xx [ 132 ] = xx [ 133 ] * xx [ 257 ] - xx [ 258 ]
* xx [ 139 ] + xx [ 162 ] * xx [ 328 ] + xx [ 152 ] * xx [ 514 ] ; xx [ 152 ]
= xx [ 442 ] + xx [ 132 ] ; xx [ 155 ] = ( xx [ 49 ] - ( xx [ 125 ] + xx [
152 ] * xx [ 159 ] ) ) / xx [ 156 ] ; xx [ 162 ] = xx [ 54 ] * xx [ 115 ] +
xx [ 117 ] * xx [ 120 ] ; xx [ 442 ] = xx [ 62 ] * xx [ 103 ] ; xx [ 443 ] =
xx [ 119 ] * xx [ 131 ] ; xx [ 444 ] = - ( xx [ 56 ] * xx [ 311 ] ) ;
pm_math_Vector3_cross_ra ( xx + 300 , xx + 442 , xx + 460 ) ; xx [ 442 ] = xx
[ 312 ] ; xx [ 443 ] = xx [ 313 ] ; xx [ 444 ] = xx [ 121 ] ; xx [ 516 ] = xx
[ 277 ] * xx [ 312 ] ; xx [ 517 ] = xx [ 360 ] * xx [ 313 ] ; xx [ 518 ] = xx
[ 121 ] * xx [ 360 ] ; pm_math_Vector3_cross_ra ( xx + 442 , xx + 516 , xx +
519 ) ; xx [ 62 ] = xx [ 519 ] + xx [ 277 ] * xx [ 313 ] * state [ 25 ] ; xx
[ 121 ] = xx [ 520 ] - xx [ 360 ] * xx [ 312 ] * state [ 25 ] ; xx [ 131 ] =
xx [ 521 ] + xx [ 292 ] * xx [ 305 ] ; xx [ 262 ] = xx [ 131 ] / xx [ 365 ] ;
xx [ 442 ] = xx [ 62 ] ; xx [ 443 ] = xx [ 121 ] ; xx [ 444 ] = xx [ 521 ] -
xx [ 360 ] * xx [ 262 ] ; pm_math_Quaternion_xform_ra ( xx + 269 , xx + 442 ,
xx + 516 ) ; xx [ 278 ] = ( ( xx [ 312 ] + xx [ 312 ] ) * xx [ 197 ] + xx [
309 ] ) * xx [ 26 ] ; xx [ 307 ] = xx [ 304 ] ; xx [ 308 ] = xx [ 305 ] - xx
[ 315 ] * xx [ 262 ] ; xx [ 309 ] = xx [ 278 ] ; pm_math_Quaternion_xform_ra
( xx + 269 , xx + 307 , xx + 311 ) ; pm_math_Vector3_cross_ra ( xx + 319 , xx
+ 311 , xx + 307 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 300
, xx + 442 ) ; xx [ 197 ] = xx [ 444 ] + state [ 23 ] ; xx [ 522 ] = xx [ 442
] ; xx [ 523 ] = xx [ 443 ] ; xx [ 524 ] = xx [ 197 ] ; xx [ 525 ] = xx [ 277
] * xx [ 442 ] ; xx [ 526 ] = xx [ 360 ] * xx [ 443 ] ; xx [ 527 ] = xx [ 197
] * xx [ 360 ] ; pm_math_Vector3_cross_ra ( xx + 522 , xx + 525 , xx + 528 )
; xx [ 314 ] = xx [ 528 ] + xx [ 277 ] * xx [ 443 ] * state [ 23 ] ; xx [ 277
] = xx [ 529 ] - xx [ 360 ] * xx [ 442 ] * state [ 23 ] ;
pm_math_Vector3_cross_ra ( xx + 300 , xx + 336 , xx + 522 ) ;
pm_math_Vector3_cross_ra ( xx + 300 , xx + 522 , xx + 525 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 525 , xx + 522 ) ; xx [
420 ] = xx [ 26 ] * xx [ 523 ] ; xx [ 421 ] = xx [ 530 ] + xx [ 292 ] * xx [
420 ] ; xx [ 443 ] = xx [ 421 ] / xx [ 365 ] ; xx [ 525 ] = xx [ 314 ] ; xx [
526 ] = xx [ 277 ] ; xx [ 527 ] = xx [ 530 ] - xx [ 360 ] * xx [ 443 ] ;
pm_math_Quaternion_xform_ra ( xx + 445 , xx + 525 , xx + 531 ) ; xx [ 453 ] =
xx [ 292 ] * state [ 23 ] ; xx [ 292 ] = xx [ 26 ] * ( xx [ 522 ] - ( xx [
444 ] + xx [ 197 ] ) * xx [ 453 ] ) ; xx [ 197 ] = ( ( xx [ 442 ] + xx [ 442
] ) * xx [ 453 ] + xx [ 524 ] ) * xx [ 26 ] ; xx [ 522 ] = xx [ 292 ] ; xx [
523 ] = xx [ 420 ] - xx [ 315 ] * xx [ 443 ] ; xx [ 524 ] = xx [ 197 ] ;
pm_math_Quaternion_xform_ra ( xx + 445 , xx + 522 , xx + 525 ) ;
pm_math_Vector3_cross_ra ( xx + 336 , xx + 525 , xx + 522 ) ; xx [ 26 ] = xx
[ 497 ] - xx [ 549 ] + xx [ 78 ] * xx [ 241 ] * state [ 21 ] ; xx [ 241 ] =
xx [ 498 ] - xx [ 550 ] - xx [ 78 ] * xx [ 188 ] * state [ 21 ] ; xx [ 188 ]
= xx [ 135 ] * xx [ 241 ] ; xx [ 442 ] = xx [ 26 ] * xx [ 135 ] ; xx [ 444 ]
= xx [ 468 ] + xx [ 26 ] - ( xx [ 130 ] * xx [ 188 ] + xx [ 442 ] * xx [ 135
] ) * xx [ 5 ] - xx [ 454 ] * xx [ 250 ] + xx [ 97 ] * xx [ 248 ] - xx [ 161
] * xx [ 79 ] - ( xx [ 255 ] * xx [ 389 ] + xx [ 252 ] * xx [ 93 ] ) ; xx [
26 ] = xx [ 444 ] + xx [ 146 ] * xx [ 148 ] ; xx [ 79 ] = xx [ 26 ] * xx [
153 ] ; xx [ 97 ] = xx [ 128 ] * xx [ 509 ] - xx [ 554 ] ; xx [ 252 ] = ( xx
[ 110 ] + xx [ 110 ] ) * xx [ 426 ] + xx [ 512 ] ; xx [ 110 ] = xx [ 469 ] +
xx [ 241 ] + xx [ 5 ] * ( xx [ 130 ] * xx [ 442 ] - xx [ 188 ] * xx [ 135 ] )
+ xx [ 250 ] * xx [ 276 ] - xx [ 140 ] * xx [ 97 ] + xx [ 248 ] * xx [ 323 ]
- xx [ 189 ] * xx [ 161 ] + xx [ 259 ] * xx [ 389 ] + xx [ 260 ] * xx [ 93 ]
- xx [ 252 ] * xx [ 283 ] ; xx [ 93 ] = xx [ 110 ] - xx [ 261 ] * xx [ 148 ]
; xx [ 130 ] = xx [ 153 ] * xx [ 93 ] ; xx [ 135 ] = xx [ 97 ] + xx [ 161 ] *
xx [ 283 ] + xx [ 177 ] * xx [ 252 ] ; xx [ 97 ] = xx [ 135 ] * xx [ 166 ] ;
xx [ 177 ] = ( xx [ 419 ] + xx [ 419 ] ) * xx [ 334 ] + xx [ 515 ] ; xx [ 188
] = xx [ 340 ] * xx [ 133 ] - xx [ 176 ] * xx [ 139 ] + xx [ 328 ] * xx [ 274
] + xx [ 514 ] * xx [ 257 ] - xx [ 177 ] * xx [ 286 ] ; xx [ 176 ] = xx [ 164
] * xx [ 135 ] ; xx [ 189 ] = xx [ 363 ] * xx [ 133 ] - xx [ 94 ] * xx [ 139
] + xx [ 287 ] * xx [ 328 ] + xx [ 258 ] * xx [ 514 ] - xx [ 177 ] * xx [ 178
] ; xx [ 257 ] = xx [ 457 ] + xx [ 26 ] - ( xx [ 153 ] * xx [ 79 ] - xx [ 130
] * xx [ 122 ] ) * xx [ 5 ] - xx [ 97 ] + xx [ 188 ] + xx [ 280 ] * xx [ 155
] ; xx [ 258 ] = xx [ 458 ] + xx [ 93 ] - xx [ 5 ] * ( xx [ 79 ] * xx [ 122 ]
+ xx [ 153 ] * xx [ 130 ] ) - xx [ 176 ] + xx [ 189 ] + xx [ 273 ] * xx [ 155
] ; xx [ 259 ] = xx [ 125 ] + xx [ 137 ] * xx [ 155 ] ;
pm_math_Quaternion_xform_ra ( xx + 415 , xx + 257 , xx + 453 ) ; xx [ 26 ] =
xx [ 133 ] * xx [ 274 ] - xx [ 287 ] * xx [ 139 ] + xx [ 160 ] * xx [ 328 ] +
xx [ 514 ] * xx [ 136 ] ; xx [ 79 ] = xx [ 135 ] + xx [ 178 ] * xx [ 139 ] -
xx [ 133 ] * xx [ 286 ] + xx [ 179 ] * xx [ 177 ] ; xx [ 177 ] = xx [ 157 ] +
xx [ 26 ] + xx [ 170 ] * xx [ 155 ] ; xx [ 178 ] = xx [ 152 ] + xx [ 154 ] *
xx [ 155 ] ; xx [ 179 ] = xx [ 79 ] ; pm_math_Quaternion_xform_ra ( xx + 415
, xx + 177 , xx + 257 ) ; pm_math_Vector3_cross_ra ( xx + 289 , xx + 257 , xx
+ 177 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 300 , xx + 497
) ; xx [ 93 ] = xx [ 499 ] + state [ 11 ] ; xx [ 507 ] = xx [ 497 ] ; xx [
508 ] = xx [ 498 ] ; xx [ 509 ] = xx [ 93 ] ; xx [ 510 ] = xx [ 59 ] * xx [
497 ] ; xx [ 511 ] = xx [ 90 ] * xx [ 498 ] ; xx [ 512 ] = xx [ 93 ] * xx [
171 ] ; pm_math_Vector3_cross_ra ( xx + 507 , xx + 510 , xx + 534 ) ; xx [ 59
] = xx [ 233 ] * xx [ 498 ] ; xx [ 90 ] = xx [ 233 ] * xx [ 497 ] ; xx [ 94 ]
= xx [ 497 ] - xx [ 5 ] * ( xx [ 59 ] * xx [ 180 ] + xx [ 233 ] * xx [ 90 ] )
; xx [ 125 ] = xx [ 498 ] - ( xx [ 233 ] * xx [ 59 ] - xx [ 90 ] * xx [ 180 ]
) * xx [ 5 ] ; xx [ 59 ] = xx [ 93 ] + state [ 13 ] ; xx [ 510 ] = xx [ 94 ]
; xx [ 511 ] = xx [ 125 ] ; xx [ 512 ] = xx [ 59 ] ; xx [ 540 ] = xx [ 94 ] *
xx [ 64 ] ; xx [ 541 ] = xx [ 129 ] * xx [ 125 ] ; xx [ 542 ] = xx [ 59 ] *
xx [ 145 ] ; pm_math_Vector3_cross_ra ( xx + 510 , xx + 540 , xx + 543 ) ; xx
[ 64 ] = xx [ 218 ] * xx [ 125 ] ; xx [ 90 ] = xx [ 94 ] * xx [ 218 ] ; xx [
129 ] = xx [ 94 ] + xx [ 5 ] * ( xx [ 1 ] * xx [ 64 ] - xx [ 90 ] * xx [ 218
] ) ; xx [ 130 ] = xx [ 125 ] - ( xx [ 1 ] * xx [ 90 ] + xx [ 64 ] * xx [ 218
] ) * xx [ 5 ] ; xx [ 64 ] = xx [ 59 ] + state [ 15 ] ; xx [ 540 ] = xx [ 129
] ; xx [ 541 ] = xx [ 130 ] ; xx [ 542 ] = xx [ 64 ] ; xx [ 546 ] = xx [ 129
] * xx [ 78 ] ; xx [ 547 ] = xx [ 78 ] * xx [ 130 ] ; xx [ 548 ] = xx [ 64 ]
* xx [ 184 ] ; pm_math_Vector3_cross_ra ( xx + 540 , xx + 546 , xx + 549 ) ;
pm_math_Quaternion_compose_ra ( xx + 476 , xx + 449 , xx + 552 ) ; xx [ 90 ]
= xx [ 555 ] * xx [ 180 ] - xx [ 233 ] * xx [ 552 ] ; xx [ 135 ] = xx [ 552 ]
* xx [ 180 ] + xx [ 233 ] * xx [ 555 ] ; xx [ 136 ] = xx [ 90 ] * xx [ 218 ]
- xx [ 1 ] * xx [ 135 ] ; xx [ 145 ] = xx [ 553 ] * xx [ 180 ] - xx [ 233 ] *
xx [ 554 ] ; xx [ 152 ] = xx [ 554 ] * xx [ 180 ] + xx [ 233 ] * xx [ 553 ] ;
xx [ 157 ] = xx [ 145 ] * xx [ 1 ] + xx [ 218 ] * xx [ 152 ] ; xx [ 160 ] =
xx [ 145 ] * xx [ 218 ] - xx [ 1 ] * xx [ 152 ] ; xx [ 171 ] = xx [ 218 ] *
xx [ 135 ] + xx [ 90 ] * xx [ 1 ] ; xx [ 241 ] = xx [ 356 ] * xx [ 160 ] ; xx
[ 252 ] = xx [ 157 ] * xx [ 356 ] ; xx [ 540 ] = xx [ 145 ] ; xx [ 541 ] = xx
[ 152 ] ; xx [ 542 ] = xx [ 90 ] ; xx [ 255 ] = xx [ 250 ] * xx [ 152 ] ; xx
[ 260 ] = xx [ 90 ] * xx [ 140 ] + xx [ 145 ] * xx [ 250 ] ; xx [ 90 ] = xx [
140 ] * xx [ 152 ] ; xx [ 546 ] = - xx [ 255 ] ; xx [ 547 ] = xx [ 260 ] ; xx
[ 548 ] = - xx [ 90 ] ; pm_math_Vector3_cross_ra ( xx + 540 , xx + 546 , xx +
556 ) ; xx [ 145 ] = xx [ 555 ] * xx [ 246 ] ; xx [ 152 ] = xx [ 244 ] * xx [
555 ] ; xx [ 274 ] = xx [ 553 ] * xx [ 246 ] + xx [ 244 ] * xx [ 554 ] ; xx [
540 ] = xx [ 145 ] ; xx [ 541 ] = xx [ 152 ] ; xx [ 542 ] = - xx [ 274 ] ;
pm_math_Vector3_cross_ra ( xx + 553 , xx + 540 , xx + 546 ) ;
pm_math_Quaternion_xform_ra ( xx + 476 , xx + 370 , xx + 540 ) ; xx [ 559 ] =
- xx [ 136 ] ; xx [ 560 ] = xx [ 157 ] ; xx [ 561 ] = - xx [ 160 ] ; xx [ 562
] = xx [ 171 ] ; xx [ 563 ] = ( xx [ 241 ] * xx [ 136 ] + xx [ 171 ] * xx [
252 ] ) * xx [ 5 ] + ( xx [ 556 ] - xx [ 255 ] * xx [ 135 ] ) * xx [ 5 ] + xx
[ 244 ] + ( xx [ 552 ] * xx [ 145 ] + xx [ 546 ] ) * xx [ 5 ] + xx [ 540 ] +
xx [ 347 ] + xx [ 140 ] ; xx [ 564 ] = xx [ 5 ] * ( xx [ 252 ] * xx [ 136 ] -
xx [ 171 ] * xx [ 241 ] ) + ( xx [ 260 ] * xx [ 135 ] + xx [ 557 ] ) * xx [ 5
] + ( xx [ 552 ] * xx [ 152 ] + xx [ 547 ] ) * xx [ 5 ] - xx [ 246 ] + xx [
541 ] + xx [ 377 ] ; xx [ 565 ] = xx [ 356 ] - ( xx [ 157 ] * xx [ 252 ] + xx
[ 241 ] * xx [ 160 ] ) * xx [ 5 ] + xx [ 5 ] * ( xx [ 558 ] - xx [ 90 ] * xx
[ 135 ] ) + xx [ 5 ] * ( xx [ 548 ] - xx [ 274 ] * xx [ 552 ] ) + xx [ 542 ]
+ xx [ 386 ] - xx [ 250 ] ; bb [ 0 ] =
sm_core_compiler_computeProximityInfoBrickCylinder (
series_link_blance_leg_ad6bcbee_1_geometry_1 ( NULL ) ,
series_link_blance_leg_ad6bcbee_1_geometry_0 ( NULL ) , ( pm_math_Transform3
* ) ( xx + 500 ) , ( pm_math_Transform3 * ) ( xx + 559 ) , xx + 90 , (
pm_math_Vector3 * ) ( xx + 476 ) , ( pm_math_Vector3 * ) ( xx + 540 ) , (
pm_math_Vector3 * ) ( xx + 546 ) , ( pm_math_Vector3 * ) ( xx + 552 ) ) ; xx
[ 566 ] = xx [ 3 ] ; xx [ 567 ] = xx [ 38 ] ; xx [ 568 ] = xx [ 38 ] ; xx [
569 ] = xx [ 38 ] ; xx [ 570 ] = xx [ 38 ] ; xx [ 571 ] = xx [ 38 ] ; xx [
572 ] = xx [ 356 ] ; xx [ 3 ] = xx [ 93 ] * xx [ 246 ] ;
pm_math_Vector3_cross_ra ( xx + 300 , xx + 370 , xx + 555 ) ; xx [ 573 ] = xx
[ 555 ] + xx [ 322 ] ; xx [ 574 ] = xx [ 556 ] + xx [ 538 ] ; xx [ 575 ] = xx
[ 557 ] + xx [ 539 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx +
573 , xx + 537 ) ; xx [ 135 ] = xx [ 3 ] + xx [ 537 ] ; xx [ 136 ] = xx [ 93
] * xx [ 244 ] ; xx [ 145 ] = xx [ 159 ] * state [ 11 ] ; xx [ 152 ] = xx [
136 ] + xx [ 538 ] + xx [ 145 ] ; xx [ 157 ] = xx [ 152 ] * xx [ 233 ] ; xx [
160 ] = xx [ 135 ] * xx [ 233 ] ; xx [ 171 ] = xx [ 250 ] * xx [ 125 ] ; xx [
241 ] = xx [ 135 ] - xx [ 5 ] * ( xx [ 157 ] * xx [ 180 ] + xx [ 233 ] * xx [
160 ] ) - xx [ 171 ] ; xx [ 135 ] = xx [ 59 ] * xx [ 140 ] + xx [ 94 ] * xx [
250 ] ; xx [ 252 ] = xx [ 143 ] * state [ 13 ] ; xx [ 255 ] = xx [ 135 ] + xx
[ 152 ] - ( xx [ 233 ] * xx [ 157 ] - xx [ 160 ] * xx [ 180 ] ) * xx [ 5 ] +
xx [ 252 ] ; xx [ 152 ] = xx [ 255 ] * xx [ 218 ] ; xx [ 157 ] = xx [ 241 ] *
xx [ 218 ] ; xx [ 160 ] = xx [ 497 ] * xx [ 246 ] + xx [ 244 ] * xx [ 498 ] ;
xx [ 260 ] = xx [ 140 ] * xx [ 125 ] ; xx [ 573 ] = xx [ 129 ] ; xx [ 574 ] =
xx [ 130 ] ; xx [ 575 ] = xx [ 64 ] ; xx [ 576 ] = xx [ 241 ] + xx [ 5 ] * (
xx [ 1 ] * xx [ 152 ] - xx [ 157 ] * xx [ 218 ] ) ; xx [ 577 ] = xx [ 255 ] -
( xx [ 1 ] * xx [ 157 ] + xx [ 152 ] * xx [ 218 ] ) * xx [ 5 ] ; xx [ 578 ] =
xx [ 539 ] - xx [ 160 ] - xx [ 260 ] ;
sm_core_compiler_computeContactWrenches ( 0 , 1 , bb [ 0 ] , xx + 90 , (
const pm_math_Vector3 * ) ( xx + 476 ) , ( const pm_math_Vector3 * ) ( xx +
540 ) , ( const pm_math_Vector3 * ) ( xx + 546 ) , ( const pm_math_Vector3 *
) ( xx + 552 ) , ( const pm_math_Transform3 * ) ( xx + 500 ) , ( const
pm_math_Transform3 * ) ( xx + 566 ) , ( const pm_math_Transform3 * ) ( xx +
500 ) , ( const pm_math_Transform3 * ) ( xx + 559 ) , NULL , ( const
pm_math_SpatialVector * ) ( xx + 573 ) , 0 , 1 , xx [ 108 ] , xx [ 369 ] , xx
[ 376 ] , xx [ 425 ] , xx [ 431 ] , xx [ 437 ] , NULL , NULL , NULL , (
pm_math_SpatialVector * ) ( xx + 579 ) ) ; xx [ 64 ] = xx [ 549 ] - xx [ 579
] + xx [ 78 ] * xx [ 130 ] * state [ 15 ] ; xx [ 90 ] = xx [ 550 ] - xx [ 580
] - xx [ 78 ] * xx [ 129 ] * state [ 15 ] ; xx [ 78 ] = xx [ 218 ] * xx [ 90
] ; xx [ 108 ] = xx [ 64 ] * xx [ 218 ] ; xx [ 476 ] = - xx [ 171 ] ; xx [
477 ] = xx [ 135 ] ; xx [ 478 ] = - xx [ 260 ] ; pm_math_Vector3_cross_ra (
xx + 510 , xx + 476 , xx + 500 ) ; xx [ 129 ] = xx [ 500 ] * xx [ 218 ] ; xx
[ 130 ] = xx [ 501 ] * xx [ 218 ] ; xx [ 135 ] = xx [ 128 ] * ( xx [ 501 ] -
( xx [ 1 ] * xx [ 129 ] + xx [ 130 ] * xx [ 218 ] ) * xx [ 5 ] ) - xx [ 583 ]
; xx [ 152 ] = ( xx [ 500 ] + xx [ 5 ] * ( xx [ 1 ] * xx [ 130 ] - xx [ 129 ]
* xx [ 218 ] ) ) * xx [ 128 ] - xx [ 582 ] ; xx [ 129 ] = xx [ 218 ] * xx [
152 ] ; xx [ 130 ] = xx [ 218 ] * xx [ 135 ] ; xx [ 157 ] = xx [ 135 ] + xx [
5 ] * ( xx [ 1 ] * xx [ 129 ] - xx [ 130 ] * xx [ 218 ] ) ; xx [ 135 ] = xx [
125 ] * state [ 13 ] ; xx [ 125 ] = xx [ 94 ] * state [ 13 ] ; xx [ 476 ] =
xx [ 3 ] ; xx [ 477 ] = xx [ 136 ] ; xx [ 478 ] = - xx [ 160 ] ;
pm_math_Vector3_cross_ra ( xx + 507 , xx + 476 , xx + 503 ) ; xx [ 3 ] = xx [
233 ] * xx [ 504 ] ; xx [ 136 ] = xx [ 233 ] * xx [ 503 ] ; xx [ 160 ] = xx [
503 ] - xx [ 5 ] * ( xx [ 3 ] * xx [ 180 ] + xx [ 233 ] * xx [ 136 ] ) - ( xx
[ 93 ] + xx [ 59 ] ) * xx [ 252 ] ; xx [ 59 ] = xx [ 504 ] - ( xx [ 233 ] *
xx [ 3 ] - xx [ 136 ] * xx [ 180 ] ) * xx [ 5 ] ; xx [ 3 ] = xx [ 543 ] + xx
[ 64 ] - ( xx [ 1 ] * xx [ 78 ] + xx [ 108 ] * xx [ 218 ] ) * xx [ 5 ] + xx [
157 ] * xx [ 250 ] + xx [ 284 ] * xx [ 135 ] - xx [ 125 ] * xx [ 158 ] + xx [
100 ] * xx [ 160 ] + xx [ 297 ] * xx [ 59 ] ; xx [ 64 ] = xx [ 551 ] - xx [
581 ] ; xx [ 136 ] = input [ 2 ] - xx [ 64 ] ; xx [ 158 ] = xx [ 157 ] * xx [
140 ] ; xx [ 171 ] = xx [ 224 ] * xx [ 160 ] + xx [ 217 ] * xx [ 59 ] + xx [
256 ] * xx [ 135 ] + xx [ 125 ] * xx [ 294 ] ; xx [ 217 ] = xx [ 545 ] + xx [
64 ] + xx [ 136 ] + xx [ 158 ] + xx [ 171 ] ; xx [ 224 ] = xx [ 157 ] + xx [
160 ] * xx [ 237 ] + xx [ 228 ] * xx [ 59 ] + xx [ 297 ] * xx [ 135 ] + xx [
125 ] * xx [ 350 ] ; xx [ 157 ] = xx [ 224 ] * xx [ 143 ] ; xx [ 228 ] = ( xx
[ 217 ] + xx [ 157 ] ) / xx [ 230 ] ; xx [ 237 ] = xx [ 3 ] - xx [ 226 ] * xx
[ 228 ] ; xx [ 241 ] = xx [ 237 ] * xx [ 233 ] ; xx [ 255 ] = xx [ 152 ] - (
xx [ 1 ] * xx [ 130 ] + xx [ 129 ] * xx [ 218 ] ) * xx [ 5 ] ; xx [ 129 ] =
xx [ 128 ] * xx [ 502 ] - xx [ 584 ] ; xx [ 128 ] = ( xx [ 94 ] + xx [ 94 ] )
* xx [ 252 ] + xx [ 505 ] ; xx [ 94 ] = xx [ 544 ] + xx [ 90 ] + xx [ 5 ] * (
xx [ 1 ] * xx [ 108 ] - xx [ 78 ] * xx [ 218 ] ) - ( xx [ 250 ] * xx [ 255 ]
+ xx [ 140 ] * xx [ 129 ] ) + xx [ 135 ] * xx [ 303 ] - xx [ 213 ] * xx [ 125
] - ( xx [ 352 ] * xx [ 160 ] + xx [ 350 ] * xx [ 59 ] + xx [ 128 ] * xx [
364 ] ) ; xx [ 1 ] = xx [ 94 ] + xx [ 351 ] * xx [ 228 ] ; xx [ 78 ] = xx [
233 ] * xx [ 1 ] ; xx [ 90 ] = xx [ 129 ] + xx [ 125 ] * xx [ 364 ] + xx [
253 ] * xx [ 128 ] ; xx [ 108 ] = xx [ 90 ] * xx [ 246 ] ; xx [ 128 ] = xx [
498 ] * state [ 11 ] ; xx [ 129 ] = xx [ 497 ] * state [ 11 ] ;
pm_math_Vector3_cross_ra ( xx + 300 , xx + 555 , xx + 476 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 476 , xx + 300 ) ; xx [
130 ] = xx [ 300 ] - ( xx [ 499 ] + xx [ 93 ] ) * xx [ 145 ] ; xx [ 93 ] = (
xx [ 497 ] + xx [ 497 ] ) * xx [ 145 ] + xx [ 302 ] ; xx [ 140 ] = xx [ 306 ]
* xx [ 128 ] - xx [ 285 ] * xx [ 129 ] + xx [ 130 ] * xx [ 355 ] + xx [ 301 ]
* xx [ 221 ] - xx [ 93 ] * xx [ 367 ] ; xx [ 145 ] = state [ 10 ] + xx [ 21 ]
; if ( xx [ 38 ] > xx [ 145 ] ) xx [ 145 ] = xx [ 38 ] ; xx [ 21 ] = xx [ 145
] / xx [ 58 ] ; if ( xx [ 6 ] < xx [ 21 ] ) xx [ 21 ] = xx [ 6 ] ; xx [ 6 ] =
( xx [ 9 ] * xx [ 145 ] + ( xx [ 145 ] == xx [ 38 ] ? xx [ 38 ] : xx [ 57 ] *
state [ 11 ] ) ) * xx [ 21 ] * xx [ 21 ] * ( xx [ 74 ] - xx [ 5 ] * xx [ 21 ]
) ; if ( xx [ 38 ] > xx [ 6 ] ) xx [ 6 ] = xx [ 38 ] ; xx [ 9 ] = input [ 0 ]
- xx [ 6 ] ; xx [ 6 ] = xx [ 224 ] - xx [ 229 ] * xx [ 228 ] ; xx [ 21 ] = xx
[ 255 ] + xx [ 222 ] * xx [ 160 ] + xx [ 59 ] * xx [ 216 ] + xx [ 100 ] * xx
[ 135 ] + xx [ 125 ] * xx [ 352 ] ; xx [ 57 ] = xx [ 21 ] - xx [ 225 ] * xx [
228 ] ; xx [ 58 ] = xx [ 233 ] * xx [ 57 ] ; xx [ 59 ] = xx [ 233 ] * xx [ 6
] ; xx [ 74 ] = xx [ 6 ] - xx [ 5 ] * ( xx [ 58 ] * xx [ 180 ] + xx [ 233 ] *
xx [ 59 ] ) ; xx [ 6 ] = xx [ 57 ] - ( xx [ 233 ] * xx [ 58 ] - xx [ 59 ] *
xx [ 180 ] ) * xx [ 5 ] ; xx [ 57 ] = xx [ 357 ] * xx [ 128 ] - xx [ 332 ] *
xx [ 129 ] + xx [ 235 ] * xx [ 130 ] + xx [ 211 ] * xx [ 301 ] ; xx [ 58 ] =
xx [ 536 ] + xx [ 217 ] - xx [ 227 ] * xx [ 228 ] + xx [ 244 ] * xx [ 74 ] +
xx [ 246 ] * xx [ 6 ] + xx [ 57 ] ; xx [ 59 ] = xx [ 128 ] * xx [ 221 ] - xx
[ 348 ] * xx [ 129 ] + xx [ 242 ] * xx [ 130 ] + xx [ 220 ] * xx [ 301 ] ; xx
[ 100 ] = xx [ 74 ] + xx [ 59 ] ; xx [ 74 ] = ( xx [ 9 ] - ( xx [ 58 ] + xx [
100 ] * xx [ 159 ] ) ) / xx [ 236 ] ; xx [ 145 ] = xx [ 244 ] * xx [ 90 ] ;
xx [ 152 ] = xx [ 362 ] * xx [ 128 ] - xx [ 215 ] * xx [ 129 ] + xx [ 368 ] *
xx [ 130 ] + xx [ 348 ] * xx [ 301 ] - xx [ 93 ] * xx [ 127 ] ; xx [ 215 ] =
xx [ 534 ] + xx [ 237 ] - ( xx [ 233 ] * xx [ 241 ] - xx [ 78 ] * xx [ 180 ]
) * xx [ 5 ] - xx [ 108 ] + xx [ 140 ] + xx [ 361 ] * xx [ 74 ] ; xx [ 216 ]
= xx [ 535 ] + xx [ 1 ] - xx [ 5 ] * ( xx [ 241 ] * xx [ 180 ] + xx [ 233 ] *
xx [ 78 ] ) - xx [ 145 ] + xx [ 152 ] + xx [ 354 ] * xx [ 74 ] ; xx [ 217 ] =
xx [ 58 ] + xx [ 167 ] * xx [ 74 ] ; pm_math_Quaternion_xform_ra ( xx + 449 ,
xx + 215 , xx + 220 ) ; xx [ 1 ] = xx [ 128 ] * xx [ 355 ] - xx [ 368 ] * xx
[ 129 ] + xx [ 240 ] * xx [ 130 ] + xx [ 301 ] * xx [ 219 ] ; xx [ 58 ] = xx
[ 90 ] + xx [ 127 ] * xx [ 129 ] - xx [ 128 ] * xx [ 367 ] + xx [ 254 ] * xx
[ 93 ] ; xx [ 215 ] = xx [ 6 ] + xx [ 1 ] + xx [ 239 ] * xx [ 74 ] ; xx [ 216
] = xx [ 100 ] + xx [ 234 ] * xx [ 74 ] ; xx [ 217 ] = xx [ 58 ] ;
pm_math_Quaternion_xform_ra ( xx + 449 , xx + 215 , xx + 240 ) ;
pm_math_Vector3_cross_ra ( xx + 370 , xx + 240 , xx + 215 ) ; xx [ 497 ] = xx
[ 107 ] ; xx [ 498 ] = xx [ 24 ] ; xx [ 499 ] = xx [ 37 ] ; xx [ 500 ] = xx [
118 ] ; xx [ 501 ] = xx [ 214 ] ; xx [ 502 ] = xx [ 232 ] ; xx [ 503 ] = xx [
48 ] ; xx [ 504 ] = xx [ 310 ] ; xx [ 505 ] = xx [ 331 ] ; xx [ 6 ] = xx [
103 ] * xx [ 54 ] ; xx [ 24 ] = xx [ 103 ] * xx [ 117 ] ; xx [ 252 ] = - xx [
162 ] ; xx [ 253 ] = xx [ 6 ] ; xx [ 254 ] = - xx [ 24 ] ;
pm_math_Matrix3x3_xform_ra ( xx + 497 , xx + 252 , xx + 283 ) ; xx [ 497 ] =
xx [ 43 ] ; xx [ 498 ] = xx [ 71 ] ; xx [ 499 ] = xx [ 40 ] ; xx [ 500 ] = xx
[ 92 ] ; xx [ 501 ] = xx [ 69 ] ; xx [ 502 ] = xx [ 72 ] ; xx [ 503 ] = xx [
181 ] ; xx [ 504 ] = xx [ 41 ] ; xx [ 505 ] = xx [ 47 ] ; xx [ 37 ] = xx [
288 ] * state [ 7 ] ; xx [ 40 ] = xx [ 279 ] * state [ 7 ] ; xx [ 41 ] = xx [
40 ] * xx [ 4 ] ; xx [ 43 ] = xx [ 10 ] * xx [ 37 ] - xx [ 40 ] * xx [ 2 ] ;
xx [ 47 ] = xx [ 37 ] * xx [ 4 ] ; xx [ 286 ] = - xx [ 41 ] ; xx [ 287 ] = xx
[ 43 ] ; xx [ 288 ] = xx [ 47 ] ; pm_math_Vector3_cross_ra ( xx + 104 , xx +
286 , xx + 355 ) ; xx [ 48 ] = xx [ 37 ] + xx [ 5 ] * ( xx [ 355 ] + xx [ 41
] * xx [ 25 ] ) ; xx [ 37 ] = xx [ 5 ] * ( xx [ 356 ] - xx [ 43 ] * xx [ 25 ]
) - ( xx [ 120 ] + xx [ 56 ] ) * xx [ 293 ] ; xx [ 41 ] = xx [ 40 ] + ( xx [
357 ] - xx [ 47 ] * xx [ 25 ] ) * xx [ 5 ] - ( xx [ 115 ] + xx [ 119 ] ) * xx
[ 293 ] ; xx [ 103 ] = xx [ 48 ] ; xx [ 104 ] = xx [ 37 ] ; xx [ 105 ] = xx [
41 ] ; pm_math_Matrix3x3_xform_ra ( xx + 497 , xx + 103 , xx + 117 ) ; xx [
40 ] = xx [ 283 ] + xx [ 117 ] ; pm_math_Matrix3x3_transposeXform_ra ( xx +
497 , xx + 252 , xx + 286 ) ; xx [ 497 ] = xx [ 91 ] ; xx [ 498 ] = xx [ 359
] ; xx [ 499 ] = xx [ 77 ] ; xx [ 500 ] = xx [ 67 ] ; xx [ 501 ] = xx [ 75 ]
; xx [ 502 ] = xx [ 101 ] ; xx [ 503 ] = xx [ 68 ] ; xx [ 504 ] = xx [ 102 ]
; xx [ 505 ] = xx [ 73 ] ; pm_math_Matrix3x3_xform_ra ( xx + 497 , xx + 103 ,
xx + 67 ) ; xx [ 43 ] = xx [ 286 ] + xx [ 67 ] ; xx [ 47 ] = xx [ 311 ] + xx
[ 525 ] + xx [ 257 ] + xx [ 240 ] + xx [ 43 ] ; xx [ 54 ] = xx [ 284 ] + xx [
118 ] ; xx [ 56 ] = xx [ 461 ] + xx [ 517 ] + xx [ 308 ] + xx [ 532 ] + xx [
523 ] + xx [ 454 ] + xx [ 178 ] + xx [ 221 ] + xx [ 216 ] + xx [ 54 ] ; xx [
71 ] = xx [ 285 ] + xx [ 119 ] ; xx [ 72 ] = xx [ 462 ] + xx [ 518 ] + xx [
309 ] + xx [ 533 ] + xx [ 524 ] + xx [ 455 ] + xx [ 179 ] + xx [ 222 ] + xx [
217 ] + xx [ 71 ] ; xx [ 73 ] = ( xx [ 47 ] * xx [ 243 ] - ( xx [ 56 ] * xx [
20 ] + xx [ 72 ] * xx [ 23 ] ) ) / xx [ 349 ] ; xx [ 90 ] = xx [ 460 ] + xx [
516 ] + xx [ 307 ] + xx [ 531 ] + xx [ 522 ] + xx [ 453 ] + xx [ 177 ] + xx [
220 ] + xx [ 215 ] + xx [ 40 ] - xx [ 66 ] * xx [ 73 ] ; xx [ 91 ] = xx [ 56
] - xx [ 263 ] * xx [ 73 ] ; xx [ 92 ] = xx [ 72 ] - xx [ 341 ] * xx [ 73 ] ;
pm_math_Quaternion_xform_ra ( xx + 265 , xx + 90 , xx + 100 ) ; xx [ 56 ] =
xx [ 287 ] + xx [ 68 ] ; xx [ 67 ] = xx [ 288 ] + xx [ 69 ] ; xx [ 90 ] = xx
[ 47 ] - xx [ 264 ] * xx [ 73 ] ; xx [ 91 ] = xx [ 312 ] + xx [ 526 ] + xx [
258 ] + xx [ 241 ] + xx [ 56 ] - xx [ 45 ] * xx [ 73 ] ; xx [ 92 ] = xx [ 313
] + xx [ 527 ] + xx [ 259 ] + xx [ 242 ] + xx [ 67 ] - xx [ 39 ] * xx [ 73 ]
; pm_math_Quaternion_xform_ra ( xx + 265 , xx + 90 , xx + 102 ) ;
pm_math_Vector3_cross_ra ( xx + 190 , xx + 102 , xx + 90 ) ; xx [ 47 ] = ( xx
[ 101 ] + xx [ 91 ] ) / xx [ 51 ] ; xx [ 90 ] = xx [ 102 ] - xx [ 47 ] * xx [
44 ] ; xx [ 91 ] = xx [ 103 ] - xx [ 47 ] * xx [ 53 ] ; xx [ 92 ] = xx [ 104
] - xx [ 47 ] * xx [ 55 ] ; pm_math_Quaternion_xform_ra ( xx + 193 , xx + 90
, xx + 100 ) ; xx [ 90 ] = - xx [ 100 ] ; xx [ 91 ] = - xx [ 101 ] ; xx [ 92
] = - xx [ 102 ] ; solveSymmetricPosDef ( xx + 400 , xx + 90 , 3 , 1 , xx +
100 , xx + 103 ) ; xx [ 68 ] = 9.806650000000001 ; xx [ 69 ] = xx [ 82 ] - xx
[ 29 ] - xx [ 31 ] - xx [ 201 ] ; xx [ 28 ] = xx [ 88 ] - xx [ 35 ] - xx [ 33
] - xx [ 207 ] ; xx [ 81 ] = xx [ 373 ] - xx [ 382 ] - xx [ 52 ] * xx [ 69 ]
; xx [ 82 ] = xx [ 374 ] - xx [ 385 ] - xx [ 113 ] * xx [ 69 ] ; xx [ 83 ] =
xx [ 375 ] - xx [ 388 ] - xx [ 116 ] * xx [ 69 ] ; xx [ 84 ] = xx [ 44 ] - xx
[ 52 ] * xx [ 50 ] ; xx [ 85 ] = xx [ 53 ] - xx [ 113 ] * xx [ 50 ] ; xx [ 86
] = xx [ 55 ] - xx [ 116 ] * xx [ 50 ] ; xx [ 87 ] = xx [ 379 ] - xx [ 384 ]
- xx [ 52 ] * xx [ 28 ] ; xx [ 88 ] = xx [ 380 ] - xx [ 387 ] - xx [ 113 ] *
xx [ 28 ] ; xx [ 89 ] = xx [ 381 ] - xx [ 390 ] - xx [ 116 ] * xx [ 28 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 81 , xx + 11 , xx + 28 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 11 , xx + 28 , xx + 81 ) ; xx [ 546 ] =
xx [ 81 ] ; xx [ 547 ] = xx [ 82 ] ; xx [ 548 ] = xx [ 83 ] ; xx [ 549 ] = xx
[ 84 ] ; xx [ 550 ] = xx [ 85 ] ; xx [ 551 ] = xx [ 86 ] ; xx [ 552 ] = xx [
87 ] ; xx [ 553 ] = xx [ 88 ] ; xx [ 554 ] = xx [ 89 ] ; xx [ 555 ] = xx [
391 ] ; xx [ 556 ] = xx [ 392 ] ; xx [ 557 ] = xx [ 393 ] ; xx [ 558 ] = xx [
394 ] ; xx [ 559 ] = xx [ 395 ] ; xx [ 560 ] = xx [ 396 ] ; xx [ 561 ] = xx [
397 ] ; xx [ 562 ] = xx [ 398 ] ; xx [ 563 ] = xx [ 399 ] ;
solveSymmetricPosDef ( xx + 400 , xx + 546 , 3 , 6 , xx + 564 , xx + 11 ) ;
xx [ 11 ] = 1.77635683940025e-15 ; xx [ 12 ] = xx [ 68 ] * xx [ 573 ] + xx [
11 ] * xx [ 579 ] ; xx [ 13 ] = xx [ 68 ] * xx [ 574 ] + xx [ 11 ] * xx [ 580
] ; xx [ 14 ] = xx [ 68 ] * xx [ 575 ] + xx [ 11 ] * xx [ 581 ] ; xx [ 15 ] =
xx [ 100 ] + xx [ 12 ] - xx [ 68 ] ; xx [ 16 ] = xx [ 101 ] + xx [ 13 ] ; xx
[ 17 ] = xx [ 102 ] + xx [ 14 ] - xx [ 11 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 193 , xx + 15 , xx + 28 ) ; xx [ 15
] = xx [ 47 ] + pm_math_Vector3_dot_ra ( xx + 422 , xx + 28 ) ; xx [ 16 ] =
xx [ 10 ] * xx [ 15 ] ; xx [ 17 ] = xx [ 15 ] * xx [ 2 ] ; xx [ 18 ] = ( xx [
16 ] * xx [ 25 ] - xx [ 17 ] * xx [ 4 ] ) * xx [ 5 ] ; xx [ 19 ] = ( xx [ 10
] * xx [ 16 ] + xx [ 17 ] * xx [ 2 ] ) * xx [ 5 ] - xx [ 15 ] ; xx [ 31 ] =
xx [ 5 ] * ( xx [ 17 ] * xx [ 25 ] + xx [ 16 ] * xx [ 4 ] ) ; xx [ 32 ] = -
xx [ 18 ] ; xx [ 33 ] = xx [ 19 ] ; xx [ 34 ] = xx [ 31 ] ; xx [ 81 ] = xx [
28 ] + xx [ 65 ] * xx [ 15 ] ; xx [ 82 ] = xx [ 29 ] ; xx [ 83 ] = xx [ 30 ]
- xx [ 15 ] * xx [ 169 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx
+ 81 , xx + 15 ) ; xx [ 28 ] = xx [ 73 ] + pm_math_Vector3_dot_ra ( xx + 428
, xx + 32 ) + pm_math_Vector3_dot_ra ( xx + 434 , xx + 15 ) ; xx [ 32 ] = - (
xx [ 162 ] + xx [ 18 ] ) ; xx [ 33 ] = xx [ 19 ] + xx [ 28 ] * xx [ 20 ] + xx
[ 6 ] ; xx [ 34 ] = xx [ 31 ] + xx [ 28 ] * xx [ 23 ] - xx [ 24 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 32 , xx + 29 ) ; xx [ 18
] = xx [ 15 ] - xx [ 28 ] * xx [ 243 ] + xx [ 48 ] ; pm_math_Vector3_cross_ra
( xx + 32 , xx + 289 , xx + 81 ) ; xx [ 15 ] = xx [ 16 ] + xx [ 37 ] ; xx [
16 ] = xx [ 17 ] + xx [ 41 ] ; xx [ 84 ] = xx [ 18 ] + xx [ 81 ] ; xx [ 85 ]
= xx [ 15 ] + xx [ 82 ] ; xx [ 86 ] = xx [ 16 ] + xx [ 83 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 84 , xx + 81 ) ; xx [ 17
] = xx [ 155 ] - ( pm_math_Vector3_dot_ra ( xx + 409 , xx + 29 ) + xx [ 163 ]
* xx [ 81 ] + xx [ 173 ] * xx [ 82 ] ) ; xx [ 19 ] = state [ 23 ] * state [
23 ] ; xx [ 28 ] = xx [ 109 ] * state [ 17 ] * state [ 17 ] ; xx [ 35 ] = xx
[ 5 ] * xx [ 98 ] * state [ 17 ] * state [ 17 ] ; xx [ 36 ] = state [ 17 ] *
state [ 17 ] ; xx [ 47 ] = state [ 19 ] * state [ 19 ] ; xx [ 50 ] = xx [ 166
] * xx [ 47 ] ; xx [ 52 ] = xx [ 47 ] * ( xx [ 168 ] - xx [ 143 ] ) ; xx [ 47
] = xx [ 95 ] * xx [ 52 ] ; xx [ 69 ] = xx [ 61 ] * xx [ 50 ] - xx [ 52 ] *
xx [ 27 ] ; xx [ 83 ] = - ( xx [ 95 ] * xx [ 50 ] ) ; xx [ 84 ] = xx [ 47 ] ;
xx [ 85 ] = xx [ 69 ] ; pm_math_Vector3_cross_ra ( xx + 325 , xx + 83 , xx +
86 ) ; xx [ 52 ] = xx [ 5 ] * xx [ 165 ] * state [ 19 ] * state [ 17 ] ; xx [
72 ] = xx [ 316 ] * state [ 19 ] * state [ 17 ] ; xx [ 73 ] = xx [ 95 ] * xx
[ 72 ] ; xx [ 75 ] = xx [ 72 ] * xx [ 27 ] + xx [ 61 ] * xx [ 52 ] ; xx [ 83
] = - ( xx [ 95 ] * xx [ 52 ] ) ; xx [ 84 ] = - xx [ 73 ] ; xx [ 85 ] = xx [
75 ] ; pm_math_Vector3_cross_ra ( xx + 325 , xx + 83 , xx + 89 ) ; xx [ 61 ]
= xx [ 126 ] * state [ 19 ] * state [ 19 ] ; xx [ 72 ] = xx [ 5 ] * xx [ 123
] * state [ 19 ] * state [ 19 ] ; xx [ 77 ] = 4.0 ; xx [ 78 ] = xx [ 29 ] +
xx [ 133 ] ; xx [ 29 ] = xx [ 30 ] - xx [ 139 ] ; xx [ 30 ] = xx [ 153 ] * xx
[ 29 ] ; xx [ 83 ] = xx [ 78 ] * xx [ 153 ] ; xx [ 84 ] = xx [ 31 ] + xx [ 17
] ; xx [ 100 ] = xx [ 78 ] - xx [ 5 ] * ( xx [ 30 ] * xx [ 122 ] + xx [ 153 ]
* xx [ 83 ] ) ; xx [ 101 ] = xx [ 29 ] - ( xx [ 153 ] * xx [ 30 ] - xx [ 83 ]
* xx [ 122 ] ) * xx [ 5 ] ; xx [ 102 ] = xx [ 84 ] ; xx [ 29 ] = xx [ 81 ] +
xx [ 328 ] + xx [ 84 ] * xx [ 166 ] ; xx [ 30 ] = xx [ 82 ] + xx [ 159 ] * xx
[ 17 ] + xx [ 514 ] + xx [ 84 ] * xx [ 164 ] ; xx [ 31 ] = xx [ 30 ] * xx [
153 ] ; xx [ 78 ] = xx [ 29 ] * xx [ 153 ] ; xx [ 81 ] = xx [ 148 ] +
pm_math_Vector3_dot_ra ( xx + 439 , xx + 100 ) + ( xx [ 29 ] - xx [ 5 ] * (
xx [ 31 ] * xx [ 122 ] + xx [ 153 ] * xx [ 78 ] ) ) * xx [ 151 ] + xx [ 141 ]
* ( xx [ 30 ] - ( xx [ 153 ] * xx [ 31 ] - xx [ 78 ] * xx [ 122 ] ) * xx [ 5
] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 32 , xx + 29 ) ;
pm_math_Vector3_cross_ra ( xx + 32 , xx + 336 , xx + 82 ) ; xx [ 100 ] = xx [
18 ] + xx [ 82 ] ; xx [ 101 ] = xx [ 15 ] + xx [ 83 ] ; xx [ 102 ] = xx [ 16
] + xx [ 84 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 100 , xx
+ 82 ) ; xx [ 29 ] = xx [ 443 ] + xx [ 114 ] * xx [ 31 ] + xx [ 138 ] * xx [
83 ] ; xx [ 30 ] = xx [ 5 ] * xx [ 112 ] * state [ 17 ] * state [ 17 ] ; xx [
31 ] = xx [ 5 ] * xx [ 111 ] * state [ 17 ] * state [ 17 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 32 , xx + 82 ) ;
pm_math_Vector3_cross_ra ( xx + 32 , xx + 370 , xx + 100 ) ; xx [ 103 ] = xx
[ 18 ] + xx [ 100 ] ; xx [ 104 ] = xx [ 15 ] + xx [ 101 ] ; xx [ 105 ] = xx [
16 ] + xx [ 102 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 103
, xx + 100 ) ; xx [ 78 ] = xx [ 74 ] - ( pm_math_Vector3_dot_ra ( xx + 465 ,
xx + 82 ) + xx [ 238 ] * xx [ 100 ] + xx [ 249 ] * xx [ 101 ] ) ; xx [ 74 ] =
state [ 25 ] * state [ 25 ] ; xx [ 85 ] = xx [ 187 ] * state [ 11 ] * state [
11 ] ; xx [ 86 ] = xx [ 5 ] * xx [ 185 ] * state [ 11 ] * state [ 11 ] ; xx [
89 ] = state [ 11 ] * state [ 11 ] ; xx [ 92 ] = state [ 13 ] * state [ 13 ]
; xx [ 93 ] = xx [ 246 ] * xx [ 92 ] ; xx [ 95 ] = xx [ 92 ] * ( xx [ 247 ] -
xx [ 143 ] ) ; xx [ 92 ] = xx [ 182 ] * xx [ 95 ] ; xx [ 98 ] = xx [ 22 ] *
xx [ 93 ] - xx [ 95 ] * xx [ 174 ] ; xx [ 102 ] = - ( xx [ 182 ] * xx [ 93 ]
) ; xx [ 103 ] = xx [ 92 ] ; xx [ 104 ] = xx [ 98 ] ;
pm_math_Vector3_cross_ra ( xx + 412 , xx + 102 , xx + 105 ) ; xx [ 95 ] = xx
[ 5 ] * xx [ 245 ] * state [ 13 ] * state [ 11 ] ; xx [ 102 ] = xx [ 63 ] *
state [ 13 ] * state [ 11 ] ; xx [ 63 ] = xx [ 182 ] * xx [ 102 ] ; xx [ 103
] = xx [ 102 ] * xx [ 174 ] + xx [ 22 ] * xx [ 95 ] ; xx [ 111 ] = - ( xx [
182 ] * xx [ 95 ] ) ; xx [ 112 ] = - xx [ 63 ] ; xx [ 113 ] = xx [ 103 ] ;
pm_math_Vector3_cross_ra ( xx + 412 , xx + 111 , xx + 115 ) ; xx [ 22 ] = xx
[ 212 ] * state [ 13 ] * state [ 13 ] ; xx [ 102 ] = xx [ 5 ] * xx [ 209 ] *
state [ 13 ] * state [ 13 ] ; xx [ 104 ] = xx [ 82 ] + xx [ 128 ] ; xx [ 82 ]
= xx [ 83 ] - xx [ 129 ] ; xx [ 83 ] = xx [ 233 ] * xx [ 82 ] ; xx [ 111 ] =
xx [ 104 ] * xx [ 233 ] ; xx [ 112 ] = xx [ 84 ] + xx [ 78 ] ; xx [ 118 ] =
xx [ 104 ] - xx [ 5 ] * ( xx [ 83 ] * xx [ 180 ] + xx [ 233 ] * xx [ 111 ] )
; xx [ 119 ] = xx [ 82 ] - ( xx [ 233 ] * xx [ 83 ] - xx [ 111 ] * xx [ 180 ]
) * xx [ 5 ] ; xx [ 120 ] = xx [ 112 ] ; xx [ 82 ] = xx [ 100 ] + xx [ 130 ]
+ xx [ 112 ] * xx [ 246 ] ; xx [ 83 ] = xx [ 101 ] + xx [ 159 ] * xx [ 78 ] +
xx [ 301 ] + xx [ 112 ] * xx [ 244 ] ; xx [ 84 ] = xx [ 83 ] * xx [ 233 ] ;
xx [ 100 ] = xx [ 82 ] * xx [ 233 ] ; xx [ 101 ] = xx [ 228 ] +
pm_math_Vector3_dot_ra ( xx + 473 , xx + 118 ) + ( xx [ 82 ] - xx [ 5 ] * (
xx [ 84 ] * xx [ 180 ] + xx [ 233 ] * xx [ 100 ] ) ) * xx [ 231 ] + xx [ 223
] * ( xx [ 83 ] - ( xx [ 233 ] * xx [ 84 ] - xx [ 100 ] * xx [ 180 ] ) * xx [
5 ] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 32 , xx + 82 ) ;
pm_math_Vector3_cross_ra ( xx + 32 , xx + 319 , xx + 111 ) ; xx [ 32 ] = xx [
18 ] + xx [ 111 ] ; xx [ 33 ] = xx [ 15 ] + xx [ 112 ] ; xx [ 34 ] = xx [ 16
] + xx [ 113 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 32 , xx
+ 111 ) ; xx [ 15 ] = xx [ 262 ] + xx [ 114 ] * xx [ 84 ] + xx [ 138 ] * xx [
112 ] ; xx [ 16 ] = xx [ 5 ] * xx [ 199 ] * state [ 11 ] * state [ 11 ] ; xx
[ 18 ] = xx [ 5 ] * xx [ 198 ] * state [ 11 ] * state [ 11 ] ; xx [ 198 ] =
xx [ 383 ] * xx [ 17 ] - ( xx [ 335 ] * xx [ 19 ] + xx [ 324 ] * xx [ 76 ] *
state [ 23 ] * state [ 23 ] - ( xx [ 166 ] * xx [ 28 ] - xx [ 164 ] * xx [ 35
] - xx [ 281 ] * xx [ 36 ] + xx [ 50 ] + ( xx [ 47 ] * xx [ 27 ] + xx [ 87 ]
) * xx [ 5 ] + xx [ 5 ] * ( xx [ 5 ] * ( xx [ 90 ] - xx [ 73 ] * xx [ 27 ] )
+ xx [ 52 ] ) + ( xx [ 35 ] * xx [ 126 ] - xx [ 124 ] * xx [ 28 ] + xx [ 99 ]
* xx [ 61 ] - xx [ 72 ] * xx [ 109 ] + xx [ 77 ] * ( xx [ 344 ] * xx [ 251 ]
+ xx [ 339 ] * xx [ 172 ] ) * state [ 17 ] * state [ 19 ] ) * xx [ 342 ] ) )
- xx [ 81 ] * xx [ 366 ] + xx [ 29 ] * xx [ 333 ] ; xx [ 199 ] = xx [ 345 ] *
xx [ 17 ] - ( xx [ 295 ] * xx [ 19 ] - xx [ 324 ] * xx [ 80 ] * state [ 23 ]
* state [ 23 ] - ( xx [ 30 ] * xx [ 166 ] - xx [ 164 ] * xx [ 31 ] + xx [ 282
] * xx [ 36 ] + ( xx [ 27 ] * xx [ 69 ] + xx [ 88 ] ) * xx [ 5 ] + ( xx [ 27
] * xx [ 75 ] + xx [ 91 ] ) * xx [ 77 ] + ( xx [ 31 ] * xx [ 126 ] - xx [ 124
] * xx [ 30 ] + xx [ 96 ] * xx [ 61 ] - xx [ 60 ] * xx [ 72 ] + xx [ 77 ] * (
xx [ 344 ] * xx [ 339 ] - xx [ 251 ] * xx [ 172 ] ) * state [ 17 ] * state [
19 ] ) * xx [ 342 ] ) ) - xx [ 81 ] * xx [ 275 ] - xx [ 29 ] * xx [ 329 ] ;
xx [ 200 ] = xx [ 317 ] * xx [ 78 ] - ( xx [ 299 ] * xx [ 74 ] + xx [ 324 ] *
xx [ 42 ] * state [ 25 ] * state [ 25 ] - ( xx [ 246 ] * xx [ 85 ] - xx [ 244
] * xx [ 86 ] - xx [ 358 ] * xx [ 89 ] + xx [ 93 ] + ( xx [ 92 ] * xx [ 174 ]
+ xx [ 106 ] ) * xx [ 5 ] + xx [ 5 ] * ( xx [ 5 ] * ( xx [ 116 ] - xx [ 63 ]
* xx [ 174 ] ) + xx [ 95 ] ) + ( xx [ 86 ] * xx [ 212 ] - xx [ 210 ] * xx [
85 ] + xx [ 186 ] * xx [ 22 ] - xx [ 102 ] * xx [ 187 ] + xx [ 77 ] * ( xx [
353 ] * xx [ 433 ] + xx [ 346 ] * xx [ 427 ] ) * state [ 11 ] * state [ 13 ]
) * xx [ 342 ] ) ) - xx [ 101 ] * xx [ 378 ] + xx [ 15 ] * xx [ 296 ] ; xx [
201 ] = xx [ 456 ] * xx [ 78 ] - ( xx [ 318 ] * xx [ 74 ] - xx [ 324 ] * xx [
46 ] * state [ 25 ] * state [ 25 ] - ( xx [ 16 ] * xx [ 246 ] - xx [ 244 ] *
xx [ 18 ] + xx [ 175 ] * xx [ 89 ] + ( xx [ 174 ] * xx [ 98 ] + xx [ 107 ] )
* xx [ 5 ] + ( xx [ 174 ] * xx [ 103 ] + xx [ 117 ] ) * xx [ 77 ] + ( xx [ 18
] * xx [ 212 ] - xx [ 210 ] * xx [ 16 ] + xx [ 183 ] * xx [ 22 ] - xx [ 8 ] *
xx [ 102 ] + xx [ 77 ] * ( xx [ 353 ] * xx [ 346 ] - xx [ 433 ] * xx [ 427 ]
) * state [ 11 ] * state [ 13 ] ) * xx [ 342 ] ) ) - xx [ 101 ] * xx [ 343 ]
- xx [ 15 ] * xx [ 298 ] ; memcpy ( xx + 202 , xx + 481 , 16 * sizeof (
double ) ) ; factorAndSolveSymmetric ( xx + 202 , 4 , xx + 27 , ii + 0 , xx +
198 , xx + 15 , xx + 546 ) ; xx [ 8 ] = ( xx [ 17 ] * xx [ 296 ] - xx [ 298 ]
* xx [ 18 ] - xx [ 131 ] ) / xx [ 365 ] ; xx [ 27 ] = xx [ 304 ] ; xx [ 28 ]
= xx [ 305 ] + xx [ 315 ] * xx [ 8 ] ; xx [ 29 ] = xx [ 278 ] ;
pm_math_Quaternion_xform_ra ( xx + 269 , xx + 27 , xx + 30 ) ; xx [ 19 ] = (
xx [ 15 ] * xx [ 333 ] - xx [ 329 ] * xx [ 16 ] - xx [ 421 ] ) / xx [ 365 ] ;
xx [ 27 ] = xx [ 292 ] ; xx [ 28 ] = xx [ 420 ] + xx [ 315 ] * xx [ 19 ] ; xx
[ 29 ] = xx [ 197 ] ; pm_math_Quaternion_xform_ra ( xx + 445 , xx + 27 , xx +
33 ) ; xx [ 22 ] = xx [ 438 ] / xx [ 184 ] ; xx [ 27 ] = xx [ 470 ] + xx [ 0
] + xx [ 184 ] * xx [ 22 ] + xx [ 432 ] + xx [ 330 ] ; xx [ 0 ] = ( xx [ 27 ]
+ xx [ 142 ] + xx [ 366 ] * xx [ 15 ] + xx [ 275 ] * xx [ 16 ] ) / xx [ 150 ]
; xx [ 28 ] = xx [ 7 ] - xx [ 144 ] * xx [ 0 ] ; xx [ 7 ] = xx [ 153 ] * xx [
28 ] ; xx [ 29 ] = xx [ 134 ] - xx [ 149 ] * xx [ 0 ] ; xx [ 36 ] = xx [ 153
] * xx [ 29 ] ; xx [ 42 ] = xx [ 28 ] - ( xx [ 153 ] * xx [ 7 ] - xx [ 36 ] *
xx [ 122 ] ) * xx [ 5 ] ; xx [ 28 ] = xx [ 29 ] - xx [ 5 ] * ( xx [ 7 ] * xx
[ 122 ] + xx [ 153 ] * xx [ 36 ] ) ; xx [ 7 ] = xx [ 459 ] + xx [ 27 ] - xx [
147 ] * xx [ 0 ] + xx [ 164 ] * xx [ 28 ] + xx [ 166 ] * xx [ 42 ] + xx [ 70
] ; xx [ 27 ] = xx [ 28 ] + xx [ 132 ] ; xx [ 28 ] = ( xx [ 49 ] - ( xx [ 7 ]
+ xx [ 27 ] * xx [ 159 ] ) - ( xx [ 383 ] * xx [ 15 ] + xx [ 345 ] * xx [ 16
] ) ) / xx [ 156 ] ; xx [ 72 ] = xx [ 42 ] + xx [ 26 ] + xx [ 170 ] * xx [ 28
] ; xx [ 73 ] = xx [ 27 ] + xx [ 154 ] * xx [ 28 ] ; xx [ 74 ] = xx [ 79 ] ;
pm_math_Quaternion_xform_ra ( xx + 415 , xx + 72 , xx + 75 ) ; xx [ 15 ] = xx
[ 136 ] / xx [ 184 ] ; xx [ 16 ] = xx [ 545 ] + xx [ 64 ] + xx [ 184 ] * xx [
15 ] + xx [ 158 ] + xx [ 171 ] ; xx [ 26 ] = ( xx [ 16 ] + xx [ 157 ] + xx [
378 ] * xx [ 17 ] + xx [ 343 ] * xx [ 18 ] ) / xx [ 230 ] ; xx [ 27 ] = xx [
21 ] - xx [ 225 ] * xx [ 26 ] ; xx [ 21 ] = xx [ 233 ] * xx [ 27 ] ; xx [ 29
] = xx [ 224 ] - xx [ 229 ] * xx [ 26 ] ; xx [ 36 ] = xx [ 233 ] * xx [ 29 ]
; xx [ 42 ] = xx [ 27 ] - ( xx [ 233 ] * xx [ 21 ] - xx [ 36 ] * xx [ 180 ] )
* xx [ 5 ] ; xx [ 27 ] = xx [ 29 ] - xx [ 5 ] * ( xx [ 21 ] * xx [ 180 ] + xx
[ 233 ] * xx [ 36 ] ) ; xx [ 21 ] = xx [ 536 ] + xx [ 16 ] - xx [ 227 ] * xx
[ 26 ] + xx [ 244 ] * xx [ 27 ] + xx [ 246 ] * xx [ 42 ] + xx [ 57 ] ; xx [
16 ] = xx [ 27 ] + xx [ 59 ] ; xx [ 27 ] = ( xx [ 9 ] - ( xx [ 21 ] + xx [ 16
] * xx [ 159 ] ) - ( xx [ 317 ] * xx [ 17 ] + xx [ 456 ] * xx [ 18 ] ) ) / xx
[ 236 ] ; xx [ 59 ] = xx [ 42 ] + xx [ 1 ] + xx [ 239 ] * xx [ 27 ] ; xx [ 60
] = xx [ 16 ] + xx [ 234 ] * xx [ 27 ] ; xx [ 61 ] = xx [ 58 ] ;
pm_math_Quaternion_xform_ra ( xx + 449 , xx + 59 , xx + 16 ) ; xx [ 1 ] = xx
[ 30 ] + xx [ 33 ] + xx [ 75 ] + xx [ 16 ] + xx [ 43 ] ; xx [ 57 ] = xx [ 62
] ; xx [ 58 ] = xx [ 121 ] ; xx [ 59 ] = xx [ 521 ] + xx [ 360 ] * xx [ 8 ] ;
pm_math_Quaternion_xform_ra ( xx + 269 , xx + 57 , xx + 60 ) ;
pm_math_Vector3_cross_ra ( xx + 319 , xx + 30 , xx + 57 ) ; xx [ 72 ] = xx [
314 ] ; xx [ 73 ] = xx [ 277 ] ; xx [ 74 ] = xx [ 530 ] + xx [ 360 ] * xx [
19 ] ; pm_math_Quaternion_xform_ra ( xx + 445 , xx + 72 , xx + 78 ) ;
pm_math_Vector3_cross_ra ( xx + 336 , xx + 33 , xx + 72 ) ; xx [ 9 ] = xx [
444 ] + xx [ 146 ] * xx [ 0 ] ; xx [ 29 ] = xx [ 9 ] * xx [ 153 ] ; xx [ 30 ]
= xx [ 110 ] - xx [ 261 ] * xx [ 0 ] ; xx [ 33 ] = xx [ 153 ] * xx [ 30 ] ;
xx [ 81 ] = xx [ 457 ] + xx [ 9 ] - ( xx [ 153 ] * xx [ 29 ] - xx [ 33 ] * xx
[ 122 ] ) * xx [ 5 ] - xx [ 97 ] + xx [ 188 ] + xx [ 280 ] * xx [ 28 ] ; xx [
82 ] = xx [ 458 ] + xx [ 30 ] - xx [ 5 ] * ( xx [ 29 ] * xx [ 122 ] + xx [
153 ] * xx [ 33 ] ) - xx [ 176 ] + xx [ 189 ] + xx [ 273 ] * xx [ 28 ] ; xx [
83 ] = xx [ 7 ] + xx [ 137 ] * xx [ 28 ] ; pm_math_Quaternion_xform_ra ( xx +
415 , xx + 81 , xx + 84 ) ; pm_math_Vector3_cross_ra ( xx + 289 , xx + 75 ,
xx + 81 ) ; xx [ 7 ] = xx [ 3 ] - xx [ 226 ] * xx [ 26 ] ; xx [ 3 ] = xx [ 7
] * xx [ 233 ] ; xx [ 9 ] = xx [ 94 ] + xx [ 351 ] * xx [ 26 ] ; xx [ 29 ] =
xx [ 233 ] * xx [ 9 ] ; xx [ 87 ] = xx [ 534 ] + xx [ 7 ] - ( xx [ 233 ] * xx
[ 3 ] - xx [ 29 ] * xx [ 180 ] ) * xx [ 5 ] - xx [ 108 ] + xx [ 140 ] + xx [
361 ] * xx [ 27 ] ; xx [ 88 ] = xx [ 535 ] + xx [ 9 ] - xx [ 5 ] * ( xx [ 3 ]
* xx [ 180 ] + xx [ 233 ] * xx [ 29 ] ) - xx [ 145 ] + xx [ 152 ] + xx [ 354
] * xx [ 27 ] ; xx [ 89 ] = xx [ 21 ] + xx [ 167 ] * xx [ 27 ] ;
pm_math_Quaternion_xform_ra ( xx + 449 , xx + 87 , xx + 90 ) ;
pm_math_Vector3_cross_ra ( xx + 370 , xx + 16 , xx + 87 ) ; xx [ 3 ] = xx [
461 ] + xx [ 61 ] + xx [ 58 ] + xx [ 79 ] + xx [ 73 ] + xx [ 85 ] + xx [ 82 ]
+ xx [ 91 ] + xx [ 88 ] + xx [ 54 ] ; xx [ 7 ] = xx [ 462 ] + xx [ 62 ] + xx
[ 59 ] + xx [ 80 ] + xx [ 74 ] + xx [ 86 ] + xx [ 83 ] + xx [ 92 ] + xx [ 89
] + xx [ 71 ] ; xx [ 9 ] = ( xx [ 1 ] * xx [ 243 ] - ( xx [ 3 ] * xx [ 20 ] +
xx [ 7 ] * xx [ 23 ] ) ) / xx [ 349 ] ; xx [ 69 ] = xx [ 1 ] - xx [ 264 ] *
xx [ 9 ] ; xx [ 70 ] = xx [ 31 ] + xx [ 34 ] + xx [ 76 ] + xx [ 17 ] + xx [
56 ] - xx [ 45 ] * xx [ 9 ] ; xx [ 71 ] = xx [ 32 ] + xx [ 35 ] + xx [ 77 ] +
xx [ 18 ] + xx [ 67 ] - xx [ 39 ] * xx [ 9 ] ; pm_math_Quaternion_xform_ra (
xx + 265 , xx + 69 , xx + 16 ) ; xx [ 29 ] = xx [ 460 ] + xx [ 60 ] + xx [ 57
] + xx [ 78 ] + xx [ 72 ] + xx [ 84 ] + xx [ 81 ] + xx [ 90 ] + xx [ 87 ] +
xx [ 40 ] - xx [ 66 ] * xx [ 9 ] ; xx [ 30 ] = xx [ 3 ] - xx [ 263 ] * xx [ 9
] ; xx [ 31 ] = xx [ 7 ] - xx [ 341 ] * xx [ 9 ] ;
pm_math_Quaternion_xform_ra ( xx + 265 , xx + 29 , xx + 32 ) ;
pm_math_Vector3_cross_ra ( xx + 190 , xx + 16 , xx + 29 ) ; xx [ 1 ] = ( xx [
33 ] + xx [ 30 ] ) / xx [ 51 ] ; xx [ 29 ] = xx [ 16 ] - xx [ 1 ] * xx [ 44 ]
; xx [ 30 ] = xx [ 17 ] - xx [ 1 ] * xx [ 53 ] ; xx [ 31 ] = xx [ 18 ] - xx [
1 ] * xx [ 55 ] ; pm_math_Quaternion_xform_ra ( xx + 193 , xx + 29 , xx + 16
) ; xx [ 29 ] = - xx [ 16 ] ; xx [ 30 ] = - xx [ 17 ] ; xx [ 31 ] = - xx [ 18
] ; solveSymmetricPosDef ( xx + 400 , xx + 29 , 3 , 1 , xx + 16 , xx + 32 ) ;
xx [ 3 ] = xx [ 16 ] + xx [ 12 ] ; xx [ 7 ] = xx [ 17 ] + xx [ 13 ] ; xx [ 12
] = xx [ 18 ] + xx [ 14 ] ; xx [ 16 ] = xx [ 3 ] - xx [ 68 ] ; xx [ 17 ] = xx
[ 7 ] ; xx [ 18 ] = xx [ 12 ] - xx [ 11 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 193 , xx + 16 , xx + 29 ) ; xx [ 11
] = xx [ 1 ] + pm_math_Vector3_dot_ra ( xx + 422 , xx + 29 ) ; xx [ 1 ] = xx
[ 10 ] * xx [ 11 ] ; xx [ 13 ] = xx [ 11 ] * xx [ 2 ] ; xx [ 14 ] = ( xx [ 1
] * xx [ 25 ] - xx [ 13 ] * xx [ 4 ] ) * xx [ 5 ] ; xx [ 16 ] = ( xx [ 10 ] *
xx [ 1 ] + xx [ 13 ] * xx [ 2 ] ) * xx [ 5 ] - xx [ 11 ] ; xx [ 2 ] = xx [ 5
] * ( xx [ 13 ] * xx [ 25 ] + xx [ 1 ] * xx [ 4 ] ) ; xx [ 32 ] = - xx [ 14 ]
; xx [ 33 ] = xx [ 16 ] ; xx [ 34 ] = xx [ 2 ] ; xx [ 42 ] = xx [ 29 ] + xx [
65 ] * xx [ 11 ] ; xx [ 43 ] = xx [ 30 ] ; xx [ 44 ] = xx [ 31 ] - xx [ 11 ]
* xx [ 169 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 265 , xx + 42 , xx +
29 ) ; xx [ 1 ] = xx [ 9 ] + pm_math_Vector3_dot_ra ( xx + 428 , xx + 32 ) +
pm_math_Vector3_dot_ra ( xx + 434 , xx + 29 ) ; xx [ 32 ] = - ( xx [ 162 ] +
xx [ 14 ] ) ; xx [ 33 ] = xx [ 16 ] + xx [ 1 ] * xx [ 20 ] + xx [ 6 ] ; xx [
34 ] = xx [ 2 ] + xx [ 1 ] * xx [ 23 ] - xx [ 24 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 32 , xx + 16 ) ; xx [ 2
] = xx [ 29 ] - xx [ 1 ] * xx [ 243 ] + xx [ 48 ] ; pm_math_Vector3_cross_ra
( xx + 32 , xx + 370 , xx + 23 ) ; xx [ 4 ] = xx [ 30 ] + xx [ 37 ] ; xx [ 6
] = xx [ 31 ] + xx [ 41 ] ; xx [ 29 ] = xx [ 2 ] + xx [ 23 ] ; xx [ 30 ] = xx
[ 4 ] + xx [ 24 ] ; xx [ 31 ] = xx [ 6 ] + xx [ 25 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 449 , xx + 29 , xx + 23 ) ; xx [ 9
] = xx [ 27 ] - ( pm_math_Vector3_dot_ra ( xx + 465 , xx + 16 ) + xx [ 238 ]
* xx [ 23 ] + xx [ 249 ] * xx [ 24 ] ) ; xx [ 10 ] = xx [ 16 ] + xx [ 128 ] ;
xx [ 13 ] = xx [ 17 ] - xx [ 129 ] ; xx [ 14 ] = xx [ 233 ] * xx [ 13 ] ; xx
[ 16 ] = xx [ 10 ] * xx [ 233 ] ; xx [ 17 ] = xx [ 10 ] - xx [ 5 ] * ( xx [
14 ] * xx [ 180 ] + xx [ 233 ] * xx [ 16 ] ) ; xx [ 10 ] = xx [ 13 ] - ( xx [
233 ] * xx [ 14 ] - xx [ 16 ] * xx [ 180 ] ) * xx [ 5 ] ; xx [ 13 ] = xx [ 18
] + xx [ 9 ] ; xx [ 29 ] = xx [ 17 ] ; xx [ 30 ] = xx [ 10 ] ; xx [ 31 ] = xx
[ 13 ] ; xx [ 14 ] = xx [ 23 ] + xx [ 130 ] + xx [ 13 ] * xx [ 246 ] ; xx [
16 ] = xx [ 24 ] + xx [ 159 ] * xx [ 9 ] + xx [ 301 ] + xx [ 13 ] * xx [ 244
] ; xx [ 18 ] = xx [ 16 ] * xx [ 233 ] ; xx [ 20 ] = xx [ 14 ] * xx [ 233 ] ;
xx [ 21 ] = xx [ 26 ] + pm_math_Vector3_dot_ra ( xx + 473 , xx + 29 ) + ( xx
[ 14 ] - xx [ 5 ] * ( xx [ 18 ] * xx [ 180 ] + xx [ 233 ] * xx [ 20 ] ) ) *
xx [ 231 ] + xx [ 223 ] * ( xx [ 16 ] - ( xx [ 233 ] * xx [ 18 ] - xx [ 20 ]
* xx [ 180 ] ) * xx [ 5 ] ) ; xx [ 14 ] = xx [ 13 ] - xx [ 21 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 32 , xx + 23 ) ;
pm_math_Vector3_cross_ra ( xx + 32 , xx + 289 , xx + 29 ) ; xx [ 35 ] = xx [
2 ] + xx [ 29 ] ; xx [ 36 ] = xx [ 4 ] + xx [ 30 ] ; xx [ 37 ] = xx [ 6 ] +
xx [ 31 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 415 , xx + 35 , xx + 29
) ; xx [ 13 ] = xx [ 28 ] - ( pm_math_Vector3_dot_ra ( xx + 409 , xx + 23 ) +
xx [ 163 ] * xx [ 29 ] + xx [ 173 ] * xx [ 30 ] ) ; xx [ 16 ] = xx [ 23 ] +
xx [ 133 ] ; xx [ 18 ] = xx [ 24 ] - xx [ 139 ] ; xx [ 20 ] = xx [ 153 ] * xx
[ 18 ] ; xx [ 23 ] = xx [ 16 ] * xx [ 153 ] ; xx [ 24 ] = xx [ 16 ] - xx [ 5
] * ( xx [ 20 ] * xx [ 122 ] + xx [ 153 ] * xx [ 23 ] ) ; xx [ 16 ] = xx [ 18
] - ( xx [ 153 ] * xx [ 20 ] - xx [ 23 ] * xx [ 122 ] ) * xx [ 5 ] ; xx [ 18
] = xx [ 25 ] + xx [ 13 ] ; xx [ 25 ] = xx [ 24 ] ; xx [ 26 ] = xx [ 16 ] ;
xx [ 27 ] = xx [ 18 ] ; xx [ 20 ] = xx [ 29 ] + xx [ 328 ] + xx [ 18 ] * xx [
166 ] ; xx [ 23 ] = xx [ 30 ] + xx [ 159 ] * xx [ 13 ] + xx [ 514 ] + xx [ 18
] * xx [ 164 ] ; xx [ 28 ] = xx [ 23 ] * xx [ 153 ] ; xx [ 29 ] = xx [ 20 ] *
xx [ 153 ] ; xx [ 30 ] = xx [ 0 ] + pm_math_Vector3_dot_ra ( xx + 439 , xx +
25 ) + ( xx [ 20 ] - xx [ 5 ] * ( xx [ 28 ] * xx [ 122 ] + xx [ 153 ] * xx [
29 ] ) ) * xx [ 151 ] + xx [ 141 ] * ( xx [ 23 ] - ( xx [ 153 ] * xx [ 28 ] -
xx [ 29 ] * xx [ 122 ] ) * xx [ 5 ] ) ; xx [ 0 ] = xx [ 18 ] - xx [ 30 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 32 , xx + 25 ) ;
pm_math_Vector3_cross_ra ( xx + 32 , xx + 336 , xx + 35 ) ; xx [ 39 ] = xx [
2 ] + xx [ 35 ] ; xx [ 40 ] = xx [ 4 ] + xx [ 36 ] ; xx [ 41 ] = xx [ 6 ] +
xx [ 37 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 445 , xx + 39 , xx + 35
) ; xx [ 5 ] = xx [ 19 ] - ( xx [ 114 ] * xx [ 27 ] + xx [ 138 ] * xx [ 36 ]
) ; pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 32 , xx + 18 ) ;
pm_math_Vector3_cross_ra ( xx + 32 , xx + 319 , xx + 35 ) ; xx [ 31 ] = xx [
2 ] + xx [ 35 ] ; xx [ 32 ] = xx [ 4 ] + xx [ 36 ] ; xx [ 33 ] = xx [ 6 ] +
xx [ 37 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 269 , xx + 31 , xx + 34
) ; xx [ 2 ] = xx [ 8 ] - ( xx [ 114 ] * xx [ 20 ] + xx [ 138 ] * xx [ 35 ] )
; xx [ 31 ] = xx [ 172 ] ; xx [ 32 ] = xx [ 344 ] ; xx [ 33 ] = xx [ 251 ] ;
xx [ 34 ] = xx [ 339 ] ; pm_math_Quaternion_inverseCompose_ra ( xx + 31 , xx
+ 445 , xx + 39 ) ; xx [ 31 ] = xx [ 24 ] + xx [ 248 ] ; xx [ 32 ] = xx [ 16
] - xx [ 161 ] ; xx [ 33 ] = xx [ 0 ] ; pm_math_Quaternion_inverseXform_ra (
xx + 39 , xx + 31 , xx + 23 ) ; xx [ 31 ] = xx [ 427 ] ; xx [ 32 ] = xx [ 353
] ; xx [ 33 ] = xx [ 433 ] ; xx [ 34 ] = xx [ 346 ] ;
pm_math_Quaternion_inverseCompose_ra ( xx + 31 , xx + 269 , xx + 39 ) ; xx [
31 ] = xx [ 17 ] + xx [ 135 ] ; xx [ 32 ] = xx [ 10 ] - xx [ 125 ] ; xx [ 33
] = xx [ 14 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 39 , xx + 31 , xx +
16 ) ; deriv [ 0 ] = state [ 3 ] ; deriv [ 1 ] = state [ 4 ] ; deriv [ 2 ] =
state [ 5 ] ; deriv [ 3 ] = xx [ 3 ] ; deriv [ 4 ] = xx [ 7 ] ; deriv [ 5 ] =
xx [ 12 ] ; deriv [ 6 ] = state [ 7 ] ; deriv [ 7 ] = - xx [ 11 ] ; deriv [ 8
] = state [ 9 ] ; deriv [ 9 ] = - xx [ 1 ] ; deriv [ 10 ] = state [ 11 ] ;
deriv [ 11 ] = xx [ 9 ] ; deriv [ 12 ] = state [ 13 ] ; deriv [ 13 ] = - xx [
21 ] ; deriv [ 14 ] = state [ 15 ] ; deriv [ 15 ] = xx [ 15 ] - xx [ 14 ] ;
deriv [ 16 ] = state [ 17 ] ; deriv [ 17 ] = xx [ 13 ] ; deriv [ 18 ] = state
[ 19 ] ; deriv [ 19 ] = - xx [ 30 ] ; deriv [ 20 ] = state [ 21 ] ; deriv [
21 ] = xx [ 22 ] - xx [ 0 ] ; deriv [ 22 ] = state [ 23 ] ; deriv [ 23 ] = xx
[ 5 ] ; deriv [ 24 ] = state [ 25 ] ; deriv [ 25 ] = xx [ 2 ] ; deriv [ 26 ]
= state [ 27 ] ; deriv [ 27 ] = xx [ 27 ] + xx [ 5 ] - xx [ 25 ] ; deriv [ 28
] = state [ 29 ] ; deriv [ 29 ] = xx [ 20 ] + xx [ 2 ] - xx [ 18 ] ;
errorResult [ 0 ] = xx [ 38 ] ; return NULL ; } PmfMessageId
series_link_blance_leg_ad6bcbee_1_numJacPerturbLoBounds ( const
RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const double
* state , const int * modeVector , const double * input , const double *
inputDot , const double * inputDdot , const double * discreteState , double *
bounds , double * errorResult , NeuDiagnosticManager * neDiagMgr ) { const
double * rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv ->
mInts . mValues ; double xx [ 2 ] ; ( void ) rtdvd ; ( void ) rtdvi ; ( void
) eqnEnableFlags ; ( void ) state ; ( void ) modeVector ; ( void ) input ; (
void ) inputDot ; ( void ) inputDdot ; ( void ) discreteState ; ( void )
neDiagMgr ; xx [ 0 ] = 1.0e-9 ; xx [ 1 ] = 1.0e-8 ; bounds [ 0 ] = xx [ 0 ] ;
bounds [ 1 ] = xx [ 0 ] ; bounds [ 2 ] = xx [ 0 ] ; bounds [ 3 ] = xx [ 0 ] ;
bounds [ 4 ] = xx [ 0 ] ; bounds [ 5 ] = xx [ 0 ] ; bounds [ 6 ] = xx [ 1 ] ;
bounds [ 7 ] = xx [ 1 ] ; bounds [ 8 ] = xx [ 1 ] ; bounds [ 9 ] = xx [ 1 ] ;
bounds [ 10 ] = xx [ 1 ] ; bounds [ 11 ] = xx [ 1 ] ; bounds [ 12 ] = xx [ 1
] ; bounds [ 13 ] = xx [ 1 ] ; bounds [ 14 ] = xx [ 1 ] ; bounds [ 15 ] = xx
[ 1 ] ; bounds [ 16 ] = xx [ 1 ] ; bounds [ 17 ] = xx [ 1 ] ; bounds [ 18 ] =
xx [ 1 ] ; bounds [ 19 ] = xx [ 1 ] ; bounds [ 20 ] = xx [ 1 ] ; bounds [ 21
] = xx [ 1 ] ; bounds [ 22 ] = xx [ 1 ] ; bounds [ 23 ] = xx [ 1 ] ; bounds [
24 ] = xx [ 1 ] ; bounds [ 25 ] = xx [ 1 ] ; bounds [ 26 ] = xx [ 1 ] ;
bounds [ 27 ] = xx [ 1 ] ; bounds [ 28 ] = xx [ 1 ] ; bounds [ 29 ] = xx [ 1
] ; errorResult [ 0 ] = 0.0 ; return NULL ; } PmfMessageId
series_link_blance_leg_ad6bcbee_1_numJacPerturbHiBounds ( const
RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const double
* state , const int * modeVector , const double * input , const double *
inputDot , const double * inputDdot , const double * discreteState , double *
bounds , double * errorResult , NeuDiagnosticManager * neDiagMgr ) { const
double * rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv ->
mInts . mValues ; double xx [ 2 ] ; ( void ) rtdvd ; ( void ) rtdvi ; ( void
) eqnEnableFlags ; ( void ) state ; ( void ) modeVector ; ( void ) input ; (
void ) inputDot ; ( void ) inputDdot ; ( void ) discreteState ; ( void )
neDiagMgr ; xx [ 0 ] = + pmf_get_inf ( ) ; xx [ 1 ] = 1.0 ; bounds [ 0 ] = xx
[ 0 ] ; bounds [ 1 ] = xx [ 0 ] ; bounds [ 2 ] = xx [ 0 ] ; bounds [ 3 ] = xx
[ 0 ] ; bounds [ 4 ] = xx [ 0 ] ; bounds [ 5 ] = xx [ 0 ] ; bounds [ 6 ] = xx
[ 1 ] ; bounds [ 7 ] = xx [ 0 ] ; bounds [ 8 ] = xx [ 1 ] ; bounds [ 9 ] = xx
[ 0 ] ; bounds [ 10 ] = xx [ 1 ] ; bounds [ 11 ] = xx [ 0 ] ; bounds [ 12 ] =
xx [ 1 ] ; bounds [ 13 ] = xx [ 0 ] ; bounds [ 14 ] = xx [ 1 ] ; bounds [ 15
] = xx [ 0 ] ; bounds [ 16 ] = xx [ 1 ] ; bounds [ 17 ] = xx [ 0 ] ; bounds [
18 ] = xx [ 1 ] ; bounds [ 19 ] = xx [ 0 ] ; bounds [ 20 ] = xx [ 1 ] ;
bounds [ 21 ] = xx [ 0 ] ; bounds [ 22 ] = xx [ 1 ] ; bounds [ 23 ] = xx [ 0
] ; bounds [ 24 ] = xx [ 1 ] ; bounds [ 25 ] = xx [ 0 ] ; bounds [ 26 ] = xx
[ 1 ] ; bounds [ 27 ] = xx [ 0 ] ; bounds [ 28 ] = xx [ 1 ] ; bounds [ 29 ] =
xx [ 0 ] ; errorResult [ 0 ] = 0.0 ; return NULL ; }
