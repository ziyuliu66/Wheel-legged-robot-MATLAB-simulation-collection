#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
const sm_core_compiler_Cylinder *
series_link_blance_leg_ad6bcbee_1_geometry_0 ( const
RuntimeDerivedValuesBundle * rtdv ) { static const sm_core_compiler_Cylinder
cylinder = { 0.08 , 0.03 } ; ( void ) rtdv ; return & cylinder ; } const
sm_core_compiler_Brick * series_link_blance_leg_ad6bcbee_1_geometry_1 ( const
RuntimeDerivedValuesBundle * rtdv ) { static const sm_core_compiler_Brick
brick = { 1.0 , 30.0 , 0.01 } ; ( void ) rtdv ; return & brick ; } void
series_link_blance_leg_ad6bcbee_1_initializeGeometries ( const struct
RuntimeDerivedValuesBundleTag * rtdv ) {
series_link_blance_leg_ad6bcbee_1_geometry_0 ( rtdv ) ;
series_link_blance_leg_ad6bcbee_1_geometry_1 ( rtdv ) ; }
