#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "series_link_blance_leg_ad6bcbee_1_geometries.h"
PmfMessageId series_link_blance_leg_ad6bcbee_1_compOutputsKin ( const
RuntimeDerivedValuesBundle * rtdv , const double * state , const int *
modeVector , const double * input , const double * inputDot , const double *
inputDdot , const double * discreteState , double * output ,
NeuDiagnosticManager * neDiagMgr ) { const double * rtdvd = rtdv -> mDoubles
. mValues ; const int * rtdvi = rtdv -> mInts . mValues ; double xx [ 37 ] ;
( void ) rtdvd ; ( void ) rtdvi ; ( void ) modeVector ; ( void ) input ; (
void ) inputDot ; ( void ) inputDdot ; ( void ) discreteState ; ( void )
neDiagMgr ; xx [ 0 ] = 0.9858330682028801 ; xx [ 1 ] = 0.7071067811865476 ;
xx [ 2 ] = 0.5 ; xx [ 3 ] = xx [ 2 ] * state [ 6 ] ; xx [ 4 ] = xx [ 1 ] *
sin ( xx [ 3 ] ) ; xx [ 5 ] = xx [ 1 ] * xx [ 4 ] ; xx [ 6 ] = xx [ 1 ] * cos
( xx [ 3 ] ) ; xx [ 3 ] = xx [ 1 ] * xx [ 6 ] ; xx [ 7 ] = xx [ 5 ] - xx [ 3
] ; xx [ 8 ] = - ( xx [ 3 ] + xx [ 5 ] ) ; xx [ 9 ] = - ( xx [ 5 ] + xx [ 3 ]
) ; xx [ 10 ] = xx [ 3 ] - xx [ 5 ] ; xx [ 1 ] = 0.4090518191766045 ; xx [ 3
] = xx [ 2 ] * state [ 8 ] ; xx [ 2 ] = cos ( xx [ 3 ] ) ; xx [ 5 ] = xx [ 1
] * xx [ 2 ] ; xx [ 11 ] = 0.5767812490262756 ; xx [ 12 ] =
0.9437336767246086 ; xx [ 13 ] = sin ( xx [ 3 ] ) ; xx [ 3 ] = xx [ 12 ] * xx
[ 13 ] ; xx [ 14 ] = xx [ 11 ] * xx [ 3 ] ; xx [ 15 ] = 0.3307064369132422 ;
xx [ 16 ] = xx [ 15 ] * xx [ 13 ] ; xx [ 13 ] = xx [ 1 ] * xx [ 16 ] ; xx [
17 ] = xx [ 5 ] - ( xx [ 14 ] - xx [ 13 ] ) ; xx [ 18 ] = xx [ 11 ] * xx [ 16
] ; xx [ 16 ] = xx [ 11 ] * xx [ 2 ] ; xx [ 2 ] = xx [ 1 ] * xx [ 3 ] ; xx [
1 ] = xx [ 18 ] - xx [ 16 ] + xx [ 2 ] ; xx [ 3 ] = xx [ 2 ] + xx [ 16 ] + xx
[ 18 ] ; xx [ 2 ] = - xx [ 3 ] ; xx [ 11 ] = xx [ 5 ] - xx [ 13 ] + xx [ 14 ]
; xx [ 18 ] = xx [ 17 ] ; xx [ 19 ] = xx [ 1 ] ; xx [ 20 ] = xx [ 2 ] ; xx [
21 ] = xx [ 11 ] ; pm_math_Quaternion_compose_ra ( xx + 7 , xx + 18 , xx + 22
) ; xx [ 5 ] = 0.167729429849671 ; xx [ 7 ] = xx [ 0 ] * xx [ 22 ] - xx [ 5 ]
* xx [ 23 ] ; xx [ 8 ] = xx [ 5 ] * xx [ 22 ] + xx [ 0 ] * xx [ 23 ] ; xx [ 9
] = xx [ 0 ] * xx [ 24 ] + xx [ 5 ] * xx [ 25 ] ; xx [ 10 ] = xx [ 0 ] * xx [
25 ] - xx [ 5 ] * xx [ 24 ] ; xx [ 13 ] = xx [ 11 ] * state [ 7 ] ; xx [ 14 ]
= xx [ 1 ] * state [ 7 ] ; xx [ 16 ] = 2.0 ; xx [ 22 ] = 1.224172520925384e-4
; xx [ 23 ] = 3.176805347321508e-5 ; xx [ 24 ] = xx [ 6 ] ; xx [ 25 ] = xx [
6 ] ; xx [ 26 ] = xx [ 4 ] ; xx [ 27 ] = xx [ 4 ] ; xx [ 28 ] = state [ 3 ] ;
xx [ 29 ] = state [ 4 ] ; xx [ 30 ] = state [ 5 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 24 , xx + 28 , xx + 31 ) ; xx [ 4 ]
= 0.0284344275538308 ; xx [ 24 ] = xx [ 1 ] ; xx [ 25 ] = xx [ 2 ] ; xx [ 26
] = xx [ 11 ] ; xx [ 2 ] = 9.889425053924039e-3 ; xx [ 6 ] = xx [ 11 ] * xx [
2 ] - xx [ 4 ] * xx [ 3 ] ; xx [ 27 ] = xx [ 2 ] * xx [ 1 ] ; xx [ 28 ] = xx
[ 6 ] ; xx [ 29 ] = - ( xx [ 4 ] * xx [ 1 ] ) ; xx [ 30 ] = - xx [ 27 ] ;
pm_math_Vector3_cross_ra ( xx + 24 , xx + 28 , xx + 34 ) ; xx [ 24 ] = xx [
31 ] - ( xx [ 4 ] + ( xx [ 36 ] - xx [ 27 ] * xx [ 17 ] ) * xx [ 16 ] ) *
state [ 7 ] ; xx [ 25 ] = xx [ 32 ] ; xx [ 26 ] = xx [ 16 ] * ( xx [ 6 ] * xx
[ 17 ] + xx [ 34 ] ) * state [ 7 ] + xx [ 33 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 18 , xx + 24 , xx + 27 ) ; xx [ 2 ]
= ( xx [ 13 ] * xx [ 17 ] - xx [ 14 ] * xx [ 3 ] ) * xx [ 16 ] ; xx [ 4 ] =
xx [ 28 ] - xx [ 22 ] * xx [ 2 ] ; xx [ 6 ] = xx [ 5 ] * xx [ 4 ] ; xx [ 18 ]
= xx [ 23 ] * xx [ 2 ] + xx [ 29 ] ; xx [ 2 ] = xx [ 18 ] * xx [ 5 ] ; xx [
19 ] = ( state [ 7 ] - ( xx [ 11 ] * xx [ 13 ] + xx [ 14 ] * xx [ 1 ] ) * xx
[ 16 ] - xx [ 12 ] * state [ 9 ] ) * xx [ 22 ] + ( xx [ 16 ] * ( xx [ 13 ] *
xx [ 3 ] + xx [ 14 ] * xx [ 17 ] ) + xx [ 15 ] * state [ 9 ] ) * xx [ 23 ] +
xx [ 27 ] + 0.03010502338364002 * state [ 9 ] ; xx [ 20 ] = xx [ 4 ] - ( xx [
5 ] * xx [ 6 ] - xx [ 0 ] * xx [ 2 ] ) * xx [ 16 ] ; xx [ 21 ] = xx [ 18 ] -
xx [ 16 ] * ( xx [ 0 ] * xx [ 6 ] + xx [ 5 ] * xx [ 2 ] ) ;
pm_math_Quaternion_xform_ra ( xx + 7 , xx + 19 , xx + 0 ) ; output [ 0 ] =
state [ 10 ] ; output [ 1 ] = state [ 16 ] ; output [ 2 ] = state [ 8 ] ;
output [ 3 ] = state [ 6 ] ; output [ 4 ] = state [ 7 ] ; output [ 5 ] = xx [
1 ] ; return NULL ; }
