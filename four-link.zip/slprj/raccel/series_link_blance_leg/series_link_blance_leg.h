#ifndef RTW_HEADER_series_link_blance_leg_h_
#define RTW_HEADER_series_link_blance_leg_h_
#ifndef series_link_blance_leg_COMMON_INCLUDES_
#define series_link_blance_leg_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#include "nesl_rtw.h"
#include "series_link_blance_leg_ad6bcbee_1_gateway.h"
#endif
#include "series_link_blance_leg_types.h"
#include <stddef.h>
#include "rtw_modelmap_simtarget.h"
#include "rt_defines.h"
#include <string.h>
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#define MODEL_NAME series_link_blance_leg
#define NSAMPLE_TIMES (3) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (41) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (37)   
#elif NCSTATES != 37
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T g1y4drz24r ; } jyjoxr5fwj ; typedef struct { real_T
ce51yimi3b ; } nstzhfyemr ; typedef struct { real_T grfdzphf00 ; } p00rr42fc4
; typedef struct { real_T evq2mmxdxv ; } hgh2bvor5a ; typedef struct { real_T
pauztuh2hc ; real_T hn03iabqcv [ 30 ] ; real_T lplw3b2kdf [ 6 ] ; real_T
i2xmftevov ; real_T l3wd5aalxa ; real_T drli3hrk5h ; real_T anpkxprbja ;
real_T oy5xm3521d ; real_T p2phmituzf ; real_T gpm1tdppix ; real_T gym3yhcqgm
; real_T colafue0bv ; real_T in3zcewtrh ; real_T ljulrgxuy2 ; real_T
g1jgegd4wm ; real_T mpta0uzi4y ; real_T lpnlritbfn ; real_T iqaeo4od0g ;
real_T c02iymmqlh ; real_T fnbcd50axg ; real_T oy2snck5ps ; real_T htrlclaxg3
; real_T glbg2zc0s5 ; real_T oujjbnqnp0 ; real_T dxmcbrhf1p [ 4 ] ; real_T
kwyo50invf [ 4 ] ; real_T cgb3czccvw [ 4 ] ; real_T nq5uupkk3g [ 4 ] ; real_T
mpvlceiipn ; hgh2bvor5a fbsnblbyea ; p00rr42fc4 kcvrgvdvjm ; hgh2bvor5a
n0y0hxfk33 ; p00rr42fc4 apbu43ywav ; jyjoxr5fwj joitgv4v2v ; jyjoxr5fwj
b2hrormsfx ; nstzhfyemr avniujwdse ; jyjoxr5fwj l3xole44kr ; jyjoxr5fwj
jopkzmxn1u ; jyjoxr5fwj au2mpwffvh ; nstzhfyemr fquyezsxxj ; jyjoxr5fwj
mkj4rrinwg ; } B ; typedef struct { real_T hm5500fwpw [ 2 ] ; real_T
i0se4p4hlw [ 2 ] ; real_T k5pjuqqisf [ 2 ] ; real_T h3nbvzy4um [ 2 ] ; real_T
dmkrz0jizc ; real_T i03vg33mpd ; real_T b1yqxpaqhl ; struct { void *
LoggedData ; } kh3e4dwkm0 ; void * bvcs1a5kon ; void * na54detrfm ; void *
ewdahqbgsp ; void * ezkexigqdp ; void * lmvg0kqj2j ; void * hjmyc4f4pq ; void
* gfmsvy5x3x ; void * bwqmy33xj5 ; void * j00ccza4vb ; void * pguwjkgeoi ;
struct { void * LoggedData ; } ajjji5jeom ; struct { void * LoggedData ; }
onvqxcrc1k ; struct { void * LoggedData ; } dvvdywdijn ; struct { void *
LoggedData ; } fasjlt4cgs ; struct { void * LoggedData ; } pkjldbzxhm ; void
* ewrahxmsrs ; void * dqvluyfjzj ; void * htokyxpb4w ; void * azs3p32xzo ;
void * aoqtp4iunx ; void * non5z2jdlx ; void * mefc4rxn2j ; void * fv1clnvzkj
; struct { void * LoggedData ; } hujsmvlycp ; int_T kfkrdvou4e ; int_T
ahf5rrmpuw ; int_T jjruupxboh ; int_T i5etx1dvmm ; int_T effr1n2tx3 ; int_T
no0kde53nr ; int_T muge3h4jv3 ; int_T amfw1jrgpg ; int_T bfqulf4eav ; int_T
lycjneddx4 ; int_T m3oahjxm15 ; int_T d4evikqooj ; int_T p5kcjqwpvc ; int_T
e1ol1lizf2 ; int_T d24f0oxkxa ; int_T j5rkxjl2e3 ; int_T ocvfy0qejk ;
boolean_T puzm4xqe0p ; boolean_T nadulzitq3 ; boolean_T el2uob1lxb ; } DW ;
typedef struct { real_T jtjnlz2ruo ; real_T azpqecuyl0 [ 30 ] ; real_T
cvhtys1nmg ; real_T k2pkguag0f ; real_T enclntnpgb ; real_T mgxiehzkbv ;
real_T bdi5kb2v3m ; real_T m5olntpqfc ; } X ; typedef struct { real_T
jtjnlz2ruo ; real_T azpqecuyl0 [ 30 ] ; real_T cvhtys1nmg ; real_T k2pkguag0f
; real_T enclntnpgb ; real_T mgxiehzkbv ; real_T bdi5kb2v3m ; real_T
m5olntpqfc ; } XDot ; typedef struct { boolean_T jtjnlz2ruo ; boolean_T
azpqecuyl0 [ 30 ] ; boolean_T cvhtys1nmg ; boolean_T k2pkguag0f ; boolean_T
enclntnpgb ; boolean_T mgxiehzkbv ; boolean_T bdi5kb2v3m ; boolean_T
m5olntpqfc ; } XDis ; typedef struct { real_T jtjnlz2ruo ; real_T azpqecuyl0
[ 30 ] ; real_T cvhtys1nmg ; real_T k2pkguag0f ; real_T enclntnpgb ; real_T
mgxiehzkbv ; real_T bdi5kb2v3m ; real_T m5olntpqfc ; } CStateAbsTol ; typedef
struct { real_T jtjnlz2ruo ; real_T azpqecuyl0 [ 30 ] ; real_T cvhtys1nmg ;
real_T k2pkguag0f ; real_T enclntnpgb ; real_T mgxiehzkbv ; real_T bdi5kb2v3m
; real_T m5olntpqfc ; } CXPtMin ; typedef struct { real_T jtjnlz2ruo ; real_T
azpqecuyl0 [ 30 ] ; real_T cvhtys1nmg ; real_T k2pkguag0f ; real_T enclntnpgb
; real_T mgxiehzkbv ; real_T bdi5kb2v3m ; real_T m5olntpqfc ; } CXPtMax ;
typedef struct { real_T daem1w2nyu ; real_T pzqlk5b4b1 ; real_T gw3dyruvn2 ;
real_T nhskplzz2c ; real_T phfuy52u3z ; real_T pjgyedrbrt ; real_T hpli5tgenp
; real_T hbmlkbktge ; real_T ayequtj1je ; real_T efl0mxynv3 ; real_T
hio0henvjn ; real_T clorgzschh ; real_T b0rja0ysvo ; real_T nzbtchguz1 ;
real_T p21yw5fdoc ; real_T pselqrc4px ; real_T asmvqpgpln ; real_T irqkjkbrov
; } ZCV ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ;
struct P_ { real_T a11 [ 3 ] ; real_T a12 [ 3 ] ; real_T a13 [ 2 ] ; real_T
a14 [ 3 ] ; real_T PIDController2_D ; real_T PIDController1_D ; real_T
PIDController1_I ; real_T PIDController2_I ; real_T
PIDController2_InitialConditionForFilter ; real_T
PIDController1_InitialConditionForFilter ; real_T
PIDController2_InitialConditionForIntegrator ; real_T
PIDController1_InitialConditionForIntegrator ; real_T PIDController2_N ;
real_T PIDController1_N ; real_T PIDController2_P ; real_T PIDController1_P ;
real_T jump_control_jump_time ; real_T Integrator1_IC ; real_T Gain7_Gain ;
real_T Gain3_Gain ; real_T Gain6_Gain ; real_T Gain2_Gain ; real_T
Integrator2_IC ; real_T Gain5_Gain ; real_T Gain1_Gain ; real_T Gain4_Gain ;
real_T Gain22_Gain ; real_T Integrator_IC ; real_T Step8_Y0 ; real_T
Step8_YFinal ; real_T u_Y0 ; real_T u_YFinal ; real_T Step9_Y0 ; real_T
Step9_YFinal ; real_T u_Y0_hm53n5zp3n ; real_T u_YFinal_gbt5lirlne ; real_T
Saturation1_UpperSat ; real_T Saturation1_LowerSat ; real_T Step_Y0 ; real_T
Step_YFinal ; real_T u_Y0_jhi1ifohxk ; real_T u_YFinal_bx230hzb35 ; real_T
Step1_Y0 ; real_T Step1_YFinal ; real_T u_Y0_l1hc11lifj ; real_T
u_YFinal_mkca3g5pip ; real_T Saturation2_UpperSat ; real_T
Saturation2_LowerSat ; real_T Saturation3_UpperSat ; real_T
Saturation3_LowerSat ; real_T Saturation7_UpperSat ; real_T
Saturation7_LowerSat ; real_T Step2_Time ; real_T Step2_Y0 ; real_T
Step2_YFinal ; real_T Step3_Time ; real_T Step3_Y0 ; real_T Step3_YFinal ;
real_T _Value ; real_T Gain8_Gain ; real_T Constant12_Value ; real_T
_Value_hav0saipvz ; } ; extern const char * RT_MEMORY_ALLOCATION_ERROR ;
extern B rtB ; extern X rtX ; extern DW rtDW ; extern P rtP ; extern mxArray
* mr_series_link_blance_leg_GetDWork ( ) ; extern void
mr_series_link_blance_leg_SetDWork ( const mxArray * ssDW ) ; extern mxArray
* mr_series_link_blance_leg_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * series_link_blance_leg_GetCAPIStaticMap (
void ) ; extern SimStruct * const rtS ; extern const int_T gblNumToFiles ;
extern const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ;
extern rtInportTUtable * gblInportTUtables ; extern const char *
gblInportFileName ; extern const int_T gblNumRootInportBlks ; extern const
int_T gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ;
extern const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [
] ; extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
