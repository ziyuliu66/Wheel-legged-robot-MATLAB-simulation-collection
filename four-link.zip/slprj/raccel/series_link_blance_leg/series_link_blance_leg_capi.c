#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "series_link_blance_leg_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
#else
#include "builtin_typeid_types.h"
#include "series_link_blance_leg.h"
#include "series_link_blance_leg_capi.h"
#include "series_link_blance_leg_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"series_link_blance_leg/Gain1" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 }
, { 1 , 0 , TARGET_STRING ( "series_link_blance_leg/Gain2" ) , TARGET_STRING
( "" ) , 0 , 0 , 0 , 0 , 0 } , { 2 , 0 , TARGET_STRING (
"series_link_blance_leg/Gain22" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0
} , { 3 , 0 , TARGET_STRING ( "series_link_blance_leg/Gain3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 4 , 0 , TARGET_STRING (
"series_link_blance_leg/Gain8" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 1 }
, { 5 , 0 , TARGET_STRING ( "series_link_blance_leg/Integrator1" ) ,
TARGET_STRING ( "x" ) , 0 , 0 , 0 , 0 , 0 } , { 6 , 0 , TARGET_STRING (
"series_link_blance_leg/Integrator2" ) , TARGET_STRING ( "x" ) , 0 , 0 , 0 ,
0 , 0 } , { 7 , 0 , TARGET_STRING ( "series_link_blance_leg/Saturation1" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 8 , 0 , TARGET_STRING (
"series_link_blance_leg/Saturation2" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 9 , 0 , TARGET_STRING ( "series_link_blance_leg/Saturation3" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 10 , 0 , TARGET_STRING (
"series_link_blance_leg/Saturation7" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0
, 0 } , { 11 , 0 , TARGET_STRING ( "series_link_blance_leg/Sum22" ) ,
TARGET_STRING ( "speed_set" ) , 0 , 0 , 0 , 0 , 2 } , { 12 , 0 ,
TARGET_STRING ( "series_link_blance_leg/Sum26" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 13 , 1 , TARGET_STRING (
"series_link_blance_leg/calc/MATLAB Function1" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 14 , 2 , TARGET_STRING (
"series_link_blance_leg/calc/MATLAB Function2" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 15 , 3 , TARGET_STRING (
"series_link_blance_leg/calc/MATLAB Function3" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 16 , 4 , TARGET_STRING (
"series_link_blance_leg/calc/MATLAB Function6" ) , TARGET_STRING ( "" ) , 0 ,
0 , 0 , 0 , 0 } , { 17 , 0 , TARGET_STRING (
"series_link_blance_leg/calc/Product" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 18 , 5 , TARGET_STRING (
"series_link_blance_leg/calc1/MATLAB Function1" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 19 , 6 , TARGET_STRING (
"series_link_blance_leg/calc1/MATLAB Function2" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 20 , 7 , TARGET_STRING (
"series_link_blance_leg/calc1/MATLAB Function3" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 21 , 8 , TARGET_STRING (
"series_link_blance_leg/calc1/MATLAB Function6" ) , TARGET_STRING ( "" ) , 0
, 0 , 0 , 0 , 0 } , { 22 , 0 , TARGET_STRING (
"series_link_blance_leg/calc1/Product" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 23 , 9 , TARGET_STRING (
"series_link_blance_leg/control/MATLAB Function6" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 24 , 10 , TARGET_STRING (
"series_link_blance_leg/control/MATLAB Function7" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 25 , 11 , TARGET_STRING (
"series_link_blance_leg/control1/MATLAB Function6" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 26 , 12 , TARGET_STRING (
"series_link_blance_leg/control1/MATLAB Function7" ) , TARGET_STRING ( "" ) ,
0 , 0 , 0 , 0 , 0 } , { 27 , 0 , TARGET_STRING (
"series_link_blance_leg/jump_control/Sum1" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 28 , 0 , TARGET_STRING (
"series_link_blance_leg/jump_control/Sum3" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 0 } , { 29 , 0 , TARGET_STRING (
"series_link_blance_leg/jump_control/Sum5" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 30 , 0 , TARGET_STRING (
"series_link_blance_leg/jump_control/Sum8" ) , TARGET_STRING ( "" ) , 0 , 0 ,
0 , 0 , 2 } , { 31 , 0 , TARGET_STRING (
 "series_link_blance_leg/PID Controller1/I Gain/Internal Parameters/Integral Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 32 , 0 , TARGET_STRING (
 "series_link_blance_leg/PID Controller1/N Gain/Internal Parameters/Filter Coefficient"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 33 , 0 , TARGET_STRING (
 "series_link_blance_leg/PID Controller2/I Gain/Internal Parameters/Integral Gain"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 34 , 0 , TARGET_STRING (
 "series_link_blance_leg/PID Controller2/N Gain/Internal Parameters/Filter Coefficient"
) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 35 , 0 , TARGET_STRING (
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/INPUT_1_1_1"
) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 36 , 0 , TARGET_STRING (
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/INPUT_2_1_1"
) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 37 , 0 , TARGET_STRING (
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/INPUT_3_1_1"
) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 38 , 0 , TARGET_STRING (
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/INPUT_4_1_1"
) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 } , { 39 , 0 , TARGET_STRING (
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/OUTPUT_1_0"
) , TARGET_STRING ( "" ) , 0 , 0 , 2 , 0 , 0 } , { 40 , 0 , TARGET_STRING (
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/STATE_1"
) , TARGET_STRING ( "" ) , 0 , 0 , 3 , 0 , 0 } , { 0 , 0 , ( NULL ) , ( NULL
) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 41 , TARGET_STRING (
"series_link_blance_leg/PID Controller1" ) , TARGET_STRING ( "P" ) , 0 , 0 ,
0 } , { 42 , TARGET_STRING ( "series_link_blance_leg/PID Controller1" ) ,
TARGET_STRING ( "I" ) , 0 , 0 , 0 } , { 43 , TARGET_STRING (
"series_link_blance_leg/PID Controller1" ) , TARGET_STRING ( "D" ) , 0 , 0 ,
0 } , { 44 , TARGET_STRING ( "series_link_blance_leg/PID Controller1" ) ,
TARGET_STRING ( "N" ) , 0 , 0 , 0 } , { 45 , TARGET_STRING (
"series_link_blance_leg/PID Controller1" ) , TARGET_STRING (
"InitialConditionForIntegrator" ) , 0 , 0 , 0 } , { 46 , TARGET_STRING (
"series_link_blance_leg/PID Controller1" ) , TARGET_STRING (
"InitialConditionForFilter" ) , 0 , 0 , 0 } , { 47 , TARGET_STRING (
"series_link_blance_leg/PID Controller2" ) , TARGET_STRING ( "P" ) , 0 , 0 ,
0 } , { 48 , TARGET_STRING ( "series_link_blance_leg/PID Controller2" ) ,
TARGET_STRING ( "I" ) , 0 , 0 , 0 } , { 49 , TARGET_STRING (
"series_link_blance_leg/PID Controller2" ) , TARGET_STRING ( "D" ) , 0 , 0 ,
0 } , { 50 , TARGET_STRING ( "series_link_blance_leg/PID Controller2" ) ,
TARGET_STRING ( "N" ) , 0 , 0 , 0 } , { 51 , TARGET_STRING (
"series_link_blance_leg/PID Controller2" ) , TARGET_STRING (
"InitialConditionForIntegrator" ) , 0 , 0 , 0 } , { 52 , TARGET_STRING (
"series_link_blance_leg/PID Controller2" ) , TARGET_STRING (
"InitialConditionForFilter" ) , 0 , 0 , 0 } , { 53 , TARGET_STRING (
"series_link_blance_leg/jump_control" ) , TARGET_STRING ( "jump_time" ) , 0 ,
0 , 0 } , { 54 , TARGET_STRING ( "series_link_blance_leg/�����ȳ�" ) ,
TARGET_STRING ( "Value" ) , 0 , 0 , 0 } , { 55 , TARGET_STRING (
"series_link_blance_leg/��������" ) , TARGET_STRING ( "Value" ) , 0 , 0 , 0 }
, { 56 , TARGET_STRING ( "series_link_blance_leg/Gain1" ) , TARGET_STRING (
"Gain" ) , 0 , 0 , 0 } , { 57 , TARGET_STRING (
"series_link_blance_leg/Gain2" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , {
58 , TARGET_STRING ( "series_link_blance_leg/Gain22" ) , TARGET_STRING (
"Gain" ) , 0 , 0 , 0 } , { 59 , TARGET_STRING (
"series_link_blance_leg/Gain3" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , {
60 , TARGET_STRING ( "series_link_blance_leg/Gain4" ) , TARGET_STRING (
"Gain" ) , 0 , 0 , 0 } , { 61 , TARGET_STRING (
"series_link_blance_leg/Gain5" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , {
62 , TARGET_STRING ( "series_link_blance_leg/Gain6" ) , TARGET_STRING (
"Gain" ) , 0 , 0 , 0 } , { 63 , TARGET_STRING (
"series_link_blance_leg/Gain7" ) , TARGET_STRING ( "Gain" ) , 0 , 0 , 0 } , {
64 , TARGET_STRING ( "series_link_blance_leg/Gain8" ) , TARGET_STRING (
"Gain" ) , 0 , 0 , 0 } , { 65 , TARGET_STRING (
"series_link_blance_leg/Integrator" ) , TARGET_STRING ( "InitialCondition" )
, 0 , 0 , 0 } , { 66 , TARGET_STRING ( "series_link_blance_leg/Integrator1" )
, TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 67 , TARGET_STRING (
"series_link_blance_leg/Integrator2" ) , TARGET_STRING ( "InitialCondition" )
, 0 , 0 , 0 } , { 68 , TARGET_STRING ( "series_link_blance_leg/Saturation1" )
, TARGET_STRING ( "UpperLimit" ) , 0 , 0 , 0 } , { 69 , TARGET_STRING (
"series_link_blance_leg/Saturation1" ) , TARGET_STRING ( "LowerLimit" ) , 0 ,
0 , 0 } , { 70 , TARGET_STRING ( "series_link_blance_leg/Saturation2" ) ,
TARGET_STRING ( "UpperLimit" ) , 0 , 0 , 0 } , { 71 , TARGET_STRING (
"series_link_blance_leg/Saturation2" ) , TARGET_STRING ( "LowerLimit" ) , 0 ,
0 , 0 } , { 72 , TARGET_STRING ( "series_link_blance_leg/Saturation3" ) ,
TARGET_STRING ( "UpperLimit" ) , 0 , 0 , 0 } , { 73 , TARGET_STRING (
"series_link_blance_leg/Saturation3" ) , TARGET_STRING ( "LowerLimit" ) , 0 ,
0 , 0 } , { 74 , TARGET_STRING ( "series_link_blance_leg/Saturation7" ) ,
TARGET_STRING ( "UpperLimit" ) , 0 , 0 , 0 } , { 75 , TARGET_STRING (
"series_link_blance_leg/Saturation7" ) , TARGET_STRING ( "LowerLimit" ) , 0 ,
0 , 0 } , { 76 , TARGET_STRING ( "series_link_blance_leg/Step2" ) ,
TARGET_STRING ( "Time" ) , 0 , 0 , 0 } , { 77 , TARGET_STRING (
"series_link_blance_leg/Step2" ) , TARGET_STRING ( "Before" ) , 0 , 0 , 0 } ,
{ 78 , TARGET_STRING ( "series_link_blance_leg/Step2" ) , TARGET_STRING (
"After" ) , 0 , 0 , 0 } , { 79 , TARGET_STRING (
"series_link_blance_leg/Step3" ) , TARGET_STRING ( "Time" ) , 0 , 0 , 0 } , {
80 , TARGET_STRING ( "series_link_blance_leg/Step3" ) , TARGET_STRING (
"Before" ) , 0 , 0 , 0 } , { 81 , TARGET_STRING (
"series_link_blance_leg/Step3" ) , TARGET_STRING ( "After" ) , 0 , 0 , 0 } ,
{ 82 , TARGET_STRING ( "series_link_blance_leg/jump_control/Step" ) ,
TARGET_STRING ( "Before" ) , 0 , 0 , 0 } , { 83 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step" ) , TARGET_STRING ( "After" ) , 0
, 0 , 0 } , { 84 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step1" ) , TARGET_STRING ( "Before" ) ,
0 , 0 , 0 } , { 85 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step1" ) , TARGET_STRING ( "After" ) , 0
, 0 , 0 } , { 86 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step8" ) , TARGET_STRING ( "Before" ) ,
0 , 0 , 0 } , { 87 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step8" ) , TARGET_STRING ( "After" ) , 0
, 0 , 0 } , { 88 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step9" ) , TARGET_STRING ( "Before" ) ,
0 , 0 , 0 } , { 89 , TARGET_STRING (
"series_link_blance_leg/jump_control/Step9" ) , TARGET_STRING ( "After" ) , 0
, 0 , 0 } , { 90 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ1" ) , TARGET_STRING ( "Before"
) , 0 , 0 , 0 } , { 91 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ1" ) , TARGET_STRING ( "After" )
, 0 , 0 , 0 } , { 92 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ2" ) , TARGET_STRING ( "Before"
) , 0 , 0 , 0 } , { 93 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ2" ) , TARGET_STRING ( "After" )
, 0 , 0 , 0 } , { 94 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ3" ) , TARGET_STRING ( "Before"
) , 0 , 0 , 0 } , { 95 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ3" ) , TARGET_STRING ( "After" )
, 0 , 0 , 0 } , { 96 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ4" ) , TARGET_STRING ( "Before"
) , 0 , 0 , 0 } , { 97 , TARGET_STRING (
"series_link_blance_leg/jump_control/���ƽ�Ծ4" ) , TARGET_STRING ( "After" )
, 0 , 0 , 0 } , { 98 , TARGET_STRING (
"series_link_blance_leg/series_blance_leg_model/Constant12" ) , TARGET_STRING
( "Value" ) , 0 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 } } ;
static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const
rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 ,
0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 ,
( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 99 , TARGET_STRING (
"a11" ) , 0 , 4 , 0 } , { 100 , TARGET_STRING ( "a12" ) , 0 , 4 , 0 } , { 101
, TARGET_STRING ( "a13" ) , 0 , 5 , 0 } , { 102 , TARGET_STRING ( "a14" ) , 0
, 4 , 0 } , { 0 , ( NULL ) , 0 , 0 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . anpkxprbja , & rtB . l3wd5aalxa ,
& rtB . oy5xm3521d , & rtB . i2xmftevov , & rtB . mpvlceiipn , & rtB .
pauztuh2hc , & rtB . drli3hrk5h , & rtB . g1jgegd4wm , & rtB . iqaeo4od0g , &
rtB . fnbcd50axg , & rtB . htrlclaxg3 , & rtB . glbg2zc0s5 , & rtB .
oujjbnqnp0 , & rtB . mkj4rrinwg . g1y4drz24r , & rtB . fquyezsxxj .
ce51yimi3b , & rtB . au2mpwffvh . g1y4drz24r , & rtB . jopkzmxn1u .
g1y4drz24r , & rtB . oy2snck5ps , & rtB . l3xole44kr . g1y4drz24r , & rtB .
avniujwdse . ce51yimi3b , & rtB . b2hrormsfx . g1y4drz24r , & rtB .
joitgv4v2v . g1y4drz24r , & rtB . c02iymmqlh , & rtB . apbu43ywav .
grfdzphf00 , & rtB . n0y0hxfk33 . evq2mmxdxv , & rtB . kcvrgvdvjm .
grfdzphf00 , & rtB . fbsnblbyea . evq2mmxdxv , & rtB . lpnlritbfn , & rtB .
ljulrgxuy2 , & rtB . mpta0uzi4y , & rtB . in3zcewtrh , & rtB . gym3yhcqgm , &
rtB . gpm1tdppix , & rtB . colafue0bv , & rtB . p2phmituzf , & rtB .
cgb3czccvw [ 0 ] , & rtB . dxmcbrhf1p [ 0 ] , & rtB . kwyo50invf [ 0 ] , &
rtB . nq5uupkk3g [ 0 ] , & rtB . lplw3b2kdf [ 0 ] , & rtB . hn03iabqcv [ 0 ]
, & rtP . PIDController1_P , & rtP . PIDController1_I , & rtP .
PIDController1_D , & rtP . PIDController1_N , & rtP .
PIDController1_InitialConditionForIntegrator , & rtP .
PIDController1_InitialConditionForFilter , & rtP . PIDController2_P , & rtP .
PIDController2_I , & rtP . PIDController2_D , & rtP . PIDController2_N , &
rtP . PIDController2_InitialConditionForIntegrator , & rtP .
PIDController2_InitialConditionForFilter , & rtP . jump_control_jump_time , &
rtP . _Value_hav0saipvz , & rtP . _Value , & rtP . Gain1_Gain , & rtP .
Gain2_Gain , & rtP . Gain22_Gain , & rtP . Gain3_Gain , & rtP . Gain4_Gain ,
& rtP . Gain5_Gain , & rtP . Gain6_Gain , & rtP . Gain7_Gain , & rtP .
Gain8_Gain , & rtP . Integrator_IC , & rtP . Integrator1_IC , & rtP .
Integrator2_IC , & rtP . Saturation1_UpperSat , & rtP . Saturation1_LowerSat
, & rtP . Saturation2_UpperSat , & rtP . Saturation2_LowerSat , & rtP .
Saturation3_UpperSat , & rtP . Saturation3_LowerSat , & rtP .
Saturation7_UpperSat , & rtP . Saturation7_LowerSat , & rtP . Step2_Time , &
rtP . Step2_Y0 , & rtP . Step2_YFinal , & rtP . Step3_Time , & rtP . Step3_Y0
, & rtP . Step3_YFinal , & rtP . Step_Y0 , & rtP . Step_YFinal , & rtP .
Step1_Y0 , & rtP . Step1_YFinal , & rtP . Step8_Y0 , & rtP . Step8_YFinal , &
rtP . Step9_Y0 , & rtP . Step9_YFinal , & rtP . u_Y0_jhi1ifohxk , & rtP .
u_YFinal_bx230hzb35 , & rtP . u_Y0 , & rtP . u_YFinal , & rtP .
u_Y0_l1hc11lifj , & rtP . u_YFinal_mkca3g5pip , & rtP . u_Y0_hm53n5zp3n , &
rtP . u_YFinal_gbt5lirlne , & rtP . Constant12_Value , & rtP . a11 [ 0 ] , &
rtP . a12 [ 0 ] , & rtP . a13 [ 0 ] , & rtP . a14 [ 0 ] , } ; static int32_T
* rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , ( uint8_T ) SS_DOUBLE , 0 , 0 , 0 } }
;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_VECTOR , 8 , 2 , 0 } , { rtwCAPI_VECTOR , 10 , 2 , 0 } } ; static
const uint_T rtDimensionArray [ ] = { 1 , 1 , 4 , 1 , 6 , 1 , 30 , 1 , 1 , 3
, 1 , 2 } ; static const real_T rtcapiStoredFloats [ ] = { 0.0 , 1.0 } ;
static const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , ( boolean_T ) 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , (
int8_T ) 0 , ( uint8_T ) 0 } , { ( NULL ) , ( NULL ) , 2 , 0 } , { ( const
void * ) & rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [
1 ] , ( int8_T ) 1 , ( uint8_T ) 0 } } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 41 ,
rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 58 ,
rtModelParameters , 4 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 3704303775U , 570096350U , 4269575092U , 1976976561U } , ( NULL ) , 0 , (
boolean_T ) 0 , rt_LoggedStateIdxList } ; const
rtwCAPI_ModelMappingStaticInfo * series_link_blance_leg_GetCAPIStaticMap (
void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void series_link_blance_leg_InitializeDataMapInfo ( void ) {
rtwCAPI_SetVersion ( ( * rt_dataMapInfoPtr ) . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( ( * rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetDataAddressMap ( ( * rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ;
rtwCAPI_SetVarDimsAddressMap ( ( * rt_dataMapInfoPtr ) . mmi ,
rtVarDimsAddrMap ) ; rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr )
. mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi
, ( NULL ) ) ; rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi ,
0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void series_link_blance_leg_host_InitializeDataMapInfo (
series_link_blance_leg_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetPath ( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap ->
mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
