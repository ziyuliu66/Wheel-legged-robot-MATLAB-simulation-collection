    function targMap = targDataMap(),

    ;%***********************
    ;% Create Parameter Map *
    ;%***********************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 1;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc paramMap
        ;%
        paramMap.nSections           = nTotSects;
        paramMap.sectIdxOffset       = sectIdxOffset;
            paramMap.sections(nTotSects) = dumSection; %prealloc
        paramMap.nTotData            = -1;

        ;%
        ;% Auto data (rtP)
        ;%
            section.nData     = 62;
            section.data(62)  = dumData; %prealloc

                    ;% rtP.a11
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.a12
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 3;

                    ;% rtP.a13
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 6;

                    ;% rtP.a14
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 8;

                    ;% rtP.PIDController2_D
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 11;

                    ;% rtP.PIDController1_D
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 12;

                    ;% rtP.PIDController1_I
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 13;

                    ;% rtP.PIDController2_I
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 14;

                    ;% rtP.PIDController2_InitialConditionForFilter
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 15;

                    ;% rtP.PIDController1_InitialConditionForFilter
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 16;

                    ;% rtP.PIDController2_InitialConditionForIntegrator
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 17;

                    ;% rtP.PIDController1_InitialConditionForIntegrator
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 18;

                    ;% rtP.PIDController2_N
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 19;

                    ;% rtP.PIDController1_N
                    section.data(14).logicalSrcIdx = 13;
                    section.data(14).dtTransOffset = 20;

                    ;% rtP.PIDController2_P
                    section.data(15).logicalSrcIdx = 14;
                    section.data(15).dtTransOffset = 21;

                    ;% rtP.PIDController1_P
                    section.data(16).logicalSrcIdx = 15;
                    section.data(16).dtTransOffset = 22;

                    ;% rtP.jump_control_jump_time
                    section.data(17).logicalSrcIdx = 16;
                    section.data(17).dtTransOffset = 23;

                    ;% rtP.Integrator1_IC
                    section.data(18).logicalSrcIdx = 17;
                    section.data(18).dtTransOffset = 24;

                    ;% rtP.Gain7_Gain
                    section.data(19).logicalSrcIdx = 18;
                    section.data(19).dtTransOffset = 25;

                    ;% rtP.Gain3_Gain
                    section.data(20).logicalSrcIdx = 19;
                    section.data(20).dtTransOffset = 26;

                    ;% rtP.Gain6_Gain
                    section.data(21).logicalSrcIdx = 20;
                    section.data(21).dtTransOffset = 27;

                    ;% rtP.Gain2_Gain
                    section.data(22).logicalSrcIdx = 21;
                    section.data(22).dtTransOffset = 28;

                    ;% rtP.Integrator2_IC
                    section.data(23).logicalSrcIdx = 22;
                    section.data(23).dtTransOffset = 29;

                    ;% rtP.Gain5_Gain
                    section.data(24).logicalSrcIdx = 23;
                    section.data(24).dtTransOffset = 30;

                    ;% rtP.Gain1_Gain
                    section.data(25).logicalSrcIdx = 24;
                    section.data(25).dtTransOffset = 31;

                    ;% rtP.Gain4_Gain
                    section.data(26).logicalSrcIdx = 25;
                    section.data(26).dtTransOffset = 32;

                    ;% rtP.Gain22_Gain
                    section.data(27).logicalSrcIdx = 26;
                    section.data(27).dtTransOffset = 33;

                    ;% rtP.Integrator_IC
                    section.data(28).logicalSrcIdx = 27;
                    section.data(28).dtTransOffset = 34;

                    ;% rtP.Step8_Y0
                    section.data(29).logicalSrcIdx = 28;
                    section.data(29).dtTransOffset = 35;

                    ;% rtP.Step8_YFinal
                    section.data(30).logicalSrcIdx = 29;
                    section.data(30).dtTransOffset = 36;

                    ;% rtP.u_Y0
                    section.data(31).logicalSrcIdx = 30;
                    section.data(31).dtTransOffset = 37;

                    ;% rtP.u_YFinal
                    section.data(32).logicalSrcIdx = 31;
                    section.data(32).dtTransOffset = 38;

                    ;% rtP.Step9_Y0
                    section.data(33).logicalSrcIdx = 32;
                    section.data(33).dtTransOffset = 39;

                    ;% rtP.Step9_YFinal
                    section.data(34).logicalSrcIdx = 33;
                    section.data(34).dtTransOffset = 40;

                    ;% rtP.u_Y0_hm53n5zp3n
                    section.data(35).logicalSrcIdx = 34;
                    section.data(35).dtTransOffset = 41;

                    ;% rtP.u_YFinal_gbt5lirlne
                    section.data(36).logicalSrcIdx = 35;
                    section.data(36).dtTransOffset = 42;

                    ;% rtP.Saturation1_UpperSat
                    section.data(37).logicalSrcIdx = 36;
                    section.data(37).dtTransOffset = 43;

                    ;% rtP.Saturation1_LowerSat
                    section.data(38).logicalSrcIdx = 37;
                    section.data(38).dtTransOffset = 44;

                    ;% rtP.Step_Y0
                    section.data(39).logicalSrcIdx = 38;
                    section.data(39).dtTransOffset = 45;

                    ;% rtP.Step_YFinal
                    section.data(40).logicalSrcIdx = 39;
                    section.data(40).dtTransOffset = 46;

                    ;% rtP.u_Y0_jhi1ifohxk
                    section.data(41).logicalSrcIdx = 40;
                    section.data(41).dtTransOffset = 47;

                    ;% rtP.u_YFinal_bx230hzb35
                    section.data(42).logicalSrcIdx = 41;
                    section.data(42).dtTransOffset = 48;

                    ;% rtP.Step1_Y0
                    section.data(43).logicalSrcIdx = 42;
                    section.data(43).dtTransOffset = 49;

                    ;% rtP.Step1_YFinal
                    section.data(44).logicalSrcIdx = 43;
                    section.data(44).dtTransOffset = 50;

                    ;% rtP.u_Y0_l1hc11lifj
                    section.data(45).logicalSrcIdx = 44;
                    section.data(45).dtTransOffset = 51;

                    ;% rtP.u_YFinal_mkca3g5pip
                    section.data(46).logicalSrcIdx = 45;
                    section.data(46).dtTransOffset = 52;

                    ;% rtP.Saturation2_UpperSat
                    section.data(47).logicalSrcIdx = 46;
                    section.data(47).dtTransOffset = 53;

                    ;% rtP.Saturation2_LowerSat
                    section.data(48).logicalSrcIdx = 47;
                    section.data(48).dtTransOffset = 54;

                    ;% rtP.Saturation3_UpperSat
                    section.data(49).logicalSrcIdx = 48;
                    section.data(49).dtTransOffset = 55;

                    ;% rtP.Saturation3_LowerSat
                    section.data(50).logicalSrcIdx = 49;
                    section.data(50).dtTransOffset = 56;

                    ;% rtP.Saturation7_UpperSat
                    section.data(51).logicalSrcIdx = 50;
                    section.data(51).dtTransOffset = 57;

                    ;% rtP.Saturation7_LowerSat
                    section.data(52).logicalSrcIdx = 51;
                    section.data(52).dtTransOffset = 58;

                    ;% rtP.Step2_Time
                    section.data(53).logicalSrcIdx = 52;
                    section.data(53).dtTransOffset = 59;

                    ;% rtP.Step2_Y0
                    section.data(54).logicalSrcIdx = 53;
                    section.data(54).dtTransOffset = 60;

                    ;% rtP.Step2_YFinal
                    section.data(55).logicalSrcIdx = 54;
                    section.data(55).dtTransOffset = 61;

                    ;% rtP.Step3_Time
                    section.data(56).logicalSrcIdx = 55;
                    section.data(56).dtTransOffset = 62;

                    ;% rtP.Step3_Y0
                    section.data(57).logicalSrcIdx = 56;
                    section.data(57).dtTransOffset = 63;

                    ;% rtP.Step3_YFinal
                    section.data(58).logicalSrcIdx = 57;
                    section.data(58).dtTransOffset = 64;

                    ;% rtP._Value
                    section.data(59).logicalSrcIdx = 58;
                    section.data(59).dtTransOffset = 65;

                    ;% rtP.Gain8_Gain
                    section.data(60).logicalSrcIdx = 59;
                    section.data(60).dtTransOffset = 66;

                    ;% rtP.Constant12_Value
                    section.data(61).logicalSrcIdx = 60;
                    section.data(61).dtTransOffset = 67;

                    ;% rtP._Value_hav0saipvz
                    section.data(62).logicalSrcIdx = 61;
                    section.data(62).dtTransOffset = 68;

            nTotData = nTotData + section.nData;
            paramMap.sections(1) = section;
            clear section


            ;%
            ;% Non-auto Data (parameter)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        paramMap.nTotData = nTotData;



    ;%**************************
    ;% Create Block Output Map *
    ;%**************************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 13;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc sigMap
        ;%
        sigMap.nSections           = nTotSects;
        sigMap.sectIdxOffset       = sectIdxOffset;
            sigMap.sections(nTotSects) = dumSection; %prealloc
        sigMap.nTotData            = -1;

        ;%
        ;% Auto data (rtB)
        ;%
            section.nData     = 29;
            section.data(29)  = dumData; %prealloc

                    ;% rtB.pauztuh2hc
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtB.hn03iabqcv
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 1;

                    ;% rtB.lplw3b2kdf
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 31;

                    ;% rtB.i2xmftevov
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 37;

                    ;% rtB.l3wd5aalxa
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 38;

                    ;% rtB.drli3hrk5h
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 39;

                    ;% rtB.anpkxprbja
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 40;

                    ;% rtB.oy5xm3521d
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 41;

                    ;% rtB.p2phmituzf
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 42;

                    ;% rtB.gpm1tdppix
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 43;

                    ;% rtB.gym3yhcqgm
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 44;

                    ;% rtB.colafue0bv
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 45;

                    ;% rtB.in3zcewtrh
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 46;

                    ;% rtB.ljulrgxuy2
                    section.data(14).logicalSrcIdx = 13;
                    section.data(14).dtTransOffset = 47;

                    ;% rtB.g1jgegd4wm
                    section.data(15).logicalSrcIdx = 14;
                    section.data(15).dtTransOffset = 48;

                    ;% rtB.mpta0uzi4y
                    section.data(16).logicalSrcIdx = 15;
                    section.data(16).dtTransOffset = 49;

                    ;% rtB.lpnlritbfn
                    section.data(17).logicalSrcIdx = 16;
                    section.data(17).dtTransOffset = 50;

                    ;% rtB.iqaeo4od0g
                    section.data(18).logicalSrcIdx = 17;
                    section.data(18).dtTransOffset = 51;

                    ;% rtB.c02iymmqlh
                    section.data(19).logicalSrcIdx = 18;
                    section.data(19).dtTransOffset = 52;

                    ;% rtB.fnbcd50axg
                    section.data(20).logicalSrcIdx = 19;
                    section.data(20).dtTransOffset = 53;

                    ;% rtB.oy2snck5ps
                    section.data(21).logicalSrcIdx = 20;
                    section.data(21).dtTransOffset = 54;

                    ;% rtB.htrlclaxg3
                    section.data(22).logicalSrcIdx = 21;
                    section.data(22).dtTransOffset = 55;

                    ;% rtB.glbg2zc0s5
                    section.data(23).logicalSrcIdx = 22;
                    section.data(23).dtTransOffset = 56;

                    ;% rtB.oujjbnqnp0
                    section.data(24).logicalSrcIdx = 23;
                    section.data(24).dtTransOffset = 57;

                    ;% rtB.dxmcbrhf1p
                    section.data(25).logicalSrcIdx = 24;
                    section.data(25).dtTransOffset = 58;

                    ;% rtB.kwyo50invf
                    section.data(26).logicalSrcIdx = 25;
                    section.data(26).dtTransOffset = 62;

                    ;% rtB.cgb3czccvw
                    section.data(27).logicalSrcIdx = 26;
                    section.data(27).dtTransOffset = 66;

                    ;% rtB.nq5uupkk3g
                    section.data(28).logicalSrcIdx = 27;
                    section.data(28).dtTransOffset = 70;

                    ;% rtB.mpvlceiipn
                    section.data(29).logicalSrcIdx = 28;
                    section.data(29).dtTransOffset = 74;

            nTotData = nTotData + section.nData;
            sigMap.sections(1) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.fbsnblbyea.evq2mmxdxv
                    section.data(1).logicalSrcIdx = 29;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(2) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.kcvrgvdvjm.grfdzphf00
                    section.data(1).logicalSrcIdx = 30;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(3) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.n0y0hxfk33.evq2mmxdxv
                    section.data(1).logicalSrcIdx = 31;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(4) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.apbu43ywav.grfdzphf00
                    section.data(1).logicalSrcIdx = 32;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(5) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.joitgv4v2v.g1y4drz24r
                    section.data(1).logicalSrcIdx = 33;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(6) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.b2hrormsfx.g1y4drz24r
                    section.data(1).logicalSrcIdx = 34;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(7) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.avniujwdse.ce51yimi3b
                    section.data(1).logicalSrcIdx = 35;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(8) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.l3xole44kr.g1y4drz24r
                    section.data(1).logicalSrcIdx = 36;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(9) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.jopkzmxn1u.g1y4drz24r
                    section.data(1).logicalSrcIdx = 37;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(10) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.au2mpwffvh.g1y4drz24r
                    section.data(1).logicalSrcIdx = 38;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(11) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.fquyezsxxj.ce51yimi3b
                    section.data(1).logicalSrcIdx = 39;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(12) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.mkj4rrinwg.g1y4drz24r
                    section.data(1).logicalSrcIdx = 40;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(13) = section;
            clear section


            ;%
            ;% Non-auto Data (signal)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        sigMap.nTotData = nTotData;



    ;%*******************
    ;% Create DWork Map *
    ;%*******************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 4;
        sectIdxOffset = 13;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc dworkMap
        ;%
        dworkMap.nSections           = nTotSects;
        dworkMap.sectIdxOffset       = sectIdxOffset;
            dworkMap.sections(nTotSects) = dumSection; %prealloc
        dworkMap.nTotData            = -1;

        ;%
        ;% Auto data (rtDW)
        ;%
            section.nData     = 7;
            section.data(7)  = dumData; %prealloc

                    ;% rtDW.hm5500fwpw
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.i0se4p4hlw
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 2;

                    ;% rtDW.k5pjuqqisf
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 4;

                    ;% rtDW.h3nbvzy4um
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 6;

                    ;% rtDW.dmkrz0jizc
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 8;

                    ;% rtDW.i03vg33mpd
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 9;

                    ;% rtDW.b1yqxpaqhl
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 10;

            nTotData = nTotData + section.nData;
            dworkMap.sections(1) = section;
            clear section

            section.nData     = 25;
            section.data(25)  = dumData; %prealloc

                    ;% rtDW.kh3e4dwkm0.LoggedData
                    section.data(1).logicalSrcIdx = 7;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.bvcs1a5kon
                    section.data(2).logicalSrcIdx = 8;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.na54detrfm
                    section.data(3).logicalSrcIdx = 9;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.ewdahqbgsp
                    section.data(4).logicalSrcIdx = 10;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.ezkexigqdp
                    section.data(5).logicalSrcIdx = 11;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.lmvg0kqj2j
                    section.data(6).logicalSrcIdx = 12;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.hjmyc4f4pq
                    section.data(7).logicalSrcIdx = 13;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.gfmsvy5x3x
                    section.data(8).logicalSrcIdx = 14;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.bwqmy33xj5
                    section.data(9).logicalSrcIdx = 15;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.j00ccza4vb
                    section.data(10).logicalSrcIdx = 16;
                    section.data(10).dtTransOffset = 9;

                    ;% rtDW.pguwjkgeoi
                    section.data(11).logicalSrcIdx = 17;
                    section.data(11).dtTransOffset = 10;

                    ;% rtDW.ajjji5jeom.LoggedData
                    section.data(12).logicalSrcIdx = 18;
                    section.data(12).dtTransOffset = 11;

                    ;% rtDW.onvqxcrc1k.LoggedData
                    section.data(13).logicalSrcIdx = 19;
                    section.data(13).dtTransOffset = 12;

                    ;% rtDW.dvvdywdijn.LoggedData
                    section.data(14).logicalSrcIdx = 20;
                    section.data(14).dtTransOffset = 13;

                    ;% rtDW.fasjlt4cgs.LoggedData
                    section.data(15).logicalSrcIdx = 21;
                    section.data(15).dtTransOffset = 14;

                    ;% rtDW.pkjldbzxhm.LoggedData
                    section.data(16).logicalSrcIdx = 22;
                    section.data(16).dtTransOffset = 15;

                    ;% rtDW.ewrahxmsrs
                    section.data(17).logicalSrcIdx = 23;
                    section.data(17).dtTransOffset = 16;

                    ;% rtDW.dqvluyfjzj
                    section.data(18).logicalSrcIdx = 24;
                    section.data(18).dtTransOffset = 17;

                    ;% rtDW.htokyxpb4w
                    section.data(19).logicalSrcIdx = 25;
                    section.data(19).dtTransOffset = 18;

                    ;% rtDW.azs3p32xzo
                    section.data(20).logicalSrcIdx = 26;
                    section.data(20).dtTransOffset = 19;

                    ;% rtDW.aoqtp4iunx
                    section.data(21).logicalSrcIdx = 27;
                    section.data(21).dtTransOffset = 20;

                    ;% rtDW.non5z2jdlx
                    section.data(22).logicalSrcIdx = 28;
                    section.data(22).dtTransOffset = 21;

                    ;% rtDW.mefc4rxn2j
                    section.data(23).logicalSrcIdx = 29;
                    section.data(23).dtTransOffset = 22;

                    ;% rtDW.fv1clnvzkj
                    section.data(24).logicalSrcIdx = 30;
                    section.data(24).dtTransOffset = 23;

                    ;% rtDW.hujsmvlycp.LoggedData
                    section.data(25).logicalSrcIdx = 31;
                    section.data(25).dtTransOffset = 24;

            nTotData = nTotData + section.nData;
            dworkMap.sections(2) = section;
            clear section

            section.nData     = 17;
            section.data(17)  = dumData; %prealloc

                    ;% rtDW.kfkrdvou4e
                    section.data(1).logicalSrcIdx = 32;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.ahf5rrmpuw
                    section.data(2).logicalSrcIdx = 33;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.jjruupxboh
                    section.data(3).logicalSrcIdx = 34;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.i5etx1dvmm
                    section.data(4).logicalSrcIdx = 35;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.effr1n2tx3
                    section.data(5).logicalSrcIdx = 36;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.no0kde53nr
                    section.data(6).logicalSrcIdx = 37;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.muge3h4jv3
                    section.data(7).logicalSrcIdx = 38;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.amfw1jrgpg
                    section.data(8).logicalSrcIdx = 39;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.bfqulf4eav
                    section.data(9).logicalSrcIdx = 40;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.lycjneddx4
                    section.data(10).logicalSrcIdx = 41;
                    section.data(10).dtTransOffset = 9;

                    ;% rtDW.m3oahjxm15
                    section.data(11).logicalSrcIdx = 42;
                    section.data(11).dtTransOffset = 10;

                    ;% rtDW.d4evikqooj
                    section.data(12).logicalSrcIdx = 43;
                    section.data(12).dtTransOffset = 11;

                    ;% rtDW.p5kcjqwpvc
                    section.data(13).logicalSrcIdx = 44;
                    section.data(13).dtTransOffset = 12;

                    ;% rtDW.e1ol1lizf2
                    section.data(14).logicalSrcIdx = 45;
                    section.data(14).dtTransOffset = 13;

                    ;% rtDW.d24f0oxkxa
                    section.data(15).logicalSrcIdx = 46;
                    section.data(15).dtTransOffset = 14;

                    ;% rtDW.j5rkxjl2e3
                    section.data(16).logicalSrcIdx = 47;
                    section.data(16).dtTransOffset = 15;

                    ;% rtDW.ocvfy0qejk
                    section.data(17).logicalSrcIdx = 48;
                    section.data(17).dtTransOffset = 16;

            nTotData = nTotData + section.nData;
            dworkMap.sections(3) = section;
            clear section

            section.nData     = 3;
            section.data(3)  = dumData; %prealloc

                    ;% rtDW.puzm4xqe0p
                    section.data(1).logicalSrcIdx = 49;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.nadulzitq3
                    section.data(2).logicalSrcIdx = 50;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.el2uob1lxb
                    section.data(3).logicalSrcIdx = 51;
                    section.data(3).dtTransOffset = 2;

            nTotData = nTotData + section.nData;
            dworkMap.sections(4) = section;
            clear section


            ;%
            ;% Non-auto Data (dwork)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        dworkMap.nTotData = nTotData;



    ;%
    ;% Add individual maps to base struct.
    ;%

    targMap.paramMap  = paramMap;
    targMap.signalMap = sigMap;
    targMap.dworkMap  = dworkMap;

    ;%
    ;% Add checksums to base struct.
    ;%


    targMap.checksum0 = 3704303775;
    targMap.checksum1 = 570096350;
    targMap.checksum2 = 4269575092;
    targMap.checksum3 = 1976976561;

