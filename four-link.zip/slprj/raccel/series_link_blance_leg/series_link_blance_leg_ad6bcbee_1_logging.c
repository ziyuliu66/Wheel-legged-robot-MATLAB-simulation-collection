#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "series_link_blance_leg_ad6bcbee_1_geometries.h"
PmfMessageId series_link_blance_leg_ad6bcbee_1_recordLog ( const
RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const double
* state , const int * modeVector , const double * input , const double *
inputDot , const double * inputDdot , double * logVector , double *
errorResult , NeuDiagnosticManager * neDiagMgr ) { const double * rtdvd =
rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ;
boolean_T bb [ 1 ] ; int ii [ 4 ] ; double xx [ 589 ] ; ( void ) rtdvd ; (
void ) rtdvi ; ( void ) eqnEnableFlags ; ( void ) modeVector ; ( void )
inputDot ; ( void ) inputDdot ; ( void ) neDiagMgr ; xx [ 0 ] =
57.29577951308232 ; xx [ 1 ] = 0.7071067811865476 ; xx [ 2 ] = 0.5 ; xx [ 3 ]
= xx [ 2 ] * state [ 6 ] ; xx [ 4 ] = xx [ 1 ] * cos ( xx [ 3 ] ) ; xx [ 5 ]
= xx [ 4 ] * xx [ 4 ] ; xx [ 6 ] = 2.0 ; xx [ 7 ] = 1.0 ; xx [ 8 ] = xx [ 1 ]
* sin ( xx [ 3 ] ) ; xx [ 3 ] = xx [ 4 ] * xx [ 8 ] ; xx [ 9 ] = xx [ 6 ] * (
xx [ 3 ] - xx [ 3 ] ) ; xx [ 10 ] = ( xx [ 3 ] + xx [ 3 ] ) * xx [ 6 ] ; xx [
3 ] = xx [ 8 ] * xx [ 8 ] ; xx [ 11 ] = ( xx [ 5 ] + xx [ 3 ] ) * xx [ 6 ] -
xx [ 7 ] ; xx [ 12 ] = ( xx [ 5 ] + xx [ 5 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [
13 ] = xx [ 9 ] ; xx [ 14 ] = xx [ 10 ] ; xx [ 15 ] = xx [ 10 ] ; xx [ 16 ] =
xx [ 11 ] ; xx [ 17 ] = xx [ 6 ] * ( xx [ 3 ] - xx [ 5 ] ) ; xx [ 18 ] = xx [
9 ] ; xx [ 19 ] = ( xx [ 3 ] + xx [ 5 ] ) * xx [ 6 ] ; xx [ 20 ] = xx [ 11 ]
; xx [ 3 ] = 0.4090518191766045 ; xx [ 5 ] = xx [ 2 ] * state [ 8 ] ; xx [ 9
] = cos ( xx [ 5 ] ) ; xx [ 10 ] = xx [ 3 ] * xx [ 9 ] ; xx [ 11 ] =
0.5767812490262756 ; xx [ 21 ] = 0.9437336767246086 ; xx [ 22 ] = sin ( xx [
5 ] ) ; xx [ 5 ] = xx [ 21 ] * xx [ 22 ] ; xx [ 23 ] = xx [ 11 ] * xx [ 5 ] ;
xx [ 24 ] = 0.3307064369132422 ; xx [ 25 ] = xx [ 24 ] * xx [ 22 ] ; xx [ 22
] = xx [ 3 ] * xx [ 25 ] ; xx [ 26 ] = xx [ 10 ] - ( xx [ 23 ] - xx [ 22 ] )
; xx [ 27 ] = xx [ 26 ] * xx [ 26 ] ; xx [ 28 ] = xx [ 11 ] * xx [ 25 ] ; xx
[ 25 ] = xx [ 11 ] * xx [ 9 ] ; xx [ 9 ] = xx [ 3 ] * xx [ 5 ] ; xx [ 3 ] =
xx [ 28 ] - xx [ 25 ] + xx [ 9 ] ; xx [ 5 ] = xx [ 9 ] + xx [ 25 ] + xx [ 28
] ; xx [ 9 ] = xx [ 5 ] * xx [ 3 ] ; xx [ 11 ] = xx [ 10 ] - xx [ 22 ] + xx [
23 ] ; xx [ 10 ] = xx [ 11 ] * xx [ 26 ] ; xx [ 22 ] = xx [ 11 ] * xx [ 3 ] ;
xx [ 23 ] = xx [ 5 ] * xx [ 26 ] ; xx [ 25 ] = xx [ 11 ] * xx [ 5 ] ; xx [ 28
] = xx [ 3 ] * xx [ 26 ] ; xx [ 29 ] = ( xx [ 27 ] + xx [ 3 ] * xx [ 3 ] ) *
xx [ 6 ] - xx [ 7 ] ; xx [ 30 ] = - ( xx [ 6 ] * ( xx [ 9 ] + xx [ 10 ] ) ) ;
xx [ 31 ] = ( xx [ 22 ] - xx [ 23 ] ) * xx [ 6 ] ; xx [ 32 ] = ( xx [ 10 ] -
xx [ 9 ] ) * xx [ 6 ] ; xx [ 33 ] = ( xx [ 27 ] + xx [ 5 ] * xx [ 5 ] ) * xx
[ 6 ] - xx [ 7 ] ; xx [ 34 ] = - ( xx [ 6 ] * ( xx [ 25 ] + xx [ 28 ] ) ) ;
xx [ 35 ] = xx [ 6 ] * ( xx [ 22 ] + xx [ 23 ] ) ; xx [ 36 ] = ( xx [ 28 ] -
xx [ 25 ] ) * xx [ 6 ] ; xx [ 37 ] = ( xx [ 27 ] + xx [ 11 ] * xx [ 11 ] ) *
xx [ 6 ] - xx [ 7 ] ; xx [ 9 ] = 0.1186026172512557 ; xx [ 10 ] = xx [ 2 ] *
state [ 24 ] ; xx [ 22 ] = sin ( xx [ 10 ] ) ; xx [ 23 ] = 0.6970892476441968
; xx [ 25 ] = cos ( xx [ 10 ] ) ; xx [ 10 ] = xx [ 9 ] * xx [ 22 ] - xx [ 23
] * xx [ 25 ] ; xx [ 27 ] = xx [ 10 ] * xx [ 10 ] ; xx [ 28 ] = xx [ 9 ] * xx
[ 25 ] ; xx [ 25 ] = xx [ 23 ] * xx [ 22 ] ; xx [ 22 ] = xx [ 28 ] + xx [ 25
] ; xx [ 38 ] = ( xx [ 27 ] + xx [ 22 ] * xx [ 22 ] ) * xx [ 6 ] - xx [ 7 ] ;
xx [ 39 ] = xx [ 25 ] + xx [ 28 ] ; xx [ 25 ] = xx [ 39 ] * xx [ 10 ] ; xx [
28 ] = xx [ 22 ] * xx [ 10 ] ; xx [ 40 ] = xx [ 6 ] * ( xx [ 25 ] - xx [ 28 ]
) ; xx [ 41 ] = xx [ 22 ] * xx [ 39 ] ; xx [ 42 ] = ( xx [ 41 ] + xx [ 27 ] )
* xx [ 6 ] ; xx [ 43 ] = xx [ 28 ] + xx [ 25 ] ; xx [ 44 ] = xx [ 43 ] * xx [
6 ] ; xx [ 45 ] = ( xx [ 27 ] + xx [ 27 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 46 ]
= xx [ 6 ] * ( xx [ 28 ] - xx [ 25 ] ) ; xx [ 47 ] = xx [ 41 ] - xx [ 27 ] ;
xx [ 41 ] = xx [ 6 ] * xx [ 47 ] ; xx [ 48 ] = ( xx [ 25 ] + xx [ 28 ] ) * xx
[ 6 ] ; xx [ 25 ] = ( xx [ 27 ] + xx [ 39 ] * xx [ 39 ] ) * xx [ 6 ] - xx [ 7
] ; xx [ 49 ] = xx [ 38 ] ; xx [ 50 ] = xx [ 40 ] ; xx [ 51 ] = xx [ 42 ] ;
xx [ 52 ] = - xx [ 44 ] ; xx [ 53 ] = xx [ 45 ] ; xx [ 54 ] = xx [ 46 ] ; xx
[ 55 ] = xx [ 41 ] ; xx [ 56 ] = - xx [ 48 ] ; xx [ 57 ] = xx [ 25 ] ; xx [
27 ] = 0.135 ; xx [ 28 ] = 0.03394634084866131 ; xx [ 58 ] = xx [ 27 ] * xx [
38 ] ; xx [ 59 ] = - ( xx [ 27 ] * xx [ 44 ] ) ; xx [ 60 ] = xx [ 27 ] * xx [
41 ] ; xx [ 61 ] = xx [ 28 ] * xx [ 40 ] ; xx [ 62 ] = xx [ 28 ] * xx [ 45 ]
; xx [ 63 ] = - ( xx [ 28 ] * xx [ 48 ] ) ; xx [ 64 ] = xx [ 27 ] * xx [ 42 ]
; xx [ 65 ] = xx [ 27 ] * xx [ 46 ] ; xx [ 66 ] = xx [ 27 ] * xx [ 25 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 49 , xx + 58 , xx + 67 ) ; xx [ 58 ] = xx
[ 2 ] * state [ 22 ] ; xx [ 59 ] = sin ( xx [ 58 ] ) ; xx [ 60 ] = cos ( xx [
58 ] ) ; xx [ 58 ] = xx [ 9 ] * xx [ 59 ] - xx [ 23 ] * xx [ 60 ] ; xx [ 61 ]
= xx [ 58 ] * xx [ 58 ] ; xx [ 62 ] = xx [ 9 ] * xx [ 60 ] ; xx [ 60 ] = xx [
23 ] * xx [ 59 ] ; xx [ 59 ] = xx [ 62 ] + xx [ 60 ] ; xx [ 63 ] = ( xx [ 61
] + xx [ 59 ] * xx [ 59 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 64 ] = xx [ 60 ] +
xx [ 62 ] ; xx [ 60 ] = xx [ 64 ] * xx [ 58 ] ; xx [ 62 ] = xx [ 59 ] * xx [
58 ] ; xx [ 65 ] = xx [ 6 ] * ( xx [ 60 ] - xx [ 62 ] ) ; xx [ 66 ] = xx [ 59
] * xx [ 64 ] ; xx [ 76 ] = ( xx [ 66 ] + xx [ 61 ] ) * xx [ 6 ] ; xx [ 77 ]
= xx [ 62 ] + xx [ 60 ] ; xx [ 78 ] = xx [ 77 ] * xx [ 6 ] ; xx [ 79 ] = ( xx
[ 61 ] + xx [ 61 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 80 ] = xx [ 6 ] * ( xx [ 62
] - xx [ 60 ] ) ; xx [ 81 ] = xx [ 66 ] - xx [ 61 ] ; xx [ 66 ] = xx [ 6 ] *
xx [ 81 ] ; xx [ 82 ] = ( xx [ 60 ] + xx [ 62 ] ) * xx [ 6 ] ; xx [ 60 ] = (
xx [ 61 ] + xx [ 64 ] * xx [ 64 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 83 ] = xx [
63 ] ; xx [ 84 ] = xx [ 65 ] ; xx [ 85 ] = xx [ 76 ] ; xx [ 86 ] = - xx [ 78
] ; xx [ 87 ] = xx [ 79 ] ; xx [ 88 ] = xx [ 80 ] ; xx [ 89 ] = xx [ 66 ] ;
xx [ 90 ] = - xx [ 82 ] ; xx [ 91 ] = xx [ 60 ] ; xx [ 92 ] = xx [ 27 ] * xx
[ 63 ] ; xx [ 93 ] = - ( xx [ 27 ] * xx [ 78 ] ) ; xx [ 94 ] = xx [ 27 ] * xx
[ 66 ] ; xx [ 95 ] = xx [ 28 ] * xx [ 65 ] ; xx [ 96 ] = xx [ 28 ] * xx [ 79
] ; xx [ 97 ] = - ( xx [ 28 ] * xx [ 82 ] ) ; xx [ 98 ] = xx [ 27 ] * xx [ 76
] ; xx [ 99 ] = xx [ 27 ] * xx [ 80 ] ; xx [ 100 ] = xx [ 27 ] * xx [ 60 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 83 , xx + 92 , xx + 101 ) ; xx [ 28 ] =
xx [ 2 ] * state [ 16 ] ; xx [ 61 ] = cos ( xx [ 28 ] ) ; xx [ 62 ] = sin (
xx [ 28 ] ) ; xx [ 28 ] = xx [ 23 ] * xx [ 61 ] - xx [ 9 ] * xx [ 62 ] ; xx [
92 ] = xx [ 28 ] * xx [ 28 ] ; xx [ 93 ] = xx [ 9 ] * xx [ 61 ] ; xx [ 61 ] =
xx [ 23 ] * xx [ 62 ] ; xx [ 62 ] = xx [ 93 ] + xx [ 61 ] ; xx [ 94 ] = ( xx
[ 92 ] + xx [ 62 ] * xx [ 62 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 95 ] = xx [ 62
] * xx [ 28 ] ; xx [ 96 ] = xx [ 61 ] + xx [ 93 ] ; xx [ 61 ] = xx [ 96 ] *
xx [ 28 ] ; xx [ 93 ] = xx [ 6 ] * ( xx [ 95 ] - xx [ 61 ] ) ; xx [ 97 ] = xx
[ 62 ] * xx [ 96 ] ; xx [ 98 ] = ( xx [ 97 ] + xx [ 92 ] ) * xx [ 6 ] ; xx [
99 ] = xx [ 95 ] + xx [ 61 ] ; xx [ 100 ] = xx [ 99 ] * xx [ 6 ] ; xx [ 110 ]
= ( xx [ 92 ] + xx [ 92 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 111 ] = xx [ 6 ] * (
xx [ 61 ] - xx [ 95 ] ) ; xx [ 112 ] = xx [ 97 ] - xx [ 92 ] ; xx [ 97 ] = xx
[ 6 ] * xx [ 112 ] ; xx [ 113 ] = xx [ 61 ] + xx [ 95 ] ; xx [ 61 ] = xx [
113 ] * xx [ 6 ] ; xx [ 95 ] = ( xx [ 92 ] + xx [ 96 ] * xx [ 96 ] ) * xx [ 6
] - xx [ 7 ] ; xx [ 114 ] = xx [ 94 ] ; xx [ 115 ] = xx [ 93 ] ; xx [ 116 ] =
xx [ 98 ] ; xx [ 117 ] = xx [ 100 ] ; xx [ 118 ] = xx [ 110 ] ; xx [ 119 ] =
xx [ 111 ] ; xx [ 120 ] = xx [ 97 ] ; xx [ 121 ] = xx [ 61 ] ; xx [ 122 ] =
xx [ 95 ] ; xx [ 92 ] = 0.1412831853071796 ; xx [ 123 ] = xx [ 2 ] * state [
18 ] ; xx [ 124 ] = xx [ 1 ] * sin ( xx [ 123 ] ) ; xx [ 125 ] = xx [ 1 ] *
cos ( xx [ 123 ] ) ; xx [ 123 ] = xx [ 124 ] - xx [ 125 ] ; xx [ 126 ] = xx [
123 ] * xx [ 123 ] ; xx [ 127 ] = xx [ 6 ] * xx [ 126 ] - xx [ 7 ] ; xx [ 128
] = 0.2762831853071796 ; xx [ 129 ] = 1.18628318530718 ; xx [ 130 ] = xx [ 2
] * state [ 20 ] ; xx [ 131 ] = cos ( xx [ 130 ] ) ; xx [ 132 ] = xx [ 131 ]
* xx [ 131 ] ; xx [ 133 ] = xx [ 6 ] * xx [ 132 ] - xx [ 7 ] ; xx [ 134 ] =
xx [ 129 ] * xx [ 133 ] ; xx [ 135 ] = xx [ 134 ] * xx [ 133 ] ; xx [ 136 ] =
sin ( xx [ 130 ] ) ; xx [ 130 ] = xx [ 6 ] * xx [ 131 ] * xx [ 136 ] ; xx [
137 ] = xx [ 129 ] * xx [ 130 ] ; xx [ 138 ] = xx [ 137 ] * xx [ 130 ] ; xx [
139 ] = xx [ 135 ] + xx [ 138 ] ; xx [ 140 ] = xx [ 128 ] + xx [ 139 ] ; xx [
141 ] = 0.1339025647286604 ; xx [ 142 ] = xx [ 137 ] * xx [ 133 ] ; xx [ 137
] = xx [ 134 ] * xx [ 130 ] ; xx [ 134 ] = xx [ 142 ] - xx [ 137 ] ; xx [ 143
] = xx [ 141 ] * xx [ 134 ] ; xx [ 144 ] = 0.02913743527133955 ; xx [ 145 ] =
xx [ 143 ] + xx [ 144 ] * xx [ 134 ] ; xx [ 146 ] = 1.04926519013724e-3 ; xx
[ 147 ] = xx [ 138 ] + xx [ 135 ] ; xx [ 135 ] = xx [ 147 ] * xx [ 141 ] ; xx
[ 138 ] = xx [ 146 ] + xx [ 141 ] * xx [ 135 ] ; xx [ 148 ] = xx [ 138 ] + xx
[ 144 ] * xx [ 135 ] ; xx [ 149 ] = xx [ 128 ] + xx [ 147 ] ; xx [ 150 ] = xx
[ 135 ] + xx [ 149 ] * xx [ 144 ] ; xx [ 151 ] = xx [ 148 ] + xx [ 150 ] * xx
[ 144 ] ; ii [ 0 ] = factorSymmetricPosDef ( xx + 151 , 1 , xx + 152 ) ; if (
ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint3' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 152 ] = xx [ 145 ] / xx [ 151 ] ; xx [ 153 ] = xx [
140 ] - xx [ 145 ] * xx [ 152 ] ; xx [ 154 ] = xx [ 124 ] + xx [ 125 ] ; xx [
124 ] = xx [ 154 ] * xx [ 123 ] ; xx [ 125 ] = xx [ 6 ] * xx [ 124 ] ; xx [
155 ] = xx [ 150 ] * xx [ 152 ] ; xx [ 156 ] = xx [ 134 ] - xx [ 155 ] ; xx [
157 ] = xx [ 153 ] * xx [ 127 ] + xx [ 125 ] * xx [ 156 ] ; xx [ 158 ] = xx [
137 ] - xx [ 142 ] ; xx [ 137 ] = xx [ 158 ] - xx [ 155 ] ; xx [ 142 ] = xx [
150 ] / xx [ 151 ] ; xx [ 155 ] = xx [ 149 ] - xx [ 150 ] * xx [ 142 ] ; xx [
159 ] = xx [ 127 ] * xx [ 137 ] + xx [ 125 ] * xx [ 155 ] ; xx [ 160 ] = xx [
127 ] * xx [ 157 ] + xx [ 125 ] * xx [ 159 ] ; xx [ 161 ] = xx [ 92 ] + xx [
160 ] ; xx [ 162 ] = ( xx [ 126 ] + xx [ 154 ] * xx [ 154 ] ) * xx [ 6 ] - xx
[ 7 ] ; xx [ 126 ] = xx [ 143 ] - xx [ 148 ] * xx [ 152 ] ; xx [ 163 ] = xx [
135 ] - xx [ 148 ] * xx [ 142 ] ; xx [ 164 ] = xx [ 162 ] * ( xx [ 126 ] * xx
[ 127 ] + xx [ 125 ] * xx [ 163 ] ) ; xx [ 165 ] = xx [ 154 ] * xx [ 144 ] ;
xx [ 166 ] = xx [ 165 ] * xx [ 123 ] ; xx [ 167 ] = xx [ 6 ] * xx [ 166 ] ;
xx [ 168 ] = 0.1078490312466243 ; xx [ 169 ] = xx [ 6 ] * xx [ 154 ] * xx [
165 ] ; xx [ 165 ] = xx [ 168 ] - xx [ 169 ] ; xx [ 170 ] = xx [ 127 ] * xx [
156 ] - xx [ 125 ] * xx [ 153 ] ; xx [ 153 ] = xx [ 155 ] * xx [ 127 ] - xx [
125 ] * xx [ 137 ] ; xx [ 137 ] = xx [ 170 ] * xx [ 127 ] + xx [ 153 ] * xx [
125 ] ; xx [ 155 ] = xx [ 167 ] * xx [ 160 ] + xx [ 165 ] * xx [ 137 ] ; xx [
156 ] = xx [ 164 ] + xx [ 155 ] ; xx [ 160 ] = 0.08603840402471528 ; xx [ 171
] = xx [ 156 ] + xx [ 160 ] * xx [ 137 ] ; xx [ 172 ] = 3.489385797727083e-4
; xx [ 173 ] = xx [ 148 ] / xx [ 151 ] ; xx [ 174 ] = ( xx [ 163 ] * xx [ 127
] - xx [ 125 ] * xx [ 126 ] ) * xx [ 162 ] ; xx [ 126 ] = xx [ 167 ] * xx [
164 ] + xx [ 165 ] * xx [ 174 ] ; xx [ 163 ] = xx [ 127 ] * xx [ 159 ] - xx [
125 ] * xx [ 157 ] ; xx [ 157 ] = xx [ 153 ] * xx [ 127 ] - xx [ 170 ] * xx [
125 ] ; xx [ 153 ] = xx [ 163 ] * xx [ 167 ] + xx [ 157 ] * xx [ 165 ] ; xx [
159 ] = xx [ 172 ] + ( xx [ 138 ] - xx [ 148 ] * xx [ 173 ] ) * xx [ 162 ] *
xx [ 162 ] + xx [ 126 ] + xx [ 126 ] + xx [ 153 ] * xx [ 165 ] + xx [ 155 ] *
xx [ 167 ] ; xx [ 126 ] = xx [ 174 ] + xx [ 153 ] ; xx [ 138 ] = xx [ 159 ] +
xx [ 126 ] * xx [ 160 ] ; xx [ 153 ] = xx [ 92 ] + xx [ 157 ] ; xx [ 155 ] =
xx [ 126 ] + xx [ 153 ] * xx [ 160 ] ; xx [ 157 ] = xx [ 138 ] + xx [ 155 ] *
xx [ 160 ] ; ii [ 0 ] = factorSymmetricPosDef ( xx + 157 , 1 , xx + 164 ) ;
if ( ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint1' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 164 ] = xx [ 171 ] / xx [ 157 ] ; xx [ 170 ] = xx [
161 ] - xx [ 171 ] * xx [ 164 ] ; xx [ 174 ] = xx [ 155 ] * xx [ 164 ] ; xx [
175 ] = xx [ 137 ] - xx [ 174 ] ; xx [ 176 ] = xx [ 163 ] - xx [ 174 ] ; xx [
174 ] = xx [ 155 ] / xx [ 157 ] ; xx [ 177 ] = xx [ 153 ] - xx [ 155 ] * xx [
174 ] ; xx [ 178 ] = ( xx [ 132 ] + xx [ 136 ] * xx [ 136 ] ) * xx [ 6 ] - xx
[ 7 ] ; xx [ 132 ] = xx [ 129 ] * xx [ 178 ] * xx [ 178 ] ; xx [ 178 ] = xx [
128 ] + xx [ 132 ] ; xx [ 179 ] = xx [ 178 ] * xx [ 162 ] * xx [ 162 ] ; xx [
180 ] = xx [ 92 ] + xx [ 179 ] ; xx [ 181 ] = xx [ 170 ] * xx [ 94 ] + xx [
93 ] * xx [ 175 ] ; xx [ 182 ] = xx [ 100 ] * xx [ 170 ] + xx [ 110 ] * xx [
175 ] ; xx [ 183 ] = xx [ 97 ] * xx [ 170 ] + xx [ 61 ] * xx [ 175 ] ; xx [
184 ] = xx [ 176 ] * xx [ 94 ] + xx [ 93 ] * xx [ 177 ] ; xx [ 185 ] = xx [
100 ] * xx [ 176 ] + xx [ 177 ] * xx [ 110 ] ; xx [ 186 ] = xx [ 97 ] * xx [
176 ] + xx [ 61 ] * xx [ 177 ] ; xx [ 187 ] = xx [ 180 ] * xx [ 98 ] ; xx [
188 ] = xx [ 180 ] * xx [ 111 ] ; xx [ 189 ] = xx [ 180 ] * xx [ 95 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 114 , xx + 181 , xx + 190 ) ; xx [ 170 ]
= 10.02513274122872 ; xx [ 175 ] = xx [ 2 ] * state [ 10 ] ; xx [ 176 ] = cos
( xx [ 175 ] ) ; xx [ 177 ] = sin ( xx [ 175 ] ) ; xx [ 175 ] = xx [ 23 ] *
xx [ 176 ] - xx [ 9 ] * xx [ 177 ] ; xx [ 181 ] = xx [ 175 ] * xx [ 175 ] ;
xx [ 182 ] = xx [ 9 ] * xx [ 176 ] ; xx [ 9 ] = xx [ 23 ] * xx [ 177 ] ; xx [
23 ] = xx [ 182 ] + xx [ 9 ] ; xx [ 176 ] = ( xx [ 181 ] + xx [ 23 ] * xx [
23 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 177 ] = xx [ 23 ] * xx [ 175 ] ; xx [ 183
] = xx [ 9 ] + xx [ 182 ] ; xx [ 9 ] = xx [ 183 ] * xx [ 175 ] ; xx [ 182 ] =
xx [ 6 ] * ( xx [ 177 ] - xx [ 9 ] ) ; xx [ 184 ] = xx [ 23 ] * xx [ 183 ] ;
xx [ 185 ] = ( xx [ 184 ] + xx [ 181 ] ) * xx [ 6 ] ; xx [ 186 ] = xx [ 177 ]
+ xx [ 9 ] ; xx [ 187 ] = xx [ 186 ] * xx [ 6 ] ; xx [ 188 ] = ( xx [ 181 ] +
xx [ 181 ] ) * xx [ 6 ] - xx [ 7 ] ; xx [ 189 ] = xx [ 6 ] * ( xx [ 9 ] - xx
[ 177 ] ) ; xx [ 199 ] = xx [ 184 ] - xx [ 181 ] ; xx [ 184 ] = xx [ 6 ] * xx
[ 199 ] ; xx [ 200 ] = xx [ 9 ] + xx [ 177 ] ; xx [ 9 ] = xx [ 200 ] * xx [ 6
] ; xx [ 177 ] = ( xx [ 181 ] + xx [ 183 ] * xx [ 183 ] ) * xx [ 6 ] - xx [ 7
] ; xx [ 201 ] = xx [ 176 ] ; xx [ 202 ] = xx [ 182 ] ; xx [ 203 ] = xx [ 185
] ; xx [ 204 ] = xx [ 187 ] ; xx [ 205 ] = xx [ 188 ] ; xx [ 206 ] = xx [ 189
] ; xx [ 207 ] = xx [ 184 ] ; xx [ 208 ] = xx [ 9 ] ; xx [ 209 ] = xx [ 177 ]
; xx [ 181 ] = xx [ 2 ] * state [ 12 ] ; xx [ 210 ] = xx [ 1 ] * sin ( xx [
181 ] ) ; xx [ 211 ] = xx [ 1 ] * cos ( xx [ 181 ] ) ; xx [ 181 ] = xx [ 210
] - xx [ 211 ] ; xx [ 212 ] = xx [ 181 ] * xx [ 181 ] ; xx [ 213 ] = xx [ 6 ]
* xx [ 212 ] - xx [ 7 ] ; xx [ 214 ] = xx [ 2 ] * state [ 14 ] ; xx [ 2 ] =
cos ( xx [ 214 ] ) ; xx [ 215 ] = xx [ 2 ] * xx [ 2 ] ; xx [ 216 ] = xx [ 6 ]
* xx [ 215 ] - xx [ 7 ] ; xx [ 217 ] = xx [ 129 ] * xx [ 216 ] ; xx [ 218 ] =
xx [ 217 ] * xx [ 216 ] ; xx [ 219 ] = sin ( xx [ 214 ] ) ; xx [ 214 ] = xx [
6 ] * xx [ 2 ] * xx [ 219 ] ; xx [ 220 ] = xx [ 129 ] * xx [ 214 ] ; xx [ 221
] = xx [ 220 ] * xx [ 214 ] ; xx [ 222 ] = xx [ 218 ] + xx [ 221 ] ; xx [ 223
] = xx [ 128 ] + xx [ 222 ] ; xx [ 224 ] = xx [ 220 ] * xx [ 216 ] ; xx [ 220
] = xx [ 217 ] * xx [ 214 ] ; xx [ 217 ] = xx [ 224 ] - xx [ 220 ] ; xx [ 225
] = xx [ 141 ] * xx [ 217 ] ; xx [ 226 ] = xx [ 225 ] + xx [ 144 ] * xx [ 217
] ; xx [ 227 ] = xx [ 221 ] + xx [ 218 ] ; xx [ 218 ] = xx [ 227 ] * xx [ 141
] ; xx [ 221 ] = xx [ 146 ] + xx [ 141 ] * xx [ 218 ] ; xx [ 228 ] = xx [ 221
] + xx [ 144 ] * xx [ 218 ] ; xx [ 229 ] = xx [ 128 ] + xx [ 227 ] ; xx [ 230
] = xx [ 218 ] + xx [ 229 ] * xx [ 144 ] ; xx [ 231 ] = xx [ 228 ] + xx [ 230
] * xx [ 144 ] ; ii [ 0 ] = factorSymmetricPosDef ( xx + 231 , 1 , xx + 232 )
; if ( ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint2' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 232 ] = xx [ 226 ] / xx [ 231 ] ; xx [ 233 ] = xx [
223 ] - xx [ 226 ] * xx [ 232 ] ; xx [ 234 ] = xx [ 210 ] + xx [ 211 ] ; xx [
210 ] = xx [ 234 ] * xx [ 181 ] ; xx [ 211 ] = xx [ 6 ] * xx [ 210 ] ; xx [
235 ] = xx [ 230 ] * xx [ 232 ] ; xx [ 236 ] = xx [ 217 ] - xx [ 235 ] ; xx [
237 ] = xx [ 233 ] * xx [ 213 ] + xx [ 211 ] * xx [ 236 ] ; xx [ 238 ] = xx [
220 ] - xx [ 224 ] ; xx [ 220 ] = xx [ 238 ] - xx [ 235 ] ; xx [ 224 ] = xx [
230 ] / xx [ 231 ] ; xx [ 235 ] = xx [ 229 ] - xx [ 230 ] * xx [ 224 ] ; xx [
239 ] = xx [ 213 ] * xx [ 220 ] + xx [ 211 ] * xx [ 235 ] ; xx [ 240 ] = xx [
213 ] * xx [ 237 ] + xx [ 211 ] * xx [ 239 ] ; xx [ 241 ] = xx [ 92 ] + xx [
240 ] ; xx [ 242 ] = ( xx [ 212 ] + xx [ 234 ] * xx [ 234 ] ) * xx [ 6 ] - xx
[ 7 ] ; xx [ 212 ] = xx [ 225 ] - xx [ 228 ] * xx [ 232 ] ; xx [ 243 ] = xx [
218 ] - xx [ 228 ] * xx [ 224 ] ; xx [ 244 ] = xx [ 242 ] * ( xx [ 212 ] * xx
[ 213 ] + xx [ 211 ] * xx [ 243 ] ) ; xx [ 245 ] = xx [ 234 ] * xx [ 144 ] ;
xx [ 246 ] = xx [ 245 ] * xx [ 181 ] ; xx [ 247 ] = xx [ 6 ] * xx [ 246 ] ;
xx [ 248 ] = xx [ 6 ] * xx [ 234 ] * xx [ 245 ] ; xx [ 245 ] = xx [ 168 ] -
xx [ 248 ] ; xx [ 168 ] = xx [ 213 ] * xx [ 236 ] - xx [ 211 ] * xx [ 233 ] ;
xx [ 233 ] = xx [ 235 ] * xx [ 213 ] - xx [ 211 ] * xx [ 220 ] ; xx [ 220 ] =
xx [ 168 ] * xx [ 213 ] + xx [ 233 ] * xx [ 211 ] ; xx [ 235 ] = xx [ 247 ] *
xx [ 240 ] + xx [ 245 ] * xx [ 220 ] ; xx [ 236 ] = xx [ 244 ] + xx [ 235 ] ;
xx [ 240 ] = xx [ 236 ] + xx [ 160 ] * xx [ 220 ] ; xx [ 249 ] = xx [ 228 ] /
xx [ 231 ] ; xx [ 250 ] = ( xx [ 243 ] * xx [ 213 ] - xx [ 211 ] * xx [ 212 ]
) * xx [ 242 ] ; xx [ 212 ] = xx [ 247 ] * xx [ 244 ] + xx [ 245 ] * xx [ 250
] ; xx [ 243 ] = xx [ 213 ] * xx [ 239 ] - xx [ 211 ] * xx [ 237 ] ; xx [ 237
] = xx [ 233 ] * xx [ 213 ] - xx [ 168 ] * xx [ 211 ] ; xx [ 168 ] = xx [ 243
] * xx [ 247 ] + xx [ 237 ] * xx [ 245 ] ; xx [ 233 ] = xx [ 172 ] + ( xx [
221 ] - xx [ 228 ] * xx [ 249 ] ) * xx [ 242 ] * xx [ 242 ] + xx [ 212 ] + xx
[ 212 ] + xx [ 168 ] * xx [ 245 ] + xx [ 235 ] * xx [ 247 ] ; xx [ 212 ] = xx
[ 250 ] + xx [ 168 ] ; xx [ 168 ] = xx [ 233 ] + xx [ 212 ] * xx [ 160 ] ; xx
[ 221 ] = xx [ 92 ] + xx [ 237 ] ; xx [ 235 ] = xx [ 212 ] + xx [ 221 ] * xx
[ 160 ] ; xx [ 237 ] = xx [ 168 ] + xx [ 235 ] * xx [ 160 ] ; ii [ 0 ] =
factorSymmetricPosDef ( xx + 237 , 1 , xx + 239 ) ; if ( ii [ 0 ] != 0 ) {
return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 239 ] = xx [ 240 ] / xx [ 237 ] ; xx [ 244 ] = xx [
241 ] - xx [ 240 ] * xx [ 239 ] ; xx [ 250 ] = xx [ 235 ] * xx [ 239 ] ; xx [
251 ] = xx [ 220 ] - xx [ 250 ] ; xx [ 252 ] = xx [ 243 ] - xx [ 250 ] ; xx [
250 ] = xx [ 235 ] / xx [ 237 ] ; xx [ 253 ] = xx [ 221 ] - xx [ 235 ] * xx [
250 ] ; xx [ 254 ] = ( xx [ 215 ] + xx [ 219 ] * xx [ 219 ] ) * xx [ 6 ] - xx
[ 7 ] ; xx [ 215 ] = xx [ 129 ] * xx [ 254 ] * xx [ 254 ] ; xx [ 254 ] = xx [
128 ] + xx [ 215 ] ; xx [ 128 ] = xx [ 254 ] * xx [ 242 ] * xx [ 242 ] ; xx [
255 ] = xx [ 92 ] + xx [ 128 ] ; xx [ 256 ] = xx [ 244 ] * xx [ 176 ] + xx [
182 ] * xx [ 251 ] ; xx [ 257 ] = xx [ 187 ] * xx [ 244 ] + xx [ 188 ] * xx [
251 ] ; xx [ 258 ] = xx [ 184 ] * xx [ 244 ] + xx [ 9 ] * xx [ 251 ] ; xx [
259 ] = xx [ 252 ] * xx [ 176 ] + xx [ 182 ] * xx [ 253 ] ; xx [ 260 ] = xx [
187 ] * xx [ 252 ] + xx [ 253 ] * xx [ 188 ] ; xx [ 261 ] = xx [ 184 ] * xx [
252 ] + xx [ 9 ] * xx [ 253 ] ; xx [ 262 ] = xx [ 255 ] * xx [ 185 ] ; xx [
263 ] = xx [ 255 ] * xx [ 189 ] ; xx [ 264 ] = xx [ 255 ] * xx [ 177 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 201 , xx + 256 , xx + 265 ) ; xx [ 92 ] =
xx [ 67 ] + xx [ 101 ] + xx [ 190 ] + xx [ 170 ] + xx [ 265 ] ; xx [ 244 ] =
0.03010502338364002 ; xx [ 251 ] = 0.03007944796046594 ; xx [ 252 ] = xx [
251 ] * xx [ 135 ] ; xx [ 253 ] = xx [ 147 ] * xx [ 251 ] ; xx [ 147 ] = xx [
252 ] + xx [ 144 ] * xx [ 253 ] ; xx [ 256 ] = xx [ 251 ] * xx [ 134 ] ; xx [
257 ] = xx [ 147 ] * xx [ 152 ] - xx [ 256 ] ; xx [ 258 ] = xx [ 147 ] * xx [
142 ] - xx [ 253 ] ; xx [ 259 ] = xx [ 257 ] * xx [ 127 ] + xx [ 125 ] * xx [
258 ] ; xx [ 260 ] = xx [ 139 ] * xx [ 251 ] ; xx [ 139 ] = xx [ 251 ] * xx [
143 ] ; xx [ 261 ] = xx [ 251 ] * xx [ 158 ] ; xx [ 262 ] = xx [ 139 ] + xx [
144 ] * xx [ 261 ] ; xx [ 263 ] = xx [ 260 ] - xx [ 262 ] * xx [ 152 ] ; xx [
264 ] = xx [ 261 ] - xx [ 262 ] * xx [ 142 ] ; xx [ 274 ] = xx [ 263 ] * xx [
127 ] + xx [ 125 ] * xx [ 264 ] ; xx [ 275 ] = xx [ 127 ] * xx [ 259 ] + xx [
125 ] * xx [ 274 ] ; xx [ 276 ] = xx [ 147 ] / xx [ 151 ] ; xx [ 277 ] = xx [
148 ] * xx [ 276 ] ; xx [ 278 ] = ( xx [ 277 ] - xx [ 252 ] ) * xx [ 162 ] ;
xx [ 252 ] = xx [ 262 ] / xx [ 151 ] ; xx [ 279 ] = xx [ 148 ] * xx [ 252 ] ;
xx [ 280 ] = xx [ 162 ] * ( xx [ 139 ] - xx [ 279 ] ) ; xx [ 139 ] = xx [ 258
] * xx [ 127 ] - xx [ 125 ] * xx [ 257 ] ; xx [ 257 ] = xx [ 264 ] * xx [ 127
] - xx [ 125 ] * xx [ 263 ] ; xx [ 258 ] = xx [ 139 ] * xx [ 127 ] + xx [ 257
] * xx [ 125 ] ; xx [ 263 ] = xx [ 167 ] * xx [ 275 ] + xx [ 165 ] * xx [ 258
] ; xx [ 264 ] = xx [ 278 ] * xx [ 127 ] + xx [ 125 ] * xx [ 280 ] + xx [ 263
] ; xx [ 281 ] = xx [ 264 ] + xx [ 160 ] * xx [ 258 ] ; xx [ 282 ] = xx [ 275
] - xx [ 281 ] * xx [ 164 ] ; xx [ 283 ] = xx [ 258 ] - xx [ 281 ] * xx [ 174
] ; xx [ 284 ] = xx [ 141 ] * xx [ 132 ] ; xx [ 132 ] = xx [ 284 ] * xx [ 162
] ; xx [ 285 ] = xx [ 125 ] * xx [ 132 ] ; xx [ 286 ] = xx [ 167 ] * xx [ 179
] ; xx [ 287 ] = xx [ 285 ] + xx [ 286 ] ; xx [ 288 ] = xx [ 127 ] * xx [ 274
] - xx [ 125 ] * xx [ 259 ] ; xx [ 259 ] = xx [ 257 ] * xx [ 127 ] - xx [ 139
] * xx [ 125 ] ; xx [ 139 ] = xx [ 288 ] * xx [ 167 ] + xx [ 259 ] * xx [ 165
] ; xx [ 257 ] = xx [ 280 ] * xx [ 127 ] - xx [ 125 ] * xx [ 278 ] + xx [ 139
] ; xx [ 274 ] = xx [ 257 ] + xx [ 259 ] * xx [ 160 ] ; xx [ 278 ] = xx [ 288
] - xx [ 274 ] * xx [ 164 ] ; xx [ 280 ] = xx [ 259 ] - xx [ 274 ] * xx [ 174
] ; xx [ 289 ] = xx [ 132 ] * xx [ 127 ] ; xx [ 132 ] = xx [ 165 ] * xx [ 179
] ; xx [ 179 ] = xx [ 289 ] + xx [ 132 ] ; xx [ 290 ] = xx [ 156 ] - xx [ 138
] * xx [ 164 ] ; xx [ 291 ] = xx [ 126 ] - xx [ 138 ] * xx [ 174 ] ; xx [ 292
] = xx [ 94 ] * xx [ 282 ] + xx [ 93 ] * xx [ 283 ] - xx [ 98 ] * xx [ 287 ]
; xx [ 293 ] = xx [ 100 ] * xx [ 282 ] + xx [ 110 ] * xx [ 283 ] - xx [ 111 ]
* xx [ 287 ] ; xx [ 294 ] = xx [ 97 ] * xx [ 282 ] + xx [ 61 ] * xx [ 283 ] -
xx [ 95 ] * xx [ 287 ] ; xx [ 295 ] = xx [ 278 ] * xx [ 94 ] + xx [ 93 ] * xx
[ 280 ] - xx [ 179 ] * xx [ 98 ] ; xx [ 296 ] = xx [ 100 ] * xx [ 278 ] + xx
[ 280 ] * xx [ 110 ] - xx [ 179 ] * xx [ 111 ] ; xx [ 297 ] = xx [ 97 ] * xx
[ 278 ] + xx [ 61 ] * xx [ 280 ] - xx [ 179 ] * xx [ 95 ] ; xx [ 298 ] = xx [
290 ] * xx [ 94 ] + xx [ 93 ] * xx [ 291 ] ; xx [ 299 ] = xx [ 100 ] * xx [
290 ] + xx [ 291 ] * xx [ 110 ] ; xx [ 300 ] = xx [ 97 ] * xx [ 290 ] + xx [
61 ] * xx [ 291 ] ; pm_math_Matrix3x3_compose_ra ( xx + 114 , xx + 292 , xx +
301 ) ; xx [ 93 ] = 0.175 ; xx [ 94 ] = xx [ 160 ] * xx [ 28 ] ; xx [ 95 ] =
xx [ 94 ] * xx [ 28 ] ; xx [ 98 ] = xx [ 96 ] * xx [ 160 ] ; xx [ 111 ] = xx
[ 96 ] * xx [ 98 ] ; xx [ 278 ] = 0.02318121863740014 ; xx [ 280 ] = xx [ 98
] * xx [ 28 ] ; xx [ 282 ] = ( xx [ 280 ] + xx [ 62 ] * xx [ 94 ] ) * xx [ 6
] ; xx [ 94 ] = 0.06593894011863007 ; xx [ 283 ] = xx [ 6 ] * ( xx [ 95 ] -
xx [ 62 ] * xx [ 98 ] ) ; xx [ 290 ] = xx [ 93 ] - ( ( xx [ 95 ] + xx [ 111 ]
) * xx [ 6 ] - xx [ 160 ] ) ; xx [ 291 ] = xx [ 278 ] + xx [ 282 ] ; xx [ 292
] = - ( xx [ 94 ] + xx [ 283 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 190
, xx + 290 , xx + 310 ) ; xx [ 95 ] = 2.887984947699861e-3 ; xx [ 98 ] = xx [
95 ] * xx [ 40 ] ; xx [ 190 ] = xx [ 98 ] * xx [ 46 ] ; xx [ 293 ] = 0.085075
; xx [ 294 ] = xx [ 293 ] * xx [ 10 ] ; xx [ 295 ] = xx [ 294 ] * xx [ 10 ] ;
xx [ 296 ] = xx [ 39 ] * xx [ 293 ] ; xx [ 297 ] = xx [ 39 ] * xx [ 296 ] ;
xx [ 298 ] = 0.04846143235075162 ; xx [ 299 ] = xx [ 296 ] * xx [ 10 ] ; xx [
300 ] = ( xx [ 299 ] + xx [ 22 ] * xx [ 294 ] ) * xx [ 6 ] ; xx [ 294 ] =
0.03147761383263407 ; xx [ 319 ] = xx [ 6 ] * ( xx [ 295 ] - xx [ 22 ] * xx [
296 ] ) ; xx [ 320 ] = - ( xx [ 93 ] + ( xx [ 295 ] + xx [ 297 ] ) * xx [ 6 ]
- xx [ 293 ] ) ; xx [ 321 ] = - ( xx [ 298 ] + xx [ 300 ] ) ; xx [ 322 ] = -
( xx [ 294 ] + xx [ 319 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 67 , xx +
320 , xx + 323 ) ; xx [ 67 ] = xx [ 95 ] * xx [ 65 ] ; xx [ 295 ] = xx [ 67 ]
* xx [ 80 ] ; xx [ 296 ] = xx [ 293 ] * xx [ 58 ] ; xx [ 332 ] = xx [ 296 ] *
xx [ 58 ] ; xx [ 333 ] = xx [ 64 ] * xx [ 293 ] ; xx [ 334 ] = xx [ 64 ] * xx
[ 333 ] ; xx [ 335 ] = xx [ 333 ] * xx [ 58 ] ; xx [ 336 ] = ( xx [ 335 ] +
xx [ 59 ] * xx [ 296 ] ) * xx [ 6 ] ; xx [ 296 ] = xx [ 6 ] * ( xx [ 332 ] -
xx [ 59 ] * xx [ 333 ] ) ; xx [ 337 ] = xx [ 93 ] - ( ( xx [ 332 ] + xx [ 334
] ) * xx [ 6 ] - xx [ 293 ] ) ; xx [ 338 ] = - ( xx [ 298 ] + xx [ 336 ] ) ;
xx [ 339 ] = - ( xx [ 294 ] + xx [ 296 ] ) ; pm_math_Matrix3x3_postCross_ra (
xx + 101 , xx + 337 , xx + 340 ) ; xx [ 101 ] = xx [ 251 ] * xx [ 217 ] ; xx
[ 294 ] = xx [ 251 ] * xx [ 218 ] ; xx [ 298 ] = xx [ 227 ] * xx [ 251 ] ; xx
[ 227 ] = xx [ 294 ] + xx [ 144 ] * xx [ 298 ] ; xx [ 332 ] = xx [ 101 ] - xx
[ 227 ] * xx [ 232 ] ; xx [ 333 ] = xx [ 298 ] - xx [ 227 ] * xx [ 224 ] ; xx
[ 349 ] = xx [ 332 ] * xx [ 213 ] + xx [ 211 ] * xx [ 333 ] ; xx [ 350 ] = xx
[ 251 ] * xx [ 225 ] ; xx [ 351 ] = xx [ 251 ] * xx [ 238 ] ; xx [ 352 ] = xx
[ 350 ] + xx [ 144 ] * xx [ 351 ] ; xx [ 353 ] = xx [ 222 ] * xx [ 251 ] ; xx
[ 222 ] = xx [ 352 ] * xx [ 232 ] - xx [ 353 ] ; xx [ 354 ] = xx [ 352 ] * xx
[ 224 ] - xx [ 351 ] ; xx [ 355 ] = xx [ 213 ] * xx [ 222 ] + xx [ 211 ] * xx
[ 354 ] ; xx [ 356 ] = xx [ 213 ] * xx [ 349 ] + xx [ 211 ] * xx [ 355 ] ; xx
[ 357 ] = xx [ 227 ] / xx [ 231 ] ; xx [ 358 ] = xx [ 228 ] * xx [ 357 ] ; xx
[ 359 ] = ( xx [ 294 ] - xx [ 358 ] ) * xx [ 242 ] ; xx [ 294 ] = xx [ 352 ]
/ xx [ 231 ] ; xx [ 360 ] = xx [ 228 ] * xx [ 294 ] ; xx [ 361 ] = xx [ 242 ]
* ( xx [ 360 ] - xx [ 350 ] ) ; xx [ 350 ] = xx [ 333 ] * xx [ 213 ] - xx [
211 ] * xx [ 332 ] ; xx [ 332 ] = xx [ 213 ] * xx [ 354 ] - xx [ 211 ] * xx [
222 ] ; xx [ 222 ] = xx [ 350 ] * xx [ 213 ] + xx [ 332 ] * xx [ 211 ] ; xx [
333 ] = xx [ 247 ] * xx [ 356 ] + xx [ 245 ] * xx [ 222 ] ; xx [ 354 ] = xx [
359 ] * xx [ 213 ] + xx [ 211 ] * xx [ 361 ] + xx [ 333 ] ; xx [ 362 ] = xx [
354 ] + xx [ 160 ] * xx [ 222 ] ; xx [ 363 ] = xx [ 356 ] - xx [ 362 ] * xx [
239 ] ; xx [ 364 ] = xx [ 222 ] - xx [ 362 ] * xx [ 250 ] ; xx [ 365 ] = xx [
141 ] * xx [ 215 ] ; xx [ 215 ] = xx [ 365 ] * xx [ 242 ] ; xx [ 366 ] = xx [
211 ] * xx [ 215 ] ; xx [ 367 ] = xx [ 247 ] * xx [ 128 ] ; xx [ 368 ] = xx [
366 ] + xx [ 367 ] ; xx [ 369 ] = xx [ 213 ] * xx [ 355 ] - xx [ 211 ] * xx [
349 ] ; xx [ 349 ] = xx [ 332 ] * xx [ 213 ] - xx [ 350 ] * xx [ 211 ] ; xx [
332 ] = xx [ 369 ] * xx [ 247 ] + xx [ 349 ] * xx [ 245 ] ; xx [ 350 ] = xx [
361 ] * xx [ 213 ] - xx [ 211 ] * xx [ 359 ] + xx [ 332 ] ; xx [ 355 ] = xx [
350 ] + xx [ 349 ] * xx [ 160 ] ; xx [ 359 ] = xx [ 369 ] - xx [ 355 ] * xx [
239 ] ; xx [ 361 ] = xx [ 349 ] - xx [ 355 ] * xx [ 250 ] ; xx [ 370 ] = xx [
215 ] * xx [ 213 ] ; xx [ 215 ] = xx [ 245 ] * xx [ 128 ] ; xx [ 128 ] = xx [
370 ] + xx [ 215 ] ; xx [ 371 ] = xx [ 236 ] - xx [ 168 ] * xx [ 239 ] ; xx [
372 ] = xx [ 212 ] - xx [ 168 ] * xx [ 250 ] ; xx [ 373 ] = xx [ 176 ] * xx [
363 ] + xx [ 182 ] * xx [ 364 ] - xx [ 185 ] * xx [ 368 ] ; xx [ 374 ] = xx [
187 ] * xx [ 363 ] + xx [ 188 ] * xx [ 364 ] - xx [ 189 ] * xx [ 368 ] ; xx [
375 ] = xx [ 184 ] * xx [ 363 ] + xx [ 9 ] * xx [ 364 ] - xx [ 177 ] * xx [
368 ] ; xx [ 376 ] = xx [ 359 ] * xx [ 176 ] + xx [ 182 ] * xx [ 361 ] - xx [
128 ] * xx [ 185 ] ; xx [ 377 ] = xx [ 187 ] * xx [ 359 ] + xx [ 361 ] * xx [
188 ] - xx [ 128 ] * xx [ 189 ] ; xx [ 378 ] = xx [ 184 ] * xx [ 359 ] + xx [
9 ] * xx [ 361 ] - xx [ 128 ] * xx [ 177 ] ; xx [ 379 ] = xx [ 371 ] * xx [
176 ] + xx [ 182 ] * xx [ 372 ] ; xx [ 380 ] = xx [ 187 ] * xx [ 371 ] + xx [
372 ] * xx [ 188 ] ; xx [ 381 ] = xx [ 184 ] * xx [ 371 ] + xx [ 9 ] * xx [
372 ] ; pm_math_Matrix3x3_compose_ra ( xx + 201 , xx + 373 , xx + 382 ) ; xx
[ 176 ] = xx [ 160 ] * xx [ 175 ] ; xx [ 177 ] = xx [ 176 ] * xx [ 175 ] ; xx
[ 182 ] = xx [ 183 ] * xx [ 160 ] ; xx [ 185 ] = xx [ 183 ] * xx [ 182 ] ; xx
[ 189 ] = xx [ 182 ] * xx [ 175 ] ; xx [ 359 ] = ( xx [ 189 ] + xx [ 23 ] *
xx [ 176 ] ) * xx [ 6 ] ; xx [ 176 ] = xx [ 6 ] * ( xx [ 177 ] - xx [ 23 ] *
xx [ 182 ] ) ; xx [ 371 ] = - ( xx [ 93 ] + ( xx [ 177 ] + xx [ 185 ] ) * xx
[ 6 ] - xx [ 160 ] ) ; xx [ 372 ] = xx [ 278 ] + xx [ 359 ] ; xx [ 373 ] = -
( xx [ 94 ] + xx [ 176 ] ) ; pm_math_Matrix3x3_postCross_ra ( xx + 265 , xx +
371 , xx + 391 ) ; xx [ 93 ] = xx [ 304 ] - xx [ 311 ] - ( xx [ 190 ] + xx [
324 ] + xx [ 295 ] + xx [ 341 ] ) + xx [ 385 ] - xx [ 392 ] ; xx [ 94 ] = xx
[ 98 ] * xx [ 25 ] ; xx [ 177 ] = xx [ 67 ] * xx [ 60 ] ; xx [ 182 ] = xx [
307 ] - xx [ 312 ] - ( xx [ 94 ] + xx [ 325 ] + xx [ 177 ] + xx [ 342 ] ) +
xx [ 388 ] - xx [ 393 ] ; xx [ 265 ] = xx [ 92 ] * xx [ 244 ] - ( xx [ 93 ] *
xx [ 21 ] + xx [ 182 ] * xx [ 24 ] ) ; xx [ 278 ] = 5.062499999999979e-6 ; xx
[ 361 ] = 3.28230253125e-4 ; xx [ 363 ] = 2.456953194255657e-4 ; xx [ 400 ] =
xx [ 278 ] * xx [ 38 ] ; xx [ 401 ] = - ( xx [ 278 ] * xx [ 44 ] ) ; xx [ 402
] = xx [ 278 ] * xx [ 41 ] ; xx [ 403 ] = xx [ 361 ] * xx [ 40 ] ; xx [ 404 ]
= xx [ 361 ] * xx [ 45 ] ; xx [ 405 ] = - ( xx [ 361 ] * xx [ 48 ] ) ; xx [
406 ] = xx [ 363 ] * xx [ 42 ] ; xx [ 407 ] = xx [ 363 ] * xx [ 46 ] ; xx [
408 ] = xx [ 363 ] * xx [ 25 ] ; pm_math_Matrix3x3_compose_ra ( xx + 49 , xx
+ 400 , xx + 409 ) ; xx [ 38 ] = xx [ 42 ] * xx [ 98 ] ; xx [ 40 ] = xx [ 95
] * xx [ 45 ] ; xx [ 41 ] = xx [ 42 ] * xx [ 40 ] ; xx [ 44 ] = xx [ 95 ] *
xx [ 48 ] ; xx [ 45 ] = xx [ 42 ] * xx [ 44 ] ; xx [ 42 ] = xx [ 40 ] * xx [
46 ] ; xx [ 48 ] = xx [ 44 ] * xx [ 46 ] ; xx [ 46 ] = xx [ 40 ] * xx [ 25 ]
; xx [ 40 ] = xx [ 44 ] * xx [ 25 ] ; xx [ 49 ] = - xx [ 38 ] ; xx [ 50 ] = -
xx [ 41 ] ; xx [ 51 ] = xx [ 45 ] ; xx [ 52 ] = - xx [ 190 ] ; xx [ 53 ] = -
xx [ 42 ] ; xx [ 54 ] = xx [ 48 ] ; xx [ 55 ] = - xx [ 94 ] ; xx [ 56 ] = -
xx [ 46 ] ; xx [ 57 ] = xx [ 40 ] ; pm_math_Matrix3x3_postCross_ra ( xx + 49
, xx + 320 , xx + 400 ) ; pm_math_Matrix3x3_preCross_ra ( xx + 323 , xx + 320
, xx + 49 ) ; xx [ 418 ] = xx [ 278 ] * xx [ 63 ] ; xx [ 419 ] = - ( xx [ 278
] * xx [ 78 ] ) ; xx [ 420 ] = xx [ 278 ] * xx [ 66 ] ; xx [ 421 ] = xx [ 361
] * xx [ 65 ] ; xx [ 422 ] = xx [ 361 ] * xx [ 79 ] ; xx [ 423 ] = - ( xx [
361 ] * xx [ 82 ] ) ; xx [ 424 ] = xx [ 363 ] * xx [ 76 ] ; xx [ 425 ] = xx [
363 ] * xx [ 80 ] ; xx [ 426 ] = xx [ 363 ] * xx [ 60 ] ;
pm_math_Matrix3x3_compose_ra ( xx + 83 , xx + 418 , xx + 427 ) ; xx [ 25 ] =
xx [ 76 ] * xx [ 67 ] ; xx [ 44 ] = xx [ 95 ] * xx [ 79 ] ; xx [ 63 ] = xx [
76 ] * xx [ 44 ] ; xx [ 65 ] = xx [ 95 ] * xx [ 82 ] ; xx [ 66 ] = xx [ 76 ]
* xx [ 65 ] ; xx [ 67 ] = xx [ 44 ] * xx [ 80 ] ; xx [ 76 ] = xx [ 65 ] * xx
[ 80 ] ; xx [ 78 ] = xx [ 44 ] * xx [ 60 ] ; xx [ 44 ] = xx [ 65 ] * xx [ 60
] ; xx [ 82 ] = - xx [ 25 ] ; xx [ 83 ] = - xx [ 63 ] ; xx [ 84 ] = xx [ 66 ]
; xx [ 85 ] = - xx [ 295 ] ; xx [ 86 ] = - xx [ 67 ] ; xx [ 87 ] = xx [ 76 ]
; xx [ 88 ] = - xx [ 177 ] ; xx [ 89 ] = - xx [ 78 ] ; xx [ 90 ] = xx [ 44 ]
; pm_math_Matrix3x3_postCross_ra ( xx + 82 , xx + 337 , xx + 418 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 340 , xx + 337 , xx + 82 ) ; xx [ 60 ] =
5.429019142918786e-6 ; xx [ 65 ] = 1.049151914291881e-5 ; xx [ 79 ] =
1.978272748043166e-3 ; xx [ 80 ] = xx [ 79 ] * xx [ 133 ] ; xx [ 91 ] = xx [
80 ] * xx [ 133 ] ; xx [ 94 ] = xx [ 79 ] * xx [ 130 ] ; xx [ 95 ] = xx [ 94
] * xx [ 130 ] ; xx [ 98 ] = xx [ 65 ] + xx [ 91 ] + xx [ 95 ] + xx [ 251 ] *
xx [ 253 ] ; xx [ 177 ] = xx [ 98 ] - xx [ 147 ] * xx [ 276 ] ; xx [ 190 ] =
xx [ 94 ] * xx [ 133 ] ; xx [ 94 ] = xx [ 80 ] * xx [ 130 ] ; xx [ 80 ] = xx
[ 190 ] - xx [ 94 ] - xx [ 251 ] * xx [ 261 ] ; xx [ 130 ] = xx [ 262 ] * xx
[ 276 ] ; xx [ 133 ] = xx [ 80 ] + xx [ 130 ] ; xx [ 295 ] = xx [ 177 ] * xx
[ 127 ] + xx [ 133 ] * xx [ 125 ] ; xx [ 324 ] = xx [ 94 ] - xx [ 190 ] - xx
[ 251 ] * xx [ 256 ] ; xx [ 94 ] = xx [ 324 ] + xx [ 130 ] ; xx [ 130 ] =
1.0493175500148e-3 ; xx [ 190 ] = xx [ 130 ] + xx [ 95 ] + xx [ 91 ] + xx [
251 ] * xx [ 260 ] + xx [ 141 ] * xx [ 284 ] ; xx [ 91 ] = xx [ 190 ] - xx [
262 ] * xx [ 252 ] ; xx [ 95 ] = xx [ 94 ] * xx [ 127 ] + xx [ 125 ] * xx [
91 ] ; xx [ 325 ] = xx [ 167 ] * xx [ 285 ] ; xx [ 341 ] = xx [ 60 ] + xx [
127 ] * xx [ 295 ] + xx [ 125 ] * xx [ 95 ] + xx [ 325 ] + xx [ 325 ] + xx [
167 ] * xx [ 286 ] ; xx [ 325 ] = xx [ 281 ] / xx [ 157 ] ; xx [ 342 ] = xx [
133 ] * xx [ 127 ] - xx [ 125 ] * xx [ 177 ] ; xx [ 133 ] = xx [ 91 ] * xx [
127 ] - xx [ 94 ] * xx [ 125 ] ; xx [ 91 ] = xx [ 165 ] * xx [ 285 ] ; xx [
94 ] = xx [ 167 ] * xx [ 289 ] ; xx [ 177 ] = xx [ 342 ] * xx [ 127 ] + xx [
133 ] * xx [ 125 ] + xx [ 91 ] + xx [ 94 ] + xx [ 132 ] * xx [ 167 ] ; xx [
285 ] = xx [ 274 ] * xx [ 325 ] ; xx [ 363 ] = xx [ 138 ] * xx [ 325 ] ; xx [
364 ] = xx [ 95 ] * xx [ 127 ] - xx [ 125 ] * xx [ 295 ] + xx [ 94 ] + xx [
91 ] + xx [ 165 ] * xx [ 286 ] ; xx [ 91 ] = 3.489909396502681e-4 ; xx [ 94 ]
= xx [ 165 ] * xx [ 289 ] ; xx [ 95 ] = xx [ 91 ] + xx [ 133 ] * xx [ 127 ] -
xx [ 342 ] * xx [ 125 ] + xx [ 94 ] + xx [ 94 ] + xx [ 165 ] * xx [ 132 ] ;
xx [ 94 ] = xx [ 274 ] / xx [ 157 ] ; xx [ 132 ] = xx [ 138 ] * xx [ 94 ] ;
xx [ 133 ] = xx [ 141 ] * xx [ 253 ] ; xx [ 286 ] = xx [ 277 ] - xx [ 133 ] ;
xx [ 277 ] = xx [ 141 ] * xx [ 261 ] ; xx [ 289 ] = xx [ 277 ] - xx [ 279 ] ;
xx [ 279 ] = xx [ 162 ] * ( xx [ 286 ] * xx [ 127 ] + xx [ 125 ] * xx [ 289 ]
) + xx [ 263 ] ; xx [ 263 ] = ( xx [ 289 ] * xx [ 127 ] - xx [ 125 ] * xx [
286 ] ) * xx [ 162 ] + xx [ 139 ] ; xx [ 139 ] = xx [ 138 ] / xx [ 157 ] ; xx
[ 436 ] = xx [ 341 ] - xx [ 281 ] * xx [ 325 ] ; xx [ 437 ] = xx [ 177 ] - xx
[ 285 ] ; xx [ 438 ] = xx [ 264 ] - xx [ 363 ] ; xx [ 439 ] = xx [ 364 ] - xx
[ 285 ] ; xx [ 440 ] = xx [ 95 ] - xx [ 274 ] * xx [ 94 ] ; xx [ 441 ] = xx [
257 ] - xx [ 132 ] ; xx [ 442 ] = xx [ 279 ] - xx [ 363 ] ; xx [ 443 ] = xx [
263 ] - xx [ 132 ] ; xx [ 444 ] = xx [ 159 ] - xx [ 138 ] * xx [ 139 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 436 , xx + 114 , xx + 445 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 114 , xx + 445 , xx + 436 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 301 , xx + 290 , xx + 114 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 310 , xx + 290 , xx + 445 ) ; xx [ 132 ]
= 0.1028383952748681 ; xx [ 159 ] = xx [ 79 ] * xx [ 216 ] ; xx [ 162 ] = xx
[ 159 ] * xx [ 216 ] ; xx [ 257 ] = xx [ 79 ] * xx [ 214 ] ; xx [ 264 ] = xx
[ 257 ] * xx [ 214 ] ; xx [ 285 ] = xx [ 65 ] + xx [ 162 ] + xx [ 264 ] + xx
[ 251 ] * xx [ 298 ] ; xx [ 286 ] = xx [ 285 ] - xx [ 227 ] * xx [ 357 ] ; xx
[ 289 ] = xx [ 257 ] * xx [ 216 ] ; xx [ 216 ] = xx [ 159 ] * xx [ 214 ] ; xx
[ 159 ] = xx [ 289 ] - xx [ 216 ] - xx [ 251 ] * xx [ 351 ] ; xx [ 214 ] = xx
[ 352 ] * xx [ 357 ] ; xx [ 257 ] = xx [ 159 ] + xx [ 214 ] ; xx [ 295 ] = xx
[ 286 ] * xx [ 213 ] + xx [ 257 ] * xx [ 211 ] ; xx [ 304 ] = xx [ 216 ] - xx
[ 289 ] - xx [ 251 ] * xx [ 101 ] ; xx [ 216 ] = xx [ 304 ] + xx [ 214 ] ; xx
[ 214 ] = xx [ 130 ] + xx [ 264 ] + xx [ 162 ] + xx [ 251 ] * xx [ 353 ] + xx
[ 141 ] * xx [ 365 ] ; xx [ 162 ] = xx [ 214 ] - xx [ 352 ] * xx [ 294 ] ; xx
[ 264 ] = xx [ 216 ] * xx [ 213 ] + xx [ 211 ] * xx [ 162 ] ; xx [ 289 ] = xx
[ 247 ] * xx [ 366 ] ; xx [ 307 ] = xx [ 60 ] + xx [ 213 ] * xx [ 295 ] + xx
[ 211 ] * xx [ 264 ] + xx [ 289 ] + xx [ 289 ] + xx [ 247 ] * xx [ 367 ] ; xx
[ 289 ] = xx [ 362 ] / xx [ 237 ] ; xx [ 311 ] = xx [ 257 ] * xx [ 213 ] - xx
[ 211 ] * xx [ 286 ] ; xx [ 257 ] = xx [ 162 ] * xx [ 213 ] - xx [ 216 ] * xx
[ 211 ] ; xx [ 162 ] = xx [ 245 ] * xx [ 366 ] ; xx [ 216 ] = xx [ 247 ] * xx
[ 370 ] ; xx [ 286 ] = xx [ 311 ] * xx [ 213 ] + xx [ 257 ] * xx [ 211 ] + xx
[ 162 ] + xx [ 216 ] + xx [ 215 ] * xx [ 247 ] ; xx [ 312 ] = xx [ 355 ] * xx
[ 289 ] ; xx [ 342 ] = xx [ 168 ] * xx [ 289 ] ; xx [ 363 ] = xx [ 264 ] * xx
[ 213 ] - xx [ 211 ] * xx [ 295 ] + xx [ 216 ] + xx [ 162 ] + xx [ 245 ] * xx
[ 367 ] ; xx [ 162 ] = xx [ 245 ] * xx [ 370 ] ; xx [ 216 ] = xx [ 91 ] + xx
[ 257 ] * xx [ 213 ] - xx [ 311 ] * xx [ 211 ] + xx [ 162 ] + xx [ 162 ] + xx
[ 245 ] * xx [ 215 ] ; xx [ 162 ] = xx [ 355 ] / xx [ 237 ] ; xx [ 215 ] = xx
[ 168 ] * xx [ 162 ] ; xx [ 257 ] = xx [ 141 ] * xx [ 298 ] ; xx [ 264 ] = xx
[ 257 ] - xx [ 358 ] ; xx [ 295 ] = xx [ 141 ] * xx [ 351 ] ; xx [ 311 ] = xx
[ 360 ] - xx [ 295 ] ; xx [ 358 ] = xx [ 242 ] * ( xx [ 264 ] * xx [ 213 ] +
xx [ 211 ] * xx [ 311 ] ) + xx [ 333 ] ; xx [ 333 ] = ( xx [ 213 ] * xx [ 311
] - xx [ 211 ] * xx [ 264 ] ) * xx [ 242 ] + xx [ 332 ] ; xx [ 242 ] = xx [
168 ] / xx [ 237 ] ; xx [ 454 ] = xx [ 307 ] - xx [ 362 ] * xx [ 289 ] ; xx [
455 ] = xx [ 286 ] - xx [ 312 ] ; xx [ 456 ] = xx [ 354 ] - xx [ 342 ] ; xx [
457 ] = xx [ 363 ] - xx [ 312 ] ; xx [ 458 ] = xx [ 216 ] - xx [ 355 ] * xx [
162 ] ; xx [ 459 ] = xx [ 350 ] - xx [ 215 ] ; xx [ 460 ] = xx [ 358 ] - xx [
342 ] ; xx [ 461 ] = xx [ 333 ] - xx [ 215 ] ; xx [ 462 ] = xx [ 233 ] - xx [
168 ] * xx [ 242 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 454 , xx +
201 , xx + 463 ) ; pm_math_Matrix3x3_compose_ra ( xx + 201 , xx + 463 , xx +
454 ) ; pm_math_Matrix3x3_postCross_ra ( xx + 382 , xx + 371 , xx + 201 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 391 , xx + 371 , xx + 463 ) ; xx [ 215 ]
= xx [ 413 ] - xx [ 404 ] - xx [ 404 ] - xx [ 53 ] + xx [ 431 ] - xx [ 422 ]
- xx [ 422 ] - xx [ 86 ] + xx [ 440 ] - xx [ 118 ] - xx [ 118 ] - xx [ 449 ]
+ xx [ 132 ] + xx [ 458 ] - xx [ 205 ] - xx [ 205 ] - xx [ 467 ] ; xx [ 233 ]
= xx [ 414 ] - xx [ 405 ] - xx [ 407 ] - xx [ 54 ] + xx [ 432 ] - xx [ 423 ]
- xx [ 425 ] - xx [ 87 ] + xx [ 441 ] - xx [ 119 ] - xx [ 121 ] - xx [ 450 ]
+ xx [ 459 ] - xx [ 206 ] - xx [ 208 ] - xx [ 468 ] ; xx [ 264 ] = xx [ 93 ]
* xx [ 244 ] - ( xx [ 215 ] * xx [ 21 ] + xx [ 233 ] * xx [ 24 ] ) ; xx [ 311
] = xx [ 416 ] - xx [ 407 ] - xx [ 405 ] - xx [ 56 ] + xx [ 434 ] - xx [ 425
] - xx [ 423 ] - xx [ 89 ] + xx [ 443 ] - xx [ 121 ] - xx [ 119 ] - xx [ 452
] + xx [ 461 ] - xx [ 208 ] - xx [ 206 ] - xx [ 470 ] ; xx [ 312 ] =
0.1028074313979146 ; xx [ 332 ] = xx [ 417 ] - xx [ 408 ] - xx [ 408 ] - xx [
57 ] + xx [ 435 ] - xx [ 426 ] - xx [ 426 ] - xx [ 90 ] + xx [ 444 ] - xx [
122 ] - xx [ 122 ] - xx [ 453 ] + xx [ 312 ] + xx [ 462 ] - xx [ 209 ] - xx [
209 ] - xx [ 471 ] ; xx [ 342 ] = xx [ 182 ] * xx [ 244 ] - ( xx [ 311 ] * xx
[ 21 ] + xx [ 332 ] * xx [ 24 ] ) ; xx [ 350 ] = xx [ 265 ] * xx [ 244 ] - (
xx [ 264 ] * xx [ 21 ] + xx [ 342 ] * xx [ 24 ] ) ; ii [ 0 ] =
factorSymmetricPosDef ( xx + 350 , 1 , xx + 354 ) ; if ( ii [ 0 ] != 0 ) {
return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Roll' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 354 ] = xx [ 265 ] / xx [ 350 ] ; xx [ 360 ] = xx [ 68
] + xx [ 102 ] + xx [ 191 ] + xx [ 266 ] ; xx [ 68 ] = xx [ 70 ] + xx [ 104 ]
+ xx [ 193 ] + xx [ 268 ] ; xx [ 70 ] = xx [ 305 ] - xx [ 314 ] - ( xx [ 42 ]
+ xx [ 327 ] + xx [ 67 ] + xx [ 344 ] ) + xx [ 386 ] - xx [ 395 ] ; xx [ 42 ]
= xx [ 308 ] - xx [ 315 ] - ( xx [ 46 ] + xx [ 328 ] + xx [ 78 ] + xx [ 345 ]
) + xx [ 389 ] - xx [ 396 ] ; xx [ 46 ] = xx [ 68 ] * xx [ 244 ] - ( xx [ 70
] * xx [ 21 ] + xx [ 42 ] * xx [ 24 ] ) ; xx [ 67 ] = xx [ 46 ] * xx [ 354 ]
; xx [ 78 ] = xx [ 69 ] + xx [ 103 ] + xx [ 192 ] + xx [ 267 ] ; xx [ 69 ] =
xx [ 73 ] + xx [ 107 ] + xx [ 196 ] + xx [ 271 ] ; xx [ 73 ] = xx [ 48 ] - xx
[ 330 ] + xx [ 76 ] - xx [ 347 ] + xx [ 306 ] - xx [ 317 ] + xx [ 387 ] - xx
[ 398 ] ; xx [ 48 ] = xx [ 40 ] - xx [ 331 ] + xx [ 44 ] - xx [ 348 ] + xx [
309 ] - xx [ 318 ] + xx [ 390 ] - xx [ 399 ] ; xx [ 40 ] = xx [ 69 ] * xx [
244 ] - ( xx [ 73 ] * xx [ 21 ] + xx [ 48 ] * xx [ 24 ] ) ; xx [ 44 ] = xx [
40 ] * xx [ 354 ] ; xx [ 76 ] = xx [ 71 ] + xx [ 105 ] + xx [ 194 ] + xx [
170 ] + xx [ 269 ] ; xx [ 71 ] = xx [ 46 ] / xx [ 350 ] ; xx [ 102 ] = xx [
72 ] + xx [ 106 ] + xx [ 195 ] + xx [ 270 ] ; xx [ 72 ] = xx [ 40 ] * xx [ 71
] ; xx [ 103 ] = xx [ 74 ] + xx [ 108 ] + xx [ 197 ] + xx [ 272 ] ; xx [ 74 ]
= xx [ 75 ] + xx [ 109 ] + xx [ 198 ] + xx [ 170 ] + xx [ 273 ] ; xx [ 75 ] =
xx [ 40 ] / xx [ 350 ] ; xx [ 472 ] = xx [ 92 ] - xx [ 265 ] * xx [ 354 ] ;
xx [ 473 ] = xx [ 360 ] - xx [ 67 ] ; xx [ 474 ] = xx [ 78 ] - xx [ 44 ] ; xx
[ 475 ] = xx [ 68 ] - xx [ 67 ] ; xx [ 476 ] = xx [ 76 ] - xx [ 46 ] * xx [
71 ] ; xx [ 477 ] = xx [ 102 ] - xx [ 72 ] ; xx [ 478 ] = xx [ 69 ] - xx [ 44
] ; xx [ 479 ] = xx [ 103 ] - xx [ 72 ] ; xx [ 480 ] = xx [ 74 ] - xx [ 40 ]
* xx [ 75 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 472 , xx + 29 , xx
+ 481 ) ; pm_math_Matrix3x3_compose_ra ( xx + 29 , xx + 481 , xx + 472 ) ; xx
[ 44 ] = xx [ 301 ] - xx [ 310 ] - ( xx [ 38 ] + xx [ 323 ] + xx [ 25 ] + xx
[ 340 ] ) + xx [ 382 ] - xx [ 391 ] ; xx [ 25 ] = xx [ 410 ] - xx [ 401 ] -
xx [ 403 ] - xx [ 50 ] + xx [ 428 ] - xx [ 419 ] - xx [ 421 ] - xx [ 83 ] +
xx [ 437 ] - xx [ 115 ] - xx [ 117 ] - xx [ 446 ] + xx [ 455 ] - xx [ 202 ] -
xx [ 204 ] - xx [ 464 ] ; xx [ 38 ] = xx [ 411 ] - xx [ 402 ] - xx [ 406 ] -
xx [ 51 ] + xx [ 429 ] - xx [ 420 ] - xx [ 424 ] - xx [ 84 ] + xx [ 438 ] -
xx [ 116 ] - xx [ 120 ] - xx [ 447 ] + xx [ 456 ] - xx [ 203 ] - xx [ 207 ] -
xx [ 465 ] ; xx [ 67 ] = xx [ 44 ] * xx [ 244 ] - ( xx [ 25 ] * xx [ 21 ] +
xx [ 38 ] * xx [ 24 ] ) ; xx [ 72 ] = xx [ 302 ] - xx [ 313 ] - ( xx [ 41 ] +
xx [ 326 ] + xx [ 63 ] + xx [ 343 ] ) + xx [ 383 ] - xx [ 394 ] ; xx [ 41 ] =
xx [ 45 ] - xx [ 329 ] + xx [ 66 ] - xx [ 346 ] + xx [ 303 ] - xx [ 316 ] +
xx [ 384 ] - xx [ 397 ] ; xx [ 374 ] = xx [ 44 ] - xx [ 67 ] * xx [ 354 ] ;
xx [ 375 ] = xx [ 72 ] - xx [ 67 ] * xx [ 71 ] ; xx [ 376 ] = xx [ 41 ] - xx
[ 67 ] * xx [ 75 ] ; xx [ 377 ] = xx [ 93 ] - xx [ 264 ] * xx [ 354 ] ; xx [
378 ] = xx [ 70 ] - xx [ 264 ] * xx [ 71 ] ; xx [ 379 ] = xx [ 73 ] - xx [
264 ] * xx [ 75 ] ; xx [ 380 ] = xx [ 182 ] - xx [ 342 ] * xx [ 354 ] ; xx [
381 ] = xx [ 42 ] - xx [ 342 ] * xx [ 71 ] ; xx [ 382 ] = xx [ 48 ] - xx [
342 ] * xx [ 75 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 374 , xx +
29 , xx + 383 ) ; pm_math_Matrix3x3_compose_ra ( xx + 29 , xx + 383 , xx +
374 ) ; xx [ 45 ] = 9.889425053924039e-3 ; xx [ 63 ] = 0.0284344275538308 ;
xx [ 66 ] = xx [ 11 ] * xx [ 45 ] - xx [ 63 ] * xx [ 5 ] ; xx [ 104 ] = - xx
[ 5 ] ; xx [ 105 ] = xx [ 3 ] ; xx [ 106 ] = xx [ 104 ] ; xx [ 107 ] = xx [
11 ] ; xx [ 108 ] = xx [ 63 ] * xx [ 3 ] ; xx [ 109 ] = xx [ 45 ] * xx [ 3 ]
; xx [ 191 ] = xx [ 66 ] ; xx [ 192 ] = - xx [ 108 ] ; xx [ 193 ] = - xx [
109 ] ; pm_math_Vector3_cross_ra ( xx + 105 , xx + 191 , xx + 194 ) ; xx [
170 ] = ( xx [ 66 ] * xx [ 26 ] + xx [ 194 ] ) * xx [ 6 ] ; xx [ 66 ] = xx [
63 ] + ( xx [ 196 ] - xx [ 109 ] * xx [ 26 ] ) * xx [ 6 ] ; xx [ 191 ] = - xx
[ 170 ] ; xx [ 192 ] = - ( xx [ 6 ] * ( xx [ 195 ] - xx [ 108 ] * xx [ 26 ] )
- xx [ 45 ] ) ; xx [ 193 ] = - xx [ 66 ] ; pm_math_Matrix3x3_postCross_ra (
xx + 472 , xx + 191 , xx + 383 ) ; xx [ 45 ] = xx [ 377 ] - xx [ 384 ] ; xx [
63 ] = 0.05410477075644175 ; xx [ 108 ] = xx [ 409 ] - xx [ 400 ] - xx [ 400
] - xx [ 49 ] + xx [ 427 ] - xx [ 418 ] - xx [ 418 ] - xx [ 82 ] + xx [ 436 ]
- xx [ 114 ] - xx [ 114 ] - xx [ 445 ] + xx [ 63 ] + xx [ 454 ] - xx [ 201 ]
- xx [ 201 ] - xx [ 463 ] ; xx [ 109 ] = xx [ 67 ] / xx [ 350 ] ; xx [ 114 ]
= xx [ 264 ] * xx [ 109 ] ; xx [ 118 ] = xx [ 342 ] * xx [ 109 ] ; xx [ 119 ]
= xx [ 412 ] - xx [ 403 ] - xx [ 401 ] - xx [ 52 ] + xx [ 430 ] - xx [ 421 ]
- xx [ 419 ] - xx [ 85 ] + xx [ 439 ] - xx [ 117 ] - xx [ 115 ] - xx [ 448 ]
+ xx [ 457 ] - xx [ 204 ] - xx [ 202 ] - xx [ 466 ] ; xx [ 115 ] = xx [ 264 ]
/ xx [ 350 ] ; xx [ 117 ] = xx [ 342 ] * xx [ 115 ] ; xx [ 49 ] = xx [ 415 ]
- xx [ 406 ] - xx [ 402 ] - xx [ 55 ] + xx [ 433 ] - xx [ 424 ] - xx [ 420 ]
- xx [ 88 ] + xx [ 442 ] - xx [ 120 ] - xx [ 116 ] - xx [ 451 ] + xx [ 460 ]
- xx [ 207 ] - xx [ 203 ] - xx [ 469 ] ; xx [ 50 ] = xx [ 342 ] / xx [ 350 ]
; xx [ 82 ] = xx [ 108 ] - xx [ 67 ] * xx [ 109 ] ; xx [ 83 ] = xx [ 25 ] -
xx [ 114 ] ; xx [ 84 ] = xx [ 38 ] - xx [ 118 ] ; xx [ 85 ] = xx [ 119 ] - xx
[ 114 ] ; xx [ 86 ] = xx [ 215 ] - xx [ 264 ] * xx [ 115 ] ; xx [ 87 ] = xx [
233 ] - xx [ 117 ] ; xx [ 88 ] = xx [ 49 ] - xx [ 118 ] ; xx [ 89 ] = xx [
311 ] - xx [ 117 ] ; xx [ 90 ] = xx [ 332 ] - xx [ 342 ] * xx [ 50 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 82 , xx + 29 , xx + 201 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 29 , xx + 201 , xx + 82 ) ;
pm_math_Matrix3x3_postCross_ra ( xx + 374 , xx + 191 , xx + 29 ) ;
pm_math_Matrix3x3_preCross_ra ( xx + 383 , xx + 191 , xx + 201 ) ; xx [ 51 ]
= xx [ 86 ] - xx [ 33 ] - xx [ 33 ] - xx [ 205 ] ; memcpy ( xx + 52 , xx + 51
, 1 * sizeof ( double ) ) ; ii [ 0 ] = factorSymmetricPosDef ( xx + 52 , 1 ,
xx + 53 ) ; if ( ii [ 0 ] != 0 ) { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/pitch' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 53 ] = xx [ 45 ] / xx [ 52 ] ; xx [ 54 ] = xx [ 378 ]
- xx [ 387 ] ; xx [ 55 ] = xx [ 53 ] * xx [ 54 ] ; xx [ 56 ] = xx [ 379 ] -
xx [ 390 ] ; xx [ 57 ] = xx [ 53 ] * xx [ 56 ] ; xx [ 114 ] = xx [ 54 ] / xx
[ 52 ] ; xx [ 116 ] = xx [ 114 ] * xx [ 56 ] ; xx [ 117 ] = xx [ 56 ] / xx [
52 ] ; xx [ 392 ] = xx [ 472 ] - xx [ 53 ] * xx [ 45 ] ; xx [ 393 ] = xx [
473 ] - xx [ 55 ] ; xx [ 394 ] = xx [ 474 ] - xx [ 57 ] ; xx [ 395 ] = xx [
475 ] - xx [ 55 ] ; xx [ 396 ] = xx [ 476 ] - xx [ 114 ] * xx [ 54 ] ; xx [
397 ] = xx [ 477 ] - xx [ 116 ] ; xx [ 398 ] = xx [ 478 ] - xx [ 57 ] ; xx [
399 ] = xx [ 479 ] - xx [ 116 ] ; xx [ 400 ] = xx [ 480 ] - xx [ 117 ] * xx [
56 ] ; pm_math_Matrix3x3_composeTranspose_ra ( xx + 392 , xx + 12 , xx + 401
) ; pm_math_Matrix3x3_compose_ra ( xx + 12 , xx + 401 , xx + 392 ) ; xx [ 401
] = xx [ 392 ] ; xx [ 402 ] = xx [ 393 ] ; xx [ 403 ] = xx [ 394 ] ; xx [ 404
] = xx [ 393 ] ; xx [ 405 ] = xx [ 396 ] ; xx [ 406 ] = xx [ 397 ] ; xx [ 407
] = xx [ 394 ] ; xx [ 408 ] = xx [ 397 ] ; xx [ 409 ] = xx [ 400 ] ; ii [ 0 ]
= factorSymmetricPosDef ( xx + 401 , 3 , xx + 120 ) ; if ( ii [ 0 ] != 0 ) {
return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:DegenerateMass" ,
 "'series_link_blance_leg/series_blance_leg_model/Cartesian Joint1' has a degenerate mass distribution on its follower side."
, neDiagMgr ) ; } xx [ 194 ] = xx [ 4 ] ; xx [ 195 ] = xx [ 4 ] ; xx [ 196 ]
= xx [ 8 ] ; xx [ 197 ] = xx [ 8 ] ; xx [ 266 ] = xx [ 26 ] ; xx [ 267 ] = xx
[ 3 ] ; xx [ 268 ] = xx [ 104 ] ; xx [ 269 ] = xx [ 11 ] ; xx [ 270 ] = xx [
10 ] ; xx [ 271 ] = - xx [ 22 ] ; xx [ 272 ] = xx [ 10 ] ; xx [ 273 ] = - xx
[ 39 ] ; xx [ 55 ] = xx [ 11 ] * state [ 7 ] ; xx [ 57 ] = xx [ 3 ] * state [
7 ] ; xx [ 104 ] = ( xx [ 55 ] * xx [ 26 ] - xx [ 57 ] * xx [ 5 ] ) * xx [ 6
] ; xx [ 116 ] = state [ 7 ] - ( xx [ 11 ] * xx [ 55 ] + xx [ 57 ] * xx [ 3 ]
) * xx [ 6 ] ; xx [ 118 ] = xx [ 21 ] * state [ 9 ] ; xx [ 120 ] = xx [ 116 ]
- xx [ 118 ] ; xx [ 121 ] = xx [ 6 ] * ( xx [ 55 ] * xx [ 5 ] + xx [ 57 ] *
xx [ 26 ] ) ; xx [ 55 ] = xx [ 24 ] * state [ 9 ] ; xx [ 57 ] = xx [ 121 ] +
xx [ 55 ] ; xx [ 301 ] = xx [ 104 ] ; xx [ 302 ] = xx [ 120 ] ; xx [ 303 ] =
- xx [ 57 ] ; pm_math_Vector3_cross_ra ( xx + 301 , xx + 320 , xx + 308 ) ;
pm_math_Vector3_cross_ra ( xx + 301 , xx + 308 , xx + 313 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 313 , xx + 308 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 301 , xx + 313 ) ; xx [
122 ] = xx [ 315 ] + state [ 25 ] ; xx [ 198 ] = xx [ 293 ] * state [ 25 ] ;
xx [ 305 ] = xx [ 27 ] * ( xx [ 308 ] - ( xx [ 315 ] + xx [ 122 ] ) * xx [
198 ] ) ; xx [ 306 ] = xx [ 27 ] * xx [ 309 ] ; xx [ 316 ] = 0.011485125 ; xx
[ 317 ] = xx [ 144 ] - xx [ 169 ] ; xx [ 326 ] = xx [ 62 ] ; xx [ 327 ] = xx
[ 28 ] ; xx [ 328 ] = xx [ 96 ] ; xx [ 318 ] = xx [ 96 ] * xx [ 167 ] ; xx [
323 ] = xx [ 167 ] * xx [ 28 ] ; xx [ 329 ] = xx [ 62 ] * xx [ 317 ] - xx [
323 ] ; xx [ 343 ] = - ( xx [ 96 ] * xx [ 317 ] ) ; xx [ 344 ] = xx [ 318 ] ;
xx [ 345 ] = xx [ 329 ] ; pm_math_Vector3_cross_ra ( xx + 326 , xx + 343 , xx
+ 346 ) ; xx [ 330 ] = xx [ 318 ] * xx [ 28 ] ; xx [ 331 ] = xx [ 154 ] * xx
[ 28 ] ; xx [ 340 ] = xx [ 96 ] * xx [ 123 ] - xx [ 331 ] ; xx [ 343 ] =
0.06918743527133955 ; xx [ 344 ] = xx [ 340 ] * xx [ 343 ] ; xx [ 345 ] = xx
[ 62 ] * xx [ 123 ] - xx [ 331 ] ; xx [ 331 ] = xx [ 345 ] * xx [ 343 ] ; xx
[ 366 ] = ( xx [ 340 ] * xx [ 344 ] + xx [ 345 ] * xx [ 331 ] ) * xx [ 6 ] ;
xx [ 367 ] = xx [ 317 ] + xx [ 6 ] * ( xx [ 347 ] + xx [ 330 ] ) + xx [ 366 ]
- xx [ 343 ] ; xx [ 370 ] = xx [ 367 ] / xx [ 151 ] ; xx [ 377 ] = xx [ 150 ]
* xx [ 370 ] ; xx [ 378 ] = xx [ 154 ] * xx [ 377 ] ; xx [ 379 ] = xx [ 145 ]
* xx [ 370 ] ; xx [ 384 ] = xx [ 154 ] * xx [ 379 ] ; xx [ 387 ] = xx [ 6 ] *
( xx [ 154 ] * xx [ 378 ] + xx [ 384 ] * xx [ 123 ] ) - xx [ 377 ] ; xx [ 377
] = ( xx [ 154 ] * xx [ 384 ] - xx [ 378 ] * xx [ 123 ] ) * xx [ 6 ] - xx [
379 ] ; xx [ 378 ] = xx [ 165 ] * xx [ 387 ] + xx [ 167 ] * xx [ 377 ] - xx [
148 ] * xx [ 370 ] ; xx [ 379 ] = xx [ 62 ] * xx [ 165 ] - xx [ 323 ] ; xx [
410 ] = - ( xx [ 96 ] * xx [ 165 ] ) ; xx [ 411 ] = xx [ 318 ] ; xx [ 412 ] =
xx [ 379 ] ; pm_math_Vector3_cross_ra ( xx + 326 , xx + 410 , xx + 413 ) ; xx
[ 318 ] = xx [ 62 ] * xx [ 160 ] ; xx [ 323 ] = 0.01685096875337573 ; xx [
384 ] = xx [ 165 ] + ( xx [ 330 ] + xx [ 414 ] ) * xx [ 6 ] - ( xx [ 111 ] +
xx [ 62 ] * xx [ 318 ] ) * xx [ 6 ] + xx [ 366 ] + xx [ 323 ] ; xx [ 111 ] =
( xx [ 378 ] + xx [ 160 ] * xx [ 387 ] + xx [ 384 ] ) / xx [ 157 ] ; xx [ 410
] = xx [ 325 ] ; xx [ 411 ] = xx [ 94 ] ; xx [ 412 ] = xx [ 139 ] ; xx [ 416
] = xx [ 28 ] ; xx [ 417 ] = xx [ 62 ] ; xx [ 418 ] = xx [ 28 ] ; xx [ 419 ]
= xx [ 96 ] ; xx [ 94 ] = xx [ 147 ] * xx [ 370 ] ; xx [ 139 ] = xx [ 262 ] *
xx [ 370 ] ; xx [ 325 ] = xx [ 154 ] * xx [ 139 ] ; xx [ 330 ] = xx [ 154 ] *
xx [ 94 ] ; xx [ 420 ] = xx [ 94 ] - xx [ 6 ] * ( xx [ 325 ] * xx [ 123 ] +
xx [ 154 ] * xx [ 330 ] ) - xx [ 281 ] * xx [ 111 ] ; xx [ 421 ] = ( xx [ 154
] * xx [ 325 ] - xx [ 330 ] * xx [ 123 ] ) * xx [ 6 ] - xx [ 139 ] - xx [ 274
] * xx [ 111 ] ; xx [ 422 ] = xx [ 378 ] - xx [ 138 ] * xx [ 111 ] ;
pm_math_Quaternion_xform_ra ( xx + 416 , xx + 420 , xx + 423 ) ; xx [ 94 ] =
xx [ 377 ] - xx [ 171 ] * xx [ 111 ] ; xx [ 139 ] = xx [ 387 ] - xx [ 155 ] *
xx [ 111 ] ; xx [ 325 ] = xx [ 96 ] * xx [ 139 ] ; xx [ 330 ] = xx [ 96 ] *
xx [ 94 ] ; xx [ 366 ] = xx [ 62 ] * xx [ 139 ] - xx [ 28 ] * xx [ 94 ] ; xx
[ 420 ] = - xx [ 325 ] ; xx [ 421 ] = xx [ 330 ] ; xx [ 422 ] = xx [ 366 ] ;
pm_math_Vector3_cross_ra ( xx + 326 , xx + 420 , xx + 426 ) ; xx [ 377 ] = xx
[ 94 ] + xx [ 6 ] * ( xx [ 426 ] - xx [ 325 ] * xx [ 28 ] ) ; xx [ 94 ] = xx
[ 139 ] + ( xx [ 330 ] * xx [ 28 ] + xx [ 427 ] ) * xx [ 6 ] ; xx [ 139 ] = (
xx [ 366 ] * xx [ 28 ] + xx [ 428 ] ) * xx [ 6 ] ; xx [ 420 ] = xx [ 377 ] ;
xx [ 421 ] = xx [ 94 ] ; xx [ 422 ] = xx [ 139 ] ; pm_math_Vector3_cross_ra (
xx + 290 , xx + 420 , xx + 426 ) ; xx [ 325 ] = 0.17015 ; xx [ 330 ] = xx [
59 ] * xx [ 293 ] ; xx [ 366 ] = ( xx [ 334 ] + xx [ 59 ] * xx [ 330 ] ) * xx
[ 6 ] ; xx [ 334 ] = xx [ 325 ] - ( xx [ 366 ] + xx [ 366 ] ) ; xx [ 366 ] =
1.3053272625e-3 ; xx [ 378 ] = xx [ 334 ] / xx [ 366 ] ; xx [ 387 ] = xx [
361 ] * xx [ 378 ] ; xx [ 390 ] = xx [ 387 ] * xx [ 58 ] ; xx [ 420 ] = xx [
390 ] * xx [ 58 ] ; xx [ 421 ] = xx [ 59 ] * xx [ 387 ] ; xx [ 422 ] = xx [
316 ] * xx [ 378 ] ; xx [ 429 ] = xx [ 64 ] * xx [ 422 ] ; xx [ 430 ] = xx [
429 ] * xx [ 58 ] ; xx [ 431 ] = xx [ 59 ] * xx [ 422 ] ; xx [ 432 ] = xx [
431 ] * xx [ 58 ] ; xx [ 433 ] = xx [ 6 ] * ( xx [ 430 ] - xx [ 432 ] ) ; xx
[ 434 ] = xx [ 422 ] - ( xx [ 64 ] * xx [ 429 ] + xx [ 59 ] * xx [ 431 ] ) *
xx [ 6 ] ; xx [ 422 ] = ( xx [ 432 ] + xx [ 430 ] ) * xx [ 6 ] ; xx [ 429 ] =
xx [ 433 ] ; xx [ 430 ] = xx [ 434 ] ; xx [ 431 ] = - xx [ 422 ] ;
pm_math_Vector3_cross_ra ( xx + 337 , xx + 429 , xx + 435 ) ; xx [ 429 ] = xx
[ 377 ] + xx [ 433 ] ; xx [ 377 ] = xx [ 424 ] + xx [ 427 ] + xx [ 6 ] * ( xx
[ 421 ] * xx [ 58 ] - xx [ 64 ] * xx [ 390 ] ) + xx [ 436 ] ; xx [ 390 ] = xx
[ 425 ] + xx [ 428 ] + xx [ 387 ] - ( xx [ 59 ] * xx [ 421 ] + xx [ 420 ] ) *
xx [ 6 ] + xx [ 437 ] ; xx [ 387 ] = ( xx [ 429 ] * xx [ 244 ] - ( xx [ 377 ]
* xx [ 21 ] + xx [ 390 ] * xx [ 24 ] ) ) / xx [ 350 ] ; xx [ 430 ] = xx [ 423
] + xx [ 426 ] + ( xx [ 420 ] + xx [ 64 ] * xx [ 421 ] ) * xx [ 6 ] + xx [
435 ] - xx [ 67 ] * xx [ 387 ] ; xx [ 431 ] = xx [ 377 ] - xx [ 264 ] * xx [
387 ] ; xx [ 432 ] = xx [ 390 ] - xx [ 342 ] * xx [ 387 ] ;
pm_math_Quaternion_xform_ra ( xx + 266 , xx + 430 , xx + 423 ) ; xx [ 425 ] =
xx [ 429 ] - xx [ 265 ] * xx [ 387 ] ; xx [ 426 ] = xx [ 94 ] + xx [ 434 ] -
xx [ 46 ] * xx [ 387 ] ; xx [ 427 ] = xx [ 139 ] - xx [ 422 ] - xx [ 40 ] *
xx [ 387 ] ; pm_math_Quaternion_xform_ra ( xx + 266 , xx + 425 , xx + 420 ) ;
pm_math_Vector3_cross_ra ( xx + 191 , xx + 420 , xx + 425 ) ; xx [ 94 ] = (
xx [ 424 ] + xx [ 426 ] ) / xx [ 52 ] ; xx [ 423 ] = xx [ 53 ] ; xx [ 424 ] =
xx [ 114 ] ; xx [ 425 ] = xx [ 117 ] ; xx [ 426 ] = xx [ 420 ] - xx [ 94 ] *
xx [ 45 ] ; xx [ 427 ] = xx [ 421 ] - xx [ 94 ] * xx [ 54 ] ; xx [ 428 ] = xx
[ 422 ] - xx [ 94 ] * xx [ 56 ] ; pm_math_Quaternion_xform_ra ( xx + 194 , xx
+ 426 , xx + 420 ) ; xx [ 426 ] = - xx [ 420 ] ; xx [ 427 ] = - xx [ 421 ] ;
xx [ 428 ] = - xx [ 422 ] ; solveSymmetricPosDef ( xx + 401 , xx + 426 , 3 ,
1 , xx + 420 , xx + 429 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 194 ,
xx + 420 , xx + 426 ) ; xx [ 139 ] = xx [ 94 ] + pm_math_Vector3_dot_ra ( xx
+ 423 , xx + 426 ) ; xx [ 94 ] = xx [ 11 ] * xx [ 139 ] ; xx [ 377 ] = xx [
139 ] * xx [ 3 ] ; xx [ 390 ] = - ( ( xx [ 94 ] * xx [ 26 ] - xx [ 377 ] * xx
[ 5 ] ) * xx [ 6 ] ) ; xx [ 420 ] = ( xx [ 11 ] * xx [ 94 ] + xx [ 377 ] * xx
[ 3 ] ) * xx [ 6 ] - xx [ 139 ] ; xx [ 429 ] = xx [ 109 ] ; xx [ 430 ] = xx [
115 ] ; xx [ 431 ] = xx [ 50 ] ; xx [ 50 ] = xx [ 6 ] * ( xx [ 377 ] * xx [
26 ] + xx [ 94 ] * xx [ 5 ] ) ; xx [ 432 ] = xx [ 390 ] ; xx [ 433 ] = xx [
420 ] ; xx [ 434 ] = xx [ 50 ] ; xx [ 435 ] = xx [ 354 ] ; xx [ 436 ] = xx [
71 ] ; xx [ 437 ] = xx [ 75 ] ; xx [ 438 ] = xx [ 426 ] + xx [ 66 ] * xx [
139 ] ; xx [ 439 ] = xx [ 427 ] ; xx [ 440 ] = xx [ 428 ] - xx [ 139 ] * xx [
170 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx + 438 , xx + 426 )
; xx [ 71 ] = xx [ 387 ] + pm_math_Vector3_dot_ra ( xx + 429 , xx + 432 ) +
pm_math_Vector3_dot_ra ( xx + 435 , xx + 426 ) ; xx [ 432 ] = xx [ 390 ] ; xx
[ 433 ] = xx [ 420 ] + xx [ 71 ] * xx [ 21 ] ; xx [ 434 ] = xx [ 50 ] + xx [
71 ] * xx [ 24 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 432 ,
xx + 420 ) ; xx [ 50 ] = xx [ 426 ] - xx [ 71 ] * xx [ 244 ] ;
pm_math_Vector3_cross_ra ( xx + 432 , xx + 290 , xx + 438 ) ; xx [ 441 ] = xx
[ 50 ] + xx [ 438 ] ; xx [ 442 ] = xx [ 427 ] + xx [ 439 ] ; xx [ 443 ] = xx
[ 428 ] + xx [ 440 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx +
441 , xx + 438 ) ; xx [ 71 ] = xx [ 111 ] + pm_math_Vector3_dot_ra ( xx + 410
, xx + 420 ) + xx [ 164 ] * xx [ 438 ] + xx [ 174 ] * xx [ 439 ] ; xx [ 440 ]
= - xx [ 276 ] ; xx [ 441 ] = xx [ 252 ] ; xx [ 442 ] = xx [ 173 ] ; xx [ 75
] = xx [ 154 ] * xx [ 421 ] ; xx [ 94 ] = xx [ 154 ] * xx [ 420 ] ; xx [ 109
] = xx [ 422 ] - xx [ 71 ] ; xx [ 443 ] = xx [ 420 ] - xx [ 6 ] * ( xx [ 75 ]
* xx [ 123 ] + xx [ 154 ] * xx [ 94 ] ) ; xx [ 444 ] = xx [ 421 ] - ( xx [
154 ] * xx [ 75 ] - xx [ 94 ] * xx [ 123 ] ) * xx [ 6 ] ; xx [ 445 ] = xx [
109 ] ; xx [ 75 ] = xx [ 438 ] + xx [ 167 ] * xx [ 109 ] ; xx [ 94 ] = xx [
439 ] - xx [ 71 ] * xx [ 160 ] + xx [ 165 ] * xx [ 109 ] ; xx [ 109 ] = xx [
154 ] * xx [ 94 ] ; xx [ 111 ] = xx [ 75 ] * xx [ 154 ] ; xx [ 115 ] =
0.2514543766567505 ; xx [ 446 ] = xx [ 58 ] ; xx [ 447 ] = - xx [ 59 ] ; xx [
448 ] = xx [ 58 ] ; xx [ 449 ] = - xx [ 64 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 432 , xx + 420 ) ; xx [
139 ] = 8.798655578527764 ; pm_math_Vector3_cross_ra ( xx + 432 , xx + 337 ,
xx + 450 ) ; xx [ 432 ] = xx [ 50 ] + xx [ 450 ] ; xx [ 433 ] = xx [ 427 ] +
xx [ 451 ] ; xx [ 434 ] = xx [ 428 ] + xx [ 452 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 432 , xx + 426 ) ; xx [
50 ] = xx [ 28 ] * xx [ 123 ] ; xx [ 173 ] = xx [ 50 ] + xx [ 96 ] * xx [ 154
] ; xx [ 252 ] = xx [ 50 ] + xx [ 62 ] * xx [ 154 ] ; xx [ 50 ] = ( xx [ 331
] * xx [ 173 ] + xx [ 344 ] * xx [ 252 ] ) * xx [ 6 ] ; xx [ 276 ] = ( xx [
329 ] * xx [ 28 ] + xx [ 348 ] ) * xx [ 6 ] - xx [ 50 ] ; xx [ 329 ] = xx [
276 ] / xx [ 151 ] ; xx [ 331 ] = xx [ 150 ] * xx [ 329 ] ; xx [ 344 ] = xx [
154 ] * xx [ 331 ] ; xx [ 346 ] = xx [ 145 ] * xx [ 329 ] ; xx [ 347 ] = xx [
154 ] * xx [ 346 ] ; xx [ 348 ] = xx [ 6 ] * ( xx [ 154 ] * xx [ 344 ] + xx [
347 ] * xx [ 123 ] ) - xx [ 331 ] ; xx [ 331 ] = ( xx [ 154 ] * xx [ 347 ] -
xx [ 344 ] * xx [ 123 ] ) * xx [ 6 ] - xx [ 346 ] ; xx [ 344 ] = xx [ 165 ] *
xx [ 348 ] + xx [ 167 ] * xx [ 331 ] - xx [ 148 ] * xx [ 329 ] ; xx [ 346 ] =
( xx [ 379 ] * xx [ 28 ] + xx [ 415 ] ) * xx [ 6 ] + ( xx [ 318 ] * xx [ 28 ]
+ xx [ 280 ] ) * xx [ 6 ] - xx [ 50 ] ; xx [ 50 ] = ( xx [ 344 ] + xx [ 160 ]
* xx [ 348 ] + xx [ 346 ] ) / xx [ 157 ] ; xx [ 280 ] = xx [ 147 ] * xx [ 329
] ; xx [ 318 ] = xx [ 262 ] * xx [ 329 ] ; xx [ 347 ] = xx [ 154 ] * xx [ 318
] ; xx [ 354 ] = xx [ 154 ] * xx [ 280 ] ; xx [ 413 ] = xx [ 280 ] - xx [ 6 ]
* ( xx [ 347 ] * xx [ 123 ] + xx [ 154 ] * xx [ 354 ] ) - xx [ 281 ] * xx [
50 ] ; xx [ 414 ] = ( xx [ 154 ] * xx [ 347 ] - xx [ 354 ] * xx [ 123 ] ) *
xx [ 6 ] - xx [ 318 ] - xx [ 274 ] * xx [ 50 ] ; xx [ 415 ] = xx [ 344 ] - xx
[ 138 ] * xx [ 50 ] ; pm_math_Quaternion_xform_ra ( xx + 416 , xx + 413 , xx
+ 432 ) ; xx [ 280 ] = xx [ 331 ] - xx [ 171 ] * xx [ 50 ] ; xx [ 318 ] = xx
[ 348 ] - xx [ 155 ] * xx [ 50 ] ; xx [ 331 ] = xx [ 96 ] * xx [ 318 ] ; xx [
344 ] = xx [ 96 ] * xx [ 280 ] ; xx [ 347 ] = xx [ 62 ] * xx [ 318 ] - xx [
28 ] * xx [ 280 ] ; xx [ 413 ] = - xx [ 331 ] ; xx [ 414 ] = xx [ 344 ] ; xx
[ 415 ] = xx [ 347 ] ; pm_math_Vector3_cross_ra ( xx + 326 , xx + 413 , xx +
450 ) ; xx [ 348 ] = xx [ 280 ] + xx [ 6 ] * ( xx [ 450 ] - xx [ 331 ] * xx [
28 ] ) ; xx [ 280 ] = xx [ 318 ] + ( xx [ 344 ] * xx [ 28 ] + xx [ 451 ] ) *
xx [ 6 ] ; xx [ 318 ] = ( xx [ 347 ] * xx [ 28 ] + xx [ 452 ] ) * xx [ 6 ] ;
xx [ 413 ] = xx [ 348 ] ; xx [ 414 ] = xx [ 280 ] ; xx [ 415 ] = xx [ 318 ] ;
pm_math_Vector3_cross_ra ( xx + 290 , xx + 413 , xx + 450 ) ; xx [ 331 ] = (
xx [ 330 ] * xx [ 58 ] + xx [ 335 ] ) * xx [ 6 ] ; xx [ 330 ] = xx [ 331 ] +
xx [ 331 ] ; xx [ 331 ] = xx [ 330 ] / xx [ 366 ] ; xx [ 335 ] = xx [ 316 ] *
xx [ 331 ] ; xx [ 344 ] = xx [ 59 ] * xx [ 335 ] ; xx [ 347 ] = xx [ 344 ] *
xx [ 58 ] ; xx [ 354 ] = xx [ 64 ] * xx [ 335 ] ; xx [ 377 ] = xx [ 354 ] *
xx [ 58 ] ; xx [ 379 ] = xx [ 6 ] * ( xx [ 347 ] - xx [ 377 ] ) ; xx [ 387 ]
= ( xx [ 64 ] * xx [ 354 ] + xx [ 59 ] * xx [ 344 ] ) * xx [ 6 ] - xx [ 335 ]
; xx [ 335 ] = ( xx [ 347 ] + xx [ 377 ] ) * xx [ 6 ] ; xx [ 413 ] = xx [ 379
] ; xx [ 414 ] = xx [ 387 ] ; xx [ 415 ] = xx [ 335 ] ;
pm_math_Vector3_cross_ra ( xx + 337 , xx + 413 , xx + 453 ) ; xx [ 344 ] = xx
[ 361 ] * xx [ 331 ] ; xx [ 347 ] = xx [ 344 ] * xx [ 58 ] ; xx [ 354 ] = xx
[ 347 ] * xx [ 58 ] ; xx [ 377 ] = xx [ 59 ] * xx [ 344 ] ; xx [ 390 ] = xx [
348 ] + xx [ 379 ] ; xx [ 348 ] = xx [ 433 ] + xx [ 451 ] + xx [ 6 ] * ( xx [
64 ] * xx [ 347 ] - xx [ 377 ] * xx [ 58 ] ) + xx [ 454 ] ; xx [ 58 ] = xx [
434 ] + xx [ 452 ] + ( xx [ 59 ] * xx [ 377 ] + xx [ 354 ] ) * xx [ 6 ] - xx
[ 344 ] + xx [ 455 ] ; xx [ 59 ] = ( xx [ 390 ] * xx [ 244 ] - ( xx [ 348 ] *
xx [ 21 ] + xx [ 58 ] * xx [ 24 ] ) ) / xx [ 350 ] ; xx [ 413 ] = xx [ 432 ]
+ xx [ 450 ] + xx [ 453 ] - ( xx [ 354 ] + xx [ 64 ] * xx [ 377 ] ) * xx [ 6
] - xx [ 67 ] * xx [ 59 ] ; xx [ 414 ] = xx [ 348 ] - xx [ 264 ] * xx [ 59 ]
; xx [ 415 ] = xx [ 58 ] - xx [ 342 ] * xx [ 59 ] ;
pm_math_Quaternion_xform_ra ( xx + 266 , xx + 413 , xx + 432 ) ; xx [ 413 ] =
xx [ 390 ] - xx [ 265 ] * xx [ 59 ] ; xx [ 414 ] = xx [ 280 ] + xx [ 387 ] -
xx [ 46 ] * xx [ 59 ] ; xx [ 415 ] = xx [ 318 ] + xx [ 335 ] - xx [ 40 ] * xx
[ 59 ] ; pm_math_Quaternion_xform_ra ( xx + 266 , xx + 413 , xx + 450 ) ;
pm_math_Vector3_cross_ra ( xx + 191 , xx + 450 , xx + 413 ) ; xx [ 58 ] = (
xx [ 433 ] + xx [ 414 ] ) / xx [ 52 ] ; xx [ 413 ] = xx [ 450 ] - xx [ 58 ] *
xx [ 45 ] ; xx [ 414 ] = xx [ 451 ] - xx [ 58 ] * xx [ 54 ] ; xx [ 415 ] = xx
[ 452 ] - xx [ 58 ] * xx [ 56 ] ; pm_math_Quaternion_xform_ra ( xx + 194 , xx
+ 413 , xx + 432 ) ; xx [ 413 ] = - xx [ 432 ] ; xx [ 414 ] = - xx [ 433 ] ;
xx [ 415 ] = - xx [ 434 ] ; solveSymmetricPosDef ( xx + 401 , xx + 413 , 3 ,
1 , xx + 432 , xx + 450 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 194 ,
xx + 432 , xx + 413 ) ; xx [ 64 ] = xx [ 58 ] + pm_math_Vector3_dot_ra ( xx +
423 , xx + 413 ) ; xx [ 58 ] = xx [ 11 ] * xx [ 64 ] ; xx [ 280 ] = xx [ 64 ]
* xx [ 3 ] ; xx [ 318 ] = - ( ( xx [ 58 ] * xx [ 26 ] - xx [ 280 ] * xx [ 5 ]
) * xx [ 6 ] ) ; xx [ 335 ] = ( xx [ 11 ] * xx [ 58 ] + xx [ 280 ] * xx [ 3 ]
) * xx [ 6 ] - xx [ 64 ] ; xx [ 344 ] = xx [ 6 ] * ( xx [ 280 ] * xx [ 26 ] +
xx [ 58 ] * xx [ 5 ] ) ; xx [ 432 ] = xx [ 318 ] ; xx [ 433 ] = xx [ 335 ] ;
xx [ 434 ] = xx [ 344 ] ; xx [ 450 ] = xx [ 413 ] + xx [ 66 ] * xx [ 64 ] ;
xx [ 451 ] = xx [ 414 ] ; xx [ 452 ] = xx [ 415 ] - xx [ 64 ] * xx [ 170 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx + 450 , xx + 413 ) ; xx [
58 ] = xx [ 59 ] + pm_math_Vector3_dot_ra ( xx + 429 , xx + 432 ) +
pm_math_Vector3_dot_ra ( xx + 435 , xx + 413 ) ; xx [ 432 ] = xx [ 318 ] ; xx
[ 433 ] = xx [ 335 ] + xx [ 58 ] * xx [ 21 ] ; xx [ 434 ] = xx [ 344 ] + xx [
58 ] * xx [ 24 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 432 ,
xx + 450 ) ; xx [ 59 ] = xx [ 413 ] - xx [ 58 ] * xx [ 244 ] ;
pm_math_Vector3_cross_ra ( xx + 432 , xx + 290 , xx + 453 ) ; xx [ 456 ] = xx
[ 59 ] + xx [ 453 ] ; xx [ 457 ] = xx [ 414 ] + xx [ 454 ] ; xx [ 458 ] = xx
[ 415 ] + xx [ 455 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx +
456 , xx + 453 ) ; xx [ 58 ] = xx [ 50 ] + pm_math_Vector3_dot_ra ( xx + 410
, xx + 450 ) + xx [ 164 ] * xx [ 453 ] + xx [ 174 ] * xx [ 454 ] ; xx [ 50 ]
= xx [ 154 ] * xx [ 451 ] ; xx [ 64 ] = xx [ 154 ] * xx [ 450 ] ; xx [ 280 ]
= xx [ 452 ] - xx [ 58 ] ; xx [ 455 ] = xx [ 450 ] - xx [ 6 ] * ( xx [ 50 ] *
xx [ 123 ] + xx [ 154 ] * xx [ 64 ] ) ; xx [ 456 ] = xx [ 451 ] - ( xx [ 154
] * xx [ 50 ] - xx [ 64 ] * xx [ 123 ] ) * xx [ 6 ] ; xx [ 457 ] = xx [ 280 ]
; xx [ 50 ] = xx [ 453 ] + xx [ 167 ] * xx [ 280 ] ; xx [ 64 ] = xx [ 454 ] -
xx [ 58 ] * xx [ 160 ] + xx [ 165 ] * xx [ 280 ] ; xx [ 280 ] = xx [ 154 ] *
xx [ 64 ] ; xx [ 318 ] = xx [ 50 ] * xx [ 154 ] ; xx [ 335 ] = xx [ 329 ] +
pm_math_Vector3_dot_ra ( xx + 440 , xx + 455 ) + ( xx [ 50 ] - xx [ 6 ] * (
xx [ 280 ] * xx [ 123 ] + xx [ 154 ] * xx [ 318 ] ) ) * xx [ 152 ] + xx [ 142
] * ( xx [ 64 ] - ( xx [ 154 ] * xx [ 280 ] - xx [ 318 ] * xx [ 123 ] ) * xx
[ 6 ] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 432 , xx + 450
) ; pm_math_Vector3_cross_ra ( xx + 432 , xx + 337 , xx + 453 ) ; xx [ 432 ]
= xx [ 59 ] + xx [ 453 ] ; xx [ 433 ] = xx [ 414 ] + xx [ 454 ] ; xx [ 434 ]
= xx [ 415 ] + xx [ 455 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 446 ,
xx + 432 , xx + 413 ) ; xx [ 50 ] = xx [ 331 ] + xx [ 115 ] * xx [ 452 ] + xx
[ 139 ] * xx [ 414 ] ; xx [ 59 ] = xx [ 58 ] * xx [ 384 ] + xx [ 335 ] * xx [
367 ] - xx [ 334 ] * xx [ 50 ] ; xx [ 450 ] = xx [ 175 ] ; xx [ 451 ] = xx [
23 ] ; xx [ 452 ] = xx [ 175 ] ; xx [ 453 ] = xx [ 183 ] ; xx [ 64 ] = xx [
144 ] - xx [ 248 ] ; xx [ 413 ] = xx [ 23 ] ; xx [ 414 ] = xx [ 175 ] ; xx [
415 ] = xx [ 183 ] ; xx [ 280 ] = xx [ 183 ] * xx [ 247 ] ; xx [ 318 ] = xx [
247 ] * xx [ 175 ] ; xx [ 329 ] = xx [ 23 ] * xx [ 64 ] - xx [ 318 ] ; xx [
432 ] = - ( xx [ 183 ] * xx [ 64 ] ) ; xx [ 433 ] = xx [ 280 ] ; xx [ 434 ] =
xx [ 329 ] ; pm_math_Vector3_cross_ra ( xx + 413 , xx + 432 , xx + 454 ) ; xx
[ 331 ] = xx [ 280 ] * xx [ 175 ] ; xx [ 344 ] = xx [ 234 ] * xx [ 175 ] ; xx
[ 347 ] = xx [ 183 ] * xx [ 181 ] - xx [ 344 ] ; xx [ 348 ] = xx [ 347 ] * xx
[ 343 ] ; xx [ 354 ] = xx [ 23 ] * xx [ 181 ] - xx [ 344 ] ; xx [ 344 ] = xx
[ 354 ] * xx [ 343 ] ; xx [ 377 ] = ( xx [ 347 ] * xx [ 348 ] + xx [ 354 ] *
xx [ 344 ] ) * xx [ 6 ] ; xx [ 379 ] = xx [ 64 ] + xx [ 6 ] * ( xx [ 455 ] +
xx [ 331 ] ) + xx [ 377 ] - xx [ 343 ] ; xx [ 387 ] = xx [ 379 ] / xx [ 231 ]
; xx [ 390 ] = xx [ 352 ] * xx [ 387 ] ; xx [ 420 ] = xx [ 234 ] * xx [ 390 ]
; xx [ 421 ] = xx [ 227 ] * xx [ 387 ] ; xx [ 426 ] = xx [ 234 ] * xx [ 421 ]
; xx [ 428 ] = xx [ 230 ] * xx [ 387 ] ; xx [ 432 ] = xx [ 234 ] * xx [ 428 ]
; xx [ 433 ] = xx [ 226 ] * xx [ 387 ] ; xx [ 434 ] = xx [ 234 ] * xx [ 433 ]
; xx [ 438 ] = xx [ 6 ] * ( xx [ 234 ] * xx [ 432 ] + xx [ 434 ] * xx [ 181 ]
) - xx [ 428 ] ; xx [ 428 ] = ( xx [ 234 ] * xx [ 434 ] - xx [ 432 ] * xx [
181 ] ) * xx [ 6 ] - xx [ 433 ] ; xx [ 432 ] = xx [ 245 ] * xx [ 438 ] + xx [
247 ] * xx [ 428 ] - xx [ 228 ] * xx [ 387 ] ; xx [ 433 ] = xx [ 23 ] * xx [
245 ] - xx [ 318 ] ; xx [ 457 ] = - ( xx [ 183 ] * xx [ 245 ] ) ; xx [ 458 ]
= xx [ 280 ] ; xx [ 459 ] = xx [ 433 ] ; pm_math_Vector3_cross_ra ( xx + 413
, xx + 457 , xx + 460 ) ; xx [ 280 ] = xx [ 23 ] * xx [ 160 ] ; xx [ 318 ] =
xx [ 245 ] + ( xx [ 331 ] + xx [ 461 ] ) * xx [ 6 ] - ( xx [ 185 ] + xx [ 23
] * xx [ 280 ] ) * xx [ 6 ] + xx [ 377 ] + xx [ 323 ] ; xx [ 185 ] = ( xx [
432 ] + xx [ 160 ] * xx [ 438 ] + xx [ 318 ] ) / xx [ 237 ] ; xx [ 457 ] = xx
[ 6 ] * ( xx [ 420 ] * xx [ 181 ] + xx [ 234 ] * xx [ 426 ] ) - xx [ 421 ] -
xx [ 362 ] * xx [ 185 ] ; xx [ 458 ] = ( xx [ 426 ] * xx [ 181 ] - xx [ 234 ]
* xx [ 420 ] ) * xx [ 6 ] + xx [ 390 ] - xx [ 355 ] * xx [ 185 ] ; xx [ 459 ]
= xx [ 432 ] - xx [ 168 ] * xx [ 185 ] ; pm_math_Quaternion_xform_ra ( xx +
450 , xx + 457 , xx + 463 ) ; xx [ 323 ] = xx [ 428 ] - xx [ 240 ] * xx [ 185
] ; xx [ 331 ] = xx [ 438 ] - xx [ 235 ] * xx [ 185 ] ; xx [ 377 ] = xx [ 183
] * xx [ 331 ] ; xx [ 390 ] = xx [ 183 ] * xx [ 323 ] ; xx [ 420 ] = xx [ 23
] * xx [ 331 ] - xx [ 175 ] * xx [ 323 ] ; xx [ 457 ] = - xx [ 377 ] ; xx [
458 ] = xx [ 390 ] ; xx [ 459 ] = xx [ 420 ] ; pm_math_Vector3_cross_ra ( xx
+ 413 , xx + 457 , xx + 466 ) ; xx [ 421 ] = xx [ 323 ] + xx [ 6 ] * ( xx [
466 ] - xx [ 377 ] * xx [ 175 ] ) ; xx [ 323 ] = xx [ 331 ] + ( xx [ 390 ] *
xx [ 175 ] + xx [ 467 ] ) * xx [ 6 ] ; xx [ 331 ] = ( xx [ 420 ] * xx [ 175 ]
+ xx [ 468 ] ) * xx [ 6 ] ; xx [ 457 ] = xx [ 421 ] ; xx [ 458 ] = xx [ 323 ]
; xx [ 459 ] = xx [ 331 ] ; pm_math_Vector3_cross_ra ( xx + 371 , xx + 457 ,
xx + 466 ) ; xx [ 377 ] = xx [ 22 ] * xx [ 293 ] ; xx [ 390 ] = ( xx [ 297 ]
+ xx [ 22 ] * xx [ 377 ] ) * xx [ 6 ] ; xx [ 297 ] = xx [ 325 ] - ( xx [ 390
] + xx [ 390 ] ) ; xx [ 390 ] = xx [ 297 ] / xx [ 366 ] ; xx [ 420 ] = xx [
361 ] * xx [ 390 ] ; xx [ 426 ] = xx [ 420 ] * xx [ 10 ] ; xx [ 428 ] = xx [
426 ] * xx [ 10 ] ; xx [ 432 ] = xx [ 22 ] * xx [ 420 ] ; xx [ 434 ] = xx [
316 ] * xx [ 390 ] ; xx [ 438 ] = xx [ 39 ] * xx [ 434 ] ; xx [ 439 ] = xx [
438 ] * xx [ 10 ] ; xx [ 457 ] = xx [ 22 ] * xx [ 434 ] ; xx [ 458 ] = xx [
457 ] * xx [ 10 ] ; xx [ 459 ] = xx [ 6 ] * ( xx [ 439 ] - xx [ 458 ] ) ; xx
[ 469 ] = xx [ 434 ] - ( xx [ 39 ] * xx [ 438 ] + xx [ 22 ] * xx [ 457 ] ) *
xx [ 6 ] ; xx [ 434 ] = ( xx [ 458 ] + xx [ 439 ] ) * xx [ 6 ] ; xx [ 470 ] =
xx [ 459 ] ; xx [ 471 ] = xx [ 469 ] ; xx [ 472 ] = - xx [ 434 ] ;
pm_math_Vector3_cross_ra ( xx + 320 , xx + 470 , xx + 473 ) ; xx [ 438 ] = xx
[ 421 ] + xx [ 459 ] ; xx [ 421 ] = xx [ 464 ] + xx [ 467 ] + xx [ 6 ] * ( xx
[ 432 ] * xx [ 10 ] - xx [ 39 ] * xx [ 426 ] ) + xx [ 474 ] ; xx [ 426 ] = xx
[ 465 ] + xx [ 468 ] + xx [ 420 ] - ( xx [ 22 ] * xx [ 432 ] + xx [ 428 ] ) *
xx [ 6 ] + xx [ 475 ] ; xx [ 420 ] = ( xx [ 438 ] * xx [ 244 ] - ( xx [ 421 ]
* xx [ 21 ] + xx [ 426 ] * xx [ 24 ] ) ) / xx [ 350 ] ; xx [ 457 ] = xx [ 463
] + xx [ 466 ] + ( xx [ 428 ] + xx [ 39 ] * xx [ 432 ] ) * xx [ 6 ] + xx [
473 ] - xx [ 67 ] * xx [ 420 ] ; xx [ 458 ] = xx [ 421 ] - xx [ 264 ] * xx [
420 ] ; xx [ 459 ] = xx [ 426 ] - xx [ 342 ] * xx [ 420 ] ;
pm_math_Quaternion_xform_ra ( xx + 266 , xx + 457 , xx + 463 ) ; xx [ 457 ] =
xx [ 438 ] - xx [ 265 ] * xx [ 420 ] ; xx [ 458 ] = xx [ 323 ] + xx [ 469 ] -
xx [ 46 ] * xx [ 420 ] ; xx [ 459 ] = xx [ 331 ] - xx [ 434 ] - xx [ 40 ] *
xx [ 420 ] ; pm_math_Quaternion_xform_ra ( xx + 266 , xx + 457 , xx + 465 ) ;
pm_math_Vector3_cross_ra ( xx + 191 , xx + 465 , xx + 457 ) ; xx [ 323 ] = (
xx [ 464 ] + xx [ 458 ] ) / xx [ 52 ] ; xx [ 457 ] = xx [ 465 ] - xx [ 323 ]
* xx [ 45 ] ; xx [ 458 ] = xx [ 466 ] - xx [ 323 ] * xx [ 54 ] ; xx [ 459 ] =
xx [ 467 ] - xx [ 323 ] * xx [ 56 ] ; pm_math_Quaternion_xform_ra ( xx + 194
, xx + 457 , xx + 463 ) ; xx [ 457 ] = - xx [ 463 ] ; xx [ 458 ] = - xx [ 464
] ; xx [ 459 ] = - xx [ 465 ] ; solveSymmetricPosDef ( xx + 401 , xx + 457 ,
3 , 1 , xx + 463 , xx + 466 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 194
, xx + 463 , xx + 457 ) ; xx [ 331 ] = xx [ 323 ] + pm_math_Vector3_dot_ra (
xx + 423 , xx + 457 ) ; xx [ 323 ] = xx [ 11 ] * xx [ 331 ] ; xx [ 421 ] = xx
[ 331 ] * xx [ 3 ] ; xx [ 426 ] = - ( ( xx [ 323 ] * xx [ 26 ] - xx [ 421 ] *
xx [ 5 ] ) * xx [ 6 ] ) ; xx [ 428 ] = ( xx [ 11 ] * xx [ 323 ] + xx [ 421 ]
* xx [ 3 ] ) * xx [ 6 ] - xx [ 331 ] ; xx [ 432 ] = xx [ 6 ] * ( xx [ 421 ] *
xx [ 26 ] + xx [ 323 ] * xx [ 5 ] ) ; xx [ 463 ] = xx [ 426 ] ; xx [ 464 ] =
xx [ 428 ] ; xx [ 465 ] = xx [ 432 ] ; xx [ 466 ] = xx [ 457 ] + xx [ 66 ] *
xx [ 331 ] ; xx [ 467 ] = xx [ 458 ] ; xx [ 468 ] = xx [ 459 ] - xx [ 331 ] *
xx [ 170 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx + 466 , xx +
457 ) ; xx [ 323 ] = xx [ 420 ] + pm_math_Vector3_dot_ra ( xx + 429 , xx +
463 ) + pm_math_Vector3_dot_ra ( xx + 435 , xx + 457 ) ; xx [ 463 ] = xx [
426 ] ; xx [ 464 ] = xx [ 428 ] + xx [ 323 ] * xx [ 21 ] ; xx [ 465 ] = xx [
432 ] + xx [ 323 ] * xx [ 24 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
416 , xx + 463 , xx + 466 ) ; xx [ 331 ] = xx [ 457 ] - xx [ 323 ] * xx [ 244
] ; pm_math_Vector3_cross_ra ( xx + 463 , xx + 290 , xx + 469 ) ; xx [ 472 ]
= xx [ 331 ] + xx [ 469 ] ; xx [ 473 ] = xx [ 458 ] + xx [ 470 ] ; xx [ 474 ]
= xx [ 459 ] + xx [ 471 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 ,
xx + 472 , xx + 469 ) ; xx [ 323 ] = pm_math_Vector3_dot_ra ( xx + 410 , xx +
466 ) + xx [ 164 ] * xx [ 469 ] + xx [ 174 ] * xx [ 470 ] ; xx [ 420 ] = xx [
154 ] * xx [ 467 ] ; xx [ 421 ] = xx [ 154 ] * xx [ 466 ] ; xx [ 426 ] = xx [
468 ] - xx [ 323 ] ; xx [ 471 ] = xx [ 466 ] - xx [ 6 ] * ( xx [ 420 ] * xx [
123 ] + xx [ 154 ] * xx [ 421 ] ) ; xx [ 472 ] = xx [ 467 ] - ( xx [ 154 ] *
xx [ 420 ] - xx [ 421 ] * xx [ 123 ] ) * xx [ 6 ] ; xx [ 473 ] = xx [ 426 ] ;
xx [ 420 ] = xx [ 469 ] + xx [ 167 ] * xx [ 426 ] ; xx [ 421 ] = xx [ 470 ] -
xx [ 323 ] * xx [ 160 ] + xx [ 165 ] * xx [ 426 ] ; xx [ 426 ] = xx [ 154 ] *
xx [ 421 ] ; xx [ 428 ] = xx [ 420 ] * xx [ 154 ] ; xx [ 432 ] =
pm_math_Vector3_dot_ra ( xx + 440 , xx + 471 ) + ( xx [ 420 ] - xx [ 6 ] * (
xx [ 426 ] * xx [ 123 ] + xx [ 154 ] * xx [ 428 ] ) ) * xx [ 152 ] + xx [ 142
] * ( xx [ 421 ] - ( xx [ 154 ] * xx [ 426 ] - xx [ 428 ] * xx [ 123 ] ) * xx
[ 6 ] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 463 , xx + 466
) ; pm_math_Vector3_cross_ra ( xx + 463 , xx + 337 , xx + 469 ) ; xx [ 472 ]
= xx [ 331 ] + xx [ 469 ] ; xx [ 473 ] = xx [ 458 ] + xx [ 470 ] ; xx [ 474 ]
= xx [ 459 ] + xx [ 471 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 446 ,
xx + 472 , xx + 469 ) ; xx [ 420 ] = xx [ 115 ] * xx [ 468 ] + xx [ 139 ] *
xx [ 470 ] ; xx [ 421 ] = xx [ 323 ] * xx [ 384 ] + xx [ 432 ] * xx [ 367 ] -
xx [ 420 ] * xx [ 334 ] ; xx [ 426 ] = xx [ 175 ] * xx [ 181 ] ; xx [ 428 ] =
xx [ 426 ] + xx [ 183 ] * xx [ 234 ] ; xx [ 434 ] = xx [ 426 ] + xx [ 23 ] *
xx [ 234 ] ; xx [ 426 ] = ( xx [ 344 ] * xx [ 428 ] + xx [ 348 ] * xx [ 434 ]
) * xx [ 6 ] ; xx [ 344 ] = ( xx [ 329 ] * xx [ 175 ] + xx [ 456 ] ) * xx [ 6
] - xx [ 426 ] ; xx [ 329 ] = xx [ 344 ] / xx [ 231 ] ; xx [ 348 ] = xx [ 352
] * xx [ 329 ] ; xx [ 438 ] = xx [ 234 ] * xx [ 348 ] ; xx [ 439 ] = xx [ 227
] * xx [ 329 ] ; xx [ 454 ] = xx [ 234 ] * xx [ 439 ] ; xx [ 455 ] = xx [ 230
] * xx [ 329 ] ; xx [ 456 ] = xx [ 234 ] * xx [ 455 ] ; xx [ 457 ] = xx [ 226
] * xx [ 329 ] ; xx [ 466 ] = xx [ 234 ] * xx [ 457 ] ; xx [ 467 ] = xx [ 6 ]
* ( xx [ 234 ] * xx [ 456 ] + xx [ 466 ] * xx [ 181 ] ) - xx [ 455 ] ; xx [
455 ] = ( xx [ 234 ] * xx [ 466 ] - xx [ 456 ] * xx [ 181 ] ) * xx [ 6 ] - xx
[ 457 ] ; xx [ 456 ] = xx [ 245 ] * xx [ 467 ] + xx [ 247 ] * xx [ 455 ] - xx
[ 228 ] * xx [ 329 ] ; xx [ 457 ] = ( xx [ 433 ] * xx [ 175 ] + xx [ 462 ] )
* xx [ 6 ] + ( xx [ 280 ] * xx [ 175 ] + xx [ 189 ] ) * xx [ 6 ] - xx [ 426 ]
; xx [ 189 ] = ( xx [ 456 ] + xx [ 160 ] * xx [ 467 ] + xx [ 457 ] ) / xx [
237 ] ; xx [ 460 ] = xx [ 6 ] * ( xx [ 438 ] * xx [ 181 ] + xx [ 234 ] * xx [
454 ] ) - xx [ 439 ] - xx [ 362 ] * xx [ 189 ] ; xx [ 461 ] = ( xx [ 454 ] *
xx [ 181 ] - xx [ 234 ] * xx [ 438 ] ) * xx [ 6 ] + xx [ 348 ] - xx [ 355 ] *
xx [ 189 ] ; xx [ 462 ] = xx [ 456 ] - xx [ 168 ] * xx [ 189 ] ;
pm_math_Quaternion_xform_ra ( xx + 450 , xx + 460 , xx + 468 ) ; xx [ 280 ] =
xx [ 455 ] - xx [ 240 ] * xx [ 189 ] ; xx [ 348 ] = xx [ 467 ] - xx [ 235 ] *
xx [ 189 ] ; xx [ 426 ] = xx [ 183 ] * xx [ 348 ] ; xx [ 433 ] = xx [ 183 ] *
xx [ 280 ] ; xx [ 438 ] = xx [ 23 ] * xx [ 348 ] - xx [ 175 ] * xx [ 280 ] ;
xx [ 454 ] = - xx [ 426 ] ; xx [ 455 ] = xx [ 433 ] ; xx [ 456 ] = xx [ 438 ]
; pm_math_Vector3_cross_ra ( xx + 413 , xx + 454 , xx + 460 ) ; xx [ 439 ] =
xx [ 280 ] + xx [ 6 ] * ( xx [ 460 ] - xx [ 426 ] * xx [ 175 ] ) ; xx [ 280 ]
= xx [ 348 ] + ( xx [ 433 ] * xx [ 175 ] + xx [ 461 ] ) * xx [ 6 ] ; xx [ 348
] = ( xx [ 438 ] * xx [ 175 ] + xx [ 462 ] ) * xx [ 6 ] ; xx [ 454 ] = xx [
439 ] ; xx [ 455 ] = xx [ 280 ] ; xx [ 456 ] = xx [ 348 ] ;
pm_math_Vector3_cross_ra ( xx + 371 , xx + 454 , xx + 460 ) ; xx [ 426 ] = (
xx [ 377 ] * xx [ 10 ] + xx [ 299 ] ) * xx [ 6 ] ; xx [ 299 ] = xx [ 426 ] +
xx [ 426 ] ; xx [ 377 ] = xx [ 299 ] / xx [ 366 ] ; xx [ 426 ] = xx [ 316 ] *
xx [ 377 ] ; xx [ 433 ] = xx [ 22 ] * xx [ 426 ] ; xx [ 438 ] = xx [ 433 ] *
xx [ 10 ] ; xx [ 454 ] = xx [ 39 ] * xx [ 426 ] ; xx [ 455 ] = xx [ 454 ] *
xx [ 10 ] ; xx [ 456 ] = xx [ 6 ] * ( xx [ 438 ] - xx [ 455 ] ) ; xx [ 466 ]
= ( xx [ 39 ] * xx [ 454 ] + xx [ 22 ] * xx [ 433 ] ) * xx [ 6 ] - xx [ 426 ]
; xx [ 426 ] = ( xx [ 438 ] + xx [ 455 ] ) * xx [ 6 ] ; xx [ 471 ] = xx [ 456
] ; xx [ 472 ] = xx [ 466 ] ; xx [ 473 ] = xx [ 426 ] ;
pm_math_Vector3_cross_ra ( xx + 320 , xx + 471 , xx + 474 ) ; xx [ 433 ] = xx
[ 361 ] * xx [ 377 ] ; xx [ 438 ] = xx [ 433 ] * xx [ 10 ] ; xx [ 454 ] = xx
[ 438 ] * xx [ 10 ] ; xx [ 455 ] = xx [ 22 ] * xx [ 433 ] ; xx [ 467 ] = xx [
439 ] + xx [ 456 ] ; xx [ 439 ] = xx [ 469 ] + xx [ 461 ] + xx [ 6 ] * ( xx [
39 ] * xx [ 438 ] - xx [ 455 ] * xx [ 10 ] ) + xx [ 475 ] ; xx [ 10 ] = xx [
470 ] + xx [ 462 ] + ( xx [ 22 ] * xx [ 455 ] + xx [ 454 ] ) * xx [ 6 ] - xx
[ 433 ] + xx [ 476 ] ; xx [ 22 ] = ( xx [ 467 ] * xx [ 244 ] - ( xx [ 439 ] *
xx [ 21 ] + xx [ 10 ] * xx [ 24 ] ) ) / xx [ 350 ] ; xx [ 469 ] = xx [ 468 ]
+ xx [ 460 ] + xx [ 474 ] - ( xx [ 454 ] + xx [ 39 ] * xx [ 455 ] ) * xx [ 6
] - xx [ 67 ] * xx [ 22 ] ; xx [ 470 ] = xx [ 439 ] - xx [ 264 ] * xx [ 22 ]
; xx [ 471 ] = xx [ 10 ] - xx [ 342 ] * xx [ 22 ] ;
pm_math_Quaternion_xform_ra ( xx + 266 , xx + 469 , xx + 454 ) ; xx [ 460 ] =
xx [ 467 ] - xx [ 265 ] * xx [ 22 ] ; xx [ 461 ] = xx [ 280 ] + xx [ 466 ] -
xx [ 46 ] * xx [ 22 ] ; xx [ 462 ] = xx [ 348 ] + xx [ 426 ] - xx [ 40 ] * xx
[ 22 ] ; pm_math_Quaternion_xform_ra ( xx + 266 , xx + 460 , xx + 466 ) ;
pm_math_Vector3_cross_ra ( xx + 191 , xx + 466 , xx + 460 ) ; xx [ 10 ] = (
xx [ 455 ] + xx [ 461 ] ) / xx [ 52 ] ; xx [ 454 ] = xx [ 466 ] - xx [ 10 ] *
xx [ 45 ] ; xx [ 455 ] = xx [ 467 ] - xx [ 10 ] * xx [ 54 ] ; xx [ 456 ] = xx
[ 468 ] - xx [ 10 ] * xx [ 56 ] ; pm_math_Quaternion_xform_ra ( xx + 194 , xx
+ 454 , xx + 460 ) ; xx [ 454 ] = - xx [ 460 ] ; xx [ 455 ] = - xx [ 461 ] ;
xx [ 456 ] = - xx [ 462 ] ; solveSymmetricPosDef ( xx + 401 , xx + 454 , 3 ,
1 , xx + 460 , xx + 466 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 194 ,
xx + 460 , xx + 454 ) ; xx [ 39 ] = xx [ 10 ] + pm_math_Vector3_dot_ra ( xx +
423 , xx + 454 ) ; xx [ 10 ] = xx [ 11 ] * xx [ 39 ] ; xx [ 280 ] = xx [ 39 ]
* xx [ 3 ] ; xx [ 348 ] = - ( ( xx [ 10 ] * xx [ 26 ] - xx [ 280 ] * xx [ 5 ]
) * xx [ 6 ] ) ; xx [ 426 ] = ( xx [ 11 ] * xx [ 10 ] + xx [ 280 ] * xx [ 3 ]
) * xx [ 6 ] - xx [ 39 ] ; xx [ 433 ] = xx [ 6 ] * ( xx [ 280 ] * xx [ 26 ] +
xx [ 10 ] * xx [ 5 ] ) ; xx [ 460 ] = xx [ 348 ] ; xx [ 461 ] = xx [ 426 ] ;
xx [ 462 ] = xx [ 433 ] ; xx [ 466 ] = xx [ 454 ] + xx [ 66 ] * xx [ 39 ] ;
xx [ 467 ] = xx [ 455 ] ; xx [ 468 ] = xx [ 456 ] - xx [ 39 ] * xx [ 170 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx + 466 , xx + 454 ) ; xx [
10 ] = xx [ 22 ] + pm_math_Vector3_dot_ra ( xx + 429 , xx + 460 ) +
pm_math_Vector3_dot_ra ( xx + 435 , xx + 454 ) ; xx [ 460 ] = xx [ 348 ] ; xx
[ 461 ] = xx [ 426 ] + xx [ 10 ] * xx [ 21 ] ; xx [ 462 ] = xx [ 433 ] + xx [
10 ] * xx [ 24 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 460 ,
xx + 466 ) ; xx [ 22 ] = xx [ 454 ] - xx [ 10 ] * xx [ 244 ] ;
pm_math_Vector3_cross_ra ( xx + 460 , xx + 290 , xx + 469 ) ; xx [ 472 ] = xx
[ 22 ] + xx [ 469 ] ; xx [ 473 ] = xx [ 455 ] + xx [ 470 ] ; xx [ 474 ] = xx
[ 456 ] + xx [ 471 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx +
472 , xx + 469 ) ; xx [ 10 ] = pm_math_Vector3_dot_ra ( xx + 410 , xx + 466 )
+ xx [ 164 ] * xx [ 469 ] + xx [ 174 ] * xx [ 470 ] ; xx [ 39 ] = xx [ 154 ]
* xx [ 467 ] ; xx [ 280 ] = xx [ 154 ] * xx [ 466 ] ; xx [ 348 ] = xx [ 468 ]
- xx [ 10 ] ; xx [ 471 ] = xx [ 466 ] - xx [ 6 ] * ( xx [ 39 ] * xx [ 123 ] +
xx [ 154 ] * xx [ 280 ] ) ; xx [ 472 ] = xx [ 467 ] - ( xx [ 154 ] * xx [ 39
] - xx [ 280 ] * xx [ 123 ] ) * xx [ 6 ] ; xx [ 473 ] = xx [ 348 ] ; xx [ 39
] = xx [ 469 ] + xx [ 167 ] * xx [ 348 ] ; xx [ 280 ] = xx [ 470 ] - xx [ 10
] * xx [ 160 ] + xx [ 165 ] * xx [ 348 ] ; xx [ 348 ] = xx [ 154 ] * xx [ 280
] ; xx [ 426 ] = xx [ 39 ] * xx [ 154 ] ; xx [ 433 ] = pm_math_Vector3_dot_ra
( xx + 440 , xx + 471 ) + ( xx [ 39 ] - xx [ 6 ] * ( xx [ 348 ] * xx [ 123 ]
+ xx [ 154 ] * xx [ 426 ] ) ) * xx [ 152 ] + xx [ 142 ] * ( xx [ 280 ] - ( xx
[ 154 ] * xx [ 348 ] - xx [ 426 ] * xx [ 123 ] ) * xx [ 6 ] ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 460 , xx + 466 ) ;
pm_math_Vector3_cross_ra ( xx + 460 , xx + 337 , xx + 469 ) ; xx [ 472 ] = xx
[ 22 ] + xx [ 469 ] ; xx [ 473 ] = xx [ 455 ] + xx [ 470 ] ; xx [ 474 ] = xx
[ 456 ] + xx [ 471 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx +
472 , xx + 469 ) ; xx [ 39 ] = xx [ 115 ] * xx [ 468 ] + xx [ 139 ] * xx [
470 ] ; xx [ 280 ] = xx [ 10 ] * xx [ 384 ] + xx [ 433 ] * xx [ 367 ] - xx [
39 ] * xx [ 334 ] ; xx [ 348 ] = xx [ 323 ] * xx [ 346 ] + xx [ 432 ] * xx [
276 ] + xx [ 330 ] * xx [ 420 ] ; xx [ 323 ] = xx [ 10 ] * xx [ 346 ] + xx [
433 ] * xx [ 276 ] + xx [ 330 ] * xx [ 39 ] ; xx [ 466 ] = xx [ 289 ] ; xx [
467 ] = xx [ 162 ] ; xx [ 468 ] = xx [ 242 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 463 , xx + 469 ) ;
pm_math_Vector3_cross_ra ( xx + 463 , xx + 371 , xx + 472 ) ; xx [ 475 ] = xx
[ 331 ] + xx [ 472 ] ; xx [ 476 ] = xx [ 458 ] + xx [ 473 ] ; xx [ 477 ] = xx
[ 459 ] + xx [ 474 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx +
475 , xx + 472 ) ; xx [ 10 ] = xx [ 185 ] + pm_math_Vector3_dot_ra ( xx + 466
, xx + 469 ) + xx [ 239 ] * xx [ 472 ] + xx [ 250 ] * xx [ 473 ] ; xx [ 474 ]
= xx [ 357 ] ; xx [ 475 ] = - xx [ 294 ] ; xx [ 476 ] = xx [ 249 ] ; xx [ 39
] = xx [ 234 ] * xx [ 470 ] ; xx [ 162 ] = xx [ 234 ] * xx [ 469 ] ; xx [ 185
] = xx [ 471 ] - xx [ 10 ] ; xx [ 477 ] = xx [ 469 ] - xx [ 6 ] * ( xx [ 39 ]
* xx [ 181 ] + xx [ 234 ] * xx [ 162 ] ) ; xx [ 478 ] = xx [ 470 ] - ( xx [
234 ] * xx [ 39 ] - xx [ 162 ] * xx [ 181 ] ) * xx [ 6 ] ; xx [ 479 ] = xx [
185 ] ; xx [ 39 ] = xx [ 472 ] + xx [ 247 ] * xx [ 185 ] ; xx [ 162 ] = xx [
473 ] - xx [ 10 ] * xx [ 160 ] + xx [ 245 ] * xx [ 185 ] ; xx [ 185 ] = xx [
234 ] * xx [ 162 ] ; xx [ 242 ] = xx [ 39 ] * xx [ 234 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 463 , xx + 469 ) ;
pm_math_Vector3_cross_ra ( xx + 463 , xx + 320 , xx + 480 ) ; xx [ 463 ] = xx
[ 331 ] + xx [ 480 ] ; xx [ 464 ] = xx [ 458 ] + xx [ 481 ] ; xx [ 465 ] = xx
[ 459 ] + xx [ 482 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx +
463 , xx + 480 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 460 ,
xx + 463 ) ; pm_math_Vector3_cross_ra ( xx + 460 , xx + 371 , xx + 482 ) ; xx
[ 485 ] = xx [ 22 ] + xx [ 482 ] ; xx [ 486 ] = xx [ 455 ] + xx [ 483 ] ; xx
[ 487 ] = xx [ 456 ] + xx [ 484 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
450 , xx + 485 , xx + 482 ) ; xx [ 249 ] = xx [ 189 ] +
pm_math_Vector3_dot_ra ( xx + 466 , xx + 463 ) + xx [ 239 ] * xx [ 482 ] + xx
[ 250 ] * xx [ 483 ] ; xx [ 189 ] = xx [ 234 ] * xx [ 464 ] ; xx [ 289 ] = xx
[ 234 ] * xx [ 463 ] ; xx [ 294 ] = xx [ 465 ] - xx [ 249 ] ; xx [ 484 ] = xx
[ 463 ] - xx [ 6 ] * ( xx [ 189 ] * xx [ 181 ] + xx [ 234 ] * xx [ 289 ] ) ;
xx [ 485 ] = xx [ 464 ] - ( xx [ 234 ] * xx [ 189 ] - xx [ 289 ] * xx [ 181 ]
) * xx [ 6 ] ; xx [ 486 ] = xx [ 294 ] ; xx [ 189 ] = xx [ 482 ] + xx [ 247 ]
* xx [ 294 ] ; xx [ 289 ] = xx [ 483 ] - xx [ 249 ] * xx [ 160 ] + xx [ 245 ]
* xx [ 294 ] ; xx [ 294 ] = xx [ 234 ] * xx [ 289 ] ; xx [ 331 ] = xx [ 189 ]
* xx [ 234 ] ; xx [ 357 ] = xx [ 329 ] + pm_math_Vector3_dot_ra ( xx + 474 ,
xx + 484 ) + ( xx [ 189 ] - xx [ 6 ] * ( xx [ 294 ] * xx [ 181 ] + xx [ 234 ]
* xx [ 331 ] ) ) * xx [ 232 ] + xx [ 224 ] * ( xx [ 289 ] - ( xx [ 234 ] * xx
[ 294 ] - xx [ 331 ] * xx [ 181 ] ) * xx [ 6 ] ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 460 , xx + 463 ) ;
pm_math_Vector3_cross_ra ( xx + 460 , xx + 320 , xx + 482 ) ; xx [ 458 ] = xx
[ 22 ] + xx [ 482 ] ; xx [ 459 ] = xx [ 455 ] + xx [ 483 ] ; xx [ 460 ] = xx
[ 456 ] + xx [ 484 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx +
458 , xx + 454 ) ; xx [ 22 ] = xx [ 377 ] + xx [ 115 ] * xx [ 465 ] + xx [
139 ] * xx [ 455 ] ; xx [ 189 ] = xx [ 249 ] * xx [ 318 ] + xx [ 357 ] * xx [
379 ] - xx [ 297 ] * xx [ 22 ] ; xx [ 482 ] = xx [ 71 ] * xx [ 384 ] + ( xx [
370 ] + pm_math_Vector3_dot_ra ( xx + 440 , xx + 443 ) + ( xx [ 75 ] - xx [ 6
] * ( xx [ 109 ] * xx [ 123 ] + xx [ 154 ] * xx [ 111 ] ) ) * xx [ 152 ] + xx
[ 142 ] * ( xx [ 94 ] - ( xx [ 154 ] * xx [ 109 ] - xx [ 111 ] * xx [ 123 ] )
* xx [ 6 ] ) ) * xx [ 367 ] + xx [ 334 ] * ( xx [ 378 ] - ( xx [ 115 ] * xx [
422 ] + xx [ 139 ] * xx [ 427 ] ) ) ; xx [ 483 ] = xx [ 59 ] ; xx [ 484 ] =
xx [ 421 ] ; xx [ 485 ] = xx [ 280 ] ; xx [ 486 ] = xx [ 59 ] ; xx [ 487 ] =
xx [ 58 ] * xx [ 346 ] + xx [ 335 ] * xx [ 276 ] + xx [ 330 ] * xx [ 50 ] ;
xx [ 488 ] = xx [ 348 ] ; xx [ 489 ] = xx [ 323 ] ; xx [ 490 ] = xx [ 421 ] ;
xx [ 491 ] = xx [ 348 ] ; xx [ 492 ] = xx [ 10 ] * xx [ 318 ] + ( xx [ 387 ]
+ pm_math_Vector3_dot_ra ( xx + 474 , xx + 477 ) + ( xx [ 39 ] - xx [ 6 ] * (
xx [ 185 ] * xx [ 181 ] + xx [ 234 ] * xx [ 242 ] ) ) * xx [ 232 ] + xx [ 224
] * ( xx [ 162 ] - ( xx [ 234 ] * xx [ 185 ] - xx [ 242 ] * xx [ 181 ] ) * xx
[ 6 ] ) ) * xx [ 379 ] + xx [ 297 ] * ( xx [ 390 ] - ( xx [ 115 ] * xx [ 471
] + xx [ 139 ] * xx [ 481 ] ) ) ; xx [ 493 ] = xx [ 189 ] ; xx [ 494 ] = xx [
280 ] ; xx [ 495 ] = xx [ 323 ] ; xx [ 496 ] = xx [ 189 ] ; xx [ 497 ] = xx [
249 ] * xx [ 457 ] + xx [ 357 ] * xx [ 344 ] + xx [ 299 ] * xx [ 22 ] ; xx [
10 ] = 5.729577951308232e5 ; xx [ 22 ] = 0.4 ; xx [ 39 ] = 0.0 ; xx [ 50 ] =
state [ 16 ] + xx [ 22 ] ; if ( xx [ 39 ] > xx [ 50 ] ) xx [ 50 ] = xx [ 39 ]
; xx [ 58 ] = 572.9577951308231 ; xx [ 59 ] = 1.74532925199433e-3 ; xx [ 71 ]
= xx [ 50 ] / xx [ 59 ] ; if ( xx [ 7 ] < xx [ 71 ] ) xx [ 71 ] = xx [ 7 ] ;
xx [ 75 ] = 3.0 ; xx [ 94 ] = ( xx [ 10 ] * xx [ 50 ] + ( xx [ 50 ] == xx [
39 ] ? xx [ 39 ] : xx [ 58 ] * state [ 17 ] ) ) * xx [ 71 ] * xx [ 71 ] * (
xx [ 75 ] - xx [ 6 ] * xx [ 71 ] ) ; if ( xx [ 39 ] > xx [ 94 ] ) xx [ 94 ] =
xx [ 39 ] ; xx [ 50 ] = input [ 1 ] - xx [ 94 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 301 , xx + 420 ) ; xx [
71 ] = xx [ 422 ] + state [ 17 ] ; xx [ 443 ] = xx [ 420 ] ; xx [ 444 ] = xx
[ 421 ] ; xx [ 445 ] = xx [ 71 ] ; xx [ 454 ] = xx [ 60 ] * xx [ 420 ] ; xx [
455 ] = xx [ 91 ] * xx [ 421 ] ; xx [ 456 ] = xx [ 71 ] * xx [ 172 ] ;
pm_math_Vector3_cross_ra ( xx + 443 , xx + 454 , xx + 458 ) ; xx [ 94 ] = xx
[ 154 ] * xx [ 421 ] ; xx [ 109 ] = xx [ 154 ] * xx [ 420 ] ; xx [ 111 ] = xx
[ 420 ] - xx [ 6 ] * ( xx [ 94 ] * xx [ 123 ] + xx [ 154 ] * xx [ 109 ] ) ;
xx [ 162 ] = xx [ 421 ] - ( xx [ 154 ] * xx [ 94 ] - xx [ 109 ] * xx [ 123 ]
) * xx [ 6 ] ; xx [ 94 ] = xx [ 71 ] + state [ 19 ] ; xx [ 454 ] = xx [ 111 ]
; xx [ 455 ] = xx [ 162 ] ; xx [ 456 ] = xx [ 94 ] ; xx [ 461 ] = xx [ 111 ]
* xx [ 65 ] ; xx [ 462 ] = xx [ 130 ] * xx [ 162 ] ; xx [ 463 ] = xx [ 94 ] *
xx [ 146 ] ; pm_math_Vector3_cross_ra ( xx + 454 , xx + 461 , xx + 469 ) ; xx
[ 109 ] = xx [ 136 ] * xx [ 162 ] ; xx [ 185 ] = xx [ 111 ] * xx [ 136 ] ; xx
[ 189 ] = xx [ 111 ] + xx [ 6 ] * ( xx [ 131 ] * xx [ 109 ] - xx [ 185 ] * xx
[ 136 ] ) ; xx [ 242 ] = xx [ 162 ] - ( xx [ 131 ] * xx [ 185 ] + xx [ 109 ]
* xx [ 136 ] ) * xx [ 6 ] ; xx [ 109 ] = xx [ 94 ] + state [ 21 ] ; xx [ 461
] = xx [ 189 ] ; xx [ 462 ] = xx [ 242 ] ; xx [ 463 ] = xx [ 109 ] ; xx [ 185
] = 3.776314159265359e-3 ; xx [ 477 ] = xx [ 189 ] * xx [ 79 ] ; xx [ 478 ] =
xx [ 79 ] * xx [ 242 ] ; xx [ 479 ] = xx [ 109 ] * xx [ 185 ] ;
pm_math_Vector3_cross_ra ( xx + 461 , xx + 477 , xx + 498 ) ; xx [ 501 ] = xx
[ 7 ] ; xx [ 502 ] = xx [ 39 ] ; xx [ 503 ] = xx [ 39 ] ; xx [ 504 ] = xx [
39 ] ; xx [ 505 ] = xx [ 39 ] ; xx [ 506 ] = xx [ 39 ] ; xx [ 507 ] = xx [ 39
] ; xx [ 249 ] = xx [ 1 ] * xx [ 8 ] ; xx [ 8 ] = xx [ 1 ] * xx [ 4 ] ; xx [
461 ] = xx [ 249 ] - xx [ 8 ] ; xx [ 462 ] = - ( xx [ 8 ] + xx [ 249 ] ) ; xx
[ 463 ] = - ( xx [ 249 ] + xx [ 8 ] ) ; xx [ 464 ] = xx [ 8 ] - xx [ 249 ] ;
pm_math_Quaternion_compose_ra ( xx + 461 , xx + 266 , xx + 477 ) ;
pm_math_Quaternion_compose_ra ( xx + 477 , xx + 416 , xx + 508 ) ; xx [ 1 ] =
xx [ 511 ] * xx [ 123 ] - xx [ 154 ] * xx [ 508 ] ; xx [ 4 ] = xx [ 508 ] *
xx [ 123 ] + xx [ 154 ] * xx [ 511 ] ; xx [ 8 ] = xx [ 1 ] * xx [ 136 ] - xx
[ 131 ] * xx [ 4 ] ; xx [ 249 ] = xx [ 509 ] * xx [ 123 ] - xx [ 154 ] * xx [
510 ] ; xx [ 280 ] = xx [ 510 ] * xx [ 123 ] + xx [ 154 ] * xx [ 509 ] ; xx [
289 ] = xx [ 249 ] * xx [ 131 ] + xx [ 136 ] * xx [ 280 ] ; xx [ 294 ] = xx [
249 ] * xx [ 136 ] - xx [ 131 ] * xx [ 280 ] ; xx [ 323 ] = xx [ 136 ] * xx [
4 ] + xx [ 1 ] * xx [ 131 ] ; xx [ 329 ] = xx [ 251 ] * xx [ 280 ] ; xx [ 512
] = xx [ 249 ] ; xx [ 513 ] = xx [ 280 ] ; xx [ 514 ] = xx [ 1 ] ; xx [ 331 ]
= xx [ 1 ] * xx [ 141 ] - xx [ 249 ] * xx [ 251 ] ; xx [ 1 ] = xx [ 141 ] *
xx [ 280 ] ; xx [ 515 ] = xx [ 329 ] ; xx [ 516 ] = xx [ 331 ] ; xx [ 517 ] =
- xx [ 1 ] ; pm_math_Vector3_cross_ra ( xx + 512 , xx + 515 , xx + 518 ) ; xx
[ 249 ] = xx [ 511 ] * xx [ 167 ] ; xx [ 280 ] = xx [ 165 ] * xx [ 511 ] ; xx
[ 335 ] = xx [ 509 ] * xx [ 167 ] + xx [ 165 ] * xx [ 510 ] ; xx [ 512 ] = xx
[ 249 ] ; xx [ 513 ] = xx [ 280 ] ; xx [ 514 ] = - xx [ 335 ] ;
pm_math_Vector3_cross_ra ( xx + 509 , xx + 512 , xx + 515 ) ;
pm_math_Quaternion_xform_ra ( xx + 477 , xx + 290 , xx + 509 ) ;
pm_math_Quaternion_xform_ra ( xx + 461 , xx + 191 , xx + 512 ) ; xx [ 348 ] =
xx [ 512 ] + state [ 2 ] ; xx [ 357 ] = 7.944796046594101e-5 ; xx [ 370 ] =
xx [ 357 ] * xx [ 294 ] ; xx [ 377 ] = xx [ 289 ] * xx [ 357 ] ; xx [ 378 ] =
xx [ 513 ] + state [ 1 ] ; xx [ 387 ] = xx [ 514 ] - state [ 0 ] + 0.8 ; xx [
521 ] = - xx [ 8 ] ; xx [ 522 ] = xx [ 289 ] ; xx [ 523 ] = - xx [ 294 ] ; xx
[ 524 ] = xx [ 323 ] ; xx [ 525 ] = ( xx [ 329 ] * xx [ 4 ] + xx [ 518 ] ) *
xx [ 6 ] + xx [ 165 ] + ( xx [ 508 ] * xx [ 249 ] + xx [ 515 ] ) * xx [ 6 ] +
xx [ 509 ] + xx [ 348 ] + xx [ 141 ] - ( xx [ 370 ] * xx [ 8 ] + xx [ 323 ] *
xx [ 377 ] ) * xx [ 6 ] ; xx [ 526 ] = xx [ 6 ] * ( xx [ 323 ] * xx [ 370 ] -
xx [ 377 ] * xx [ 8 ] ) + ( xx [ 331 ] * xx [ 4 ] + xx [ 519 ] ) * xx [ 6 ] +
( xx [ 508 ] * xx [ 280 ] + xx [ 516 ] ) * xx [ 6 ] - xx [ 167 ] + xx [ 510 ]
+ xx [ 378 ] ; xx [ 527 ] = ( xx [ 289 ] * xx [ 377 ] + xx [ 370 ] * xx [ 294
] ) * xx [ 6 ] - xx [ 357 ] + xx [ 6 ] * ( xx [ 520 ] - xx [ 1 ] * xx [ 4 ] )
+ xx [ 6 ] * ( xx [ 517 ] - xx [ 335 ] * xx [ 508 ] ) + xx [ 511 ] + xx [ 387
] + xx [ 251 ] ; bb [ 0 ] =
sm_core_compiler_computeProximityInfoBrickCylinder (
series_link_blance_leg_ad6bcbee_1_geometry_1 ( NULL ) ,
series_link_blance_leg_ad6bcbee_1_geometry_0 ( NULL ) , ( pm_math_Transform3
* ) ( xx + 501 ) , ( pm_math_Transform3 * ) ( xx + 521 ) , xx + 1 , (
pm_math_Vector3 * ) ( xx + 461 ) , ( pm_math_Vector3 * ) ( xx + 508 ) , (
pm_math_Vector3 * ) ( xx + 511 ) , ( pm_math_Vector3 * ) ( xx + 514 ) ) ; xx
[ 4 ] = - xx [ 7 ] ; xx [ 528 ] = xx [ 4 ] ; xx [ 529 ] = xx [ 39 ] ; xx [
530 ] = xx [ 39 ] ; xx [ 531 ] = xx [ 39 ] ; xx [ 532 ] = xx [ 39 ] ; xx [
533 ] = xx [ 39 ] ; xx [ 534 ] = - xx [ 357 ] ; xx [ 8 ] = xx [ 251 ] * xx [
162 ] ; xx [ 249 ] = xx [ 71 ] * xx [ 167 ] ; pm_math_Vector3_cross_ra ( xx +
301 , xx + 290 , xx + 517 ) ; xx [ 535 ] = state [ 3 ] ; xx [ 536 ] = state [
4 ] ; xx [ 537 ] = state [ 5 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
194 , xx + 535 , xx + 538 ) ; xx [ 280 ] = xx [ 66 ] * state [ 7 ] ; xx [ 289
] = xx [ 170 ] * state [ 7 ] ; xx [ 535 ] = xx [ 538 ] - xx [ 280 ] ; xx [
536 ] = xx [ 539 ] ; xx [ 537 ] = xx [ 289 ] + xx [ 540 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx + 535 , xx + 538 ) ; xx [
294 ] = xx [ 244 ] * state [ 9 ] ; xx [ 323 ] = xx [ 538 ] + xx [ 294 ] ; xx
[ 535 ] = xx [ 517 ] + xx [ 323 ] ; xx [ 536 ] = xx [ 518 ] + xx [ 539 ] ; xx
[ 537 ] = xx [ 519 ] + xx [ 540 ] ; pm_math_Quaternion_inverseXform_ra ( xx +
416 , xx + 535 , xx + 541 ) ; xx [ 329 ] = xx [ 249 ] + xx [ 541 ] ; xx [ 331
] = xx [ 71 ] * xx [ 165 ] ; xx [ 335 ] = xx [ 160 ] * state [ 17 ] ; xx [
370 ] = xx [ 331 ] + xx [ 542 ] + xx [ 335 ] ; xx [ 377 ] = xx [ 370 ] * xx [
154 ] ; xx [ 390 ] = xx [ 329 ] * xx [ 154 ] ; xx [ 426 ] = xx [ 8 ] + xx [
329 ] - xx [ 6 ] * ( xx [ 377 ] * xx [ 123 ] + xx [ 154 ] * xx [ 390 ] ) ; xx
[ 329 ] = xx [ 94 ] * xx [ 141 ] - xx [ 111 ] * xx [ 251 ] ; xx [ 427 ] = xx
[ 144 ] * state [ 19 ] ; xx [ 432 ] = xx [ 329 ] + xx [ 370 ] - ( xx [ 154 ]
* xx [ 377 ] - xx [ 390 ] * xx [ 123 ] ) * xx [ 6 ] + xx [ 427 ] ; xx [ 370 ]
= xx [ 432 ] * xx [ 136 ] ; xx [ 377 ] = xx [ 426 ] * xx [ 136 ] ; xx [ 390 ]
= xx [ 420 ] * xx [ 167 ] + xx [ 165 ] * xx [ 421 ] ; xx [ 433 ] = xx [ 141 ]
* xx [ 162 ] ; xx [ 544 ] = xx [ 189 ] ; xx [ 545 ] = xx [ 242 ] ; xx [ 546 ]
= xx [ 109 ] ; xx [ 547 ] = xx [ 426 ] + xx [ 6 ] * ( xx [ 131 ] * xx [ 370 ]
- xx [ 377 ] * xx [ 136 ] ) ; xx [ 548 ] = xx [ 432 ] - ( xx [ 131 ] * xx [
377 ] + xx [ 370 ] * xx [ 136 ] ) * xx [ 6 ] ; xx [ 549 ] = xx [ 543 ] - xx [
390 ] - xx [ 433 ] ; xx [ 109 ] = 1.0e6 ; xx [ 370 ] = 1000.0 ; xx [ 377 ] =
1.0e-4 ; xx [ 426 ] = 0.3 ; xx [ 432 ] = 0.2119573811760597 ; xx [ 438 ] =
9.126024771145405e-4 ; sm_core_compiler_computeContactWrenches ( 0 , 1 , bb [
0 ] , xx + 1 , ( const pm_math_Vector3 * ) ( xx + 461 ) , ( const
pm_math_Vector3 * ) ( xx + 508 ) , ( const pm_math_Vector3 * ) ( xx + 511 ) ,
( const pm_math_Vector3 * ) ( xx + 514 ) , ( const pm_math_Transform3 * ) (
xx + 501 ) , ( const pm_math_Transform3 * ) ( xx + 528 ) , ( const
pm_math_Transform3 * ) ( xx + 501 ) , ( const pm_math_Transform3 * ) ( xx +
521 ) , NULL , ( const pm_math_SpatialVector * ) ( xx + 544 ) , 0 , 1 , xx [
109 ] , xx [ 370 ] , xx [ 377 ] , xx [ 426 ] , xx [ 432 ] , xx [ 438 ] , NULL
, NULL , NULL , ( pm_math_SpatialVector * ) ( xx + 550 ) ) ; xx [ 1 ] = xx [
500 ] - xx [ 552 ] ; xx [ 439 ] = input [ 3 ] - xx [ 1 ] ; xx [ 461 ] = xx [
8 ] ; xx [ 462 ] = xx [ 329 ] ; xx [ 463 ] = - xx [ 433 ] ;
pm_math_Vector3_cross_ra ( xx + 454 , xx + 461 , xx + 508 ) ; xx [ 8 ] = xx [
508 ] * xx [ 136 ] ; xx [ 329 ] = xx [ 509 ] * xx [ 136 ] ; xx [ 433 ] = xx [
129 ] * ( xx [ 509 ] - ( xx [ 131 ] * xx [ 8 ] + xx [ 329 ] * xx [ 136 ] ) *
xx [ 6 ] ) - xx [ 554 ] ; xx [ 461 ] = ( xx [ 508 ] + xx [ 6 ] * ( xx [ 131 ]
* xx [ 329 ] - xx [ 8 ] * xx [ 136 ] ) ) * xx [ 129 ] - xx [ 553 ] ; xx [ 8 ]
= xx [ 136 ] * xx [ 461 ] ; xx [ 329 ] = xx [ 136 ] * xx [ 433 ] ; xx [ 462 ]
= xx [ 433 ] + xx [ 6 ] * ( xx [ 131 ] * xx [ 8 ] - xx [ 329 ] * xx [ 136 ] )
; xx [ 433 ] = xx [ 462 ] * xx [ 141 ] ; xx [ 463 ] = xx [ 249 ] ; xx [ 464 ]
= xx [ 331 ] ; xx [ 465 ] = - xx [ 390 ] ; pm_math_Vector3_cross_ra ( xx +
443 , xx + 463 , xx + 511 ) ; xx [ 249 ] = xx [ 154 ] * xx [ 512 ] ; xx [ 331
] = xx [ 154 ] * xx [ 511 ] ; xx [ 390 ] = xx [ 511 ] - xx [ 6 ] * ( xx [ 249
] * xx [ 123 ] + xx [ 154 ] * xx [ 331 ] ) - ( xx [ 71 ] + xx [ 94 ] ) * xx [
427 ] ; xx [ 94 ] = xx [ 512 ] - ( xx [ 154 ] * xx [ 249 ] - xx [ 331 ] * xx
[ 123 ] ) * xx [ 6 ] ; xx [ 249 ] = xx [ 162 ] * state [ 19 ] ; xx [ 162 ] =
xx [ 111 ] * state [ 19 ] ; xx [ 331 ] = xx [ 143 ] * xx [ 390 ] + xx [ 135 ]
* xx [ 94 ] - ( xx [ 133 ] * xx [ 249 ] + xx [ 162 ] * xx [ 277 ] ) ; xx [
133 ] = xx [ 471 ] + xx [ 1 ] + xx [ 439 ] + xx [ 433 ] + xx [ 331 ] ; xx [
135 ] = xx [ 462 ] + xx [ 390 ] * xx [ 158 ] + xx [ 149 ] * xx [ 94 ] - ( xx
[ 253 ] * xx [ 249 ] + xx [ 162 ] * xx [ 261 ] ) ; xx [ 143 ] = xx [ 135 ] *
xx [ 144 ] ; xx [ 149 ] = ( xx [ 133 ] + xx [ 143 ] ) / xx [ 151 ] ; xx [ 158
] = xx [ 135 ] - xx [ 150 ] * xx [ 149 ] ; xx [ 277 ] = xx [ 461 ] - ( xx [
131 ] * xx [ 329 ] + xx [ 8 ] * xx [ 136 ] ) * xx [ 6 ] ; xx [ 8 ] = xx [ 277
] + xx [ 140 ] * xx [ 390 ] + xx [ 94 ] * xx [ 134 ] - ( xx [ 256 ] * xx [
249 ] + xx [ 162 ] * xx [ 260 ] ) ; xx [ 134 ] = xx [ 8 ] - xx [ 145 ] * xx [
149 ] ; xx [ 140 ] = xx [ 154 ] * xx [ 134 ] ; xx [ 329 ] = xx [ 154 ] * xx [
158 ] ; xx [ 443 ] = xx [ 158 ] - xx [ 6 ] * ( xx [ 140 ] * xx [ 123 ] + xx [
154 ] * xx [ 329 ] ) ; xx [ 158 ] = xx [ 134 ] - ( xx [ 154 ] * xx [ 140 ] -
xx [ 329 ] * xx [ 123 ] ) * xx [ 6 ] ; xx [ 134 ] = xx [ 421 ] * state [ 17 ]
; xx [ 140 ] = xx [ 420 ] * state [ 17 ] ; pm_math_Vector3_cross_ra ( xx +
301 , xx + 517 , xx + 463 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 416 ,
xx + 463 , xx + 514 ) ; xx [ 329 ] = xx [ 514 ] - ( xx [ 422 ] + xx [ 71 ] )
* xx [ 335 ] ; xx [ 71 ] = xx [ 279 ] * xx [ 134 ] - xx [ 263 ] * xx [ 140 ]
+ xx [ 156 ] * xx [ 329 ] + xx [ 126 ] * xx [ 515 ] ; xx [ 126 ] = xx [ 460 ]
+ xx [ 133 ] - xx [ 148 ] * xx [ 149 ] + xx [ 165 ] * xx [ 443 ] + xx [ 167 ]
* xx [ 158 ] + xx [ 71 ] ; xx [ 133 ] = xx [ 134 ] * xx [ 258 ] - xx [ 259 ]
* xx [ 140 ] + xx [ 163 ] * xx [ 329 ] + xx [ 153 ] * xx [ 515 ] ; xx [ 153 ]
= xx [ 443 ] + xx [ 133 ] ; xx [ 156 ] = ( xx [ 50 ] - ( xx [ 126 ] + xx [
153 ] * xx [ 160 ] ) ) / xx [ 157 ] ; xx [ 163 ] = xx [ 55 ] * xx [ 116 ] +
xx [ 118 ] * xx [ 121 ] ; xx [ 443 ] = xx [ 63 ] * xx [ 104 ] ; xx [ 444 ] =
xx [ 120 ] * xx [ 132 ] ; xx [ 445 ] = - ( xx [ 57 ] * xx [ 312 ] ) ;
pm_math_Vector3_cross_ra ( xx + 301 , xx + 443 , xx + 463 ) ; xx [ 443 ] = xx
[ 313 ] ; xx [ 444 ] = xx [ 314 ] ; xx [ 445 ] = xx [ 122 ] ; xx [ 517 ] = xx
[ 278 ] * xx [ 313 ] ; xx [ 518 ] = xx [ 361 ] * xx [ 314 ] ; xx [ 519 ] = xx
[ 122 ] * xx [ 361 ] ; pm_math_Vector3_cross_ra ( xx + 443 , xx + 517 , xx +
520 ) ; xx [ 63 ] = xx [ 520 ] + xx [ 278 ] * xx [ 314 ] * state [ 25 ] ; xx
[ 132 ] = xx [ 521 ] - xx [ 361 ] * xx [ 313 ] * state [ 25 ] ; xx [ 263 ] =
xx [ 522 ] + xx [ 293 ] * xx [ 306 ] ; xx [ 279 ] = xx [ 263 ] / xx [ 366 ] ;
xx [ 443 ] = xx [ 63 ] ; xx [ 444 ] = xx [ 132 ] ; xx [ 445 ] = xx [ 522 ] -
xx [ 361 ] * xx [ 279 ] ; pm_math_Quaternion_xform_ra ( xx + 270 , xx + 443 ,
xx + 517 ) ; xx [ 308 ] = ( ( xx [ 313 ] + xx [ 313 ] ) * xx [ 198 ] + xx [
310 ] ) * xx [ 27 ] ; xx [ 312 ] = xx [ 305 ] ; xx [ 313 ] = xx [ 306 ] - xx
[ 316 ] * xx [ 279 ] ; xx [ 314 ] = xx [ 308 ] ; pm_math_Quaternion_xform_ra
( xx + 270 , xx + 312 , xx + 443 ) ; pm_math_Vector3_cross_ra ( xx + 320 , xx
+ 443 , xx + 312 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 301
, xx + 523 ) ; xx [ 198 ] = xx [ 525 ] + state [ 23 ] ; xx [ 526 ] = xx [ 523
] ; xx [ 527 ] = xx [ 524 ] ; xx [ 528 ] = xx [ 198 ] ; xx [ 529 ] = xx [ 278
] * xx [ 523 ] ; xx [ 530 ] = xx [ 361 ] * xx [ 524 ] ; xx [ 531 ] = xx [ 198
] * xx [ 361 ] ; pm_math_Vector3_cross_ra ( xx + 526 , xx + 529 , xx + 532 )
; xx [ 309 ] = xx [ 532 ] + xx [ 278 ] * xx [ 524 ] * state [ 23 ] ; xx [ 278
] = xx [ 533 ] - xx [ 361 ] * xx [ 523 ] * state [ 23 ] ;
pm_math_Vector3_cross_ra ( xx + 301 , xx + 337 , xx + 526 ) ;
pm_math_Vector3_cross_ra ( xx + 301 , xx + 526 , xx + 529 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 529 , xx + 526 ) ; xx [
310 ] = xx [ 27 ] * xx [ 527 ] ; xx [ 315 ] = xx [ 534 ] + xx [ 293 ] * xx [
310 ] ; xx [ 421 ] = xx [ 315 ] / xx [ 366 ] ; xx [ 529 ] = xx [ 309 ] ; xx [
530 ] = xx [ 278 ] ; xx [ 531 ] = xx [ 534 ] - xx [ 361 ] * xx [ 421 ] ;
pm_math_Quaternion_xform_ra ( xx + 446 , xx + 529 , xx + 535 ) ; xx [ 422 ] =
xx [ 293 ] * state [ 23 ] ; xx [ 293 ] = xx [ 27 ] * ( xx [ 526 ] - ( xx [
525 ] + xx [ 198 ] ) * xx [ 422 ] ) ; xx [ 461 ] = ( ( xx [ 523 ] + xx [ 523
] ) * xx [ 422 ] + xx [ 528 ] ) * xx [ 27 ] ; xx [ 523 ] = xx [ 293 ] ; xx [
524 ] = xx [ 310 ] - xx [ 316 ] * xx [ 421 ] ; xx [ 525 ] = xx [ 461 ] ;
pm_math_Quaternion_xform_ra ( xx + 446 , xx + 523 , xx + 526 ) ;
pm_math_Vector3_cross_ra ( xx + 337 , xx + 526 , xx + 523 ) ; xx [ 27 ] = xx
[ 498 ] - xx [ 550 ] + xx [ 79 ] * xx [ 242 ] * state [ 21 ] ; xx [ 242 ] =
xx [ 499 ] - xx [ 551 ] - xx [ 79 ] * xx [ 189 ] * state [ 21 ] ; xx [ 189 ]
= xx [ 136 ] * xx [ 242 ] ; xx [ 422 ] = xx [ 27 ] * xx [ 136 ] ; xx [ 472 ]
= xx [ 469 ] + xx [ 27 ] - ( xx [ 131 ] * xx [ 189 ] + xx [ 422 ] * xx [ 136
] ) * xx [ 6 ] - xx [ 462 ] * xx [ 251 ] + xx [ 98 ] * xx [ 249 ] - xx [ 162
] * xx [ 80 ] - ( xx [ 256 ] * xx [ 390 ] + xx [ 253 ] * xx [ 94 ] ) ; xx [
27 ] = xx [ 472 ] + xx [ 147 ] * xx [ 149 ] ; xx [ 80 ] = xx [ 27 ] * xx [
154 ] ; xx [ 98 ] = xx [ 129 ] * xx [ 510 ] - xx [ 555 ] ; xx [ 253 ] = ( xx
[ 111 ] + xx [ 111 ] ) * xx [ 427 ] + xx [ 513 ] ; xx [ 111 ] = xx [ 470 ] +
xx [ 242 ] + xx [ 6 ] * ( xx [ 131 ] * xx [ 422 ] - xx [ 189 ] * xx [ 136 ] )
+ xx [ 251 ] * xx [ 277 ] - xx [ 141 ] * xx [ 98 ] + xx [ 249 ] * xx [ 324 ]
- xx [ 190 ] * xx [ 162 ] + xx [ 260 ] * xx [ 390 ] + xx [ 261 ] * xx [ 94 ]
- xx [ 253 ] * xx [ 284 ] ; xx [ 94 ] = xx [ 111 ] - xx [ 262 ] * xx [ 149 ]
; xx [ 131 ] = xx [ 154 ] * xx [ 94 ] ; xx [ 136 ] = xx [ 98 ] + xx [ 162 ] *
xx [ 284 ] + xx [ 178 ] * xx [ 253 ] ; xx [ 98 ] = xx [ 136 ] * xx [ 167 ] ;
xx [ 178 ] = ( xx [ 420 ] + xx [ 420 ] ) * xx [ 335 ] + xx [ 516 ] ; xx [ 189
] = xx [ 341 ] * xx [ 134 ] - xx [ 177 ] * xx [ 140 ] + xx [ 329 ] * xx [ 275
] + xx [ 515 ] * xx [ 258 ] - xx [ 178 ] * xx [ 287 ] ; xx [ 177 ] = xx [ 165
] * xx [ 136 ] ; xx [ 190 ] = xx [ 364 ] * xx [ 134 ] - xx [ 95 ] * xx [ 140
] + xx [ 288 ] * xx [ 329 ] + xx [ 259 ] * xx [ 515 ] - xx [ 178 ] * xx [ 179
] ; xx [ 258 ] = xx [ 458 ] + xx [ 27 ] - ( xx [ 154 ] * xx [ 80 ] - xx [ 131
] * xx [ 123 ] ) * xx [ 6 ] - xx [ 98 ] + xx [ 189 ] + xx [ 281 ] * xx [ 156
] ; xx [ 259 ] = xx [ 459 ] + xx [ 94 ] - xx [ 6 ] * ( xx [ 80 ] * xx [ 123 ]
+ xx [ 154 ] * xx [ 131 ] ) - xx [ 177 ] + xx [ 190 ] + xx [ 274 ] * xx [ 156
] ; xx [ 260 ] = xx [ 126 ] + xx [ 138 ] * xx [ 156 ] ;
pm_math_Quaternion_xform_ra ( xx + 416 , xx + 258 , xx + 498 ) ; xx [ 27 ] =
xx [ 134 ] * xx [ 275 ] - xx [ 288 ] * xx [ 140 ] + xx [ 161 ] * xx [ 329 ] +
xx [ 515 ] * xx [ 137 ] ; xx [ 80 ] = xx [ 136 ] + xx [ 179 ] * xx [ 140 ] -
xx [ 134 ] * xx [ 287 ] + xx [ 180 ] * xx [ 178 ] ; xx [ 178 ] = xx [ 158 ] +
xx [ 27 ] + xx [ 171 ] * xx [ 156 ] ; xx [ 179 ] = xx [ 153 ] + xx [ 155 ] *
xx [ 156 ] ; xx [ 180 ] = xx [ 80 ] ; pm_math_Quaternion_xform_ra ( xx + 416
, xx + 178 , xx + 258 ) ; pm_math_Vector3_cross_ra ( xx + 290 , xx + 258 , xx
+ 178 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 301 , xx + 508
) ; xx [ 94 ] = xx [ 510 ] + state [ 11 ] ; xx [ 511 ] = xx [ 508 ] ; xx [
512 ] = xx [ 509 ] ; xx [ 513 ] = xx [ 94 ] ; xx [ 529 ] = xx [ 60 ] * xx [
508 ] ; xx [ 530 ] = xx [ 91 ] * xx [ 509 ] ; xx [ 531 ] = xx [ 94 ] * xx [
172 ] ; pm_math_Vector3_cross_ra ( xx + 511 , xx + 529 , xx + 541 ) ; xx [ 60
] = xx [ 234 ] * xx [ 509 ] ; xx [ 91 ] = xx [ 234 ] * xx [ 508 ] ; xx [ 95 ]
= xx [ 508 ] - xx [ 6 ] * ( xx [ 60 ] * xx [ 181 ] + xx [ 234 ] * xx [ 91 ] )
; xx [ 126 ] = xx [ 509 ] - ( xx [ 234 ] * xx [ 60 ] - xx [ 91 ] * xx [ 181 ]
) * xx [ 6 ] ; xx [ 60 ] = xx [ 94 ] + state [ 13 ] ; xx [ 529 ] = xx [ 95 ]
; xx [ 530 ] = xx [ 126 ] ; xx [ 531 ] = xx [ 60 ] ; xx [ 544 ] = xx [ 95 ] *
xx [ 65 ] ; xx [ 545 ] = xx [ 130 ] * xx [ 126 ] ; xx [ 546 ] = xx [ 60 ] *
xx [ 146 ] ; pm_math_Vector3_cross_ra ( xx + 529 , xx + 544 , xx + 547 ) ; xx
[ 65 ] = xx [ 219 ] * xx [ 126 ] ; xx [ 91 ] = xx [ 95 ] * xx [ 219 ] ; xx [
130 ] = xx [ 95 ] + xx [ 6 ] * ( xx [ 2 ] * xx [ 65 ] - xx [ 91 ] * xx [ 219
] ) ; xx [ 131 ] = xx [ 126 ] - ( xx [ 2 ] * xx [ 91 ] + xx [ 65 ] * xx [ 219
] ) * xx [ 6 ] ; xx [ 65 ] = xx [ 60 ] + state [ 15 ] ; xx [ 544 ] = xx [ 130
] ; xx [ 545 ] = xx [ 131 ] ; xx [ 546 ] = xx [ 65 ] ; xx [ 550 ] = xx [ 130
] * xx [ 79 ] ; xx [ 551 ] = xx [ 79 ] * xx [ 131 ] ; xx [ 552 ] = xx [ 65 ]
* xx [ 185 ] ; pm_math_Vector3_cross_ra ( xx + 544 , xx + 550 , xx + 553 ) ;
pm_math_Quaternion_compose_ra ( xx + 477 , xx + 450 , xx + 556 ) ; xx [ 91 ]
= xx [ 559 ] * xx [ 181 ] - xx [ 234 ] * xx [ 556 ] ; xx [ 136 ] = xx [ 556 ]
* xx [ 181 ] + xx [ 234 ] * xx [ 559 ] ; xx [ 137 ] = xx [ 91 ] * xx [ 219 ]
- xx [ 2 ] * xx [ 136 ] ; xx [ 146 ] = xx [ 557 ] * xx [ 181 ] - xx [ 234 ] *
xx [ 558 ] ; xx [ 153 ] = xx [ 558 ] * xx [ 181 ] + xx [ 234 ] * xx [ 557 ] ;
xx [ 158 ] = xx [ 146 ] * xx [ 2 ] + xx [ 219 ] * xx [ 153 ] ; xx [ 161 ] =
xx [ 146 ] * xx [ 219 ] - xx [ 2 ] * xx [ 153 ] ; xx [ 172 ] = xx [ 219 ] *
xx [ 136 ] + xx [ 91 ] * xx [ 2 ] ; xx [ 242 ] = xx [ 357 ] * xx [ 161 ] ; xx
[ 253 ] = xx [ 158 ] * xx [ 357 ] ; xx [ 544 ] = xx [ 146 ] ; xx [ 545 ] = xx
[ 153 ] ; xx [ 546 ] = xx [ 91 ] ; xx [ 256 ] = xx [ 251 ] * xx [ 153 ] ; xx
[ 261 ] = xx [ 91 ] * xx [ 141 ] + xx [ 146 ] * xx [ 251 ] ; xx [ 91 ] = xx [
141 ] * xx [ 153 ] ; xx [ 550 ] = - xx [ 256 ] ; xx [ 551 ] = xx [ 261 ] ; xx
[ 552 ] = - xx [ 91 ] ; pm_math_Vector3_cross_ra ( xx + 544 , xx + 550 , xx +
560 ) ; xx [ 146 ] = xx [ 559 ] * xx [ 247 ] ; xx [ 153 ] = xx [ 245 ] * xx [
559 ] ; xx [ 275 ] = xx [ 557 ] * xx [ 247 ] + xx [ 245 ] * xx [ 558 ] ; xx [
544 ] = xx [ 146 ] ; xx [ 545 ] = xx [ 153 ] ; xx [ 546 ] = - xx [ 275 ] ;
pm_math_Vector3_cross_ra ( xx + 557 , xx + 544 , xx + 550 ) ;
pm_math_Quaternion_xform_ra ( xx + 477 , xx + 371 , xx + 544 ) ; xx [ 563 ] =
- xx [ 137 ] ; xx [ 564 ] = xx [ 158 ] ; xx [ 565 ] = - xx [ 161 ] ; xx [ 566
] = xx [ 172 ] ; xx [ 567 ] = ( xx [ 242 ] * xx [ 137 ] + xx [ 172 ] * xx [
253 ] ) * xx [ 6 ] + ( xx [ 560 ] - xx [ 256 ] * xx [ 136 ] ) * xx [ 6 ] + xx
[ 245 ] + ( xx [ 556 ] * xx [ 146 ] + xx [ 550 ] ) * xx [ 6 ] + xx [ 544 ] +
xx [ 348 ] + xx [ 141 ] ; xx [ 568 ] = xx [ 6 ] * ( xx [ 253 ] * xx [ 137 ] -
xx [ 172 ] * xx [ 242 ] ) + ( xx [ 261 ] * xx [ 136 ] + xx [ 561 ] ) * xx [ 6
] + ( xx [ 556 ] * xx [ 153 ] + xx [ 551 ] ) * xx [ 6 ] - xx [ 247 ] + xx [
545 ] + xx [ 378 ] ; xx [ 569 ] = xx [ 357 ] - ( xx [ 158 ] * xx [ 253 ] + xx
[ 242 ] * xx [ 161 ] ) * xx [ 6 ] + xx [ 6 ] * ( xx [ 562 ] - xx [ 91 ] * xx
[ 136 ] ) + xx [ 6 ] * ( xx [ 552 ] - xx [ 275 ] * xx [ 556 ] ) + xx [ 546 ]
+ xx [ 387 ] - xx [ 251 ] ; bb [ 0 ] =
sm_core_compiler_computeProximityInfoBrickCylinder (
series_link_blance_leg_ad6bcbee_1_geometry_1 ( NULL ) ,
series_link_blance_leg_ad6bcbee_1_geometry_0 ( NULL ) , ( pm_math_Transform3
* ) ( xx + 501 ) , ( pm_math_Transform3 * ) ( xx + 563 ) , xx + 91 , (
pm_math_Vector3 * ) ( xx + 477 ) , ( pm_math_Vector3 * ) ( xx + 544 ) , (
pm_math_Vector3 * ) ( xx + 550 ) , ( pm_math_Vector3 * ) ( xx + 556 ) ) ; xx
[ 570 ] = xx [ 4 ] ; xx [ 571 ] = xx [ 39 ] ; xx [ 572 ] = xx [ 39 ] ; xx [
573 ] = xx [ 39 ] ; xx [ 574 ] = xx [ 39 ] ; xx [ 575 ] = xx [ 39 ] ; xx [
576 ] = xx [ 357 ] ; xx [ 4 ] = xx [ 94 ] * xx [ 247 ] ;
pm_math_Vector3_cross_ra ( xx + 301 , xx + 371 , xx + 559 ) ; xx [ 577 ] = xx
[ 559 ] + xx [ 323 ] ; xx [ 578 ] = xx [ 560 ] + xx [ 539 ] ; xx [ 579 ] = xx
[ 561 ] + xx [ 540 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx +
577 , xx + 538 ) ; xx [ 136 ] = xx [ 4 ] + xx [ 538 ] ; xx [ 137 ] = xx [ 94
] * xx [ 245 ] ; xx [ 146 ] = xx [ 160 ] * state [ 11 ] ; xx [ 153 ] = xx [
137 ] + xx [ 539 ] + xx [ 146 ] ; xx [ 158 ] = xx [ 153 ] * xx [ 234 ] ; xx [
161 ] = xx [ 136 ] * xx [ 234 ] ; xx [ 172 ] = xx [ 251 ] * xx [ 126 ] ; xx [
242 ] = xx [ 136 ] - xx [ 6 ] * ( xx [ 158 ] * xx [ 181 ] + xx [ 234 ] * xx [
161 ] ) - xx [ 172 ] ; xx [ 136 ] = xx [ 60 ] * xx [ 141 ] + xx [ 95 ] * xx [
251 ] ; xx [ 253 ] = xx [ 144 ] * state [ 13 ] ; xx [ 256 ] = xx [ 136 ] + xx
[ 153 ] - ( xx [ 234 ] * xx [ 158 ] - xx [ 161 ] * xx [ 181 ] ) * xx [ 6 ] +
xx [ 253 ] ; xx [ 153 ] = xx [ 256 ] * xx [ 219 ] ; xx [ 158 ] = xx [ 242 ] *
xx [ 219 ] ; xx [ 161 ] = xx [ 508 ] * xx [ 247 ] + xx [ 245 ] * xx [ 509 ] ;
xx [ 261 ] = xx [ 141 ] * xx [ 126 ] ; xx [ 577 ] = xx [ 130 ] ; xx [ 578 ] =
xx [ 131 ] ; xx [ 579 ] = xx [ 65 ] ; xx [ 580 ] = xx [ 242 ] + xx [ 6 ] * (
xx [ 2 ] * xx [ 153 ] - xx [ 158 ] * xx [ 219 ] ) ; xx [ 581 ] = xx [ 256 ] -
( xx [ 2 ] * xx [ 158 ] + xx [ 153 ] * xx [ 219 ] ) * xx [ 6 ] ; xx [ 582 ] =
xx [ 540 ] - xx [ 161 ] - xx [ 261 ] ;
sm_core_compiler_computeContactWrenches ( 0 , 1 , bb [ 0 ] , xx + 91 , (
const pm_math_Vector3 * ) ( xx + 477 ) , ( const pm_math_Vector3 * ) ( xx +
544 ) , ( const pm_math_Vector3 * ) ( xx + 550 ) , ( const pm_math_Vector3 *
) ( xx + 556 ) , ( const pm_math_Transform3 * ) ( xx + 501 ) , ( const
pm_math_Transform3 * ) ( xx + 570 ) , ( const pm_math_Transform3 * ) ( xx +
501 ) , ( const pm_math_Transform3 * ) ( xx + 563 ) , NULL , ( const
pm_math_SpatialVector * ) ( xx + 577 ) , 0 , 1 , xx [ 109 ] , xx [ 370 ] , xx
[ 377 ] , xx [ 426 ] , xx [ 432 ] , xx [ 438 ] , NULL , NULL , NULL , (
pm_math_SpatialVector * ) ( xx + 583 ) ) ; xx [ 65 ] = xx [ 553 ] - xx [ 583
] + xx [ 79 ] * xx [ 131 ] * state [ 15 ] ; xx [ 91 ] = xx [ 554 ] - xx [ 584
] - xx [ 79 ] * xx [ 130 ] * state [ 15 ] ; xx [ 79 ] = xx [ 219 ] * xx [ 91
] ; xx [ 109 ] = xx [ 65 ] * xx [ 219 ] ; xx [ 477 ] = - xx [ 172 ] ; xx [
478 ] = xx [ 136 ] ; xx [ 479 ] = - xx [ 261 ] ; pm_math_Vector3_cross_ra (
xx + 529 , xx + 477 , xx + 501 ) ; xx [ 130 ] = xx [ 501 ] * xx [ 219 ] ; xx
[ 131 ] = xx [ 502 ] * xx [ 219 ] ; xx [ 136 ] = xx [ 129 ] * ( xx [ 502 ] -
( xx [ 2 ] * xx [ 130 ] + xx [ 131 ] * xx [ 219 ] ) * xx [ 6 ] ) - xx [ 587 ]
; xx [ 153 ] = ( xx [ 501 ] + xx [ 6 ] * ( xx [ 2 ] * xx [ 131 ] - xx [ 130 ]
* xx [ 219 ] ) ) * xx [ 129 ] - xx [ 586 ] ; xx [ 130 ] = xx [ 219 ] * xx [
153 ] ; xx [ 131 ] = xx [ 219 ] * xx [ 136 ] ; xx [ 158 ] = xx [ 136 ] + xx [
6 ] * ( xx [ 2 ] * xx [ 130 ] - xx [ 131 ] * xx [ 219 ] ) ; xx [ 136 ] = xx [
126 ] * state [ 13 ] ; xx [ 126 ] = xx [ 95 ] * state [ 13 ] ; xx [ 477 ] =
xx [ 4 ] ; xx [ 478 ] = xx [ 137 ] ; xx [ 479 ] = - xx [ 161 ] ;
pm_math_Vector3_cross_ra ( xx + 511 , xx + 477 , xx + 504 ) ; xx [ 4 ] = xx [
234 ] * xx [ 505 ] ; xx [ 137 ] = xx [ 234 ] * xx [ 504 ] ; xx [ 161 ] = xx [
504 ] - xx [ 6 ] * ( xx [ 4 ] * xx [ 181 ] + xx [ 234 ] * xx [ 137 ] ) - ( xx
[ 94 ] + xx [ 60 ] ) * xx [ 253 ] ; xx [ 60 ] = xx [ 505 ] - ( xx [ 234 ] *
xx [ 4 ] - xx [ 137 ] * xx [ 181 ] ) * xx [ 6 ] ; xx [ 4 ] = xx [ 547 ] + xx
[ 65 ] - ( xx [ 2 ] * xx [ 79 ] + xx [ 109 ] * xx [ 219 ] ) * xx [ 6 ] + xx [
158 ] * xx [ 251 ] + xx [ 285 ] * xx [ 136 ] - xx [ 126 ] * xx [ 159 ] + xx [
101 ] * xx [ 161 ] + xx [ 298 ] * xx [ 60 ] ; xx [ 65 ] = xx [ 555 ] - xx [
585 ] ; xx [ 137 ] = input [ 2 ] - xx [ 65 ] ; xx [ 159 ] = xx [ 158 ] * xx [
141 ] ; xx [ 172 ] = xx [ 225 ] * xx [ 161 ] + xx [ 218 ] * xx [ 60 ] + xx [
257 ] * xx [ 136 ] + xx [ 126 ] * xx [ 295 ] ; xx [ 218 ] = xx [ 549 ] + xx [
65 ] + xx [ 137 ] + xx [ 159 ] + xx [ 172 ] ; xx [ 225 ] = xx [ 158 ] + xx [
161 ] * xx [ 238 ] + xx [ 229 ] * xx [ 60 ] + xx [ 298 ] * xx [ 136 ] + xx [
126 ] * xx [ 351 ] ; xx [ 158 ] = xx [ 225 ] * xx [ 144 ] ; xx [ 229 ] = ( xx
[ 218 ] + xx [ 158 ] ) / xx [ 231 ] ; xx [ 238 ] = xx [ 4 ] - xx [ 227 ] * xx
[ 229 ] ; xx [ 242 ] = xx [ 238 ] * xx [ 234 ] ; xx [ 256 ] = xx [ 153 ] - (
xx [ 2 ] * xx [ 131 ] + xx [ 130 ] * xx [ 219 ] ) * xx [ 6 ] ; xx [ 130 ] =
xx [ 129 ] * xx [ 503 ] - xx [ 588 ] ; xx [ 129 ] = ( xx [ 95 ] + xx [ 95 ] )
* xx [ 253 ] + xx [ 506 ] ; xx [ 95 ] = xx [ 548 ] + xx [ 91 ] + xx [ 6 ] * (
xx [ 2 ] * xx [ 109 ] - xx [ 79 ] * xx [ 219 ] ) - ( xx [ 251 ] * xx [ 256 ]
+ xx [ 141 ] * xx [ 130 ] ) + xx [ 136 ] * xx [ 304 ] - xx [ 214 ] * xx [ 126
] - ( xx [ 353 ] * xx [ 161 ] + xx [ 351 ] * xx [ 60 ] + xx [ 129 ] * xx [
365 ] ) ; xx [ 2 ] = xx [ 95 ] + xx [ 352 ] * xx [ 229 ] ; xx [ 79 ] = xx [
234 ] * xx [ 2 ] ; xx [ 91 ] = xx [ 130 ] + xx [ 126 ] * xx [ 365 ] + xx [
254 ] * xx [ 129 ] ; xx [ 109 ] = xx [ 91 ] * xx [ 247 ] ; xx [ 129 ] = xx [
509 ] * state [ 11 ] ; xx [ 130 ] = xx [ 508 ] * state [ 11 ] ;
pm_math_Vector3_cross_ra ( xx + 301 , xx + 559 , xx + 477 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 477 , xx + 301 ) ; xx [
131 ] = xx [ 301 ] - ( xx [ 510 ] + xx [ 94 ] ) * xx [ 146 ] ; xx [ 94 ] = (
xx [ 508 ] + xx [ 508 ] ) * xx [ 146 ] + xx [ 303 ] ; xx [ 141 ] = xx [ 307 ]
* xx [ 129 ] - xx [ 286 ] * xx [ 130 ] + xx [ 131 ] * xx [ 356 ] + xx [ 302 ]
* xx [ 222 ] - xx [ 94 ] * xx [ 368 ] ; xx [ 146 ] = state [ 10 ] + xx [ 22 ]
; if ( xx [ 39 ] > xx [ 146 ] ) xx [ 146 ] = xx [ 39 ] ; xx [ 22 ] = xx [ 146
] / xx [ 59 ] ; if ( xx [ 7 ] < xx [ 22 ] ) xx [ 22 ] = xx [ 7 ] ; xx [ 7 ] =
( xx [ 10 ] * xx [ 146 ] + ( xx [ 146 ] == xx [ 39 ] ? xx [ 39 ] : xx [ 58 ]
* state [ 11 ] ) ) * xx [ 22 ] * xx [ 22 ] * ( xx [ 75 ] - xx [ 6 ] * xx [ 22
] ) ; if ( xx [ 39 ] > xx [ 7 ] ) xx [ 7 ] = xx [ 39 ] ; xx [ 10 ] = input [
0 ] - xx [ 7 ] ; xx [ 7 ] = xx [ 225 ] - xx [ 230 ] * xx [ 229 ] ; xx [ 22 ]
= xx [ 256 ] + xx [ 223 ] * xx [ 161 ] + xx [ 60 ] * xx [ 217 ] + xx [ 101 ]
* xx [ 136 ] + xx [ 126 ] * xx [ 353 ] ; xx [ 58 ] = xx [ 22 ] - xx [ 226 ] *
xx [ 229 ] ; xx [ 59 ] = xx [ 234 ] * xx [ 58 ] ; xx [ 60 ] = xx [ 234 ] * xx
[ 7 ] ; xx [ 75 ] = xx [ 7 ] - xx [ 6 ] * ( xx [ 59 ] * xx [ 181 ] + xx [ 234
] * xx [ 60 ] ) ; xx [ 7 ] = xx [ 58 ] - ( xx [ 234 ] * xx [ 59 ] - xx [ 60 ]
* xx [ 181 ] ) * xx [ 6 ] ; xx [ 58 ] = xx [ 358 ] * xx [ 129 ] - xx [ 333 ]
* xx [ 130 ] + xx [ 236 ] * xx [ 131 ] + xx [ 212 ] * xx [ 302 ] ; xx [ 59 ]
= xx [ 543 ] + xx [ 218 ] - xx [ 228 ] * xx [ 229 ] + xx [ 245 ] * xx [ 75 ]
+ xx [ 247 ] * xx [ 7 ] + xx [ 58 ] ; xx [ 60 ] = xx [ 129 ] * xx [ 222 ] -
xx [ 349 ] * xx [ 130 ] + xx [ 243 ] * xx [ 131 ] + xx [ 221 ] * xx [ 302 ] ;
xx [ 101 ] = xx [ 75 ] + xx [ 60 ] ; xx [ 75 ] = ( xx [ 10 ] - ( xx [ 59 ] +
xx [ 101 ] * xx [ 160 ] ) ) / xx [ 237 ] ; xx [ 146 ] = xx [ 245 ] * xx [ 91
] ; xx [ 153 ] = xx [ 363 ] * xx [ 129 ] - xx [ 216 ] * xx [ 130 ] + xx [ 369
] * xx [ 131 ] + xx [ 349 ] * xx [ 302 ] - xx [ 94 ] * xx [ 128 ] ; xx [ 216
] = xx [ 541 ] + xx [ 238 ] - ( xx [ 234 ] * xx [ 242 ] - xx [ 79 ] * xx [
181 ] ) * xx [ 6 ] - xx [ 109 ] + xx [ 141 ] + xx [ 362 ] * xx [ 75 ] ; xx [
217 ] = xx [ 542 ] + xx [ 2 ] - xx [ 6 ] * ( xx [ 242 ] * xx [ 181 ] + xx [
234 ] * xx [ 79 ] ) - xx [ 146 ] + xx [ 153 ] + xx [ 355 ] * xx [ 75 ] ; xx [
218 ] = xx [ 59 ] + xx [ 168 ] * xx [ 75 ] ; pm_math_Quaternion_xform_ra ( xx
+ 450 , xx + 216 , xx + 221 ) ; xx [ 2 ] = xx [ 129 ] * xx [ 356 ] - xx [ 369
] * xx [ 130 ] + xx [ 241 ] * xx [ 131 ] + xx [ 302 ] * xx [ 220 ] ; xx [ 59
] = xx [ 91 ] + xx [ 128 ] * xx [ 130 ] - xx [ 129 ] * xx [ 368 ] + xx [ 255
] * xx [ 94 ] ; xx [ 216 ] = xx [ 7 ] + xx [ 2 ] + xx [ 240 ] * xx [ 75 ] ;
xx [ 217 ] = xx [ 101 ] + xx [ 235 ] * xx [ 75 ] ; xx [ 218 ] = xx [ 59 ] ;
pm_math_Quaternion_xform_ra ( xx + 450 , xx + 216 , xx + 241 ) ;
pm_math_Vector3_cross_ra ( xx + 371 , xx + 241 , xx + 216 ) ; xx [ 501 ] = xx
[ 108 ] ; xx [ 502 ] = xx [ 25 ] ; xx [ 503 ] = xx [ 38 ] ; xx [ 504 ] = xx [
119 ] ; xx [ 505 ] = xx [ 215 ] ; xx [ 506 ] = xx [ 233 ] ; xx [ 507 ] = xx [
49 ] ; xx [ 508 ] = xx [ 311 ] ; xx [ 509 ] = xx [ 332 ] ; xx [ 7 ] = xx [
104 ] * xx [ 55 ] ; xx [ 25 ] = xx [ 104 ] * xx [ 118 ] ; xx [ 253 ] = - xx [
163 ] ; xx [ 254 ] = xx [ 7 ] ; xx [ 255 ] = - xx [ 25 ] ;
pm_math_Matrix3x3_xform_ra ( xx + 501 , xx + 253 , xx + 284 ) ; xx [ 501 ] =
xx [ 44 ] ; xx [ 502 ] = xx [ 72 ] ; xx [ 503 ] = xx [ 41 ] ; xx [ 504 ] = xx
[ 93 ] ; xx [ 505 ] = xx [ 70 ] ; xx [ 506 ] = xx [ 73 ] ; xx [ 507 ] = xx [
182 ] ; xx [ 508 ] = xx [ 42 ] ; xx [ 509 ] = xx [ 48 ] ; xx [ 38 ] = xx [
289 ] * state [ 7 ] ; xx [ 41 ] = xx [ 280 ] * state [ 7 ] ; xx [ 42 ] = xx [
41 ] * xx [ 5 ] ; xx [ 44 ] = xx [ 11 ] * xx [ 38 ] - xx [ 41 ] * xx [ 3 ] ;
xx [ 48 ] = xx [ 38 ] * xx [ 5 ] ; xx [ 287 ] = - xx [ 42 ] ; xx [ 288 ] = xx
[ 44 ] ; xx [ 289 ] = xx [ 48 ] ; pm_math_Vector3_cross_ra ( xx + 105 , xx +
287 , xx + 356 ) ; xx [ 49 ] = xx [ 38 ] + xx [ 6 ] * ( xx [ 356 ] + xx [ 42
] * xx [ 26 ] ) ; xx [ 38 ] = xx [ 6 ] * ( xx [ 357 ] - xx [ 44 ] * xx [ 26 ]
) - ( xx [ 121 ] + xx [ 57 ] ) * xx [ 294 ] ; xx [ 42 ] = xx [ 41 ] + ( xx [
358 ] - xx [ 48 ] * xx [ 26 ] ) * xx [ 6 ] - ( xx [ 116 ] + xx [ 120 ] ) * xx
[ 294 ] ; xx [ 104 ] = xx [ 49 ] ; xx [ 105 ] = xx [ 38 ] ; xx [ 106 ] = xx [
42 ] ; pm_math_Matrix3x3_xform_ra ( xx + 501 , xx + 104 , xx + 118 ) ; xx [
41 ] = xx [ 284 ] + xx [ 118 ] ; pm_math_Matrix3x3_transposeXform_ra ( xx +
501 , xx + 253 , xx + 287 ) ; xx [ 501 ] = xx [ 92 ] ; xx [ 502 ] = xx [ 360
] ; xx [ 503 ] = xx [ 78 ] ; xx [ 504 ] = xx [ 68 ] ; xx [ 505 ] = xx [ 76 ]
; xx [ 506 ] = xx [ 102 ] ; xx [ 507 ] = xx [ 69 ] ; xx [ 508 ] = xx [ 103 ]
; xx [ 509 ] = xx [ 74 ] ; pm_math_Matrix3x3_xform_ra ( xx + 501 , xx + 104 ,
xx + 68 ) ; xx [ 44 ] = xx [ 287 ] + xx [ 68 ] ; xx [ 48 ] = xx [ 443 ] + xx
[ 526 ] + xx [ 258 ] + xx [ 241 ] + xx [ 44 ] ; xx [ 55 ] = xx [ 285 ] + xx [
119 ] ; xx [ 57 ] = xx [ 464 ] + xx [ 518 ] + xx [ 313 ] + xx [ 536 ] + xx [
524 ] + xx [ 499 ] + xx [ 179 ] + xx [ 222 ] + xx [ 217 ] + xx [ 55 ] ; xx [
72 ] = xx [ 286 ] + xx [ 120 ] ; xx [ 73 ] = xx [ 465 ] + xx [ 519 ] + xx [
314 ] + xx [ 537 ] + xx [ 525 ] + xx [ 500 ] + xx [ 180 ] + xx [ 223 ] + xx [
218 ] + xx [ 72 ] ; xx [ 74 ] = ( xx [ 48 ] * xx [ 244 ] - ( xx [ 57 ] * xx [
21 ] + xx [ 73 ] * xx [ 24 ] ) ) / xx [ 350 ] ; xx [ 91 ] = xx [ 463 ] + xx [
517 ] + xx [ 312 ] + xx [ 535 ] + xx [ 523 ] + xx [ 498 ] + xx [ 178 ] + xx [
221 ] + xx [ 216 ] + xx [ 41 ] - xx [ 67 ] * xx [ 74 ] ; xx [ 92 ] = xx [ 57
] - xx [ 264 ] * xx [ 74 ] ; xx [ 93 ] = xx [ 73 ] - xx [ 342 ] * xx [ 74 ] ;
pm_math_Quaternion_xform_ra ( xx + 266 , xx + 91 , xx + 101 ) ; xx [ 57 ] =
xx [ 288 ] + xx [ 69 ] ; xx [ 68 ] = xx [ 289 ] + xx [ 70 ] ; xx [ 91 ] = xx
[ 48 ] - xx [ 265 ] * xx [ 74 ] ; xx [ 92 ] = xx [ 444 ] + xx [ 527 ] + xx [
259 ] + xx [ 242 ] + xx [ 57 ] - xx [ 46 ] * xx [ 74 ] ; xx [ 93 ] = xx [ 445
] + xx [ 528 ] + xx [ 260 ] + xx [ 243 ] + xx [ 68 ] - xx [ 40 ] * xx [ 74 ]
; pm_math_Quaternion_xform_ra ( xx + 266 , xx + 91 , xx + 103 ) ;
pm_math_Vector3_cross_ra ( xx + 191 , xx + 103 , xx + 91 ) ; xx [ 48 ] = ( xx
[ 102 ] + xx [ 92 ] ) / xx [ 52 ] ; xx [ 91 ] = xx [ 103 ] - xx [ 48 ] * xx [
45 ] ; xx [ 92 ] = xx [ 104 ] - xx [ 48 ] * xx [ 54 ] ; xx [ 93 ] = xx [ 105
] - xx [ 48 ] * xx [ 56 ] ; pm_math_Quaternion_xform_ra ( xx + 194 , xx + 91
, xx + 101 ) ; xx [ 91 ] = - xx [ 101 ] ; xx [ 92 ] = - xx [ 102 ] ; xx [ 93
] = - xx [ 103 ] ; solveSymmetricPosDef ( xx + 401 , xx + 91 , 3 , 1 , xx +
101 , xx + 104 ) ; xx [ 69 ] = 9.806650000000001 ; xx [ 70 ] = xx [ 83 ] - xx
[ 30 ] - xx [ 32 ] - xx [ 202 ] ; xx [ 29 ] = xx [ 89 ] - xx [ 36 ] - xx [ 34
] - xx [ 208 ] ; xx [ 82 ] = xx [ 374 ] - xx [ 383 ] - xx [ 53 ] * xx [ 70 ]
; xx [ 83 ] = xx [ 375 ] - xx [ 386 ] - xx [ 114 ] * xx [ 70 ] ; xx [ 84 ] =
xx [ 376 ] - xx [ 389 ] - xx [ 117 ] * xx [ 70 ] ; xx [ 85 ] = xx [ 45 ] - xx
[ 53 ] * xx [ 51 ] ; xx [ 86 ] = xx [ 54 ] - xx [ 114 ] * xx [ 51 ] ; xx [ 87
] = xx [ 56 ] - xx [ 117 ] * xx [ 51 ] ; xx [ 88 ] = xx [ 380 ] - xx [ 385 ]
- xx [ 53 ] * xx [ 29 ] ; xx [ 89 ] = xx [ 381 ] - xx [ 388 ] - xx [ 114 ] *
xx [ 29 ] ; xx [ 90 ] = xx [ 382 ] - xx [ 391 ] - xx [ 117 ] * xx [ 29 ] ;
pm_math_Matrix3x3_composeTranspose_ra ( xx + 82 , xx + 12 , xx + 29 ) ;
pm_math_Matrix3x3_compose_ra ( xx + 12 , xx + 29 , xx + 82 ) ; xx [ 550 ] =
xx [ 82 ] ; xx [ 551 ] = xx [ 83 ] ; xx [ 552 ] = xx [ 84 ] ; xx [ 553 ] = xx
[ 85 ] ; xx [ 554 ] = xx [ 86 ] ; xx [ 555 ] = xx [ 87 ] ; xx [ 556 ] = xx [
88 ] ; xx [ 557 ] = xx [ 89 ] ; xx [ 558 ] = xx [ 90 ] ; xx [ 559 ] = xx [
392 ] ; xx [ 560 ] = xx [ 393 ] ; xx [ 561 ] = xx [ 394 ] ; xx [ 562 ] = xx [
395 ] ; xx [ 563 ] = xx [ 396 ] ; xx [ 564 ] = xx [ 397 ] ; xx [ 565 ] = xx [
398 ] ; xx [ 566 ] = xx [ 399 ] ; xx [ 567 ] = xx [ 400 ] ;
solveSymmetricPosDef ( xx + 401 , xx + 550 , 3 , 6 , xx + 568 , xx + 12 ) ;
xx [ 12 ] = 1.77635683940025e-15 ; xx [ 13 ] = xx [ 69 ] * xx [ 577 ] + xx [
12 ] * xx [ 583 ] ; xx [ 14 ] = xx [ 69 ] * xx [ 578 ] + xx [ 12 ] * xx [ 584
] ; xx [ 15 ] = xx [ 69 ] * xx [ 579 ] + xx [ 12 ] * xx [ 585 ] ; xx [ 16 ] =
xx [ 101 ] + xx [ 13 ] - xx [ 69 ] ; xx [ 17 ] = xx [ 102 ] + xx [ 14 ] ; xx
[ 18 ] = xx [ 103 ] + xx [ 15 ] - xx [ 12 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 194 , xx + 16 , xx + 29 ) ; xx [ 16
] = xx [ 48 ] + pm_math_Vector3_dot_ra ( xx + 423 , xx + 29 ) ; xx [ 17 ] =
xx [ 11 ] * xx [ 16 ] ; xx [ 18 ] = xx [ 16 ] * xx [ 3 ] ; xx [ 19 ] = ( xx [
17 ] * xx [ 26 ] - xx [ 18 ] * xx [ 5 ] ) * xx [ 6 ] ; xx [ 20 ] = ( xx [ 11
] * xx [ 17 ] + xx [ 18 ] * xx [ 3 ] ) * xx [ 6 ] - xx [ 16 ] ; xx [ 32 ] =
xx [ 6 ] * ( xx [ 18 ] * xx [ 26 ] + xx [ 17 ] * xx [ 5 ] ) ; xx [ 33 ] = -
xx [ 19 ] ; xx [ 34 ] = xx [ 20 ] ; xx [ 35 ] = xx [ 32 ] ; xx [ 82 ] = xx [
29 ] + xx [ 66 ] * xx [ 16 ] ; xx [ 83 ] = xx [ 30 ] ; xx [ 84 ] = xx [ 31 ]
- xx [ 16 ] * xx [ 170 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx
+ 82 , xx + 16 ) ; xx [ 29 ] = xx [ 74 ] + pm_math_Vector3_dot_ra ( xx + 429
, xx + 33 ) + pm_math_Vector3_dot_ra ( xx + 435 , xx + 16 ) ; xx [ 33 ] = - (
xx [ 163 ] + xx [ 19 ] ) ; xx [ 34 ] = xx [ 20 ] + xx [ 29 ] * xx [ 21 ] + xx
[ 7 ] ; xx [ 35 ] = xx [ 32 ] + xx [ 29 ] * xx [ 24 ] - xx [ 25 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 33 , xx + 30 ) ; xx [ 19
] = xx [ 16 ] - xx [ 29 ] * xx [ 244 ] + xx [ 49 ] ; pm_math_Vector3_cross_ra
( xx + 33 , xx + 290 , xx + 82 ) ; xx [ 16 ] = xx [ 17 ] + xx [ 38 ] ; xx [
17 ] = xx [ 18 ] + xx [ 42 ] ; xx [ 85 ] = xx [ 19 ] + xx [ 82 ] ; xx [ 86 ]
= xx [ 16 ] + xx [ 83 ] ; xx [ 87 ] = xx [ 17 ] + xx [ 84 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 85 , xx + 82 ) ; xx [ 18
] = xx [ 156 ] - ( pm_math_Vector3_dot_ra ( xx + 410 , xx + 30 ) + xx [ 164 ]
* xx [ 82 ] + xx [ 174 ] * xx [ 83 ] ) ; xx [ 20 ] = state [ 23 ] * state [
23 ] ; xx [ 29 ] = xx [ 110 ] * state [ 17 ] * state [ 17 ] ; xx [ 36 ] = xx
[ 6 ] * xx [ 99 ] * state [ 17 ] * state [ 17 ] ; xx [ 37 ] = state [ 17 ] *
state [ 17 ] ; xx [ 48 ] = state [ 19 ] * state [ 19 ] ; xx [ 51 ] = xx [ 167
] * xx [ 48 ] ; xx [ 53 ] = xx [ 48 ] * ( xx [ 169 ] - xx [ 144 ] ) ; xx [ 48
] = xx [ 96 ] * xx [ 53 ] ; xx [ 70 ] = xx [ 62 ] * xx [ 51 ] - xx [ 53 ] *
xx [ 28 ] ; xx [ 84 ] = - ( xx [ 96 ] * xx [ 51 ] ) ; xx [ 85 ] = xx [ 48 ] ;
xx [ 86 ] = xx [ 70 ] ; pm_math_Vector3_cross_ra ( xx + 326 , xx + 84 , xx +
87 ) ; xx [ 53 ] = xx [ 6 ] * xx [ 166 ] * state [ 19 ] * state [ 17 ] ; xx [
73 ] = xx [ 317 ] * state [ 19 ] * state [ 17 ] ; xx [ 74 ] = xx [ 96 ] * xx
[ 73 ] ; xx [ 76 ] = xx [ 73 ] * xx [ 28 ] + xx [ 62 ] * xx [ 53 ] ; xx [ 84
] = - ( xx [ 96 ] * xx [ 53 ] ) ; xx [ 85 ] = - xx [ 74 ] ; xx [ 86 ] = xx [
76 ] ; pm_math_Vector3_cross_ra ( xx + 326 , xx + 84 , xx + 90 ) ; xx [ 62 ]
= xx [ 127 ] * state [ 19 ] * state [ 19 ] ; xx [ 73 ] = xx [ 6 ] * xx [ 124
] * state [ 19 ] * state [ 19 ] ; xx [ 78 ] = 4.0 ; xx [ 79 ] = xx [ 30 ] +
xx [ 134 ] ; xx [ 30 ] = xx [ 31 ] - xx [ 140 ] ; xx [ 31 ] = xx [ 154 ] * xx
[ 30 ] ; xx [ 84 ] = xx [ 79 ] * xx [ 154 ] ; xx [ 85 ] = xx [ 32 ] + xx [ 18
] ; xx [ 101 ] = xx [ 79 ] - xx [ 6 ] * ( xx [ 31 ] * xx [ 123 ] + xx [ 154 ]
* xx [ 84 ] ) ; xx [ 102 ] = xx [ 30 ] - ( xx [ 154 ] * xx [ 31 ] - xx [ 84 ]
* xx [ 123 ] ) * xx [ 6 ] ; xx [ 103 ] = xx [ 85 ] ; xx [ 30 ] = xx [ 82 ] +
xx [ 329 ] + xx [ 85 ] * xx [ 167 ] ; xx [ 31 ] = xx [ 83 ] + xx [ 160 ] * xx
[ 18 ] + xx [ 515 ] + xx [ 85 ] * xx [ 165 ] ; xx [ 32 ] = xx [ 31 ] * xx [
154 ] ; xx [ 79 ] = xx [ 30 ] * xx [ 154 ] ; xx [ 82 ] = xx [ 149 ] +
pm_math_Vector3_dot_ra ( xx + 440 , xx + 101 ) + ( xx [ 30 ] - xx [ 6 ] * (
xx [ 32 ] * xx [ 123 ] + xx [ 154 ] * xx [ 79 ] ) ) * xx [ 152 ] + xx [ 142 ]
* ( xx [ 31 ] - ( xx [ 154 ] * xx [ 32 ] - xx [ 79 ] * xx [ 123 ] ) * xx [ 6
] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 33 , xx + 30 ) ;
pm_math_Vector3_cross_ra ( xx + 33 , xx + 337 , xx + 83 ) ; xx [ 101 ] = xx [
19 ] + xx [ 83 ] ; xx [ 102 ] = xx [ 16 ] + xx [ 84 ] ; xx [ 103 ] = xx [ 17
] + xx [ 85 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 101 , xx
+ 83 ) ; xx [ 30 ] = xx [ 421 ] + xx [ 115 ] * xx [ 32 ] + xx [ 139 ] * xx [
84 ] ; xx [ 31 ] = xx [ 6 ] * xx [ 113 ] * state [ 17 ] * state [ 17 ] ; xx [
32 ] = xx [ 6 ] * xx [ 112 ] * state [ 17 ] * state [ 17 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 33 , xx + 83 ) ;
pm_math_Vector3_cross_ra ( xx + 33 , xx + 371 , xx + 101 ) ; xx [ 104 ] = xx
[ 19 ] + xx [ 101 ] ; xx [ 105 ] = xx [ 16 ] + xx [ 102 ] ; xx [ 106 ] = xx [
17 ] + xx [ 103 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 104
, xx + 101 ) ; xx [ 79 ] = xx [ 75 ] - ( pm_math_Vector3_dot_ra ( xx + 466 ,
xx + 83 ) + xx [ 239 ] * xx [ 101 ] + xx [ 250 ] * xx [ 102 ] ) ; xx [ 75 ] =
state [ 25 ] * state [ 25 ] ; xx [ 86 ] = xx [ 188 ] * state [ 11 ] * state [
11 ] ; xx [ 87 ] = xx [ 6 ] * xx [ 186 ] * state [ 11 ] * state [ 11 ] ; xx [
90 ] = state [ 11 ] * state [ 11 ] ; xx [ 93 ] = state [ 13 ] * state [ 13 ]
; xx [ 94 ] = xx [ 247 ] * xx [ 93 ] ; xx [ 96 ] = xx [ 93 ] * ( xx [ 248 ] -
xx [ 144 ] ) ; xx [ 93 ] = xx [ 183 ] * xx [ 96 ] ; xx [ 99 ] = xx [ 23 ] *
xx [ 94 ] - xx [ 96 ] * xx [ 175 ] ; xx [ 103 ] = - ( xx [ 183 ] * xx [ 94 ]
) ; xx [ 104 ] = xx [ 93 ] ; xx [ 105 ] = xx [ 99 ] ;
pm_math_Vector3_cross_ra ( xx + 413 , xx + 103 , xx + 106 ) ; xx [ 96 ] = xx
[ 6 ] * xx [ 246 ] * state [ 13 ] * state [ 11 ] ; xx [ 103 ] = xx [ 64 ] *
state [ 13 ] * state [ 11 ] ; xx [ 64 ] = xx [ 183 ] * xx [ 103 ] ; xx [ 104
] = xx [ 103 ] * xx [ 175 ] + xx [ 23 ] * xx [ 96 ] ; xx [ 112 ] = - ( xx [
183 ] * xx [ 96 ] ) ; xx [ 113 ] = - xx [ 64 ] ; xx [ 114 ] = xx [ 104 ] ;
pm_math_Vector3_cross_ra ( xx + 413 , xx + 112 , xx + 116 ) ; xx [ 23 ] = xx
[ 213 ] * state [ 13 ] * state [ 13 ] ; xx [ 103 ] = xx [ 6 ] * xx [ 210 ] *
state [ 13 ] * state [ 13 ] ; xx [ 105 ] = xx [ 83 ] + xx [ 129 ] ; xx [ 83 ]
= xx [ 84 ] - xx [ 130 ] ; xx [ 84 ] = xx [ 234 ] * xx [ 83 ] ; xx [ 112 ] =
xx [ 105 ] * xx [ 234 ] ; xx [ 113 ] = xx [ 85 ] + xx [ 79 ] ; xx [ 119 ] =
xx [ 105 ] - xx [ 6 ] * ( xx [ 84 ] * xx [ 181 ] + xx [ 234 ] * xx [ 112 ] )
; xx [ 120 ] = xx [ 83 ] - ( xx [ 234 ] * xx [ 84 ] - xx [ 112 ] * xx [ 181 ]
) * xx [ 6 ] ; xx [ 121 ] = xx [ 113 ] ; xx [ 83 ] = xx [ 101 ] + xx [ 131 ]
+ xx [ 113 ] * xx [ 247 ] ; xx [ 84 ] = xx [ 102 ] + xx [ 160 ] * xx [ 79 ] +
xx [ 302 ] + xx [ 113 ] * xx [ 245 ] ; xx [ 85 ] = xx [ 84 ] * xx [ 234 ] ;
xx [ 101 ] = xx [ 83 ] * xx [ 234 ] ; xx [ 102 ] = xx [ 229 ] +
pm_math_Vector3_dot_ra ( xx + 474 , xx + 119 ) + ( xx [ 83 ] - xx [ 6 ] * (
xx [ 85 ] * xx [ 181 ] + xx [ 234 ] * xx [ 101 ] ) ) * xx [ 232 ] + xx [ 224
] * ( xx [ 84 ] - ( xx [ 234 ] * xx [ 85 ] - xx [ 101 ] * xx [ 181 ] ) * xx [
6 ] ) ; pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 33 , xx + 83 ) ;
pm_math_Vector3_cross_ra ( xx + 33 , xx + 320 , xx + 112 ) ; xx [ 33 ] = xx [
19 ] + xx [ 112 ] ; xx [ 34 ] = xx [ 16 ] + xx [ 113 ] ; xx [ 35 ] = xx [ 17
] + xx [ 114 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 33 , xx
+ 112 ) ; xx [ 16 ] = xx [ 279 ] + xx [ 115 ] * xx [ 85 ] + xx [ 139 ] * xx [
113 ] ; xx [ 17 ] = xx [ 6 ] * xx [ 200 ] * state [ 11 ] * state [ 11 ] ; xx
[ 19 ] = xx [ 6 ] * xx [ 199 ] * state [ 11 ] * state [ 11 ] ; xx [ 199 ] =
xx [ 384 ] * xx [ 18 ] - ( xx [ 336 ] * xx [ 20 ] + xx [ 325 ] * xx [ 77 ] *
state [ 23 ] * state [ 23 ] - ( xx [ 167 ] * xx [ 29 ] - xx [ 165 ] * xx [ 36
] - xx [ 282 ] * xx [ 37 ] + xx [ 51 ] + ( xx [ 48 ] * xx [ 28 ] + xx [ 88 ]
) * xx [ 6 ] + xx [ 6 ] * ( xx [ 6 ] * ( xx [ 91 ] - xx [ 74 ] * xx [ 28 ] )
+ xx [ 53 ] ) + ( xx [ 36 ] * xx [ 127 ] - xx [ 125 ] * xx [ 29 ] + xx [ 100
] * xx [ 62 ] - xx [ 73 ] * xx [ 110 ] + xx [ 78 ] * ( xx [ 345 ] * xx [ 252
] + xx [ 340 ] * xx [ 173 ] ) * state [ 17 ] * state [ 19 ] ) * xx [ 343 ] )
) - xx [ 82 ] * xx [ 367 ] + xx [ 30 ] * xx [ 334 ] ; xx [ 200 ] = xx [ 346 ]
* xx [ 18 ] - ( xx [ 296 ] * xx [ 20 ] - xx [ 325 ] * xx [ 81 ] * state [ 23
] * state [ 23 ] - ( xx [ 31 ] * xx [ 167 ] - xx [ 165 ] * xx [ 32 ] + xx [
283 ] * xx [ 37 ] + ( xx [ 28 ] * xx [ 70 ] + xx [ 89 ] ) * xx [ 6 ] + ( xx [
28 ] * xx [ 76 ] + xx [ 92 ] ) * xx [ 78 ] + ( xx [ 32 ] * xx [ 127 ] - xx [
125 ] * xx [ 31 ] + xx [ 97 ] * xx [ 62 ] - xx [ 61 ] * xx [ 73 ] + xx [ 78 ]
* ( xx [ 345 ] * xx [ 340 ] - xx [ 252 ] * xx [ 173 ] ) * state [ 17 ] *
state [ 19 ] ) * xx [ 343 ] ) ) - xx [ 82 ] * xx [ 276 ] - xx [ 30 ] * xx [
330 ] ; xx [ 201 ] = xx [ 318 ] * xx [ 79 ] - ( xx [ 300 ] * xx [ 75 ] + xx [
325 ] * xx [ 43 ] * state [ 25 ] * state [ 25 ] - ( xx [ 247 ] * xx [ 86 ] -
xx [ 245 ] * xx [ 87 ] - xx [ 359 ] * xx [ 90 ] + xx [ 94 ] + ( xx [ 93 ] *
xx [ 175 ] + xx [ 107 ] ) * xx [ 6 ] + xx [ 6 ] * ( xx [ 6 ] * ( xx [ 117 ] -
xx [ 64 ] * xx [ 175 ] ) + xx [ 96 ] ) + ( xx [ 87 ] * xx [ 213 ] - xx [ 211
] * xx [ 86 ] + xx [ 187 ] * xx [ 23 ] - xx [ 103 ] * xx [ 188 ] + xx [ 78 ]
* ( xx [ 354 ] * xx [ 434 ] + xx [ 347 ] * xx [ 428 ] ) * state [ 11 ] *
state [ 13 ] ) * xx [ 343 ] ) ) - xx [ 102 ] * xx [ 379 ] + xx [ 16 ] * xx [
297 ] ; xx [ 202 ] = xx [ 457 ] * xx [ 79 ] - ( xx [ 319 ] * xx [ 75 ] - xx [
325 ] * xx [ 47 ] * state [ 25 ] * state [ 25 ] - ( xx [ 17 ] * xx [ 247 ] -
xx [ 245 ] * xx [ 19 ] + xx [ 176 ] * xx [ 90 ] + ( xx [ 175 ] * xx [ 99 ] +
xx [ 108 ] ) * xx [ 6 ] + ( xx [ 175 ] * xx [ 104 ] + xx [ 118 ] ) * xx [ 78
] + ( xx [ 19 ] * xx [ 213 ] - xx [ 211 ] * xx [ 17 ] + xx [ 184 ] * xx [ 23
] - xx [ 9 ] * xx [ 103 ] + xx [ 78 ] * ( xx [ 354 ] * xx [ 347 ] - xx [ 434
] * xx [ 428 ] ) * state [ 11 ] * state [ 13 ] ) * xx [ 343 ] ) ) - xx [ 102
] * xx [ 344 ] - xx [ 16 ] * xx [ 299 ] ; memcpy ( xx + 203 , xx + 482 , 16 *
sizeof ( double ) ) ; factorAndSolveSymmetric ( xx + 203 , 4 , xx + 28 , ii +
0 , xx + 199 , xx + 16 , xx + 550 ) ; xx [ 9 ] = ( xx [ 18 ] * xx [ 297 ] -
xx [ 299 ] * xx [ 19 ] - xx [ 263 ] ) / xx [ 366 ] ; xx [ 28 ] = xx [ 305 ] ;
xx [ 29 ] = xx [ 306 ] + xx [ 316 ] * xx [ 9 ] ; xx [ 30 ] = xx [ 308 ] ;
pm_math_Quaternion_xform_ra ( xx + 270 , xx + 28 , xx + 31 ) ; xx [ 20 ] = (
xx [ 16 ] * xx [ 334 ] - xx [ 330 ] * xx [ 17 ] - xx [ 315 ] ) / xx [ 366 ] ;
xx [ 28 ] = xx [ 293 ] ; xx [ 29 ] = xx [ 310 ] + xx [ 316 ] * xx [ 20 ] ; xx
[ 30 ] = xx [ 461 ] ; pm_math_Quaternion_xform_ra ( xx + 446 , xx + 28 , xx +
34 ) ; xx [ 23 ] = xx [ 439 ] / xx [ 185 ] ; xx [ 28 ] = xx [ 471 ] + xx [ 1
] + xx [ 185 ] * xx [ 23 ] + xx [ 433 ] + xx [ 331 ] ; xx [ 1 ] = ( xx [ 28 ]
+ xx [ 143 ] + xx [ 367 ] * xx [ 16 ] + xx [ 276 ] * xx [ 17 ] ) / xx [ 151 ]
; xx [ 29 ] = xx [ 8 ] - xx [ 145 ] * xx [ 1 ] ; xx [ 8 ] = xx [ 154 ] * xx [
29 ] ; xx [ 30 ] = xx [ 135 ] - xx [ 150 ] * xx [ 1 ] ; xx [ 37 ] = xx [ 154
] * xx [ 30 ] ; xx [ 43 ] = xx [ 29 ] - ( xx [ 154 ] * xx [ 8 ] - xx [ 37 ] *
xx [ 123 ] ) * xx [ 6 ] ; xx [ 29 ] = xx [ 30 ] - xx [ 6 ] * ( xx [ 8 ] * xx
[ 123 ] + xx [ 154 ] * xx [ 37 ] ) ; xx [ 8 ] = xx [ 460 ] + xx [ 28 ] - xx [
148 ] * xx [ 1 ] + xx [ 165 ] * xx [ 29 ] + xx [ 167 ] * xx [ 43 ] + xx [ 71
] ; xx [ 28 ] = xx [ 29 ] + xx [ 133 ] ; xx [ 29 ] = ( xx [ 50 ] - ( xx [ 8 ]
+ xx [ 28 ] * xx [ 160 ] ) - ( xx [ 384 ] * xx [ 16 ] + xx [ 346 ] * xx [ 17
] ) ) / xx [ 157 ] ; xx [ 73 ] = xx [ 43 ] + xx [ 27 ] + xx [ 171 ] * xx [ 29
] ; xx [ 74 ] = xx [ 28 ] + xx [ 155 ] * xx [ 29 ] ; xx [ 75 ] = xx [ 80 ] ;
pm_math_Quaternion_xform_ra ( xx + 416 , xx + 73 , xx + 76 ) ; xx [ 16 ] = xx
[ 137 ] / xx [ 185 ] ; xx [ 17 ] = xx [ 549 ] + xx [ 65 ] + xx [ 185 ] * xx [
16 ] + xx [ 159 ] + xx [ 172 ] ; xx [ 27 ] = ( xx [ 17 ] + xx [ 158 ] + xx [
379 ] * xx [ 18 ] + xx [ 344 ] * xx [ 19 ] ) / xx [ 231 ] ; xx [ 28 ] = xx [
22 ] - xx [ 226 ] * xx [ 27 ] ; xx [ 22 ] = xx [ 234 ] * xx [ 28 ] ; xx [ 30
] = xx [ 225 ] - xx [ 230 ] * xx [ 27 ] ; xx [ 37 ] = xx [ 234 ] * xx [ 30 ]
; xx [ 43 ] = xx [ 28 ] - ( xx [ 234 ] * xx [ 22 ] - xx [ 37 ] * xx [ 181 ] )
* xx [ 6 ] ; xx [ 28 ] = xx [ 30 ] - xx [ 6 ] * ( xx [ 22 ] * xx [ 181 ] + xx
[ 234 ] * xx [ 37 ] ) ; xx [ 22 ] = xx [ 543 ] + xx [ 17 ] - xx [ 228 ] * xx
[ 27 ] + xx [ 245 ] * xx [ 28 ] + xx [ 247 ] * xx [ 43 ] + xx [ 58 ] ; xx [
17 ] = xx [ 28 ] + xx [ 60 ] ; xx [ 28 ] = ( xx [ 10 ] - ( xx [ 22 ] + xx [
17 ] * xx [ 160 ] ) - ( xx [ 318 ] * xx [ 18 ] + xx [ 457 ] * xx [ 19 ] ) ) /
xx [ 237 ] ; xx [ 60 ] = xx [ 43 ] + xx [ 2 ] + xx [ 240 ] * xx [ 28 ] ; xx [
61 ] = xx [ 17 ] + xx [ 235 ] * xx [ 28 ] ; xx [ 62 ] = xx [ 59 ] ;
pm_math_Quaternion_xform_ra ( xx + 450 , xx + 60 , xx + 17 ) ; xx [ 2 ] = xx
[ 31 ] + xx [ 34 ] + xx [ 76 ] + xx [ 17 ] + xx [ 44 ] ; xx [ 58 ] = xx [ 63
] ; xx [ 59 ] = xx [ 132 ] ; xx [ 60 ] = xx [ 522 ] + xx [ 361 ] * xx [ 9 ] ;
pm_math_Quaternion_xform_ra ( xx + 270 , xx + 58 , xx + 61 ) ;
pm_math_Vector3_cross_ra ( xx + 320 , xx + 31 , xx + 58 ) ; xx [ 73 ] = xx [
309 ] ; xx [ 74 ] = xx [ 278 ] ; xx [ 75 ] = xx [ 534 ] + xx [ 361 ] * xx [
20 ] ; pm_math_Quaternion_xform_ra ( xx + 446 , xx + 73 , xx + 79 ) ;
pm_math_Vector3_cross_ra ( xx + 337 , xx + 34 , xx + 73 ) ; xx [ 10 ] = xx [
472 ] + xx [ 147 ] * xx [ 1 ] ; xx [ 30 ] = xx [ 10 ] * xx [ 154 ] ; xx [ 31
] = xx [ 111 ] - xx [ 262 ] * xx [ 1 ] ; xx [ 34 ] = xx [ 154 ] * xx [ 31 ] ;
xx [ 82 ] = xx [ 458 ] + xx [ 10 ] - ( xx [ 154 ] * xx [ 30 ] - xx [ 34 ] *
xx [ 123 ] ) * xx [ 6 ] - xx [ 98 ] + xx [ 189 ] + xx [ 281 ] * xx [ 29 ] ;
xx [ 83 ] = xx [ 459 ] + xx [ 31 ] - xx [ 6 ] * ( xx [ 30 ] * xx [ 123 ] + xx
[ 154 ] * xx [ 34 ] ) - xx [ 177 ] + xx [ 190 ] + xx [ 274 ] * xx [ 29 ] ; xx
[ 84 ] = xx [ 8 ] + xx [ 138 ] * xx [ 29 ] ; pm_math_Quaternion_xform_ra ( xx
+ 416 , xx + 82 , xx + 85 ) ; pm_math_Vector3_cross_ra ( xx + 290 , xx + 76 ,
xx + 82 ) ; xx [ 8 ] = xx [ 4 ] - xx [ 227 ] * xx [ 27 ] ; xx [ 4 ] = xx [ 8
] * xx [ 234 ] ; xx [ 10 ] = xx [ 95 ] + xx [ 352 ] * xx [ 27 ] ; xx [ 30 ] =
xx [ 234 ] * xx [ 10 ] ; xx [ 88 ] = xx [ 541 ] + xx [ 8 ] - ( xx [ 234 ] *
xx [ 4 ] - xx [ 30 ] * xx [ 181 ] ) * xx [ 6 ] - xx [ 109 ] + xx [ 141 ] + xx
[ 362 ] * xx [ 28 ] ; xx [ 89 ] = xx [ 542 ] + xx [ 10 ] - xx [ 6 ] * ( xx [
4 ] * xx [ 181 ] + xx [ 234 ] * xx [ 30 ] ) - xx [ 146 ] + xx [ 153 ] + xx [
355 ] * xx [ 28 ] ; xx [ 90 ] = xx [ 22 ] + xx [ 168 ] * xx [ 28 ] ;
pm_math_Quaternion_xform_ra ( xx + 450 , xx + 88 , xx + 91 ) ;
pm_math_Vector3_cross_ra ( xx + 371 , xx + 17 , xx + 88 ) ; xx [ 4 ] = xx [
464 ] + xx [ 62 ] + xx [ 59 ] + xx [ 80 ] + xx [ 74 ] + xx [ 86 ] + xx [ 83 ]
+ xx [ 92 ] + xx [ 89 ] + xx [ 55 ] ; xx [ 8 ] = xx [ 465 ] + xx [ 63 ] + xx
[ 60 ] + xx [ 81 ] + xx [ 75 ] + xx [ 87 ] + xx [ 84 ] + xx [ 93 ] + xx [ 90
] + xx [ 72 ] ; xx [ 10 ] = ( xx [ 2 ] * xx [ 244 ] - ( xx [ 4 ] * xx [ 21 ]
+ xx [ 8 ] * xx [ 24 ] ) ) / xx [ 350 ] ; xx [ 70 ] = xx [ 2 ] - xx [ 265 ] *
xx [ 10 ] ; xx [ 71 ] = xx [ 32 ] + xx [ 35 ] + xx [ 77 ] + xx [ 18 ] + xx [
57 ] - xx [ 46 ] * xx [ 10 ] ; xx [ 72 ] = xx [ 33 ] + xx [ 36 ] + xx [ 78 ]
+ xx [ 19 ] + xx [ 68 ] - xx [ 40 ] * xx [ 10 ] ; pm_math_Quaternion_xform_ra
( xx + 266 , xx + 70 , xx + 17 ) ; xx [ 30 ] = xx [ 463 ] + xx [ 61 ] + xx [
58 ] + xx [ 79 ] + xx [ 73 ] + xx [ 85 ] + xx [ 82 ] + xx [ 91 ] + xx [ 88 ]
+ xx [ 41 ] - xx [ 67 ] * xx [ 10 ] ; xx [ 31 ] = xx [ 4 ] - xx [ 264 ] * xx
[ 10 ] ; xx [ 32 ] = xx [ 8 ] - xx [ 342 ] * xx [ 10 ] ;
pm_math_Quaternion_xform_ra ( xx + 266 , xx + 30 , xx + 33 ) ;
pm_math_Vector3_cross_ra ( xx + 191 , xx + 17 , xx + 30 ) ; xx [ 2 ] = ( xx [
34 ] + xx [ 31 ] ) / xx [ 52 ] ; xx [ 30 ] = xx [ 17 ] - xx [ 2 ] * xx [ 45 ]
; xx [ 31 ] = xx [ 18 ] - xx [ 2 ] * xx [ 54 ] ; xx [ 32 ] = xx [ 19 ] - xx [
2 ] * xx [ 56 ] ; pm_math_Quaternion_xform_ra ( xx + 194 , xx + 30 , xx + 17
) ; xx [ 30 ] = - xx [ 17 ] ; xx [ 31 ] = - xx [ 18 ] ; xx [ 32 ] = - xx [ 19
] ; solveSymmetricPosDef ( xx + 401 , xx + 30 , 3 , 1 , xx + 17 , xx + 33 ) ;
xx [ 4 ] = xx [ 17 ] + xx [ 13 ] ; xx [ 8 ] = xx [ 18 ] + xx [ 14 ] ; xx [ 13
] = xx [ 19 ] + xx [ 15 ] ; xx [ 17 ] = xx [ 4 ] - xx [ 69 ] ; xx [ 18 ] = xx
[ 8 ] ; xx [ 19 ] = xx [ 13 ] - xx [ 12 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 194 , xx + 17 , xx + 30 ) ; xx [ 12
] = xx [ 2 ] + pm_math_Vector3_dot_ra ( xx + 423 , xx + 30 ) ; xx [ 2 ] = xx
[ 11 ] * xx [ 12 ] ; xx [ 14 ] = xx [ 12 ] * xx [ 3 ] ; xx [ 15 ] = ( xx [ 2
] * xx [ 26 ] - xx [ 14 ] * xx [ 5 ] ) * xx [ 6 ] ; xx [ 17 ] = ( xx [ 11 ] *
xx [ 2 ] + xx [ 14 ] * xx [ 3 ] ) * xx [ 6 ] - xx [ 12 ] ; xx [ 3 ] = xx [ 6
] * ( xx [ 14 ] * xx [ 26 ] + xx [ 2 ] * xx [ 5 ] ) ; xx [ 33 ] = - xx [ 15 ]
; xx [ 34 ] = xx [ 17 ] ; xx [ 35 ] = xx [ 3 ] ; xx [ 43 ] = xx [ 30 ] + xx [
66 ] * xx [ 12 ] ; xx [ 44 ] = xx [ 31 ] ; xx [ 45 ] = xx [ 32 ] - xx [ 12 ]
* xx [ 170 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 266 , xx + 43 , xx +
30 ) ; xx [ 2 ] = xx [ 10 ] + pm_math_Vector3_dot_ra ( xx + 429 , xx + 33 ) +
pm_math_Vector3_dot_ra ( xx + 435 , xx + 30 ) ; xx [ 33 ] = - ( xx [ 163 ] +
xx [ 15 ] ) ; xx [ 34 ] = xx [ 17 ] + xx [ 2 ] * xx [ 21 ] + xx [ 7 ] ; xx [
35 ] = xx [ 3 ] + xx [ 2 ] * xx [ 24 ] - xx [ 25 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 33 , xx + 17 ) ; xx [ 3
] = xx [ 30 ] - xx [ 2 ] * xx [ 244 ] + xx [ 49 ] ; pm_math_Vector3_cross_ra
( xx + 33 , xx + 371 , xx + 24 ) ; xx [ 5 ] = xx [ 31 ] + xx [ 38 ] ; xx [ 7
] = xx [ 32 ] + xx [ 42 ] ; xx [ 30 ] = xx [ 3 ] + xx [ 24 ] ; xx [ 31 ] = xx
[ 5 ] + xx [ 25 ] ; xx [ 32 ] = xx [ 7 ] + xx [ 26 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 450 , xx + 30 , xx + 24 ) ; xx [ 10
] = xx [ 28 ] - ( pm_math_Vector3_dot_ra ( xx + 466 , xx + 17 ) + xx [ 239 ]
* xx [ 24 ] + xx [ 250 ] * xx [ 25 ] ) ; xx [ 11 ] = xx [ 17 ] + xx [ 129 ] ;
xx [ 14 ] = xx [ 18 ] - xx [ 130 ] ; xx [ 15 ] = xx [ 234 ] * xx [ 14 ] ; xx
[ 17 ] = xx [ 11 ] * xx [ 234 ] ; xx [ 18 ] = xx [ 11 ] - xx [ 6 ] * ( xx [
15 ] * xx [ 181 ] + xx [ 234 ] * xx [ 17 ] ) ; xx [ 11 ] = xx [ 14 ] - ( xx [
234 ] * xx [ 15 ] - xx [ 17 ] * xx [ 181 ] ) * xx [ 6 ] ; xx [ 14 ] = xx [ 19
] + xx [ 10 ] ; xx [ 30 ] = xx [ 18 ] ; xx [ 31 ] = xx [ 11 ] ; xx [ 32 ] =
xx [ 14 ] ; xx [ 15 ] = xx [ 24 ] + xx [ 131 ] + xx [ 14 ] * xx [ 247 ] ; xx
[ 17 ] = xx [ 25 ] + xx [ 160 ] * xx [ 10 ] + xx [ 302 ] + xx [ 14 ] * xx [
245 ] ; xx [ 19 ] = xx [ 17 ] * xx [ 234 ] ; xx [ 21 ] = xx [ 15 ] * xx [ 234
] ; xx [ 22 ] = xx [ 27 ] + pm_math_Vector3_dot_ra ( xx + 474 , xx + 30 ) + (
xx [ 15 ] - xx [ 6 ] * ( xx [ 19 ] * xx [ 181 ] + xx [ 234 ] * xx [ 21 ] ) )
* xx [ 232 ] + xx [ 224 ] * ( xx [ 17 ] - ( xx [ 234 ] * xx [ 19 ] - xx [ 21
] * xx [ 181 ] ) * xx [ 6 ] ) ; xx [ 15 ] = xx [ 14 ] - xx [ 22 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 33 , xx + 24 ) ;
pm_math_Vector3_cross_ra ( xx + 33 , xx + 290 , xx + 30 ) ; xx [ 36 ] = xx [
3 ] + xx [ 30 ] ; xx [ 37 ] = xx [ 5 ] + xx [ 31 ] ; xx [ 38 ] = xx [ 7 ] +
xx [ 32 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 416 , xx + 36 , xx + 30
) ; xx [ 14 ] = xx [ 29 ] - ( pm_math_Vector3_dot_ra ( xx + 410 , xx + 24 ) +
xx [ 164 ] * xx [ 30 ] + xx [ 174 ] * xx [ 31 ] ) ; xx [ 17 ] = xx [ 24 ] +
xx [ 134 ] ; xx [ 19 ] = xx [ 25 ] - xx [ 140 ] ; xx [ 21 ] = xx [ 154 ] * xx
[ 19 ] ; xx [ 24 ] = xx [ 17 ] * xx [ 154 ] ; xx [ 25 ] = xx [ 17 ] - xx [ 6
] * ( xx [ 21 ] * xx [ 123 ] + xx [ 154 ] * xx [ 24 ] ) ; xx [ 17 ] = xx [ 19
] - ( xx [ 154 ] * xx [ 21 ] - xx [ 24 ] * xx [ 123 ] ) * xx [ 6 ] ; xx [ 19
] = xx [ 26 ] + xx [ 14 ] ; xx [ 26 ] = xx [ 25 ] ; xx [ 27 ] = xx [ 17 ] ;
xx [ 28 ] = xx [ 19 ] ; xx [ 21 ] = xx [ 30 ] + xx [ 329 ] + xx [ 19 ] * xx [
167 ] ; xx [ 24 ] = xx [ 31 ] + xx [ 160 ] * xx [ 14 ] + xx [ 515 ] + xx [ 19
] * xx [ 165 ] ; xx [ 29 ] = xx [ 24 ] * xx [ 154 ] ; xx [ 30 ] = xx [ 21 ] *
xx [ 154 ] ; xx [ 31 ] = xx [ 1 ] + pm_math_Vector3_dot_ra ( xx + 440 , xx +
26 ) + ( xx [ 21 ] - xx [ 6 ] * ( xx [ 29 ] * xx [ 123 ] + xx [ 154 ] * xx [
30 ] ) ) * xx [ 152 ] + xx [ 142 ] * ( xx [ 24 ] - ( xx [ 154 ] * xx [ 29 ] -
xx [ 30 ] * xx [ 123 ] ) * xx [ 6 ] ) ; xx [ 1 ] = xx [ 19 ] - xx [ 31 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 33 , xx + 26 ) ;
pm_math_Vector3_cross_ra ( xx + 33 , xx + 337 , xx + 36 ) ; xx [ 40 ] = xx [
3 ] + xx [ 36 ] ; xx [ 41 ] = xx [ 5 ] + xx [ 37 ] ; xx [ 42 ] = xx [ 7 ] +
xx [ 38 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 446 , xx + 40 , xx + 36
) ; xx [ 19 ] = xx [ 20 ] - ( xx [ 115 ] * xx [ 28 ] + xx [ 139 ] * xx [ 37 ]
) ; pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 33 , xx + 36 ) ;
pm_math_Vector3_cross_ra ( xx + 33 , xx + 320 , xx + 40 ) ; xx [ 32 ] = xx [
3 ] + xx [ 40 ] ; xx [ 33 ] = xx [ 5 ] + xx [ 41 ] ; xx [ 34 ] = xx [ 7 ] +
xx [ 42 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 270 , xx + 32 , xx + 35
) ; xx [ 3 ] = xx [ 9 ] - ( xx [ 115 ] * xx [ 38 ] + xx [ 139 ] * xx [ 36 ] )
; xx [ 32 ] = xx [ 173 ] ; xx [ 33 ] = xx [ 345 ] ; xx [ 34 ] = xx [ 252 ] ;
xx [ 35 ] = xx [ 340 ] ; pm_math_Quaternion_inverseCompose_ra ( xx + 32 , xx
+ 446 , xx + 40 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 40 , xx + 454 ,
xx + 32 ) ; xx [ 35 ] = xx [ 25 ] + xx [ 249 ] ; xx [ 36 ] = xx [ 17 ] - xx [
162 ] ; xx [ 37 ] = xx [ 1 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 40 ,
xx + 35 , xx + 24 ) ; xx [ 44 ] = xx [ 428 ] ; xx [ 45 ] = xx [ 354 ] ; xx [
46 ] = xx [ 434 ] ; xx [ 47 ] = xx [ 347 ] ;
pm_math_Quaternion_inverseCompose_ra ( xx + 44 , xx + 270 , xx + 48 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 48 , xx + 529 , xx + 35 ) ; xx [ 44
] = xx [ 18 ] + xx [ 136 ] ; xx [ 45 ] = xx [ 11 ] - xx [ 126 ] ; xx [ 46 ] =
xx [ 15 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 48 , xx + 44 , xx + 52
) ; logVector [ 0 ] = state [ 0 ] ; logVector [ 1 ] = state [ 1 ] ; logVector
[ 2 ] = state [ 2 ] ; logVector [ 3 ] = state [ 3 ] ; logVector [ 4 ] = state
[ 4 ] ; logVector [ 5 ] = state [ 5 ] ; logVector [ 6 ] = xx [ 0 ] * state [
6 ] ; logVector [ 7 ] = xx [ 0 ] * state [ 7 ] ; logVector [ 8 ] = xx [ 0 ] *
state [ 8 ] ; logVector [ 9 ] = xx [ 0 ] * state [ 9 ] ; logVector [ 10 ] =
xx [ 0 ] * state [ 10 ] ; logVector [ 11 ] = xx [ 0 ] * state [ 11 ] ;
logVector [ 12 ] = xx [ 0 ] * state [ 12 ] ; logVector [ 13 ] = xx [ 0 ] *
state [ 13 ] ; logVector [ 14 ] = xx [ 0 ] * state [ 14 ] ; logVector [ 15 ]
= xx [ 0 ] * state [ 15 ] ; logVector [ 16 ] = xx [ 0 ] * state [ 16 ] ;
logVector [ 17 ] = xx [ 0 ] * state [ 17 ] ; logVector [ 18 ] = xx [ 0 ] *
state [ 18 ] ; logVector [ 19 ] = xx [ 0 ] * state [ 19 ] ; logVector [ 20 ]
= xx [ 0 ] * state [ 20 ] ; logVector [ 21 ] = xx [ 0 ] * state [ 21 ] ;
logVector [ 22 ] = xx [ 0 ] * state [ 22 ] ; logVector [ 23 ] = xx [ 0 ] *
state [ 23 ] ; logVector [ 24 ] = xx [ 0 ] * state [ 24 ] ; logVector [ 25 ]
= xx [ 0 ] * state [ 25 ] ; logVector [ 26 ] = xx [ 4 ] ; logVector [ 27 ] =
xx [ 8 ] ; logVector [ 28 ] = xx [ 13 ] ; logVector [ 29 ] = - ( xx [ 12 ] *
xx [ 0 ] ) ; logVector [ 30 ] = - ( xx [ 2 ] * xx [ 0 ] ) ; logVector [ 31 ]
= xx [ 0 ] * xx [ 10 ] ; logVector [ 32 ] = - ( xx [ 22 ] * xx [ 0 ] ) ;
logVector [ 33 ] = xx [ 0 ] * ( xx [ 16 ] - xx [ 15 ] ) ; logVector [ 34 ] =
xx [ 0 ] * xx [ 14 ] ; logVector [ 35 ] = - ( xx [ 31 ] * xx [ 0 ] ) ;
logVector [ 36 ] = xx [ 0 ] * ( xx [ 23 ] - xx [ 1 ] ) ; logVector [ 37 ] =
xx [ 0 ] * xx [ 19 ] ; logVector [ 38 ] = xx [ 0 ] * xx [ 3 ] ; logVector [
39 ] = ( state [ 26 ] + sm_core_canonicalAngle ( xx [ 6 ] * atan2 ( sqrt ( xx
[ 41 ] * xx [ 41 ] + xx [ 42 ] * xx [ 42 ] + xx [ 43 ] * xx [ 43 ] ) , fabs (
- xx [ 40 ] ) ) * ( ( xx [ 40 ] * xx [ 43 ] ) < 0.0 ? - 1.0 : + 1.0 ) - state
[ 26 ] ) ) * xx [ 0 ] ; logVector [ 40 ] = xx [ 0 ] * ( xx [ 198 ] - xx [ 34
] ) ; logVector [ 41 ] = xx [ 0 ] * ( xx [ 28 ] + xx [ 19 ] - xx [ 26 ] ) ;
logVector [ 42 ] = ( state [ 28 ] + sm_core_canonicalAngle ( xx [ 6 ] * atan2
( sqrt ( xx [ 49 ] * xx [ 49 ] + xx [ 50 ] * xx [ 50 ] + xx [ 51 ] * xx [ 51
] ) , fabs ( - xx [ 48 ] ) ) * ( ( xx [ 48 ] * xx [ 51 ] ) < 0.0 ? - 1.0 : +
1.0 ) - state [ 28 ] ) ) * xx [ 0 ] ; logVector [ 43 ] = xx [ 0 ] * ( xx [
122 ] - xx [ 37 ] ) ; logVector [ 44 ] = xx [ 0 ] * ( xx [ 38 ] + xx [ 3 ] -
xx [ 54 ] ) ; errorResult [ 0 ] = xx [ 39 ] ; return NULL ; }
