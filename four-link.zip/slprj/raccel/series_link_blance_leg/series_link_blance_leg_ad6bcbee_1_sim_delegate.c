#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
void series_link_blance_leg_ad6bcbee_1_resetSimStateVector ( const void *
mech , double * state ) { double xx [ 1 ] ; ( void ) mech ; xx [ 0 ] = 0.0 ;
state [ 0 ] = xx [ 0 ] ; state [ 1 ] = xx [ 0 ] ; state [ 2 ] = xx [ 0 ] ;
state [ 3 ] = xx [ 0 ] ; state [ 4 ] = xx [ 0 ] ; state [ 5 ] = xx [ 0 ] ;
state [ 6 ] = xx [ 0 ] ; state [ 7 ] = xx [ 0 ] ; state [ 8 ] = xx [ 0 ] ;
state [ 9 ] = xx [ 0 ] ; state [ 10 ] = xx [ 0 ] ; state [ 11 ] = xx [ 0 ] ;
state [ 12 ] = xx [ 0 ] ; state [ 13 ] = xx [ 0 ] ; state [ 14 ] = xx [ 0 ] ;
state [ 15 ] = xx [ 0 ] ; state [ 16 ] = xx [ 0 ] ; state [ 17 ] = xx [ 0 ] ;
state [ 18 ] = xx [ 0 ] ; state [ 19 ] = xx [ 0 ] ; state [ 20 ] = xx [ 0 ] ;
state [ 21 ] = xx [ 0 ] ; state [ 22 ] = xx [ 0 ] ; state [ 23 ] = xx [ 0 ] ;
state [ 24 ] = xx [ 0 ] ; state [ 25 ] = xx [ 0 ] ; state [ 26 ] = xx [ 0 ] ;
state [ 27 ] = xx [ 0 ] ; state [ 28 ] = xx [ 0 ] ; state [ 29 ] = xx [ 0 ] ;
} static void perturbSimJointPrimitiveState_0_0 ( double mag , double * state
) { state [ 0 ] = state [ 0 ] + mag ; } static void
perturbSimJointPrimitiveState_0_0v ( double mag , double * state ) { state [
0 ] = state [ 0 ] + mag ; state [ 3 ] = state [ 3 ] - 0.875 * mag ; } static
void perturbSimJointPrimitiveState_0_1 ( double mag , double * state ) {
state [ 1 ] = state [ 1 ] + mag ; } static void
perturbSimJointPrimitiveState_0_1v ( double mag , double * state ) { state [
1 ] = state [ 1 ] + mag ; state [ 4 ] = state [ 4 ] - 0.875 * mag ; } static
void perturbSimJointPrimitiveState_0_2 ( double mag , double * state ) {
state [ 2 ] = state [ 2 ] + mag ; } static void
perturbSimJointPrimitiveState_0_2v ( double mag , double * state ) { state [
2 ] = state [ 2 ] + mag ; state [ 5 ] = state [ 5 ] - 0.875 * mag ; } static
void perturbSimJointPrimitiveState_1_0 ( double mag , double * state ) {
state [ 6 ] = state [ 6 ] + mag ; } static void
perturbSimJointPrimitiveState_1_0v ( double mag , double * state ) { state [
6 ] = state [ 6 ] + mag ; state [ 7 ] = state [ 7 ] - 0.875 * mag ; } static
void perturbSimJointPrimitiveState_2_0 ( double mag , double * state ) {
state [ 8 ] = state [ 8 ] + mag ; } static void
perturbSimJointPrimitiveState_2_0v ( double mag , double * state ) { state [
8 ] = state [ 8 ] + mag ; state [ 9 ] = state [ 9 ] - 0.875 * mag ; } static
void perturbSimJointPrimitiveState_3_0 ( double mag , double * state ) {
state [ 10 ] = state [ 10 ] + mag ; } static void
perturbSimJointPrimitiveState_3_0v ( double mag , double * state ) { state [
10 ] = state [ 10 ] + mag ; state [ 11 ] = state [ 11 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_4_0 ( double mag , double * state )
{ state [ 12 ] = state [ 12 ] + mag ; } static void
perturbSimJointPrimitiveState_4_0v ( double mag , double * state ) { state [
12 ] = state [ 12 ] + mag ; state [ 13 ] = state [ 13 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_5_0 ( double mag , double * state )
{ state [ 14 ] = state [ 14 ] + mag ; } static void
perturbSimJointPrimitiveState_5_0v ( double mag , double * state ) { state [
14 ] = state [ 14 ] + mag ; state [ 15 ] = state [ 15 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_6_0 ( double mag , double * state )
{ state [ 16 ] = state [ 16 ] + mag ; } static void
perturbSimJointPrimitiveState_6_0v ( double mag , double * state ) { state [
16 ] = state [ 16 ] + mag ; state [ 17 ] = state [ 17 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_7_0 ( double mag , double * state )
{ state [ 18 ] = state [ 18 ] + mag ; } static void
perturbSimJointPrimitiveState_7_0v ( double mag , double * state ) { state [
18 ] = state [ 18 ] + mag ; state [ 19 ] = state [ 19 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_8_0 ( double mag , double * state )
{ state [ 20 ] = state [ 20 ] + mag ; } static void
perturbSimJointPrimitiveState_8_0v ( double mag , double * state ) { state [
20 ] = state [ 20 ] + mag ; state [ 21 ] = state [ 21 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_9_0 ( double mag , double * state )
{ state [ 22 ] = state [ 22 ] + mag ; } static void
perturbSimJointPrimitiveState_9_0v ( double mag , double * state ) { state [
22 ] = state [ 22 ] + mag ; state [ 23 ] = state [ 23 ] - 0.875 * mag ; }
static void perturbSimJointPrimitiveState_10_0 ( double mag , double * state
) { state [ 24 ] = state [ 24 ] + mag ; } static void
perturbSimJointPrimitiveState_10_0v ( double mag , double * state ) { state [
24 ] = state [ 24 ] + mag ; state [ 25 ] = state [ 25 ] - 0.875 * mag ; }
void series_link_blance_leg_ad6bcbee_1_perturbSimJointPrimitiveState ( const
void * mech , size_t stageIdx , size_t primIdx , double mag , boolean_T
doPerturbVelocity , double * state ) { ( void ) mech ; ( void ) stageIdx ; (
void ) primIdx ; ( void ) mag ; ( void ) doPerturbVelocity ; ( void ) state ;
switch ( ( stageIdx * 6 + primIdx ) * 2 + ( doPerturbVelocity ? 1 : 0 ) ) {
case 0 : perturbSimJointPrimitiveState_0_0 ( mag , state ) ; break ; case 1 :
perturbSimJointPrimitiveState_0_0v ( mag , state ) ; break ; case 2 :
perturbSimJointPrimitiveState_0_1 ( mag , state ) ; break ; case 3 :
perturbSimJointPrimitiveState_0_1v ( mag , state ) ; break ; case 4 :
perturbSimJointPrimitiveState_0_2 ( mag , state ) ; break ; case 5 :
perturbSimJointPrimitiveState_0_2v ( mag , state ) ; break ; case 12 :
perturbSimJointPrimitiveState_1_0 ( mag , state ) ; break ; case 13 :
perturbSimJointPrimitiveState_1_0v ( mag , state ) ; break ; case 24 :
perturbSimJointPrimitiveState_2_0 ( mag , state ) ; break ; case 25 :
perturbSimJointPrimitiveState_2_0v ( mag , state ) ; break ; case 36 :
perturbSimJointPrimitiveState_3_0 ( mag , state ) ; break ; case 37 :
perturbSimJointPrimitiveState_3_0v ( mag , state ) ; break ; case 48 :
perturbSimJointPrimitiveState_4_0 ( mag , state ) ; break ; case 49 :
perturbSimJointPrimitiveState_4_0v ( mag , state ) ; break ; case 60 :
perturbSimJointPrimitiveState_5_0 ( mag , state ) ; break ; case 61 :
perturbSimJointPrimitiveState_5_0v ( mag , state ) ; break ; case 72 :
perturbSimJointPrimitiveState_6_0 ( mag , state ) ; break ; case 73 :
perturbSimJointPrimitiveState_6_0v ( mag , state ) ; break ; case 84 :
perturbSimJointPrimitiveState_7_0 ( mag , state ) ; break ; case 85 :
perturbSimJointPrimitiveState_7_0v ( mag , state ) ; break ; case 96 :
perturbSimJointPrimitiveState_8_0 ( mag , state ) ; break ; case 97 :
perturbSimJointPrimitiveState_8_0v ( mag , state ) ; break ; case 108 :
perturbSimJointPrimitiveState_9_0 ( mag , state ) ; break ; case 109 :
perturbSimJointPrimitiveState_9_0v ( mag , state ) ; break ; case 120 :
perturbSimJointPrimitiveState_10_0 ( mag , state ) ; break ; case 121 :
perturbSimJointPrimitiveState_10_0v ( mag , state ) ; break ; } } void
series_link_blance_leg_ad6bcbee_1_perturbFlexibleBodyState ( const void *
mech , size_t stageIdx , double mag , boolean_T doPerturbVelocity , double *
state ) { ( void ) mech ; ( void ) stageIdx ; ( void ) mag ; ( void )
doPerturbVelocity ; ( void ) state ; switch ( stageIdx * 2 + (
doPerturbVelocity ? 1 : 0 ) ) { } } void
series_link_blance_leg_ad6bcbee_1_constructStateVector ( const void * mech ,
const double * solverState , const double * u , const double * uDot , double
* discreteState , double * fullState ) { ( void ) mech ; ( void ) u ; ( void
) uDot ; ( void ) discreteState ; fullState [ 0 ] = solverState [ 0 ] ;
fullState [ 1 ] = solverState [ 1 ] ; fullState [ 2 ] = solverState [ 2 ] ;
fullState [ 3 ] = solverState [ 3 ] ; fullState [ 4 ] = solverState [ 4 ] ;
fullState [ 5 ] = solverState [ 5 ] ; fullState [ 6 ] = solverState [ 6 ] ;
fullState [ 7 ] = solverState [ 7 ] ; fullState [ 8 ] = solverState [ 8 ] ;
fullState [ 9 ] = solverState [ 9 ] ; fullState [ 10 ] = solverState [ 10 ] ;
fullState [ 11 ] = solverState [ 11 ] ; fullState [ 12 ] = solverState [ 12 ]
; fullState [ 13 ] = solverState [ 13 ] ; fullState [ 14 ] = solverState [ 14
] ; fullState [ 15 ] = solverState [ 15 ] ; fullState [ 16 ] = solverState [
16 ] ; fullState [ 17 ] = solverState [ 17 ] ; fullState [ 18 ] = solverState
[ 18 ] ; fullState [ 19 ] = solverState [ 19 ] ; fullState [ 20 ] =
solverState [ 20 ] ; fullState [ 21 ] = solverState [ 21 ] ; fullState [ 22 ]
= solverState [ 22 ] ; fullState [ 23 ] = solverState [ 23 ] ; fullState [ 24
] = solverState [ 24 ] ; fullState [ 25 ] = solverState [ 25 ] ; fullState [
26 ] = solverState [ 26 ] ; fullState [ 27 ] = solverState [ 27 ] ; fullState
[ 28 ] = solverState [ 28 ] ; fullState [ 29 ] = solverState [ 29 ] ; } void
series_link_blance_leg_ad6bcbee_1_extractSolverStateVector ( const void *
mech , const double * fullState , double * solverState ) { ( void ) mech ;
solverState [ 0 ] = fullState [ 0 ] ; solverState [ 1 ] = fullState [ 1 ] ;
solverState [ 2 ] = fullState [ 2 ] ; solverState [ 3 ] = fullState [ 3 ] ;
solverState [ 4 ] = fullState [ 4 ] ; solverState [ 5 ] = fullState [ 5 ] ;
solverState [ 6 ] = fullState [ 6 ] ; solverState [ 7 ] = fullState [ 7 ] ;
solverState [ 8 ] = fullState [ 8 ] ; solverState [ 9 ] = fullState [ 9 ] ;
solverState [ 10 ] = fullState [ 10 ] ; solverState [ 11 ] = fullState [ 11 ]
; solverState [ 12 ] = fullState [ 12 ] ; solverState [ 13 ] = fullState [ 13
] ; solverState [ 14 ] = fullState [ 14 ] ; solverState [ 15 ] = fullState [
15 ] ; solverState [ 16 ] = fullState [ 16 ] ; solverState [ 17 ] = fullState
[ 17 ] ; solverState [ 18 ] = fullState [ 18 ] ; solverState [ 19 ] =
fullState [ 19 ] ; solverState [ 20 ] = fullState [ 20 ] ; solverState [ 21 ]
= fullState [ 21 ] ; solverState [ 22 ] = fullState [ 22 ] ; solverState [ 23
] = fullState [ 23 ] ; solverState [ 24 ] = fullState [ 24 ] ; solverState [
25 ] = fullState [ 25 ] ; solverState [ 26 ] = fullState [ 26 ] ; solverState
[ 27 ] = fullState [ 27 ] ; solverState [ 28 ] = fullState [ 28 ] ;
solverState [ 29 ] = fullState [ 29 ] ; } boolean_T
series_link_blance_leg_ad6bcbee_1_isPositionViolation ( const void * mech ,
const RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const
double * state , const int * modeVector ) { const double * rtdvd = rtdv ->
mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ; int ii [ 1
] ; double xx [ 48 ] ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; (
void ) eqnEnableFlags ; ( void ) modeVector ; xx [ 0 ] = 0.6970892476441968 ;
xx [ 1 ] = 0.5 ; xx [ 2 ] = xx [ 1 ] * state [ 22 ] ; xx [ 3 ] = sin ( xx [ 2
] ) ; xx [ 4 ] = xx [ 0 ] * xx [ 3 ] ; xx [ 5 ] = 0.1186026172512557 ; xx [ 6
] = cos ( xx [ 2 ] ) ; xx [ 2 ] = xx [ 5 ] * xx [ 6 ] ; xx [ 7 ] = 0.085075 ;
xx [ 8 ] = ( xx [ 4 ] + xx [ 2 ] ) * xx [ 7 ] ; xx [ 9 ] = xx [ 5 ] * xx [ 3
] - xx [ 0 ] * xx [ 6 ] ; xx [ 3 ] = xx [ 8 ] * xx [ 9 ] ; xx [ 6 ] = xx [ 2
] + xx [ 4 ] ; xx [ 2 ] = xx [ 7 ] * xx [ 9 ] ; xx [ 4 ] = xx [ 6 ] * xx [ 2
] ; xx [ 10 ] = 2.0 ; xx [ 11 ] = xx [ 1 ] * state [ 16 ] ; xx [ 12 ] = sin (
xx [ 11 ] ) ; xx [ 13 ] = xx [ 0 ] * xx [ 12 ] ; xx [ 14 ] = cos ( xx [ 11 ]
) ; xx [ 11 ] = xx [ 5 ] * xx [ 14 ] ; xx [ 15 ] = xx [ 13 ] + xx [ 11 ] ; xx
[ 16 ] = 0.1078490312466243 ; xx [ 17 ] = 0.7071067811865476 ; xx [ 18 ] = xx
[ 1 ] * state [ 18 ] ; xx [ 19 ] = xx [ 17 ] * sin ( xx [ 18 ] ) ; xx [ 20 ]
= xx [ 17 ] * cos ( xx [ 18 ] ) ; xx [ 18 ] = xx [ 19 ] + xx [ 20 ] ; xx [ 21
] = 0.02913743527133955 ; xx [ 22 ] = xx [ 18 ] * xx [ 21 ] ; xx [ 23 ] = xx
[ 16 ] - xx [ 10 ] * xx [ 18 ] * xx [ 22 ] ; xx [ 24 ] = xx [ 15 ] * xx [ 23
] ; xx [ 25 ] = xx [ 0 ] * xx [ 14 ] - xx [ 5 ] * xx [ 12 ] ; xx [ 12 ] = xx
[ 11 ] + xx [ 13 ] ; xx [ 26 ] = xx [ 12 ] ; xx [ 27 ] = xx [ 25 ] ; xx [ 28
] = xx [ 15 ] ; xx [ 11 ] = xx [ 19 ] - xx [ 20 ] ; xx [ 13 ] = xx [ 10 ] *
xx [ 22 ] * xx [ 11 ] ; xx [ 14 ] = xx [ 12 ] * xx [ 13 ] + xx [ 23 ] * xx [
25 ] ; xx [ 29 ] = xx [ 15 ] * xx [ 13 ] ; xx [ 30 ] = xx [ 24 ] ; xx [ 31 ]
= - xx [ 14 ] ; pm_math_Vector3_cross_ra ( xx + 26 , xx + 29 , xx + 32 ) ; xx
[ 19 ] = 0.08603840402471528 ; xx [ 20 ] = xx [ 15 ] * xx [ 19 ] ; xx [ 22 ]
= xx [ 19 ] * xx [ 25 ] ; xx [ 23 ] = xx [ 18 ] * xx [ 25 ] ; xx [ 26 ] =
0.06918743527133955 ; xx [ 27 ] = ( xx [ 15 ] * xx [ 11 ] - xx [ 23 ] ) * xx
[ 26 ] ; xx [ 28 ] = xx [ 25 ] * xx [ 11 ] ; xx [ 29 ] = xx [ 28 ] + xx [ 15
] * xx [ 18 ] ; xx [ 15 ] = xx [ 12 ] * xx [ 11 ] - xx [ 23 ] ; xx [ 11 ] =
xx [ 26 ] * ( xx [ 28 ] + xx [ 12 ] * xx [ 18 ] ) ; xx [ 18 ] =
0.07164265098815176 ; xx [ 23 ] = xx [ 6 ] * xx [ 8 ] ; xx [ 6 ] = xx [ 2 ] *
xx [ 9 ] ; xx [ 2 ] = 0.03446132628599599 ; xx [ 8 ] = xx [ 1 ] * state [ 24
] ; xx [ 9 ] = sin ( xx [ 8 ] ) ; xx [ 28 ] = xx [ 0 ] * xx [ 9 ] ; xx [ 30 ]
= cos ( xx [ 8 ] ) ; xx [ 8 ] = xx [ 5 ] * xx [ 30 ] ; xx [ 31 ] = ( xx [ 28
] + xx [ 8 ] ) * xx [ 7 ] ; xx [ 32 ] = xx [ 5 ] * xx [ 9 ] - xx [ 0 ] * xx [
30 ] ; xx [ 9 ] = xx [ 31 ] * xx [ 32 ] ; xx [ 30 ] = xx [ 8 ] + xx [ 28 ] ;
xx [ 8 ] = xx [ 7 ] * xx [ 32 ] ; xx [ 7 ] = xx [ 30 ] * xx [ 8 ] ; xx [ 28 ]
= xx [ 1 ] * state [ 10 ] ; xx [ 35 ] = sin ( xx [ 28 ] ) ; xx [ 36 ] = xx [
0 ] * xx [ 35 ] ; xx [ 37 ] = cos ( xx [ 28 ] ) ; xx [ 28 ] = xx [ 5 ] * xx [
37 ] ; xx [ 38 ] = xx [ 36 ] + xx [ 28 ] ; xx [ 39 ] = xx [ 1 ] * state [ 12
] ; xx [ 1 ] = xx [ 17 ] * sin ( xx [ 39 ] ) ; xx [ 40 ] = xx [ 17 ] * cos (
xx [ 39 ] ) ; xx [ 17 ] = xx [ 1 ] + xx [ 40 ] ; xx [ 39 ] = xx [ 17 ] * xx [
21 ] ; xx [ 21 ] = xx [ 16 ] - xx [ 10 ] * xx [ 17 ] * xx [ 39 ] ; xx [ 16 ]
= xx [ 38 ] * xx [ 21 ] ; xx [ 41 ] = xx [ 0 ] * xx [ 37 ] - xx [ 5 ] * xx [
35 ] ; xx [ 0 ] = xx [ 28 ] + xx [ 36 ] ; xx [ 35 ] = xx [ 0 ] ; xx [ 36 ] =
xx [ 41 ] ; xx [ 37 ] = xx [ 38 ] ; xx [ 5 ] = xx [ 1 ] - xx [ 40 ] ; xx [ 1
] = xx [ 10 ] * xx [ 39 ] * xx [ 5 ] ; xx [ 28 ] = xx [ 0 ] * xx [ 1 ] + xx [
21 ] * xx [ 41 ] ; xx [ 42 ] = xx [ 38 ] * xx [ 1 ] ; xx [ 43 ] = xx [ 16 ] ;
xx [ 44 ] = - xx [ 28 ] ; pm_math_Vector3_cross_ra ( xx + 35 , xx + 42 , xx +
45 ) ; xx [ 21 ] = xx [ 38 ] * xx [ 19 ] ; xx [ 35 ] = xx [ 19 ] * xx [ 41 ]
; xx [ 19 ] = xx [ 17 ] * xx [ 41 ] ; xx [ 36 ] = ( xx [ 38 ] * xx [ 5 ] - xx
[ 19 ] ) * xx [ 26 ] ; xx [ 37 ] = xx [ 41 ] * xx [ 5 ] ; xx [ 39 ] = xx [ 37
] + xx [ 38 ] * xx [ 17 ] ; xx [ 38 ] = xx [ 0 ] * xx [ 5 ] - xx [ 19 ] ; xx
[ 5 ] = xx [ 26 ] * ( xx [ 37 ] + xx [ 0 ] * xx [ 17 ] ) ; xx [ 17 ] = xx [
30 ] * xx [ 31 ] ; xx [ 19 ] = xx [ 8 ] * xx [ 32 ] ; xx [ 42 ] = fabs ( - (
( xx [ 3 ] + xx [ 4 ] ) * xx [ 10 ] + ( xx [ 3 ] + xx [ 4 ] ) * xx [ 10 ] + (
xx [ 24 ] * xx [ 25 ] + xx [ 33 ] ) * xx [ 10 ] - ( xx [ 13 ] - ( xx [ 20 ] *
xx [ 25 ] + xx [ 12 ] * xx [ 22 ] ) * xx [ 10 ] ) - ( xx [ 27 ] * xx [ 29 ] +
xx [ 15 ] * xx [ 11 ] ) * xx [ 10 ] + xx [ 18 ] ) ) ; xx [ 43 ] = fabs ( xx [
10 ] * ( xx [ 23 ] - xx [ 6 ] ) - xx [ 10 ] * ( xx [ 6 ] - xx [ 23 ] ) - ( xx
[ 10 ] * ( xx [ 11 ] * xx [ 29 ] - xx [ 15 ] * xx [ 27 ] ) + xx [ 10 ] * ( xx
[ 34 ] - xx [ 14 ] * xx [ 25 ] ) - xx [ 10 ] * ( xx [ 22 ] * xx [ 25 ] - xx [
12 ] * xx [ 20 ] ) ) + xx [ 2 ] ) ; xx [ 44 ] = fabs ( - ( ( xx [ 9 ] + xx [
7 ] ) * xx [ 10 ] + ( xx [ 9 ] + xx [ 7 ] ) * xx [ 10 ] + ( xx [ 16 ] * xx [
41 ] + xx [ 46 ] ) * xx [ 10 ] - ( xx [ 1 ] - ( xx [ 21 ] * xx [ 41 ] + xx [
0 ] * xx [ 35 ] ) * xx [ 10 ] ) - ( xx [ 36 ] * xx [ 39 ] + xx [ 38 ] * xx [
5 ] ) * xx [ 10 ] + xx [ 18 ] ) ) ; xx [ 45 ] = fabs ( xx [ 10 ] * ( xx [ 17
] - xx [ 19 ] ) - xx [ 10 ] * ( xx [ 19 ] - xx [ 17 ] ) - ( xx [ 10 ] * ( xx
[ 5 ] * xx [ 39 ] - xx [ 38 ] * xx [ 36 ] ) + xx [ 10 ] * ( xx [ 47 ] - xx [
28 ] * xx [ 41 ] ) - xx [ 10 ] * ( xx [ 35 ] * xx [ 41 ] - xx [ 0 ] * xx [ 21
] ) ) + xx [ 2 ] ) ; ii [ 0 ] = 42 ; { int ll ; for ( ll = 43 ; ll < 46 ; ++
ll ) if ( xx [ ll ] > xx [ ii [ 0 ] ] ) ii [ 0 ] = ll ; } ii [ 0 ] -= 42 ; xx
[ 0 ] = xx [ 42 + ( ii [ 0 ] ) ] ; return xx [ 0 ] > 1.0e-9 ; } boolean_T
series_link_blance_leg_ad6bcbee_1_isVelocityViolation ( const void * mech ,
const RuntimeDerivedValuesBundle * rtdv , const int * eqnEnableFlags , const
double * state , const int * modeVector ) { const double * rtdvd = rtdv ->
mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ; int ii [ 1
] ; double xx [ 65 ] ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; (
void ) eqnEnableFlags ; ( void ) modeVector ; xx [ 0 ] = 0.085075 ; xx [ 1 ]
= xx [ 0 ] * state [ 23 ] ; xx [ 2 ] = 0.6970892476441968 ; xx [ 3 ] = 0.5 ;
xx [ 4 ] = xx [ 3 ] * state [ 22 ] ; xx [ 5 ] = sin ( xx [ 4 ] ) ; xx [ 6 ] =
xx [ 2 ] * xx [ 5 ] ; xx [ 7 ] = 0.1186026172512557 ; xx [ 8 ] = cos ( xx [ 4
] ) ; xx [ 4 ] = xx [ 7 ] * xx [ 8 ] ; xx [ 9 ] = xx [ 6 ] + xx [ 4 ] ; xx [
10 ] = xx [ 9 ] * xx [ 1 ] ; xx [ 11 ] = xx [ 4 ] + xx [ 6 ] ; xx [ 4 ] = xx
[ 11 ] * xx [ 1 ] ; xx [ 6 ] = 2.0 ; xx [ 12 ] = xx [ 9 ] * xx [ 0 ] ; xx [
13 ] = xx [ 11 ] * xx [ 0 ] ; xx [ 14 ] = xx [ 3 ] * state [ 16 ] ; xx [ 15 ]
= sin ( xx [ 14 ] ) ; xx [ 16 ] = xx [ 2 ] * xx [ 15 ] ; xx [ 17 ] = cos ( xx
[ 14 ] ) ; xx [ 14 ] = xx [ 7 ] * xx [ 17 ] ; xx [ 18 ] = xx [ 16 ] + xx [ 14
] ; xx [ 19 ] = 0.7071067811865476 ; xx [ 20 ] = xx [ 3 ] * state [ 18 ] ; xx
[ 21 ] = xx [ 19 ] * sin ( xx [ 20 ] ) ; xx [ 22 ] = xx [ 19 ] * cos ( xx [
20 ] ) ; xx [ 20 ] = xx [ 21 ] - xx [ 22 ] ; xx [ 23 ] = xx [ 21 ] + xx [ 22
] ; xx [ 21 ] = xx [ 2 ] * xx [ 17 ] - xx [ 7 ] * xx [ 15 ] ; xx [ 15 ] = xx
[ 23 ] * xx [ 21 ] ; xx [ 17 ] = xx [ 18 ] * xx [ 20 ] - xx [ 15 ] ; xx [ 22
] = 0.06918743527133955 ; xx [ 24 ] = ( state [ 17 ] + state [ 19 ] ) * xx [
22 ] ; xx [ 25 ] = xx [ 17 ] * xx [ 24 ] ; xx [ 26 ] = xx [ 14 ] + xx [ 16 ]
; xx [ 14 ] = xx [ 26 ] * xx [ 20 ] - xx [ 15 ] ; xx [ 15 ] = xx [ 14 ] * xx
[ 24 ] ; xx [ 16 ] = 0.08603840402471528 ; xx [ 27 ] = xx [ 18 ] * xx [ 16 ]
; xx [ 28 ] = xx [ 26 ] * xx [ 16 ] ; xx [ 29 ] = 0.02913743527133955 ; xx [
30 ] = xx [ 23 ] * xx [ 29 ] ; xx [ 31 ] = xx [ 6 ] * xx [ 23 ] * xx [ 30 ] ;
xx [ 32 ] = 0.1078490312466243 ; xx [ 33 ] = ( xx [ 29 ] - xx [ 31 ] ) *
state [ 19 ] + ( xx [ 32 ] - xx [ 31 ] ) * state [ 17 ] ; xx [ 31 ] = xx [ 30
] * xx [ 20 ] ; xx [ 30 ] = xx [ 6 ] * xx [ 31 ] * state [ 17 ] + xx [ 6 ] *
xx [ 31 ] * state [ 19 ] ; xx [ 31 ] = xx [ 18 ] * xx [ 30 ] ; xx [ 34 ] = xx
[ 26 ] ; xx [ 35 ] = xx [ 21 ] ; xx [ 36 ] = xx [ 18 ] ; xx [ 37 ] = xx [ 26
] * xx [ 33 ] - xx [ 21 ] * xx [ 30 ] ; xx [ 38 ] = - ( xx [ 18 ] * xx [ 33 ]
) ; xx [ 39 ] = xx [ 31 ] ; xx [ 40 ] = xx [ 37 ] ; pm_math_Vector3_cross_ra
( xx + 34 , xx + 38 , xx + 41 ) ; xx [ 30 ] = xx [ 7 ] * xx [ 5 ] - xx [ 2 ]
* xx [ 8 ] ; xx [ 5 ] = xx [ 21 ] * xx [ 20 ] ; xx [ 8 ] = xx [ 0 ] * state [
25 ] ; xx [ 20 ] = xx [ 3 ] * state [ 24 ] ; xx [ 34 ] = sin ( xx [ 20 ] ) ;
xx [ 35 ] = xx [ 2 ] * xx [ 34 ] ; xx [ 36 ] = cos ( xx [ 20 ] ) ; xx [ 20 ]
= xx [ 7 ] * xx [ 36 ] ; xx [ 38 ] = xx [ 35 ] + xx [ 20 ] ; xx [ 39 ] = xx [
38 ] * xx [ 8 ] ; xx [ 40 ] = xx [ 20 ] + xx [ 35 ] ; xx [ 20 ] = xx [ 40 ] *
xx [ 8 ] ; xx [ 35 ] = xx [ 38 ] * xx [ 0 ] ; xx [ 41 ] = xx [ 40 ] * xx [ 0
] ; xx [ 44 ] = xx [ 3 ] * state [ 10 ] ; xx [ 45 ] = sin ( xx [ 44 ] ) ; xx
[ 46 ] = xx [ 2 ] * xx [ 45 ] ; xx [ 47 ] = cos ( xx [ 44 ] ) ; xx [ 44 ] =
xx [ 7 ] * xx [ 47 ] ; xx [ 48 ] = xx [ 46 ] + xx [ 44 ] ; xx [ 49 ] = xx [ 3
] * state [ 12 ] ; xx [ 3 ] = xx [ 19 ] * sin ( xx [ 49 ] ) ; xx [ 50 ] = xx
[ 19 ] * cos ( xx [ 49 ] ) ; xx [ 19 ] = xx [ 3 ] - xx [ 50 ] ; xx [ 49 ] =
xx [ 3 ] + xx [ 50 ] ; xx [ 3 ] = xx [ 2 ] * xx [ 47 ] - xx [ 7 ] * xx [ 45 ]
; xx [ 45 ] = xx [ 49 ] * xx [ 3 ] ; xx [ 47 ] = xx [ 48 ] * xx [ 19 ] - xx [
45 ] ; xx [ 50 ] = ( state [ 11 ] + state [ 13 ] ) * xx [ 22 ] ; xx [ 22 ] =
xx [ 47 ] * xx [ 50 ] ; xx [ 51 ] = xx [ 44 ] + xx [ 46 ] ; xx [ 44 ] = xx [
51 ] * xx [ 19 ] - xx [ 45 ] ; xx [ 45 ] = xx [ 44 ] * xx [ 50 ] ; xx [ 46 ]
= xx [ 48 ] * xx [ 16 ] ; xx [ 52 ] = xx [ 51 ] * xx [ 16 ] ; xx [ 53 ] = xx
[ 49 ] * xx [ 29 ] ; xx [ 54 ] = xx [ 6 ] * xx [ 49 ] * xx [ 53 ] ; xx [ 55 ]
= ( xx [ 29 ] - xx [ 54 ] ) * state [ 13 ] + ( xx [ 32 ] - xx [ 54 ] ) *
state [ 11 ] ; xx [ 29 ] = xx [ 53 ] * xx [ 19 ] ; xx [ 32 ] = xx [ 6 ] * xx
[ 29 ] * state [ 11 ] + xx [ 6 ] * xx [ 29 ] * state [ 13 ] ; xx [ 29 ] = xx
[ 48 ] * xx [ 32 ] ; xx [ 56 ] = xx [ 51 ] ; xx [ 57 ] = xx [ 3 ] ; xx [ 58 ]
= xx [ 48 ] ; xx [ 53 ] = xx [ 51 ] * xx [ 55 ] - xx [ 3 ] * xx [ 32 ] ; xx [
59 ] = - ( xx [ 48 ] * xx [ 55 ] ) ; xx [ 60 ] = xx [ 29 ] ; xx [ 61 ] = xx [
53 ] ; pm_math_Vector3_cross_ra ( xx + 56 , xx + 59 , xx + 62 ) ; xx [ 32 ] =
xx [ 7 ] * xx [ 34 ] - xx [ 2 ] * xx [ 36 ] ; xx [ 2 ] = xx [ 3 ] * xx [ 19 ]
; xx [ 56 ] = fabs ( xx [ 1 ] - ( xx [ 9 ] * xx [ 10 ] + xx [ 11 ] * xx [ 4 ]
) * xx [ 6 ] + ( xx [ 0 ] - ( xx [ 9 ] * xx [ 12 ] + xx [ 11 ] * xx [ 13 ] )
* xx [ 6 ] ) * state [ 23 ] - ( ( xx [ 17 ] * xx [ 25 ] + xx [ 14 ] * xx [ 15
] ) * xx [ 6 ] - xx [ 24 ] + ( xx [ 16 ] - ( xx [ 18 ] * xx [ 27 ] + xx [ 26
] * xx [ 28 ] ) * xx [ 6 ] ) * state [ 17 ] + xx [ 33 ] + ( xx [ 31 ] * xx [
21 ] + xx [ 42 ] ) * xx [ 6 ] ) ) ; xx [ 57 ] = fabs ( - ( ( xx [ 4 ] * xx [
30 ] + xx [ 10 ] * xx [ 30 ] ) * xx [ 6 ] + xx [ 6 ] * ( xx [ 13 ] * xx [ 30
] + xx [ 12 ] * xx [ 30 ] ) * state [ 23 ] + xx [ 6 ] * ( xx [ 28 ] * xx [ 21
] + xx [ 27 ] * xx [ 21 ] ) * state [ 17 ] + ( xx [ 37 ] * xx [ 21 ] + xx [
43 ] ) * xx [ 6 ] - ( xx [ 15 ] * ( xx [ 5 ] + xx [ 18 ] * xx [ 23 ] ) + xx [
25 ] * ( xx [ 5 ] + xx [ 26 ] * xx [ 23 ] ) ) * xx [ 6 ] ) ) ; xx [ 58 ] =
fabs ( xx [ 8 ] - ( xx [ 38 ] * xx [ 39 ] + xx [ 40 ] * xx [ 20 ] ) * xx [ 6
] + ( xx [ 0 ] - ( xx [ 38 ] * xx [ 35 ] + xx [ 40 ] * xx [ 41 ] ) * xx [ 6 ]
) * state [ 25 ] - ( ( xx [ 47 ] * xx [ 22 ] + xx [ 44 ] * xx [ 45 ] ) * xx [
6 ] - xx [ 50 ] + ( xx [ 16 ] - ( xx [ 48 ] * xx [ 46 ] + xx [ 51 ] * xx [ 52
] ) * xx [ 6 ] ) * state [ 11 ] + xx [ 55 ] + ( xx [ 29 ] * xx [ 3 ] + xx [
63 ] ) * xx [ 6 ] ) ) ; xx [ 59 ] = fabs ( - ( ( xx [ 20 ] * xx [ 32 ] + xx [
39 ] * xx [ 32 ] ) * xx [ 6 ] + xx [ 6 ] * ( xx [ 41 ] * xx [ 32 ] + xx [ 35
] * xx [ 32 ] ) * state [ 25 ] + xx [ 6 ] * ( xx [ 52 ] * xx [ 3 ] + xx [ 46
] * xx [ 3 ] ) * state [ 11 ] + ( xx [ 53 ] * xx [ 3 ] + xx [ 64 ] ) * xx [ 6
] - ( xx [ 45 ] * ( xx [ 2 ] + xx [ 48 ] * xx [ 49 ] ) + xx [ 22 ] * ( xx [ 2
] + xx [ 51 ] * xx [ 49 ] ) ) * xx [ 6 ] ) ) ; ii [ 0 ] = 56 ; { int ll ; for
( ll = 57 ; ll < 60 ; ++ ll ) if ( xx [ ll ] > xx [ ii [ 0 ] ] ) ii [ 0 ] =
ll ; } ii [ 0 ] -= 56 ; xx [ 0 ] = xx [ 56 + ( ii [ 0 ] ) ] ; return xx [ 0 ]
> 1.0e-9 ; } PmfMessageId series_link_blance_leg_ad6bcbee_1_projectStateSim (
const void * mech , const RuntimeDerivedValuesBundle * rtdv , const int *
eqnEnableFlags , const int * modeVector , double * state , void * neDiagMgr0
) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi =
rtdv -> mInts . mValues ; NeuDiagnosticManager * neDiagMgr = (
NeuDiagnosticManager * ) neDiagMgr0 ; int ii [ 4 ] ; double xx [ 229 ] ; (
void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; ( void ) eqnEnableFlags ; (
void ) modeVector ; ( void ) neDiagMgr ; xx [ 0 ] = 0.0 ; xx [ 1 ] =
0.1078490312466243 ; xx [ 2 ] = 2.0 ; xx [ 3 ] = 0.7071067811865476 ; xx [ 4
] = 0.5 ; xx [ 5 ] = xx [ 4 ] * state [ 18 ] ; xx [ 6 ] = xx [ 3 ] * sin ( xx
[ 5 ] ) ; xx [ 7 ] = xx [ 3 ] * cos ( xx [ 5 ] ) ; xx [ 5 ] = xx [ 6 ] + xx [
7 ] ; xx [ 8 ] = 0.02913743527133955 ; xx [ 9 ] = xx [ 5 ] * xx [ 8 ] ; xx [
10 ] = xx [ 2 ] * xx [ 5 ] * xx [ 9 ] ; xx [ 11 ] = xx [ 1 ] - xx [ 10 ] ; xx
[ 12 ] = 0.6970892476441968 ; xx [ 13 ] = xx [ 4 ] * state [ 16 ] ; xx [ 14 ]
= sin ( xx [ 13 ] ) ; xx [ 15 ] = xx [ 12 ] * xx [ 14 ] ; xx [ 16 ] =
0.1186026172512557 ; xx [ 17 ] = cos ( xx [ 13 ] ) ; xx [ 13 ] = xx [ 16 ] *
xx [ 17 ] ; xx [ 18 ] = xx [ 15 ] + xx [ 13 ] ; xx [ 19 ] = xx [ 6 ] - xx [ 7
] ; xx [ 6 ] = xx [ 2 ] * xx [ 9 ] * xx [ 19 ] ; xx [ 7 ] = xx [ 18 ] * xx [
6 ] ; xx [ 9 ] = xx [ 12 ] * xx [ 17 ] - xx [ 16 ] * xx [ 14 ] ; xx [ 14 ] =
xx [ 7 ] * xx [ 9 ] ; xx [ 17 ] = xx [ 13 ] + xx [ 15 ] ; xx [ 20 ] = xx [ 17
] ; xx [ 21 ] = xx [ 9 ] ; xx [ 22 ] = xx [ 18 ] ; xx [ 13 ] = xx [ 18 ] * xx
[ 11 ] ; xx [ 15 ] = xx [ 6 ] * xx [ 9 ] ; xx [ 23 ] = xx [ 17 ] * xx [ 11 ]
- xx [ 15 ] ; xx [ 24 ] = - xx [ 13 ] ; xx [ 25 ] = xx [ 7 ] ; xx [ 26 ] = xx
[ 23 ] ; pm_math_Vector3_cross_ra ( xx + 20 , xx + 24 , xx + 27 ) ; xx [ 24 ]
= 0.08603840402471528 ; xx [ 25 ] = xx [ 18 ] * xx [ 24 ] ; xx [ 26 ] = xx [
17 ] * xx [ 24 ] ; xx [ 30 ] = xx [ 5 ] * xx [ 9 ] ; xx [ 31 ] = xx [ 18 ] *
xx [ 19 ] - xx [ 30 ] ; xx [ 32 ] = 0.06918743527133955 ; xx [ 33 ] = xx [ 31
] * xx [ 32 ] ; xx [ 34 ] = xx [ 17 ] * xx [ 19 ] - xx [ 30 ] ; xx [ 30 ] =
xx [ 34 ] * xx [ 32 ] ; xx [ 35 ] = ( xx [ 31 ] * xx [ 33 ] + xx [ 34 ] * xx
[ 30 ] ) * xx [ 2 ] ; xx [ 31 ] = 0.01685096875337573 ; xx [ 36 ] = xx [ 8 ]
- xx [ 10 ] ; xx [ 10 ] = xx [ 17 ] * xx [ 36 ] - xx [ 15 ] ; xx [ 37 ] = - (
xx [ 18 ] * xx [ 36 ] ) ; xx [ 38 ] = xx [ 7 ] ; xx [ 39 ] = xx [ 10 ] ;
pm_math_Vector3_cross_ra ( xx + 20 , xx + 37 , xx + 40 ) ; xx [ 15 ] =
0.17015 ; xx [ 37 ] = xx [ 4 ] * state [ 22 ] ; xx [ 38 ] = sin ( xx [ 37 ] )
; xx [ 39 ] = xx [ 12 ] * xx [ 38 ] ; xx [ 43 ] = cos ( xx [ 37 ] ) ; xx [ 37
] = xx [ 16 ] * xx [ 43 ] ; xx [ 44 ] = xx [ 39 ] + xx [ 37 ] ; xx [ 45 ] =
0.085075 ; xx [ 46 ] = xx [ 44 ] * xx [ 45 ] ; xx [ 47 ] = xx [ 37 ] + xx [
39 ] ; xx [ 37 ] = xx [ 47 ] * xx [ 45 ] ; xx [ 39 ] = ( xx [ 44 ] * xx [ 46
] + xx [ 47 ] * xx [ 37 ] ) * xx [ 2 ] ; xx [ 27 ] = xx [ 25 ] * xx [ 9 ] ;
xx [ 44 ] = xx [ 9 ] * xx [ 19 ] ; xx [ 19 ] = xx [ 44 ] + xx [ 18 ] * xx [ 5
] ; xx [ 48 ] = xx [ 44 ] + xx [ 17 ] * xx [ 5 ] ; xx [ 5 ] = ( xx [ 30 ] *
xx [ 19 ] + xx [ 33 ] * xx [ 48 ] ) * xx [ 2 ] ; xx [ 30 ] = xx [ 16 ] * xx [
38 ] - xx [ 12 ] * xx [ 43 ] ; xx [ 38 ] = xx [ 46 ] * xx [ 30 ] ; xx [ 40 ]
= ( xx [ 37 ] * xx [ 30 ] + xx [ 38 ] ) * xx [ 2 ] ; xx [ 37 ] = xx [ 4 ] *
state [ 12 ] ; xx [ 43 ] = xx [ 3 ] * sin ( xx [ 37 ] ) ; xx [ 44 ] = xx [ 3
] * cos ( xx [ 37 ] ) ; xx [ 37 ] = xx [ 43 ] + xx [ 44 ] ; xx [ 49 ] = xx [
37 ] * xx [ 8 ] ; xx [ 50 ] = xx [ 2 ] * xx [ 37 ] * xx [ 49 ] ; xx [ 51 ] =
xx [ 1 ] - xx [ 50 ] ; xx [ 52 ] = xx [ 4 ] * state [ 10 ] ; xx [ 53 ] = sin
( xx [ 52 ] ) ; xx [ 54 ] = xx [ 12 ] * xx [ 53 ] ; xx [ 55 ] = cos ( xx [ 52
] ) ; xx [ 52 ] = xx [ 16 ] * xx [ 55 ] ; xx [ 56 ] = xx [ 54 ] + xx [ 52 ] ;
xx [ 57 ] = xx [ 43 ] - xx [ 44 ] ; xx [ 43 ] = xx [ 2 ] * xx [ 49 ] * xx [
57 ] ; xx [ 44 ] = xx [ 56 ] * xx [ 43 ] ; xx [ 49 ] = xx [ 12 ] * xx [ 55 ]
- xx [ 16 ] * xx [ 53 ] ; xx [ 53 ] = xx [ 44 ] * xx [ 49 ] ; xx [ 55 ] = xx
[ 52 ] + xx [ 54 ] ; xx [ 58 ] = xx [ 55 ] ; xx [ 59 ] = xx [ 49 ] ; xx [ 60
] = xx [ 56 ] ; xx [ 52 ] = xx [ 56 ] * xx [ 51 ] ; xx [ 54 ] = xx [ 43 ] *
xx [ 49 ] ; xx [ 61 ] = xx [ 55 ] * xx [ 51 ] - xx [ 54 ] ; xx [ 62 ] = - xx
[ 52 ] ; xx [ 63 ] = xx [ 44 ] ; xx [ 64 ] = xx [ 61 ] ;
pm_math_Vector3_cross_ra ( xx + 58 , xx + 62 , xx + 65 ) ; xx [ 62 ] = xx [
56 ] * xx [ 24 ] ; xx [ 63 ] = xx [ 55 ] * xx [ 24 ] ; xx [ 64 ] = xx [ 37 ]
* xx [ 49 ] ; xx [ 68 ] = xx [ 56 ] * xx [ 57 ] - xx [ 64 ] ; xx [ 69 ] = xx
[ 68 ] * xx [ 32 ] ; xx [ 70 ] = xx [ 55 ] * xx [ 57 ] - xx [ 64 ] ; xx [ 64
] = xx [ 70 ] * xx [ 32 ] ; xx [ 71 ] = ( xx [ 68 ] * xx [ 69 ] + xx [ 70 ] *
xx [ 64 ] ) * xx [ 2 ] ; xx [ 68 ] = xx [ 8 ] - xx [ 50 ] ; xx [ 50 ] = xx [
55 ] * xx [ 68 ] - xx [ 54 ] ; xx [ 72 ] = - ( xx [ 56 ] * xx [ 68 ] ) ; xx [
73 ] = xx [ 44 ] ; xx [ 74 ] = xx [ 50 ] ; pm_math_Vector3_cross_ra ( xx + 58
, xx + 72 , xx + 75 ) ; xx [ 54 ] = xx [ 4 ] * state [ 24 ] ; xx [ 72 ] = sin
( xx [ 54 ] ) ; xx [ 73 ] = xx [ 12 ] * xx [ 72 ] ; xx [ 74 ] = cos ( xx [ 54
] ) ; xx [ 54 ] = xx [ 16 ] * xx [ 74 ] ; xx [ 78 ] = xx [ 73 ] + xx [ 54 ] ;
xx [ 79 ] = xx [ 78 ] * xx [ 45 ] ; xx [ 80 ] = xx [ 54 ] + xx [ 73 ] ; xx [
54 ] = xx [ 80 ] * xx [ 45 ] ; xx [ 73 ] = ( xx [ 78 ] * xx [ 79 ] + xx [ 80
] * xx [ 54 ] ) * xx [ 2 ] ; xx [ 65 ] = xx [ 62 ] * xx [ 49 ] ; xx [ 78 ] =
xx [ 49 ] * xx [ 57 ] ; xx [ 57 ] = xx [ 78 ] + xx [ 56 ] * xx [ 37 ] ; xx [
81 ] = xx [ 78 ] + xx [ 55 ] * xx [ 37 ] ; xx [ 37 ] = ( xx [ 64 ] * xx [ 57
] + xx [ 69 ] * xx [ 81 ] ) * xx [ 2 ] ; xx [ 64 ] = xx [ 16 ] * xx [ 72 ] -
xx [ 12 ] * xx [ 74 ] ; xx [ 72 ] = xx [ 79 ] * xx [ 64 ] ; xx [ 74 ] = ( xx
[ 54 ] * xx [ 64 ] + xx [ 72 ] ) * xx [ 2 ] ; xx [ 82 ] = xx [ 0 ] ; xx [ 83
] = xx [ 0 ] ; xx [ 84 ] = xx [ 0 ] ; xx [ 85 ] = xx [ 0 ] ; xx [ 86 ] = xx [
0 ] ; xx [ 87 ] = xx [ 0 ] ; xx [ 88 ] = xx [ 0 ] ; xx [ 89 ] = xx [ 0 ] ; xx
[ 90 ] = - ( xx [ 11 ] + ( xx [ 14 ] + xx [ 28 ] ) * xx [ 2 ] - ( xx [ 18 ] *
xx [ 25 ] + xx [ 17 ] * xx [ 26 ] ) * xx [ 2 ] + xx [ 35 ] + xx [ 31 ] ) ; xx
[ 91 ] = - ( xx [ 36 ] + xx [ 2 ] * ( xx [ 41 ] + xx [ 14 ] ) + xx [ 35 ] -
xx [ 32 ] ) ; xx [ 92 ] = xx [ 0 ] ; xx [ 93 ] = xx [ 15 ] - ( xx [ 39 ] + xx
[ 39 ] ) ; xx [ 94 ] = xx [ 0 ] ; xx [ 95 ] = xx [ 0 ] ; xx [ 96 ] = xx [ 0 ]
; xx [ 97 ] = xx [ 0 ] ; xx [ 98 ] = xx [ 0 ] ; xx [ 99 ] = xx [ 0 ] ; xx [
100 ] = xx [ 0 ] ; xx [ 101 ] = xx [ 0 ] ; xx [ 102 ] = xx [ 0 ] ; xx [ 103 ]
= - ( ( xx [ 23 ] * xx [ 9 ] + xx [ 29 ] ) * xx [ 2 ] + ( xx [ 26 ] * xx [ 9
] + xx [ 27 ] ) * xx [ 2 ] - xx [ 5 ] ) ; xx [ 104 ] = - ( ( xx [ 10 ] * xx [
9 ] + xx [ 42 ] ) * xx [ 2 ] - xx [ 5 ] ) ; xx [ 105 ] = xx [ 0 ] ; xx [ 106
] = - ( xx [ 40 ] + xx [ 40 ] ) ; xx [ 107 ] = xx [ 0 ] ; xx [ 108 ] = xx [ 0
] ; xx [ 109 ] = xx [ 0 ] ; xx [ 110 ] = xx [ 0 ] ; xx [ 111 ] = xx [ 0 ] ;
xx [ 112 ] = xx [ 0 ] ; xx [ 113 ] = - ( xx [ 51 ] + ( xx [ 53 ] + xx [ 66 ]
) * xx [ 2 ] - ( xx [ 56 ] * xx [ 62 ] + xx [ 55 ] * xx [ 63 ] ) * xx [ 2 ] +
xx [ 71 ] + xx [ 31 ] ) ; xx [ 114 ] = - ( xx [ 68 ] + xx [ 2 ] * ( xx [ 76 ]
+ xx [ 53 ] ) + xx [ 71 ] - xx [ 32 ] ) ; xx [ 115 ] = xx [ 0 ] ; xx [ 116 ]
= xx [ 0 ] ; xx [ 117 ] = xx [ 0 ] ; xx [ 118 ] = xx [ 0 ] ; xx [ 119 ] = xx
[ 0 ] ; xx [ 120 ] = xx [ 15 ] - ( xx [ 73 ] + xx [ 73 ] ) ; xx [ 121 ] = xx
[ 0 ] ; xx [ 122 ] = xx [ 0 ] ; xx [ 123 ] = xx [ 0 ] ; xx [ 124 ] = xx [ 0 ]
; xx [ 125 ] = xx [ 0 ] ; xx [ 126 ] = - ( ( xx [ 61 ] * xx [ 49 ] + xx [ 67
] ) * xx [ 2 ] + ( xx [ 63 ] * xx [ 49 ] + xx [ 65 ] ) * xx [ 2 ] - xx [ 37 ]
) ; xx [ 127 ] = - ( ( xx [ 50 ] * xx [ 49 ] + xx [ 77 ] ) * xx [ 2 ] - xx [
37 ] ) ; xx [ 128 ] = xx [ 0 ] ; xx [ 129 ] = xx [ 0 ] ; xx [ 130 ] = xx [ 0
] ; xx [ 131 ] = xx [ 0 ] ; xx [ 132 ] = xx [ 0 ] ; xx [ 133 ] = - ( xx [ 74
] + xx [ 74 ] ) ; xx [ 5 ] = xx [ 45 ] * xx [ 30 ] ; xx [ 10 ] = xx [ 47 ] *
xx [ 5 ] ; xx [ 14 ] = xx [ 17 ] * xx [ 6 ] + xx [ 11 ] * xx [ 9 ] ; xx [ 35
] = xx [ 7 ] ; xx [ 36 ] = xx [ 13 ] ; xx [ 37 ] = - xx [ 14 ] ;
pm_math_Vector3_cross_ra ( xx + 20 , xx + 35 , xx + 39 ) ; xx [ 7 ] = xx [ 24
] * xx [ 9 ] ; xx [ 11 ] = xx [ 32 ] * xx [ 48 ] ; xx [ 18 ] =
0.07164265098815176 ; xx [ 20 ] = xx [ 47 ] * xx [ 46 ] ; xx [ 21 ] = xx [ 5
] * xx [ 30 ] ; xx [ 5 ] = 0.03446132628599599 ; xx [ 22 ] = xx [ 45 ] * xx [
64 ] ; xx [ 23 ] = xx [ 80 ] * xx [ 22 ] ; xx [ 26 ] = xx [ 55 ] * xx [ 43 ]
+ xx [ 51 ] * xx [ 49 ] ; xx [ 28 ] = xx [ 44 ] ; xx [ 29 ] = xx [ 52 ] ; xx
[ 30 ] = - xx [ 26 ] ; pm_math_Vector3_cross_ra ( xx + 58 , xx + 28 , xx + 35
) ; xx [ 28 ] = xx [ 24 ] * xx [ 49 ] ; xx [ 29 ] = xx [ 32 ] * xx [ 81 ] ;
xx [ 30 ] = xx [ 80 ] * xx [ 79 ] ; xx [ 39 ] = xx [ 22 ] * xx [ 64 ] ; xx [
58 ] = ( xx [ 38 ] + xx [ 10 ] ) * xx [ 2 ] + ( xx [ 38 ] + xx [ 10 ] ) * xx
[ 2 ] + ( xx [ 13 ] * xx [ 9 ] + xx [ 40 ] ) * xx [ 2 ] - ( xx [ 6 ] - ( xx [
27 ] + xx [ 17 ] * xx [ 7 ] ) * xx [ 2 ] ) - ( xx [ 33 ] * xx [ 19 ] + xx [
34 ] * xx [ 11 ] ) * xx [ 2 ] + xx [ 18 ] ; xx [ 59 ] = - ( xx [ 2 ] * ( xx [
20 ] - xx [ 21 ] ) - xx [ 2 ] * ( xx [ 21 ] - xx [ 20 ] ) - ( xx [ 2 ] * ( xx
[ 11 ] * xx [ 19 ] - xx [ 34 ] * xx [ 33 ] ) + xx [ 2 ] * ( xx [ 41 ] - xx [
14 ] * xx [ 9 ] ) - xx [ 2 ] * ( xx [ 7 ] * xx [ 9 ] - xx [ 17 ] * xx [ 25 ]
) ) + xx [ 5 ] ) ; xx [ 60 ] = ( xx [ 72 ] + xx [ 23 ] ) * xx [ 2 ] + ( xx [
72 ] + xx [ 23 ] ) * xx [ 2 ] + ( xx [ 52 ] * xx [ 49 ] + xx [ 36 ] ) * xx [
2 ] - ( xx [ 43 ] - ( xx [ 65 ] + xx [ 55 ] * xx [ 28 ] ) * xx [ 2 ] ) - ( xx
[ 69 ] * xx [ 57 ] + xx [ 70 ] * xx [ 29 ] ) * xx [ 2 ] + xx [ 18 ] ; xx [ 61
] = - ( xx [ 2 ] * ( xx [ 30 ] - xx [ 39 ] ) - xx [ 2 ] * ( xx [ 39 ] - xx [
30 ] ) - ( xx [ 2 ] * ( xx [ 29 ] * xx [ 57 ] - xx [ 70 ] * xx [ 69 ] ) + xx
[ 2 ] * ( xx [ 37 ] - xx [ 26 ] * xx [ 49 ] ) - xx [ 2 ] * ( xx [ 28 ] * xx [
49 ] - xx [ 55 ] * xx [ 62 ] ) ) + xx [ 5 ] ) ; xx [ 6 ] = 1.0e-8 ; memcpy (
xx + 134 , xx + 82 , 52 * sizeof ( double ) ) ; factorAndSolveWide ( 4 , 13 ,
xx + 134 , xx + 19 , xx + 25 , ii + 0 , xx + 58 , xx [ 6 ] , xx + 62 ) ; xx [
7 ] = state [ 18 ] + xx [ 71 ] ; xx [ 9 ] = xx [ 7 ] * xx [ 4 ] ; xx [ 10 ] =
xx [ 3 ] * sin ( xx [ 9 ] ) ; xx [ 11 ] = xx [ 3 ] * cos ( xx [ 9 ] ) ; xx [
9 ] = xx [ 10 ] + xx [ 11 ] ; xx [ 13 ] = xx [ 9 ] * xx [ 8 ] ; xx [ 14 ] =
xx [ 2 ] * xx [ 9 ] * xx [ 13 ] ; xx [ 17 ] = xx [ 1 ] - xx [ 14 ] ; xx [ 19
] = state [ 16 ] + xx [ 70 ] ; xx [ 20 ] = xx [ 19 ] * xx [ 4 ] ; xx [ 21 ] =
sin ( xx [ 20 ] ) ; xx [ 22 ] = xx [ 12 ] * xx [ 21 ] ; xx [ 23 ] = cos ( xx
[ 20 ] ) ; xx [ 20 ] = xx [ 16 ] * xx [ 23 ] ; xx [ 25 ] = xx [ 22 ] + xx [
20 ] ; xx [ 26 ] = xx [ 10 ] - xx [ 11 ] ; xx [ 10 ] = xx [ 2 ] * xx [ 13 ] *
xx [ 26 ] ; xx [ 11 ] = xx [ 25 ] * xx [ 10 ] ; xx [ 13 ] = xx [ 12 ] * xx [
23 ] - xx [ 16 ] * xx [ 21 ] ; xx [ 21 ] = xx [ 11 ] * xx [ 13 ] ; xx [ 23 ]
= xx [ 20 ] + xx [ 22 ] ; xx [ 27 ] = xx [ 23 ] ; xx [ 28 ] = xx [ 13 ] ; xx
[ 29 ] = xx [ 25 ] ; xx [ 20 ] = xx [ 25 ] * xx [ 17 ] ; xx [ 22 ] = xx [ 10
] * xx [ 13 ] ; xx [ 30 ] = xx [ 23 ] * xx [ 17 ] - xx [ 22 ] ; xx [ 33 ] = -
xx [ 20 ] ; xx [ 34 ] = xx [ 11 ] ; xx [ 35 ] = xx [ 30 ] ;
pm_math_Vector3_cross_ra ( xx + 27 , xx + 33 , xx + 36 ) ; xx [ 33 ] = xx [
25 ] * xx [ 24 ] ; xx [ 34 ] = xx [ 23 ] * xx [ 24 ] ; xx [ 35 ] = xx [ 9 ] *
xx [ 13 ] ; xx [ 39 ] = xx [ 25 ] * xx [ 26 ] - xx [ 35 ] ; xx [ 40 ] = xx [
39 ] * xx [ 32 ] ; xx [ 41 ] = xx [ 23 ] * xx [ 26 ] - xx [ 35 ] ; xx [ 35 ]
= xx [ 41 ] * xx [ 32 ] ; xx [ 42 ] = ( xx [ 39 ] * xx [ 40 ] + xx [ 41 ] *
xx [ 35 ] ) * xx [ 2 ] ; xx [ 39 ] = xx [ 8 ] - xx [ 14 ] ; xx [ 14 ] = xx [
23 ] * xx [ 39 ] - xx [ 22 ] ; xx [ 46 ] = - ( xx [ 25 ] * xx [ 39 ] ) ; xx [
47 ] = xx [ 11 ] ; xx [ 48 ] = xx [ 14 ] ; pm_math_Vector3_cross_ra ( xx + 27
, xx + 46 , xx + 49 ) ; xx [ 22 ] = state [ 22 ] + xx [ 73 ] ; xx [ 43 ] = xx
[ 22 ] * xx [ 4 ] ; xx [ 44 ] = sin ( xx [ 43 ] ) ; xx [ 46 ] = xx [ 12 ] *
xx [ 44 ] ; xx [ 47 ] = cos ( xx [ 43 ] ) ; xx [ 43 ] = xx [ 16 ] * xx [ 47 ]
; xx [ 48 ] = xx [ 46 ] + xx [ 43 ] ; xx [ 52 ] = xx [ 48 ] * xx [ 45 ] ; xx
[ 53 ] = xx [ 43 ] + xx [ 46 ] ; xx [ 43 ] = xx [ 53 ] * xx [ 45 ] ; xx [ 46
] = ( xx [ 48 ] * xx [ 52 ] + xx [ 53 ] * xx [ 43 ] ) * xx [ 2 ] ; xx [ 36 ]
= xx [ 33 ] * xx [ 13 ] ; xx [ 48 ] = xx [ 13 ] * xx [ 26 ] ; xx [ 26 ] = xx
[ 48 ] + xx [ 25 ] * xx [ 9 ] ; xx [ 54 ] = xx [ 48 ] + xx [ 23 ] * xx [ 9 ]
; xx [ 9 ] = ( xx [ 35 ] * xx [ 26 ] + xx [ 40 ] * xx [ 54 ] ) * xx [ 2 ] ;
xx [ 35 ] = xx [ 16 ] * xx [ 44 ] - xx [ 12 ] * xx [ 47 ] ; xx [ 44 ] = xx [
52 ] * xx [ 35 ] ; xx [ 47 ] = ( xx [ 43 ] * xx [ 35 ] + xx [ 44 ] ) * xx [ 2
] ; xx [ 43 ] = state [ 12 ] + xx [ 68 ] ; xx [ 48 ] = xx [ 43 ] * xx [ 4 ] ;
xx [ 49 ] = xx [ 3 ] * sin ( xx [ 48 ] ) ; xx [ 55 ] = xx [ 3 ] * cos ( xx [
48 ] ) ; xx [ 48 ] = xx [ 49 ] + xx [ 55 ] ; xx [ 56 ] = xx [ 48 ] * xx [ 8 ]
; xx [ 57 ] = xx [ 2 ] * xx [ 48 ] * xx [ 56 ] ; xx [ 58 ] = xx [ 1 ] - xx [
57 ] ; xx [ 59 ] = state [ 10 ] + xx [ 67 ] ; xx [ 60 ] = xx [ 59 ] * xx [ 4
] ; xx [ 61 ] = sin ( xx [ 60 ] ) ; xx [ 75 ] = xx [ 12 ] * xx [ 61 ] ; xx [
76 ] = cos ( xx [ 60 ] ) ; xx [ 60 ] = xx [ 16 ] * xx [ 76 ] ; xx [ 77 ] = xx
[ 75 ] + xx [ 60 ] ; xx [ 78 ] = xx [ 49 ] - xx [ 55 ] ; xx [ 49 ] = xx [ 2 ]
* xx [ 56 ] * xx [ 78 ] ; xx [ 55 ] = xx [ 77 ] * xx [ 49 ] ; xx [ 56 ] = xx
[ 12 ] * xx [ 76 ] - xx [ 16 ] * xx [ 61 ] ; xx [ 61 ] = xx [ 55 ] * xx [ 56
] ; xx [ 76 ] = xx [ 60 ] + xx [ 75 ] ; xx [ 79 ] = xx [ 76 ] ; xx [ 80 ] =
xx [ 56 ] ; xx [ 81 ] = xx [ 77 ] ; xx [ 60 ] = xx [ 77 ] * xx [ 58 ] ; xx [
75 ] = xx [ 49 ] * xx [ 56 ] ; xx [ 82 ] = xx [ 76 ] * xx [ 58 ] - xx [ 75 ]
; xx [ 83 ] = - xx [ 60 ] ; xx [ 84 ] = xx [ 55 ] ; xx [ 85 ] = xx [ 82 ] ;
pm_math_Vector3_cross_ra ( xx + 79 , xx + 83 , xx + 86 ) ; xx [ 83 ] = xx [
77 ] * xx [ 24 ] ; xx [ 84 ] = xx [ 76 ] * xx [ 24 ] ; xx [ 85 ] = xx [ 48 ]
* xx [ 56 ] ; xx [ 89 ] = xx [ 77 ] * xx [ 78 ] - xx [ 85 ] ; xx [ 90 ] = xx
[ 89 ] * xx [ 32 ] ; xx [ 91 ] = xx [ 76 ] * xx [ 78 ] - xx [ 85 ] ; xx [ 85
] = xx [ 91 ] * xx [ 32 ] ; xx [ 92 ] = ( xx [ 89 ] * xx [ 90 ] + xx [ 91 ] *
xx [ 85 ] ) * xx [ 2 ] ; xx [ 89 ] = xx [ 8 ] - xx [ 57 ] ; xx [ 57 ] = xx [
76 ] * xx [ 89 ] - xx [ 75 ] ; xx [ 93 ] = - ( xx [ 77 ] * xx [ 89 ] ) ; xx [
94 ] = xx [ 55 ] ; xx [ 95 ] = xx [ 57 ] ; pm_math_Vector3_cross_ra ( xx + 79
, xx + 93 , xx + 96 ) ; xx [ 75 ] = state [ 24 ] + xx [ 74 ] ; xx [ 93 ] = xx
[ 75 ] * xx [ 4 ] ; xx [ 94 ] = sin ( xx [ 93 ] ) ; xx [ 95 ] = xx [ 12 ] *
xx [ 94 ] ; xx [ 99 ] = cos ( xx [ 93 ] ) ; xx [ 93 ] = xx [ 16 ] * xx [ 99 ]
; xx [ 100 ] = xx [ 95 ] + xx [ 93 ] ; xx [ 101 ] = xx [ 100 ] * xx [ 45 ] ;
xx [ 102 ] = xx [ 93 ] + xx [ 95 ] ; xx [ 93 ] = xx [ 102 ] * xx [ 45 ] ; xx
[ 95 ] = ( xx [ 100 ] * xx [ 101 ] + xx [ 102 ] * xx [ 93 ] ) * xx [ 2 ] ; xx
[ 86 ] = xx [ 83 ] * xx [ 56 ] ; xx [ 100 ] = xx [ 56 ] * xx [ 78 ] ; xx [ 78
] = xx [ 100 ] + xx [ 77 ] * xx [ 48 ] ; xx [ 103 ] = xx [ 100 ] + xx [ 76 ]
* xx [ 48 ] ; xx [ 48 ] = ( xx [ 85 ] * xx [ 78 ] + xx [ 90 ] * xx [ 103 ] )
* xx [ 2 ] ; xx [ 85 ] = xx [ 16 ] * xx [ 94 ] - xx [ 12 ] * xx [ 99 ] ; xx [
94 ] = xx [ 101 ] * xx [ 85 ] ; xx [ 96 ] = ( xx [ 93 ] * xx [ 85 ] + xx [ 94
] ) * xx [ 2 ] ; xx [ 104 ] = xx [ 0 ] ; xx [ 105 ] = xx [ 0 ] ; xx [ 106 ] =
xx [ 0 ] ; xx [ 107 ] = xx [ 0 ] ; xx [ 108 ] = xx [ 0 ] ; xx [ 109 ] = xx [
0 ] ; xx [ 110 ] = xx [ 0 ] ; xx [ 111 ] = xx [ 0 ] ; xx [ 112 ] = - ( xx [
17 ] + ( xx [ 21 ] + xx [ 37 ] ) * xx [ 2 ] - ( xx [ 25 ] * xx [ 33 ] + xx [
23 ] * xx [ 34 ] ) * xx [ 2 ] + xx [ 42 ] + xx [ 31 ] ) ; xx [ 113 ] = - ( xx
[ 39 ] + xx [ 2 ] * ( xx [ 50 ] + xx [ 21 ] ) + xx [ 42 ] - xx [ 32 ] ) ; xx
[ 114 ] = xx [ 0 ] ; xx [ 115 ] = xx [ 15 ] - ( xx [ 46 ] + xx [ 46 ] ) ; xx
[ 116 ] = xx [ 0 ] ; xx [ 117 ] = xx [ 0 ] ; xx [ 118 ] = xx [ 0 ] ; xx [ 119
] = xx [ 0 ] ; xx [ 120 ] = xx [ 0 ] ; xx [ 121 ] = xx [ 0 ] ; xx [ 122 ] =
xx [ 0 ] ; xx [ 123 ] = xx [ 0 ] ; xx [ 124 ] = xx [ 0 ] ; xx [ 125 ] = - ( (
xx [ 30 ] * xx [ 13 ] + xx [ 38 ] ) * xx [ 2 ] + ( xx [ 34 ] * xx [ 13 ] + xx
[ 36 ] ) * xx [ 2 ] - xx [ 9 ] ) ; xx [ 126 ] = - ( ( xx [ 14 ] * xx [ 13 ] +
xx [ 51 ] ) * xx [ 2 ] - xx [ 9 ] ) ; xx [ 127 ] = xx [ 0 ] ; xx [ 128 ] = -
( xx [ 47 ] + xx [ 47 ] ) ; xx [ 129 ] = xx [ 0 ] ; xx [ 130 ] = xx [ 0 ] ;
xx [ 131 ] = xx [ 0 ] ; xx [ 132 ] = xx [ 0 ] ; xx [ 133 ] = xx [ 0 ] ; xx [
134 ] = xx [ 0 ] ; xx [ 135 ] = - ( xx [ 58 ] + ( xx [ 61 ] + xx [ 87 ] ) *
xx [ 2 ] - ( xx [ 77 ] * xx [ 83 ] + xx [ 76 ] * xx [ 84 ] ) * xx [ 2 ] + xx
[ 92 ] + xx [ 31 ] ) ; xx [ 136 ] = - ( xx [ 89 ] + xx [ 2 ] * ( xx [ 97 ] +
xx [ 61 ] ) + xx [ 92 ] - xx [ 32 ] ) ; xx [ 137 ] = xx [ 0 ] ; xx [ 138 ] =
xx [ 0 ] ; xx [ 139 ] = xx [ 0 ] ; xx [ 140 ] = xx [ 0 ] ; xx [ 141 ] = xx [
0 ] ; xx [ 142 ] = xx [ 15 ] - ( xx [ 95 ] + xx [ 95 ] ) ; xx [ 143 ] = xx [
0 ] ; xx [ 144 ] = xx [ 0 ] ; xx [ 145 ] = xx [ 0 ] ; xx [ 146 ] = xx [ 0 ] ;
xx [ 147 ] = xx [ 0 ] ; xx [ 148 ] = - ( ( xx [ 82 ] * xx [ 56 ] + xx [ 88 ]
) * xx [ 2 ] + ( xx [ 84 ] * xx [ 56 ] + xx [ 86 ] ) * xx [ 2 ] - xx [ 48 ] )
; xx [ 149 ] = - ( ( xx [ 57 ] * xx [ 56 ] + xx [ 98 ] ) * xx [ 2 ] - xx [ 48
] ) ; xx [ 150 ] = xx [ 0 ] ; xx [ 151 ] = xx [ 0 ] ; xx [ 152 ] = xx [ 0 ] ;
xx [ 153 ] = xx [ 0 ] ; xx [ 154 ] = xx [ 0 ] ; xx [ 155 ] = - ( xx [ 96 ] +
xx [ 96 ] ) ; xx [ 9 ] = xx [ 45 ] * xx [ 35 ] ; xx [ 14 ] = xx [ 53 ] * xx [
9 ] ; xx [ 21 ] = xx [ 23 ] * xx [ 10 ] + xx [ 17 ] * xx [ 13 ] ; xx [ 37 ] =
xx [ 11 ] ; xx [ 38 ] = xx [ 20 ] ; xx [ 39 ] = - xx [ 21 ] ;
pm_math_Vector3_cross_ra ( xx + 27 , xx + 37 , xx + 46 ) ; xx [ 11 ] = xx [
24 ] * xx [ 13 ] ; xx [ 17 ] = xx [ 32 ] * xx [ 54 ] ; xx [ 25 ] = xx [ 53 ]
* xx [ 52 ] ; xx [ 27 ] = xx [ 9 ] * xx [ 35 ] ; xx [ 9 ] = xx [ 45 ] * xx [
85 ] ; xx [ 28 ] = xx [ 102 ] * xx [ 9 ] ; xx [ 29 ] = xx [ 76 ] * xx [ 49 ]
+ xx [ 58 ] * xx [ 56 ] ; xx [ 37 ] = xx [ 55 ] ; xx [ 38 ] = xx [ 60 ] ; xx
[ 39 ] = - xx [ 29 ] ; pm_math_Vector3_cross_ra ( xx + 79 , xx + 37 , xx + 50
) ; xx [ 30 ] = xx [ 24 ] * xx [ 56 ] ; xx [ 34 ] = xx [ 32 ] * xx [ 103 ] ;
xx [ 35 ] = xx [ 102 ] * xx [ 101 ] ; xx [ 37 ] = xx [ 9 ] * xx [ 85 ] ; xx [
79 ] = ( xx [ 44 ] + xx [ 14 ] ) * xx [ 2 ] + ( xx [ 44 ] + xx [ 14 ] ) * xx
[ 2 ] + ( xx [ 20 ] * xx [ 13 ] + xx [ 47 ] ) * xx [ 2 ] - ( xx [ 10 ] - ( xx
[ 36 ] + xx [ 23 ] * xx [ 11 ] ) * xx [ 2 ] ) - ( xx [ 40 ] * xx [ 26 ] + xx
[ 41 ] * xx [ 17 ] ) * xx [ 2 ] + xx [ 18 ] ; xx [ 80 ] = - ( xx [ 2 ] * ( xx
[ 25 ] - xx [ 27 ] ) - xx [ 2 ] * ( xx [ 27 ] - xx [ 25 ] ) - ( xx [ 2 ] * (
xx [ 17 ] * xx [ 26 ] - xx [ 41 ] * xx [ 40 ] ) + xx [ 2 ] * ( xx [ 48 ] - xx
[ 21 ] * xx [ 13 ] ) - xx [ 2 ] * ( xx [ 11 ] * xx [ 13 ] - xx [ 23 ] * xx [
33 ] ) ) + xx [ 5 ] ) ; xx [ 81 ] = ( xx [ 94 ] + xx [ 28 ] ) * xx [ 2 ] + (
xx [ 94 ] + xx [ 28 ] ) * xx [ 2 ] + ( xx [ 60 ] * xx [ 56 ] + xx [ 51 ] ) *
xx [ 2 ] - ( xx [ 49 ] - ( xx [ 86 ] + xx [ 76 ] * xx [ 30 ] ) * xx [ 2 ] ) -
( xx [ 90 ] * xx [ 78 ] + xx [ 91 ] * xx [ 34 ] ) * xx [ 2 ] + xx [ 18 ] ; xx
[ 82 ] = - ( xx [ 2 ] * ( xx [ 35 ] - xx [ 37 ] ) - xx [ 2 ] * ( xx [ 37 ] -
xx [ 35 ] ) - ( xx [ 2 ] * ( xx [ 34 ] * xx [ 78 ] - xx [ 91 ] * xx [ 90 ] )
+ xx [ 2 ] * ( xx [ 52 ] - xx [ 29 ] * xx [ 56 ] ) - xx [ 2 ] * ( xx [ 30 ] *
xx [ 56 ] - xx [ 76 ] * xx [ 83 ] ) ) + xx [ 5 ] ) ; memcpy ( xx + 156 , xx +
104 , 52 * sizeof ( double ) ) ; factorAndSolveWide ( 4 , 13 , xx + 156 , xx
+ 25 , xx + 33 , ii + 0 , xx + 79 , xx [ 6 ] , xx + 46 ) ; xx [ 9 ] = xx [ 59
] + xx [ 51 ] ; xx [ 10 ] = xx [ 43 ] + xx [ 52 ] ; xx [ 11 ] = xx [ 19 ] +
xx [ 54 ] ; xx [ 13 ] = xx [ 7 ] + xx [ 55 ] ; xx [ 7 ] = xx [ 22 ] + xx [ 57
] ; xx [ 14 ] = xx [ 75 ] + xx [ 58 ] ; xx [ 73 ] = state [ 0 ] + xx [ 62 ] +
xx [ 46 ] ; xx [ 74 ] = state [ 1 ] + xx [ 63 ] + xx [ 47 ] ; xx [ 75 ] =
state [ 2 ] + xx [ 64 ] + xx [ 48 ] ; xx [ 76 ] = state [ 3 ] ; xx [ 77 ] =
state [ 4 ] ; xx [ 78 ] = state [ 5 ] ; xx [ 79 ] = state [ 6 ] + xx [ 65 ] +
xx [ 49 ] ; xx [ 80 ] = state [ 7 ] ; xx [ 81 ] = state [ 8 ] + xx [ 66 ] +
xx [ 50 ] ; xx [ 82 ] = state [ 9 ] ; xx [ 83 ] = xx [ 9 ] ; xx [ 84 ] =
state [ 11 ] ; xx [ 85 ] = xx [ 10 ] ; xx [ 86 ] = state [ 13 ] ; xx [ 87 ] =
state [ 14 ] + xx [ 69 ] + xx [ 53 ] ; xx [ 88 ] = state [ 15 ] ; xx [ 89 ] =
xx [ 11 ] ; xx [ 90 ] = state [ 17 ] ; xx [ 91 ] = xx [ 13 ] ; xx [ 92 ] =
state [ 19 ] ; xx [ 93 ] = state [ 20 ] + xx [ 72 ] + xx [ 56 ] ; xx [ 94 ] =
state [ 21 ] ; xx [ 95 ] = xx [ 7 ] ; xx [ 96 ] = state [ 23 ] ; xx [ 97 ] =
xx [ 14 ] ; xx [ 98 ] = state [ 25 ] ; xx [ 99 ] = state [ 26 ] ; xx [ 100 ]
= state [ 27 ] ; xx [ 101 ] = state [ 28 ] ; xx [ 102 ] = state [ 29 ] ; xx [
17 ] = xx [ 7 ] * xx [ 4 ] ; xx [ 7 ] = sin ( xx [ 17 ] ) ; xx [ 19 ] = xx [
12 ] * xx [ 7 ] ; xx [ 20 ] = cos ( xx [ 17 ] ) ; xx [ 17 ] = xx [ 16 ] * xx
[ 20 ] ; xx [ 21 ] = ( xx [ 19 ] + xx [ 17 ] ) * xx [ 45 ] ; xx [ 22 ] = xx [
16 ] * xx [ 7 ] - xx [ 12 ] * xx [ 20 ] ; xx [ 7 ] = xx [ 21 ] * xx [ 22 ] ;
xx [ 20 ] = xx [ 17 ] + xx [ 19 ] ; xx [ 17 ] = xx [ 45 ] * xx [ 22 ] ; xx [
19 ] = xx [ 20 ] * xx [ 17 ] ; xx [ 23 ] = xx [ 11 ] * xx [ 4 ] ; xx [ 11 ] =
sin ( xx [ 23 ] ) ; xx [ 25 ] = xx [ 12 ] * xx [ 11 ] ; xx [ 26 ] = cos ( xx
[ 23 ] ) ; xx [ 23 ] = xx [ 16 ] * xx [ 26 ] ; xx [ 27 ] = xx [ 25 ] + xx [
23 ] ; xx [ 28 ] = xx [ 13 ] * xx [ 4 ] ; xx [ 13 ] = xx [ 3 ] * sin ( xx [
28 ] ) ; xx [ 29 ] = xx [ 3 ] * cos ( xx [ 28 ] ) ; xx [ 28 ] = xx [ 13 ] +
xx [ 29 ] ; xx [ 30 ] = xx [ 28 ] * xx [ 8 ] ; xx [ 33 ] = xx [ 1 ] - xx [ 2
] * xx [ 28 ] * xx [ 30 ] ; xx [ 34 ] = xx [ 27 ] * xx [ 33 ] ; xx [ 35 ] =
xx [ 12 ] * xx [ 26 ] - xx [ 16 ] * xx [ 11 ] ; xx [ 11 ] = xx [ 23 ] + xx [
25 ] ; xx [ 36 ] = xx [ 11 ] ; xx [ 37 ] = xx [ 35 ] ; xx [ 38 ] = xx [ 27 ]
; xx [ 23 ] = xx [ 13 ] - xx [ 29 ] ; xx [ 13 ] = xx [ 2 ] * xx [ 30 ] * xx [
23 ] ; xx [ 25 ] = xx [ 11 ] * xx [ 13 ] + xx [ 33 ] * xx [ 35 ] ; xx [ 39 ]
= xx [ 27 ] * xx [ 13 ] ; xx [ 40 ] = xx [ 34 ] ; xx [ 41 ] = - xx [ 25 ] ;
pm_math_Vector3_cross_ra ( xx + 36 , xx + 39 , xx + 42 ) ; xx [ 26 ] = xx [
27 ] * xx [ 24 ] ; xx [ 29 ] = xx [ 24 ] * xx [ 35 ] ; xx [ 30 ] = xx [ 28 ]
* xx [ 35 ] ; xx [ 33 ] = ( xx [ 27 ] * xx [ 23 ] - xx [ 30 ] ) * xx [ 32 ] ;
xx [ 36 ] = xx [ 35 ] * xx [ 23 ] ; xx [ 37 ] = xx [ 36 ] + xx [ 27 ] * xx [
28 ] ; xx [ 27 ] = xx [ 11 ] * xx [ 23 ] - xx [ 30 ] ; xx [ 23 ] = xx [ 32 ]
* ( xx [ 36 ] + xx [ 11 ] * xx [ 28 ] ) ; xx [ 28 ] = xx [ 20 ] * xx [ 21 ] ;
xx [ 20 ] = xx [ 17 ] * xx [ 22 ] ; xx [ 17 ] = xx [ 14 ] * xx [ 4 ] ; xx [
14 ] = sin ( xx [ 17 ] ) ; xx [ 21 ] = xx [ 12 ] * xx [ 14 ] ; xx [ 22 ] =
cos ( xx [ 17 ] ) ; xx [ 17 ] = xx [ 16 ] * xx [ 22 ] ; xx [ 30 ] = ( xx [ 21
] + xx [ 17 ] ) * xx [ 45 ] ; xx [ 36 ] = xx [ 16 ] * xx [ 14 ] - xx [ 12 ] *
xx [ 22 ] ; xx [ 14 ] = xx [ 30 ] * xx [ 36 ] ; xx [ 22 ] = xx [ 17 ] + xx [
21 ] ; xx [ 17 ] = xx [ 45 ] * xx [ 36 ] ; xx [ 21 ] = xx [ 22 ] * xx [ 17 ]
; xx [ 38 ] = xx [ 9 ] * xx [ 4 ] ; xx [ 9 ] = sin ( xx [ 38 ] ) ; xx [ 39 ]
= xx [ 12 ] * xx [ 9 ] ; xx [ 40 ] = cos ( xx [ 38 ] ) ; xx [ 38 ] = xx [ 16
] * xx [ 40 ] ; xx [ 41 ] = xx [ 39 ] + xx [ 38 ] ; xx [ 42 ] = xx [ 10 ] *
xx [ 4 ] ; xx [ 10 ] = xx [ 3 ] * sin ( xx [ 42 ] ) ; xx [ 46 ] = xx [ 3 ] *
cos ( xx [ 42 ] ) ; xx [ 42 ] = xx [ 10 ] + xx [ 46 ] ; xx [ 47 ] = xx [ 42 ]
* xx [ 8 ] ; xx [ 48 ] = xx [ 1 ] - xx [ 2 ] * xx [ 42 ] * xx [ 47 ] ; xx [
49 ] = xx [ 41 ] * xx [ 48 ] ; xx [ 50 ] = xx [ 12 ] * xx [ 40 ] - xx [ 16 ]
* xx [ 9 ] ; xx [ 9 ] = xx [ 38 ] + xx [ 39 ] ; xx [ 38 ] = xx [ 9 ] ; xx [
39 ] = xx [ 50 ] ; xx [ 40 ] = xx [ 41 ] ; xx [ 51 ] = xx [ 10 ] - xx [ 46 ]
; xx [ 10 ] = xx [ 2 ] * xx [ 47 ] * xx [ 51 ] ; xx [ 46 ] = xx [ 9 ] * xx [
10 ] + xx [ 48 ] * xx [ 50 ] ; xx [ 52 ] = xx [ 41 ] * xx [ 10 ] ; xx [ 53 ]
= xx [ 49 ] ; xx [ 54 ] = - xx [ 46 ] ; pm_math_Vector3_cross_ra ( xx + 38 ,
xx + 52 , xx + 55 ) ; xx [ 38 ] = xx [ 41 ] * xx [ 24 ] ; xx [ 39 ] = xx [ 24
] * xx [ 50 ] ; xx [ 40 ] = xx [ 42 ] * xx [ 50 ] ; xx [ 47 ] = ( xx [ 41 ] *
xx [ 51 ] - xx [ 40 ] ) * xx [ 32 ] ; xx [ 48 ] = xx [ 50 ] * xx [ 51 ] ; xx
[ 52 ] = xx [ 48 ] + xx [ 41 ] * xx [ 42 ] ; xx [ 41 ] = xx [ 9 ] * xx [ 51 ]
- xx [ 40 ] ; xx [ 40 ] = xx [ 32 ] * ( xx [ 48 ] + xx [ 9 ] * xx [ 42 ] ) ;
xx [ 42 ] = xx [ 22 ] * xx [ 30 ] ; xx [ 22 ] = xx [ 17 ] * xx [ 36 ] ; xx [
58 ] = fabs ( - ( ( xx [ 7 ] + xx [ 19 ] ) * xx [ 2 ] + ( xx [ 7 ] + xx [ 19
] ) * xx [ 2 ] + ( xx [ 34 ] * xx [ 35 ] + xx [ 43 ] ) * xx [ 2 ] - ( xx [ 13
] - ( xx [ 26 ] * xx [ 35 ] + xx [ 11 ] * xx [ 29 ] ) * xx [ 2 ] ) - ( xx [
33 ] * xx [ 37 ] + xx [ 27 ] * xx [ 23 ] ) * xx [ 2 ] + xx [ 18 ] ) ) ; xx [
59 ] = fabs ( xx [ 2 ] * ( xx [ 28 ] - xx [ 20 ] ) - xx [ 2 ] * ( xx [ 20 ] -
xx [ 28 ] ) - ( xx [ 2 ] * ( xx [ 23 ] * xx [ 37 ] - xx [ 27 ] * xx [ 33 ] )
+ xx [ 2 ] * ( xx [ 44 ] - xx [ 25 ] * xx [ 35 ] ) - xx [ 2 ] * ( xx [ 29 ] *
xx [ 35 ] - xx [ 11 ] * xx [ 26 ] ) ) + xx [ 5 ] ) ; xx [ 60 ] = fabs ( - ( (
xx [ 14 ] + xx [ 21 ] ) * xx [ 2 ] + ( xx [ 14 ] + xx [ 21 ] ) * xx [ 2 ] + (
xx [ 49 ] * xx [ 50 ] + xx [ 56 ] ) * xx [ 2 ] - ( xx [ 10 ] - ( xx [ 38 ] *
xx [ 50 ] + xx [ 9 ] * xx [ 39 ] ) * xx [ 2 ] ) - ( xx [ 47 ] * xx [ 52 ] +
xx [ 41 ] * xx [ 40 ] ) * xx [ 2 ] + xx [ 18 ] ) ) ; xx [ 61 ] = fabs ( xx [
2 ] * ( xx [ 42 ] - xx [ 22 ] ) - xx [ 2 ] * ( xx [ 22 ] - xx [ 42 ] ) - ( xx
[ 2 ] * ( xx [ 40 ] * xx [ 52 ] - xx [ 41 ] * xx [ 47 ] ) + xx [ 2 ] * ( xx [
57 ] - xx [ 46 ] * xx [ 50 ] ) - xx [ 2 ] * ( xx [ 39 ] * xx [ 50 ] - xx [ 9
] * xx [ 38 ] ) ) + xx [ 5 ] ) ; ii [ 0 ] = 58 ; { int ll ; for ( ll = 59 ;
ll < 62 ; ++ ll ) if ( xx [ ll ] > xx [ ii [ 0 ] ] ) ii [ 0 ] = ll ; } ii [ 0
] -= 58 ; xx [ 5 ] = xx [ 58 + ( ii [ 0 ] ) ] ; xx [ 7 ] = 1.0e-9 ; if ( xx [
5 ] > xx [ 7 ] ) { switch ( ii [ 0 ] ) { case 0 : case 1 : { return
sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:ConstraintViolation" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint6' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem."
, neDiagMgr ) ; } case 2 : case 3 : { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:ConstraintViolation" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint9' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem."
, neDiagMgr ) ; } } } xx [ 5 ] = xx [ 4 ] * xx [ 91 ] ; xx [ 9 ] = xx [ 3 ] *
sin ( xx [ 5 ] ) ; xx [ 10 ] = xx [ 3 ] * cos ( xx [ 5 ] ) ; xx [ 5 ] = xx [
9 ] + xx [ 10 ] ; xx [ 11 ] = xx [ 5 ] * xx [ 8 ] ; xx [ 13 ] = xx [ 2 ] * xx
[ 5 ] * xx [ 11 ] ; xx [ 14 ] = xx [ 1 ] - xx [ 13 ] ; xx [ 17 ] = xx [ 4 ] *
xx [ 89 ] ; xx [ 18 ] = sin ( xx [ 17 ] ) ; xx [ 19 ] = xx [ 12 ] * xx [ 18 ]
; xx [ 20 ] = cos ( xx [ 17 ] ) ; xx [ 17 ] = xx [ 16 ] * xx [ 20 ] ; xx [ 21
] = xx [ 19 ] + xx [ 17 ] ; xx [ 22 ] = xx [ 9 ] - xx [ 10 ] ; xx [ 9 ] = xx
[ 11 ] * xx [ 22 ] ; xx [ 10 ] = xx [ 2 ] * xx [ 9 ] ; xx [ 11 ] = xx [ 21 ]
* xx [ 10 ] ; xx [ 23 ] = xx [ 12 ] * xx [ 20 ] - xx [ 16 ] * xx [ 18 ] ; xx
[ 18 ] = xx [ 11 ] * xx [ 23 ] ; xx [ 20 ] = xx [ 17 ] + xx [ 19 ] ; xx [ 25
] = xx [ 20 ] ; xx [ 26 ] = xx [ 23 ] ; xx [ 27 ] = xx [ 21 ] ; xx [ 17 ] =
xx [ 10 ] * xx [ 23 ] ; xx [ 19 ] = xx [ 20 ] * xx [ 14 ] - xx [ 17 ] ; xx [
28 ] = - ( xx [ 21 ] * xx [ 14 ] ) ; xx [ 29 ] = xx [ 11 ] ; xx [ 30 ] = xx [
19 ] ; pm_math_Vector3_cross_ra ( xx + 25 , xx + 28 , xx + 33 ) ; xx [ 28 ] =
xx [ 21 ] * xx [ 24 ] ; xx [ 29 ] = xx [ 20 ] * xx [ 24 ] ; xx [ 30 ] = ( xx
[ 21 ] * xx [ 28 ] + xx [ 20 ] * xx [ 29 ] ) * xx [ 2 ] ; xx [ 36 ] = xx [ 5
] * xx [ 23 ] ; xx [ 37 ] = xx [ 21 ] * xx [ 22 ] - xx [ 36 ] ; xx [ 38 ] =
xx [ 37 ] * xx [ 32 ] ; xx [ 39 ] = xx [ 20 ] * xx [ 22 ] - xx [ 36 ] ; xx [
36 ] = xx [ 39 ] * xx [ 32 ] ; xx [ 40 ] = ( xx [ 37 ] * xx [ 38 ] + xx [ 39
] * xx [ 36 ] ) * xx [ 2 ] ; xx [ 41 ] = xx [ 8 ] - xx [ 13 ] ; xx [ 13 ] =
xx [ 20 ] * xx [ 41 ] - xx [ 17 ] ; xx [ 42 ] = - ( xx [ 21 ] * xx [ 41 ] ) ;
xx [ 43 ] = xx [ 11 ] ; xx [ 44 ] = xx [ 13 ] ; pm_math_Vector3_cross_ra ( xx
+ 25 , xx + 42 , xx + 46 ) ; xx [ 11 ] = xx [ 4 ] * xx [ 95 ] ; xx [ 17 ] =
sin ( xx [ 11 ] ) ; xx [ 42 ] = xx [ 12 ] * xx [ 17 ] ; xx [ 43 ] = cos ( xx
[ 11 ] ) ; xx [ 11 ] = xx [ 16 ] * xx [ 43 ] ; xx [ 44 ] = xx [ 42 ] + xx [
11 ] ; xx [ 49 ] = xx [ 44 ] * xx [ 45 ] ; xx [ 50 ] = xx [ 11 ] + xx [ 42 ]
; xx [ 11 ] = xx [ 50 ] * xx [ 45 ] ; xx [ 42 ] = ( xx [ 44 ] * xx [ 49 ] +
xx [ 50 ] * xx [ 11 ] ) * xx [ 2 ] ; xx [ 33 ] = xx [ 29 ] * xx [ 23 ] + xx [
28 ] * xx [ 23 ] ; xx [ 28 ] = xx [ 33 ] * xx [ 2 ] ; xx [ 29 ] = xx [ 23 ] *
xx [ 22 ] ; xx [ 22 ] = xx [ 29 ] + xx [ 21 ] * xx [ 5 ] ; xx [ 51 ] = xx [
29 ] + xx [ 20 ] * xx [ 5 ] ; xx [ 5 ] = ( xx [ 36 ] * xx [ 22 ] + xx [ 38 ]
* xx [ 51 ] ) * xx [ 2 ] ; xx [ 29 ] = xx [ 16 ] * xx [ 17 ] - xx [ 12 ] * xx
[ 43 ] ; xx [ 17 ] = xx [ 11 ] * xx [ 29 ] + xx [ 49 ] * xx [ 29 ] ; xx [ 11
] = xx [ 17 ] * xx [ 2 ] ; xx [ 36 ] = xx [ 4 ] * xx [ 85 ] ; xx [ 38 ] = xx
[ 3 ] * sin ( xx [ 36 ] ) ; xx [ 43 ] = xx [ 3 ] * cos ( xx [ 36 ] ) ; xx [
36 ] = xx [ 38 ] + xx [ 43 ] ; xx [ 46 ] = xx [ 36 ] * xx [ 8 ] ; xx [ 49 ] =
xx [ 2 ] * xx [ 36 ] * xx [ 46 ] ; xx [ 52 ] = xx [ 1 ] - xx [ 49 ] ; xx [ 1
] = xx [ 4 ] * xx [ 83 ] ; xx [ 53 ] = sin ( xx [ 1 ] ) ; xx [ 54 ] = xx [ 12
] * xx [ 53 ] ; xx [ 55 ] = cos ( xx [ 1 ] ) ; xx [ 1 ] = xx [ 16 ] * xx [ 55
] ; xx [ 56 ] = xx [ 54 ] + xx [ 1 ] ; xx [ 57 ] = xx [ 38 ] - xx [ 43 ] ; xx
[ 38 ] = xx [ 46 ] * xx [ 57 ] ; xx [ 43 ] = xx [ 2 ] * xx [ 38 ] ; xx [ 46 ]
= xx [ 56 ] * xx [ 43 ] ; xx [ 58 ] = xx [ 12 ] * xx [ 55 ] - xx [ 16 ] * xx
[ 53 ] ; xx [ 53 ] = xx [ 46 ] * xx [ 58 ] ; xx [ 55 ] = xx [ 1 ] + xx [ 54 ]
; xx [ 59 ] = xx [ 55 ] ; xx [ 60 ] = xx [ 58 ] ; xx [ 61 ] = xx [ 56 ] ; xx
[ 1 ] = xx [ 43 ] * xx [ 58 ] ; xx [ 54 ] = xx [ 55 ] * xx [ 52 ] - xx [ 1 ]
; xx [ 62 ] = - ( xx [ 56 ] * xx [ 52 ] ) ; xx [ 63 ] = xx [ 46 ] ; xx [ 64 ]
= xx [ 54 ] ; pm_math_Vector3_cross_ra ( xx + 59 , xx + 62 , xx + 65 ) ; xx [
62 ] = xx [ 56 ] * xx [ 24 ] ; xx [ 63 ] = xx [ 55 ] * xx [ 24 ] ; xx [ 64 ]
= ( xx [ 56 ] * xx [ 62 ] + xx [ 55 ] * xx [ 63 ] ) * xx [ 2 ] ; xx [ 68 ] =
xx [ 36 ] * xx [ 58 ] ; xx [ 69 ] = xx [ 56 ] * xx [ 57 ] - xx [ 68 ] ; xx [
70 ] = xx [ 69 ] * xx [ 32 ] ; xx [ 71 ] = xx [ 55 ] * xx [ 57 ] - xx [ 68 ]
; xx [ 68 ] = xx [ 71 ] * xx [ 32 ] ; xx [ 72 ] = ( xx [ 69 ] * xx [ 70 ] +
xx [ 71 ] * xx [ 68 ] ) * xx [ 2 ] ; xx [ 103 ] = xx [ 8 ] - xx [ 49 ] ; xx [
8 ] = xx [ 55 ] * xx [ 103 ] - xx [ 1 ] ; xx [ 104 ] = - ( xx [ 56 ] * xx [
103 ] ) ; xx [ 105 ] = xx [ 46 ] ; xx [ 106 ] = xx [ 8 ] ;
pm_math_Vector3_cross_ra ( xx + 59 , xx + 104 , xx + 107 ) ; xx [ 1 ] = xx [
4 ] * xx [ 97 ] ; xx [ 46 ] = sin ( xx [ 1 ] ) ; xx [ 49 ] = xx [ 12 ] * xx [
46 ] ; xx [ 104 ] = cos ( xx [ 1 ] ) ; xx [ 1 ] = xx [ 16 ] * xx [ 104 ] ; xx
[ 105 ] = xx [ 49 ] + xx [ 1 ] ; xx [ 106 ] = xx [ 105 ] * xx [ 45 ] ; xx [
110 ] = xx [ 1 ] + xx [ 49 ] ; xx [ 1 ] = xx [ 110 ] * xx [ 45 ] ; xx [ 49 ]
= ( xx [ 105 ] * xx [ 106 ] + xx [ 110 ] * xx [ 1 ] ) * xx [ 2 ] ; xx [ 65 ]
= xx [ 63 ] * xx [ 58 ] + xx [ 62 ] * xx [ 58 ] ; xx [ 62 ] = xx [ 65 ] * xx
[ 2 ] ; xx [ 63 ] = xx [ 58 ] * xx [ 57 ] ; xx [ 57 ] = xx [ 63 ] + xx [ 56 ]
* xx [ 36 ] ; xx [ 111 ] = xx [ 63 ] + xx [ 55 ] * xx [ 36 ] ; xx [ 36 ] = (
xx [ 68 ] * xx [ 57 ] + xx [ 70 ] * xx [ 111 ] ) * xx [ 2 ] ; xx [ 63 ] = xx
[ 16 ] * xx [ 46 ] - xx [ 12 ] * xx [ 104 ] ; xx [ 46 ] = xx [ 1 ] * xx [ 63
] + xx [ 106 ] * xx [ 63 ] ; xx [ 1 ] = xx [ 46 ] * xx [ 2 ] ; xx [ 112 ] =
xx [ 0 ] ; xx [ 113 ] = xx [ 0 ] ; xx [ 114 ] = xx [ 0 ] ; xx [ 115 ] = xx [
0 ] ; xx [ 116 ] = xx [ 0 ] ; xx [ 117 ] = xx [ 0 ] ; xx [ 118 ] = xx [ 0 ] ;
xx [ 119 ] = xx [ 0 ] ; xx [ 120 ] = - ( xx [ 14 ] + ( xx [ 18 ] + xx [ 34 ]
) * xx [ 2 ] - xx [ 30 ] + xx [ 40 ] + xx [ 31 ] ) ; xx [ 121 ] = - ( xx [ 41
] + xx [ 2 ] * ( xx [ 47 ] + xx [ 18 ] ) + xx [ 40 ] - xx [ 32 ] ) ; xx [ 122
] = xx [ 0 ] ; xx [ 123 ] = xx [ 15 ] - ( xx [ 42 ] + xx [ 42 ] ) ; xx [ 124
] = xx [ 0 ] ; xx [ 125 ] = xx [ 0 ] ; xx [ 126 ] = xx [ 0 ] ; xx [ 127 ] =
xx [ 0 ] ; xx [ 128 ] = xx [ 0 ] ; xx [ 129 ] = xx [ 0 ] ; xx [ 130 ] = xx [
0 ] ; xx [ 131 ] = xx [ 0 ] ; xx [ 132 ] = xx [ 0 ] ; xx [ 133 ] = - ( ( xx [
19 ] * xx [ 23 ] + xx [ 35 ] ) * xx [ 2 ] + xx [ 28 ] - xx [ 5 ] ) ; xx [ 134
] = - ( ( xx [ 13 ] * xx [ 23 ] + xx [ 48 ] ) * xx [ 2 ] - xx [ 5 ] ) ; xx [
135 ] = xx [ 0 ] ; xx [ 136 ] = - ( xx [ 11 ] + xx [ 11 ] ) ; xx [ 137 ] = xx
[ 0 ] ; xx [ 138 ] = xx [ 0 ] ; xx [ 139 ] = xx [ 0 ] ; xx [ 140 ] = xx [ 0 ]
; xx [ 141 ] = xx [ 0 ] ; xx [ 142 ] = xx [ 0 ] ; xx [ 143 ] = - ( xx [ 52 ]
+ ( xx [ 53 ] + xx [ 66 ] ) * xx [ 2 ] - xx [ 64 ] + xx [ 72 ] + xx [ 31 ] )
; xx [ 144 ] = - ( xx [ 103 ] + xx [ 2 ] * ( xx [ 108 ] + xx [ 53 ] ) + xx [
72 ] - xx [ 32 ] ) ; xx [ 145 ] = xx [ 0 ] ; xx [ 146 ] = xx [ 0 ] ; xx [ 147
] = xx [ 0 ] ; xx [ 148 ] = xx [ 0 ] ; xx [ 149 ] = xx [ 0 ] ; xx [ 150 ] =
xx [ 15 ] - ( xx [ 49 ] + xx [ 49 ] ) ; xx [ 151 ] = xx [ 0 ] ; xx [ 152 ] =
xx [ 0 ] ; xx [ 153 ] = xx [ 0 ] ; xx [ 154 ] = xx [ 0 ] ; xx [ 155 ] = xx [
0 ] ; xx [ 156 ] = - ( ( xx [ 54 ] * xx [ 58 ] + xx [ 67 ] ) * xx [ 2 ] + xx
[ 62 ] - xx [ 36 ] ) ; xx [ 157 ] = - ( ( xx [ 8 ] * xx [ 58 ] + xx [ 109 ] )
* xx [ 2 ] - xx [ 36 ] ) ; xx [ 158 ] = xx [ 0 ] ; xx [ 159 ] = xx [ 0 ] ; xx
[ 160 ] = xx [ 0 ] ; xx [ 161 ] = xx [ 0 ] ; xx [ 162 ] = xx [ 0 ] ; xx [ 163
] = - ( xx [ 1 ] + xx [ 1 ] ) ; xx [ 0 ] = ( xx [ 90 ] + xx [ 92 ] ) * xx [
32 ] ; xx [ 5 ] = xx [ 37 ] * xx [ 0 ] ; xx [ 8 ] = xx [ 39 ] * xx [ 0 ] ; xx
[ 13 ] = xx [ 24 ] - xx [ 30 ] ; xx [ 15 ] = xx [ 92 ] * xx [ 41 ] + xx [ 14
] * xx [ 90 ] ; xx [ 18 ] = xx [ 90 ] * xx [ 10 ] + xx [ 2 ] * xx [ 92 ] * xx
[ 9 ] ; xx [ 9 ] = xx [ 21 ] * xx [ 18 ] ; xx [ 19 ] = xx [ 20 ] * xx [ 15 ]
- xx [ 23 ] * xx [ 18 ] ; xx [ 34 ] = - ( xx [ 21 ] * xx [ 15 ] ) ; xx [ 35 ]
= xx [ 9 ] ; xx [ 36 ] = xx [ 19 ] ; pm_math_Vector3_cross_ra ( xx + 25 , xx
+ 34 , xx + 66 ) ; xx [ 18 ] = xx [ 45 ] * xx [ 96 ] ; xx [ 30 ] = xx [ 44 ]
* xx [ 18 ] ; xx [ 31 ] = xx [ 50 ] * xx [ 18 ] ; xx [ 34 ] = xx [ 45 ] - xx
[ 42 ] ; xx [ 35 ] = ( xx [ 84 ] + xx [ 86 ] ) * xx [ 32 ] ; xx [ 36 ] = xx [
69 ] * xx [ 35 ] ; xx [ 40 ] = xx [ 71 ] * xx [ 35 ] ; xx [ 42 ] = xx [ 24 ]
- xx [ 64 ] ; xx [ 24 ] = xx [ 86 ] * xx [ 103 ] + xx [ 52 ] * xx [ 84 ] ; xx
[ 47 ] = xx [ 84 ] * xx [ 43 ] + xx [ 2 ] * xx [ 86 ] * xx [ 38 ] ; xx [ 38 ]
= xx [ 56 ] * xx [ 47 ] ; xx [ 48 ] = xx [ 55 ] * xx [ 24 ] - xx [ 58 ] * xx
[ 47 ] ; xx [ 106 ] = - ( xx [ 56 ] * xx [ 24 ] ) ; xx [ 107 ] = xx [ 38 ] ;
xx [ 108 ] = xx [ 48 ] ; pm_math_Vector3_cross_ra ( xx + 59 , xx + 106 , xx +
164 ) ; xx [ 47 ] = xx [ 45 ] * xx [ 98 ] ; xx [ 53 ] = xx [ 105 ] * xx [ 47
] ; xx [ 54 ] = xx [ 110 ] * xx [ 47 ] ; xx [ 64 ] = xx [ 45 ] - xx [ 49 ] ;
xx [ 106 ] = ( xx [ 37 ] * xx [ 5 ] + xx [ 39 ] * xx [ 8 ] ) * xx [ 2 ] - xx
[ 0 ] + xx [ 90 ] * xx [ 13 ] + xx [ 15 ] + ( xx [ 9 ] * xx [ 23 ] + xx [ 67
] ) * xx [ 2 ] - ( xx [ 18 ] - ( xx [ 44 ] * xx [ 30 ] + xx [ 50 ] * xx [ 31
] ) * xx [ 2 ] + xx [ 96 ] * xx [ 34 ] ) ; xx [ 107 ] = xx [ 2 ] * xx [ 33 ]
* xx [ 90 ] + ( xx [ 19 ] * xx [ 23 ] + xx [ 68 ] ) * xx [ 2 ] - ( xx [ 8 ] *
xx [ 22 ] + xx [ 5 ] * xx [ 51 ] ) * xx [ 2 ] + ( xx [ 31 ] * xx [ 29 ] + xx
[ 30 ] * xx [ 29 ] ) * xx [ 2 ] + xx [ 2 ] * xx [ 17 ] * xx [ 96 ] ; xx [ 108
] = ( xx [ 69 ] * xx [ 36 ] + xx [ 71 ] * xx [ 40 ] ) * xx [ 2 ] - xx [ 35 ]
+ xx [ 84 ] * xx [ 42 ] + xx [ 24 ] + ( xx [ 38 ] * xx [ 58 ] + xx [ 165 ] )
* xx [ 2 ] - ( xx [ 47 ] - ( xx [ 105 ] * xx [ 53 ] + xx [ 110 ] * xx [ 54 ]
) * xx [ 2 ] + xx [ 98 ] * xx [ 64 ] ) ; xx [ 109 ] = xx [ 2 ] * xx [ 65 ] *
xx [ 84 ] + ( xx [ 48 ] * xx [ 58 ] + xx [ 166 ] ) * xx [ 2 ] - ( xx [ 40 ] *
xx [ 57 ] + xx [ 36 ] * xx [ 111 ] ) * xx [ 2 ] + ( xx [ 54 ] * xx [ 63 ] +
xx [ 53 ] * xx [ 63 ] ) * xx [ 2 ] + xx [ 2 ] * xx [ 46 ] * xx [ 98 ] ;
memcpy ( xx + 177 , xx + 112 , 52 * sizeof ( double ) ) ; factorAndSolveWide
( 4 , 13 , xx + 177 , xx + 46 , xx + 65 , ii + 0 , xx + 106 , xx [ 6 ] , xx +
164 ) ; xx [ 0 ] = xx [ 84 ] + xx [ 169 ] ; xx [ 5 ] = xx [ 86 ] + xx [ 170 ]
; xx [ 6 ] = xx [ 90 ] + xx [ 172 ] ; xx [ 8 ] = xx [ 92 ] + xx [ 173 ] ; xx
[ 9 ] = xx [ 96 ] + xx [ 175 ] ; xx [ 15 ] = xx [ 98 ] + xx [ 176 ] ; xx [
112 ] = xx [ 73 ] ; xx [ 113 ] = xx [ 74 ] ; xx [ 114 ] = xx [ 75 ] ; xx [
115 ] = xx [ 76 ] + xx [ 164 ] ; xx [ 116 ] = xx [ 77 ] + xx [ 165 ] ; xx [
117 ] = xx [ 78 ] + xx [ 166 ] ; xx [ 118 ] = xx [ 79 ] ; xx [ 119 ] = xx [
80 ] + xx [ 167 ] ; xx [ 120 ] = xx [ 81 ] ; xx [ 121 ] = xx [ 82 ] + xx [
168 ] ; xx [ 122 ] = xx [ 83 ] ; xx [ 123 ] = xx [ 0 ] ; xx [ 124 ] = xx [ 85
] ; xx [ 125 ] = xx [ 5 ] ; xx [ 126 ] = xx [ 87 ] ; xx [ 127 ] = xx [ 88 ] +
xx [ 171 ] ; xx [ 128 ] = xx [ 89 ] ; xx [ 129 ] = xx [ 6 ] ; xx [ 130 ] = xx
[ 91 ] ; xx [ 131 ] = xx [ 8 ] ; xx [ 132 ] = xx [ 93 ] ; xx [ 133 ] = xx [
94 ] + xx [ 174 ] ; xx [ 134 ] = xx [ 95 ] ; xx [ 135 ] = xx [ 9 ] ; xx [ 136
] = xx [ 97 ] ; xx [ 137 ] = xx [ 15 ] ; xx [ 138 ] = xx [ 99 ] ; xx [ 139 ]
= xx [ 100 ] ; xx [ 140 ] = xx [ 101 ] ; xx [ 141 ] = xx [ 102 ] ; xx [ 17 ]
= xx [ 9 ] * xx [ 45 ] ; xx [ 18 ] = xx [ 44 ] * xx [ 17 ] ; xx [ 19 ] = xx [
50 ] * xx [ 17 ] ; xx [ 24 ] = ( xx [ 6 ] + xx [ 8 ] ) * xx [ 32 ] ; xx [ 30
] = xx [ 37 ] * xx [ 24 ] ; xx [ 31 ] = xx [ 39 ] * xx [ 24 ] ; xx [ 33 ] =
xx [ 8 ] * xx [ 41 ] + xx [ 6 ] * xx [ 14 ] ; xx [ 14 ] = xx [ 6 ] * xx [ 10
] + xx [ 8 ] * xx [ 10 ] ; xx [ 8 ] = xx [ 21 ] * xx [ 14 ] ; xx [ 10 ] = xx
[ 33 ] * xx [ 20 ] - xx [ 23 ] * xx [ 14 ] ; xx [ 46 ] = - ( xx [ 33 ] * xx [
21 ] ) ; xx [ 47 ] = xx [ 8 ] ; xx [ 48 ] = xx [ 10 ] ;
pm_math_Vector3_cross_ra ( xx + 25 , xx + 46 , xx + 65 ) ; xx [ 14 ] = xx [
15 ] * xx [ 45 ] ; xx [ 20 ] = xx [ 105 ] * xx [ 14 ] ; xx [ 21 ] = xx [ 110
] * xx [ 14 ] ; xx [ 25 ] = ( xx [ 0 ] + xx [ 5 ] ) * xx [ 32 ] ; xx [ 26 ] =
xx [ 69 ] * xx [ 25 ] ; xx [ 27 ] = xx [ 71 ] * xx [ 25 ] ; xx [ 32 ] = xx [
5 ] * xx [ 103 ] + xx [ 0 ] * xx [ 52 ] ; xx [ 35 ] = xx [ 0 ] * xx [ 43 ] +
xx [ 5 ] * xx [ 43 ] ; xx [ 5 ] = xx [ 56 ] * xx [ 35 ] ; xx [ 36 ] = xx [ 32
] * xx [ 55 ] - xx [ 58 ] * xx [ 35 ] ; xx [ 45 ] = - ( xx [ 32 ] * xx [ 56 ]
) ; xx [ 46 ] = xx [ 5 ] ; xx [ 47 ] = xx [ 36 ] ; pm_math_Vector3_cross_ra (
xx + 59 , xx + 45 , xx + 52 ) ; xx [ 45 ] = fabs ( xx [ 17 ] - ( xx [ 44 ] *
xx [ 18 ] + xx [ 50 ] * xx [ 19 ] ) * xx [ 2 ] + xx [ 9 ] * xx [ 34 ] - ( (
xx [ 37 ] * xx [ 30 ] + xx [ 39 ] * xx [ 31 ] ) * xx [ 2 ] - xx [ 24 ] + xx [
6 ] * xx [ 13 ] + xx [ 33 ] + ( xx [ 8 ] * xx [ 23 ] + xx [ 66 ] ) * xx [ 2 ]
) ) ; xx [ 46 ] = fabs ( - ( ( xx [ 19 ] * xx [ 29 ] + xx [ 18 ] * xx [ 29 ]
) * xx [ 2 ] + xx [ 9 ] * xx [ 11 ] + xx [ 6 ] * xx [ 28 ] + ( xx [ 10 ] * xx
[ 23 ] + xx [ 67 ] ) * xx [ 2 ] - ( xx [ 31 ] * xx [ 22 ] + xx [ 30 ] * xx [
51 ] ) * xx [ 2 ] ) ) ; xx [ 47 ] = fabs ( xx [ 14 ] - ( xx [ 105 ] * xx [ 20
] + xx [ 110 ] * xx [ 21 ] ) * xx [ 2 ] + xx [ 15 ] * xx [ 64 ] - ( ( xx [ 69
] * xx [ 26 ] + xx [ 71 ] * xx [ 27 ] ) * xx [ 2 ] - xx [ 25 ] + xx [ 0 ] *
xx [ 42 ] + xx [ 32 ] + ( xx [ 5 ] * xx [ 58 ] + xx [ 53 ] ) * xx [ 2 ] ) ) ;
xx [ 48 ] = fabs ( - ( ( xx [ 21 ] * xx [ 63 ] + xx [ 20 ] * xx [ 63 ] ) * xx
[ 2 ] + xx [ 15 ] * xx [ 1 ] + xx [ 0 ] * xx [ 62 ] + ( xx [ 36 ] * xx [ 58 ]
+ xx [ 54 ] ) * xx [ 2 ] - ( xx [ 27 ] * xx [ 57 ] + xx [ 26 ] * xx [ 111 ] )
* xx [ 2 ] ) ) ; ii [ 0 ] = 45 ; { int ll ; for ( ll = 46 ; ll < 49 ; ++ ll )
if ( xx [ ll ] > xx [ ii [ 0 ] ] ) ii [ 0 ] = ll ; } ii [ 0 ] -= 45 ; xx [ 0
] = xx [ 45 + ( ii [ 0 ] ) ] ; if ( xx [ 0 ] > xx [ 7 ] ) { switch ( ii [ 0 ]
) { case 0 : case 1 : { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:ConstraintViolation" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint6' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem."
, neDiagMgr ) ; } case 2 : case 3 : { return sm_ssci_recordRunTimeError (
"sm:compiler:messages:simulationErrors:ConstraintViolation" ,
 "'series_link_blance_leg/series_blance_leg_model/Revolute Joint9' kinematic constraints cannot be maintained. Check solver type and consistency tolerance in the Simscape Solver Configuration block. Check Simulink solver type and tolerances in Model Configuration Parameters. A kinematic singularity might be the source of this problem."
, neDiagMgr ) ; } } } xx [ 0 ] = xx [ 4 ] * xx [ 128 ] ; xx [ 1 ] = cos ( xx
[ 0 ] ) ; xx [ 5 ] = sin ( xx [ 0 ] ) ; xx [ 0 ] = xx [ 12 ] * xx [ 1 ] - xx
[ 16 ] * xx [ 5 ] ; xx [ 6 ] = xx [ 4 ] * xx [ 130 ] ; xx [ 7 ] = xx [ 3 ] *
sin ( xx [ 6 ] ) ; xx [ 8 ] = xx [ 3 ] * cos ( xx [ 6 ] ) ; xx [ 6 ] = xx [ 7
] - xx [ 8 ] ; xx [ 9 ] = xx [ 0 ] * xx [ 6 ] ; xx [ 10 ] = xx [ 12 ] * xx [
5 ] ; xx [ 5 ] = xx [ 16 ] * xx [ 1 ] ; xx [ 1 ] = xx [ 10 ] + xx [ 5 ] ; xx
[ 11 ] = xx [ 7 ] + xx [ 8 ] ; xx [ 7 ] = xx [ 5 ] + xx [ 10 ] ; xx [ 5 ] =
xx [ 11 ] * xx [ 0 ] ; xx [ 17 ] = xx [ 9 ] + xx [ 1 ] * xx [ 11 ] ; xx [ 18
] = xx [ 7 ] * xx [ 6 ] - xx [ 5 ] ; xx [ 19 ] = xx [ 9 ] + xx [ 7 ] * xx [
11 ] ; xx [ 20 ] = xx [ 1 ] * xx [ 6 ] - xx [ 5 ] ; xx [ 5 ] = xx [ 4 ] * xx
[ 134 ] ; xx [ 8 ] = sin ( xx [ 5 ] ) ; xx [ 9 ] = cos ( xx [ 5 ] ) ; xx [ 5
] = xx [ 16 ] * xx [ 8 ] - xx [ 12 ] * xx [ 9 ] ; xx [ 10 ] = xx [ 16 ] * xx
[ 9 ] ; xx [ 9 ] = xx [ 12 ] * xx [ 8 ] ; xx [ 21 ] = xx [ 5 ] ; xx [ 22 ] =
- ( xx [ 10 ] + xx [ 9 ] ) ; xx [ 23 ] = xx [ 5 ] ; xx [ 24 ] = - ( xx [ 9 ]
+ xx [ 10 ] ) ; pm_math_Quaternion_inverseCompose_ra ( xx + 17 , xx + 21 , xx
+ 25 ) ; xx [ 5 ] = 0.4090518191766045 ; xx [ 8 ] = xx [ 4 ] * xx [ 120 ] ;
xx [ 9 ] = cos ( xx [ 8 ] ) ; xx [ 10 ] = xx [ 5 ] * xx [ 9 ] ; xx [ 13 ] =
0.3307064369132422 ; xx [ 14 ] = sin ( xx [ 8 ] ) ; xx [ 8 ] = xx [ 13 ] * xx
[ 14 ] ; xx [ 15 ] = xx [ 5 ] * xx [ 8 ] ; xx [ 17 ] = 0.5767812490262756 ;
xx [ 18 ] = 0.9437336767246086 ; xx [ 19 ] = xx [ 18 ] * xx [ 14 ] ; xx [ 14
] = xx [ 17 ] * xx [ 19 ] ; xx [ 20 ] = xx [ 10 ] - xx [ 15 ] + xx [ 14 ] ;
xx [ 29 ] = xx [ 20 ] * xx [ 119 ] ; xx [ 30 ] = xx [ 10 ] - ( xx [ 14 ] - xx
[ 15 ] ) ; xx [ 10 ] = xx [ 17 ] * xx [ 8 ] ; xx [ 8 ] = xx [ 17 ] * xx [ 9 ]
; xx [ 9 ] = xx [ 5 ] * xx [ 19 ] ; xx [ 5 ] = xx [ 10 ] - xx [ 8 ] + xx [ 9
] ; xx [ 14 ] = xx [ 119 ] * xx [ 5 ] ; xx [ 15 ] = xx [ 9 ] + xx [ 8 ] + xx
[ 10 ] ; xx [ 8 ] = ( xx [ 29 ] * xx [ 30 ] - xx [ 14 ] * xx [ 15 ] ) * xx [
2 ] ; xx [ 9 ] = xx [ 119 ] - ( xx [ 20 ] * xx [ 29 ] + xx [ 14 ] * xx [ 5 ]
) * xx [ 2 ] - xx [ 18 ] * xx [ 121 ] ; xx [ 10 ] = - ( xx [ 2 ] * ( xx [ 29
] * xx [ 15 ] + xx [ 14 ] * xx [ 30 ] ) + xx [ 13 ] * xx [ 121 ] ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 21 , xx + 8 , xx + 13 ) ; xx [ 17 ]
= xx [ 0 ] ; xx [ 18 ] = xx [ 7 ] ; xx [ 19 ] = xx [ 0 ] ; xx [ 20 ] = xx [ 1
] ; pm_math_Quaternion_inverseXform_ra ( xx + 17 , xx + 8 , xx + 21 ) ; xx [
0 ] = xx [ 11 ] * xx [ 22 ] ; xx [ 1 ] = xx [ 11 ] * xx [ 21 ] ; xx [ 17 ] =
xx [ 21 ] - xx [ 2 ] * ( xx [ 0 ] * xx [ 6 ] + xx [ 11 ] * xx [ 1 ] ) ; xx [
18 ] = xx [ 22 ] - ( xx [ 11 ] * xx [ 0 ] - xx [ 1 ] * xx [ 6 ] ) * xx [ 2 ]
; xx [ 19 ] = xx [ 23 ] + xx [ 129 ] + xx [ 131 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 25 , xx + 17 , xx + 5 ) ; xx [ 0 ]
= xx [ 4 ] * xx [ 122 ] ; xx [ 1 ] = cos ( xx [ 0 ] ) ; xx [ 5 ] = sin ( xx [
0 ] ) ; xx [ 0 ] = xx [ 12 ] * xx [ 1 ] - xx [ 16 ] * xx [ 5 ] ; xx [ 6 ] =
xx [ 4 ] * xx [ 124 ] ; xx [ 11 ] = xx [ 3 ] * sin ( xx [ 6 ] ) ; xx [ 13 ] =
xx [ 3 ] * cos ( xx [ 6 ] ) ; xx [ 3 ] = xx [ 11 ] - xx [ 13 ] ; xx [ 6 ] =
xx [ 0 ] * xx [ 3 ] ; xx [ 14 ] = xx [ 12 ] * xx [ 5 ] ; xx [ 5 ] = xx [ 16 ]
* xx [ 1 ] ; xx [ 1 ] = xx [ 14 ] + xx [ 5 ] ; xx [ 17 ] = xx [ 11 ] + xx [
13 ] ; xx [ 11 ] = xx [ 5 ] + xx [ 14 ] ; xx [ 5 ] = xx [ 17 ] * xx [ 0 ] ;
xx [ 18 ] = xx [ 6 ] + xx [ 1 ] * xx [ 17 ] ; xx [ 19 ] = xx [ 11 ] * xx [ 3
] - xx [ 5 ] ; xx [ 20 ] = xx [ 6 ] + xx [ 11 ] * xx [ 17 ] ; xx [ 21 ] = xx
[ 1 ] * xx [ 3 ] - xx [ 5 ] ; xx [ 5 ] = xx [ 4 ] * xx [ 136 ] ; xx [ 4 ] =
sin ( xx [ 5 ] ) ; xx [ 6 ] = cos ( xx [ 5 ] ) ; xx [ 5 ] = xx [ 16 ] * xx [
4 ] - xx [ 12 ] * xx [ 6 ] ; xx [ 13 ] = xx [ 16 ] * xx [ 6 ] ; xx [ 6 ] = xx
[ 12 ] * xx [ 4 ] ; xx [ 29 ] = xx [ 5 ] ; xx [ 30 ] = - ( xx [ 13 ] + xx [ 6
] ) ; xx [ 31 ] = xx [ 5 ] ; xx [ 32 ] = - ( xx [ 6 ] + xx [ 13 ] ) ;
pm_math_Quaternion_inverseCompose_ra ( xx + 18 , xx + 29 , xx + 33 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 29 , xx + 8 , xx + 4 ) ; xx [ 18 ]
= xx [ 0 ] ; xx [ 19 ] = xx [ 11 ] ; xx [ 20 ] = xx [ 0 ] ; xx [ 21 ] = xx [
1 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 18 , xx + 8 , xx + 11 ) ; xx
[ 0 ] = xx [ 17 ] * xx [ 12 ] ; xx [ 1 ] = xx [ 17 ] * xx [ 11 ] ; xx [ 8 ] =
xx [ 11 ] - xx [ 2 ] * ( xx [ 0 ] * xx [ 3 ] + xx [ 17 ] * xx [ 1 ] ) ; xx [
9 ] = xx [ 12 ] - ( xx [ 17 ] * xx [ 0 ] - xx [ 1 ] * xx [ 3 ] ) * xx [ 2 ] ;
xx [ 10 ] = xx [ 13 ] + xx [ 123 ] + xx [ 125 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 33 , xx + 8 , xx + 3 ) ; state [ 0
] = xx [ 112 ] ; state [ 1 ] = xx [ 113 ] ; state [ 2 ] = xx [ 114 ] ; state
[ 3 ] = xx [ 115 ] ; state [ 4 ] = xx [ 116 ] ; state [ 5 ] = xx [ 117 ] ;
state [ 6 ] = xx [ 118 ] ; state [ 7 ] = xx [ 119 ] ; state [ 8 ] = xx [ 120
] ; state [ 9 ] = xx [ 121 ] ; state [ 10 ] = xx [ 122 ] ; state [ 11 ] = xx
[ 123 ] ; state [ 12 ] = xx [ 124 ] ; state [ 13 ] = xx [ 125 ] ; state [ 14
] = xx [ 126 ] ; state [ 15 ] = xx [ 127 ] ; state [ 16 ] = xx [ 128 ] ;
state [ 17 ] = xx [ 129 ] ; state [ 18 ] = xx [ 130 ] ; state [ 19 ] = xx [
131 ] ; state [ 20 ] = xx [ 132 ] ; state [ 21 ] = xx [ 133 ] ; state [ 22 ]
= xx [ 134 ] ; state [ 23 ] = xx [ 135 ] ; state [ 24 ] = xx [ 136 ] ; state
[ 25 ] = xx [ 137 ] ; state [ 26 ] = xx [ 138 ] + sm_core_canonicalAngle ( xx
[ 2 ] * atan2 ( sqrt ( xx [ 26 ] * xx [ 26 ] + xx [ 27 ] * xx [ 27 ] + xx [
28 ] * xx [ 28 ] ) , fabs ( - xx [ 25 ] ) ) * ( ( xx [ 25 ] * xx [ 28 ] ) <
0.0 ? - 1.0 : + 1.0 ) - xx [ 138 ] ) ; state [ 27 ] = xx [ 15 ] + xx [ 135 ]
- xx [ 7 ] ; state [ 28 ] = xx [ 140 ] + sm_core_canonicalAngle ( xx [ 2 ] *
atan2 ( sqrt ( xx [ 34 ] * xx [ 34 ] + xx [ 35 ] * xx [ 35 ] + xx [ 36 ] * xx
[ 36 ] ) , fabs ( - xx [ 33 ] ) ) * ( ( xx [ 33 ] * xx [ 36 ] ) < 0.0 ? - 1.0
: + 1.0 ) - xx [ 140 ] ) ; state [ 29 ] = xx [ 6 ] + xx [ 137 ] - xx [ 5 ] ;
return NULL ; } void series_link_blance_leg_ad6bcbee_1_computeConstraintError
( const void * mech , const RuntimeDerivedValuesBundle * rtdv , const double
* state , const int * modeVector , double * error ) { const double * rtdvd =
rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ;
double xx [ 48 ] ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; ( void )
modeVector ; xx [ 0 ] = 0.6970892476441968 ; xx [ 1 ] = 0.5 ; xx [ 2 ] = xx [
1 ] * state [ 22 ] ; xx [ 3 ] = sin ( xx [ 2 ] ) ; xx [ 4 ] = xx [ 0 ] * xx [
3 ] ; xx [ 5 ] = 0.1186026172512557 ; xx [ 6 ] = cos ( xx [ 2 ] ) ; xx [ 2 ]
= xx [ 5 ] * xx [ 6 ] ; xx [ 7 ] = 0.085075 ; xx [ 8 ] = ( xx [ 4 ] + xx [ 2
] ) * xx [ 7 ] ; xx [ 9 ] = xx [ 5 ] * xx [ 3 ] - xx [ 0 ] * xx [ 6 ] ; xx [
3 ] = xx [ 8 ] * xx [ 9 ] ; xx [ 6 ] = xx [ 2 ] + xx [ 4 ] ; xx [ 2 ] = xx [
7 ] * xx [ 9 ] ; xx [ 4 ] = xx [ 6 ] * xx [ 2 ] ; xx [ 10 ] = 2.0 ; xx [ 11 ]
= xx [ 1 ] * state [ 16 ] ; xx [ 12 ] = sin ( xx [ 11 ] ) ; xx [ 13 ] = xx [
0 ] * xx [ 12 ] ; xx [ 14 ] = cos ( xx [ 11 ] ) ; xx [ 11 ] = xx [ 5 ] * xx [
14 ] ; xx [ 15 ] = xx [ 13 ] + xx [ 11 ] ; xx [ 16 ] = 0.1078490312466243 ;
xx [ 17 ] = 0.7071067811865476 ; xx [ 18 ] = xx [ 1 ] * state [ 18 ] ; xx [
19 ] = xx [ 17 ] * sin ( xx [ 18 ] ) ; xx [ 20 ] = xx [ 17 ] * cos ( xx [ 18
] ) ; xx [ 18 ] = xx [ 19 ] + xx [ 20 ] ; xx [ 21 ] = 0.02913743527133955 ;
xx [ 22 ] = xx [ 18 ] * xx [ 21 ] ; xx [ 23 ] = xx [ 16 ] - xx [ 10 ] * xx [
18 ] * xx [ 22 ] ; xx [ 24 ] = xx [ 15 ] * xx [ 23 ] ; xx [ 25 ] = xx [ 0 ] *
xx [ 14 ] - xx [ 5 ] * xx [ 12 ] ; xx [ 12 ] = xx [ 11 ] + xx [ 13 ] ; xx [
26 ] = xx [ 12 ] ; xx [ 27 ] = xx [ 25 ] ; xx [ 28 ] = xx [ 15 ] ; xx [ 11 ]
= xx [ 19 ] - xx [ 20 ] ; xx [ 13 ] = xx [ 10 ] * xx [ 22 ] * xx [ 11 ] ; xx
[ 14 ] = xx [ 12 ] * xx [ 13 ] + xx [ 23 ] * xx [ 25 ] ; xx [ 29 ] = xx [ 15
] * xx [ 13 ] ; xx [ 30 ] = xx [ 24 ] ; xx [ 31 ] = - xx [ 14 ] ;
pm_math_Vector3_cross_ra ( xx + 26 , xx + 29 , xx + 32 ) ; xx [ 19 ] =
0.08603840402471528 ; xx [ 20 ] = xx [ 15 ] * xx [ 19 ] ; xx [ 22 ] = xx [ 19
] * xx [ 25 ] ; xx [ 23 ] = xx [ 18 ] * xx [ 25 ] ; xx [ 26 ] =
0.06918743527133955 ; xx [ 27 ] = ( xx [ 15 ] * xx [ 11 ] - xx [ 23 ] ) * xx
[ 26 ] ; xx [ 28 ] = xx [ 25 ] * xx [ 11 ] ; xx [ 29 ] = xx [ 28 ] + xx [ 15
] * xx [ 18 ] ; xx [ 15 ] = xx [ 12 ] * xx [ 11 ] - xx [ 23 ] ; xx [ 11 ] =
xx [ 26 ] * ( xx [ 28 ] + xx [ 12 ] * xx [ 18 ] ) ; xx [ 18 ] =
0.07164265098815176 ; xx [ 23 ] = xx [ 6 ] * xx [ 8 ] ; xx [ 6 ] = xx [ 2 ] *
xx [ 9 ] ; xx [ 2 ] = 0.03446132628599599 ; xx [ 8 ] = xx [ 1 ] * state [ 24
] ; xx [ 9 ] = sin ( xx [ 8 ] ) ; xx [ 28 ] = xx [ 0 ] * xx [ 9 ] ; xx [ 30 ]
= cos ( xx [ 8 ] ) ; xx [ 8 ] = xx [ 5 ] * xx [ 30 ] ; xx [ 31 ] = ( xx [ 28
] + xx [ 8 ] ) * xx [ 7 ] ; xx [ 32 ] = xx [ 5 ] * xx [ 9 ] - xx [ 0 ] * xx [
30 ] ; xx [ 9 ] = xx [ 31 ] * xx [ 32 ] ; xx [ 30 ] = xx [ 8 ] + xx [ 28 ] ;
xx [ 8 ] = xx [ 7 ] * xx [ 32 ] ; xx [ 7 ] = xx [ 30 ] * xx [ 8 ] ; xx [ 28 ]
= xx [ 1 ] * state [ 10 ] ; xx [ 35 ] = sin ( xx [ 28 ] ) ; xx [ 36 ] = xx [
0 ] * xx [ 35 ] ; xx [ 37 ] = cos ( xx [ 28 ] ) ; xx [ 28 ] = xx [ 5 ] * xx [
37 ] ; xx [ 38 ] = xx [ 36 ] + xx [ 28 ] ; xx [ 39 ] = xx [ 1 ] * state [ 12
] ; xx [ 1 ] = xx [ 17 ] * sin ( xx [ 39 ] ) ; xx [ 40 ] = xx [ 17 ] * cos (
xx [ 39 ] ) ; xx [ 17 ] = xx [ 1 ] + xx [ 40 ] ; xx [ 39 ] = xx [ 17 ] * xx [
21 ] ; xx [ 21 ] = xx [ 16 ] - xx [ 10 ] * xx [ 17 ] * xx [ 39 ] ; xx [ 16 ]
= xx [ 38 ] * xx [ 21 ] ; xx [ 41 ] = xx [ 0 ] * xx [ 37 ] - xx [ 5 ] * xx [
35 ] ; xx [ 0 ] = xx [ 28 ] + xx [ 36 ] ; xx [ 35 ] = xx [ 0 ] ; xx [ 36 ] =
xx [ 41 ] ; xx [ 37 ] = xx [ 38 ] ; xx [ 5 ] = xx [ 1 ] - xx [ 40 ] ; xx [ 1
] = xx [ 10 ] * xx [ 39 ] * xx [ 5 ] ; xx [ 28 ] = xx [ 0 ] * xx [ 1 ] + xx [
21 ] * xx [ 41 ] ; xx [ 42 ] = xx [ 38 ] * xx [ 1 ] ; xx [ 43 ] = xx [ 16 ] ;
xx [ 44 ] = - xx [ 28 ] ; pm_math_Vector3_cross_ra ( xx + 35 , xx + 42 , xx +
45 ) ; xx [ 21 ] = xx [ 38 ] * xx [ 19 ] ; xx [ 35 ] = xx [ 19 ] * xx [ 41 ]
; xx [ 19 ] = xx [ 17 ] * xx [ 41 ] ; xx [ 36 ] = ( xx [ 38 ] * xx [ 5 ] - xx
[ 19 ] ) * xx [ 26 ] ; xx [ 37 ] = xx [ 41 ] * xx [ 5 ] ; xx [ 39 ] = xx [ 37
] + xx [ 38 ] * xx [ 17 ] ; xx [ 38 ] = xx [ 0 ] * xx [ 5 ] - xx [ 19 ] ; xx
[ 5 ] = xx [ 26 ] * ( xx [ 37 ] + xx [ 0 ] * xx [ 17 ] ) ; xx [ 17 ] = xx [
30 ] * xx [ 31 ] ; xx [ 19 ] = xx [ 8 ] * xx [ 32 ] ; error [ 0 ] = - ( ( xx
[ 3 ] + xx [ 4 ] ) * xx [ 10 ] + ( xx [ 3 ] + xx [ 4 ] ) * xx [ 10 ] + ( xx [
24 ] * xx [ 25 ] + xx [ 33 ] ) * xx [ 10 ] - ( xx [ 13 ] - ( xx [ 20 ] * xx [
25 ] + xx [ 12 ] * xx [ 22 ] ) * xx [ 10 ] ) - ( xx [ 27 ] * xx [ 29 ] + xx [
15 ] * xx [ 11 ] ) * xx [ 10 ] + xx [ 18 ] ) ; error [ 1 ] = xx [ 10 ] * ( xx
[ 23 ] - xx [ 6 ] ) - xx [ 10 ] * ( xx [ 6 ] - xx [ 23 ] ) - ( xx [ 10 ] * (
xx [ 11 ] * xx [ 29 ] - xx [ 15 ] * xx [ 27 ] ) + xx [ 10 ] * ( xx [ 34 ] -
xx [ 14 ] * xx [ 25 ] ) - xx [ 10 ] * ( xx [ 22 ] * xx [ 25 ] - xx [ 12 ] *
xx [ 20 ] ) ) + xx [ 2 ] ; error [ 2 ] = - ( ( xx [ 9 ] + xx [ 7 ] ) * xx [
10 ] + ( xx [ 9 ] + xx [ 7 ] ) * xx [ 10 ] + ( xx [ 16 ] * xx [ 41 ] + xx [
46 ] ) * xx [ 10 ] - ( xx [ 1 ] - ( xx [ 21 ] * xx [ 41 ] + xx [ 0 ] * xx [
35 ] ) * xx [ 10 ] ) - ( xx [ 36 ] * xx [ 39 ] + xx [ 38 ] * xx [ 5 ] ) * xx
[ 10 ] + xx [ 18 ] ) ; error [ 3 ] = xx [ 10 ] * ( xx [ 17 ] - xx [ 19 ] ) -
xx [ 10 ] * ( xx [ 19 ] - xx [ 17 ] ) - ( xx [ 10 ] * ( xx [ 5 ] * xx [ 39 ]
- xx [ 38 ] * xx [ 36 ] ) + xx [ 10 ] * ( xx [ 47 ] - xx [ 28 ] * xx [ 41 ] )
- xx [ 10 ] * ( xx [ 35 ] * xx [ 41 ] - xx [ 0 ] * xx [ 21 ] ) ) + xx [ 2 ] ;
} void series_link_blance_leg_ad6bcbee_1_resetModeVector ( const void * mech
, int * modeVector ) { ( void ) mech ; ( void ) modeVector ; } boolean_T
series_link_blance_leg_ad6bcbee_1_hasJointDisToNormModeChange ( const void *
mech , const int * prevModeVector , const int * modeVector ) { ( void ) mech
; ( void ) prevModeVector ; ( void ) modeVector ; return 0 ; } PmfMessageId
series_link_blance_leg_ad6bcbee_1_performJointDisToNormModeChange ( const
void * mech , const RuntimeDerivedValuesBundle * rtdv , const int *
eqnEnableFlags , const int * prevModeVector , const int * modeVector , const
double * input , double * state , void * neDiagMgr0 ) { const double * rtdvd
= rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts . mValues ;
NeuDiagnosticManager * neDiagMgr = ( NeuDiagnosticManager * ) neDiagMgr0 ; (
void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; ( void ) eqnEnableFlags ; (
void ) prevModeVector ; ( void ) modeVector ; ( void ) input ; ( void ) state
; ( void ) neDiagMgr ; return NULL ; } void
series_link_blance_leg_ad6bcbee_1_onModeChangedCutJoints ( const void * mech
, const int * prevModeVector , const int * modeVector , double * state ) { (
void ) mech ; ( void ) prevModeVector ; ( void ) modeVector ; ( void ) state
; }
