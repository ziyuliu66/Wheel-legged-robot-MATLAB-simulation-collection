#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ne_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "sm_CTarget.h"
void series_link_blance_leg_ad6bcbee_1_setTargets ( const
RuntimeDerivedValuesBundle * rtdv , CTarget * targets ) { ( void ) rtdv ; (
void ) targets ; } void series_link_blance_leg_ad6bcbee_1_resetAsmStateVector
( const void * mech , double * state ) { double xx [ 1 ] ; ( void ) mech ; xx
[ 0 ] = 0.0 ; state [ 0 ] = xx [ 0 ] ; state [ 1 ] = xx [ 0 ] ; state [ 2 ] =
xx [ 0 ] ; state [ 3 ] = xx [ 0 ] ; state [ 4 ] = xx [ 0 ] ; state [ 5 ] = xx
[ 0 ] ; state [ 6 ] = xx [ 0 ] ; state [ 7 ] = xx [ 0 ] ; state [ 8 ] = xx [
0 ] ; state [ 9 ] = xx [ 0 ] ; state [ 10 ] = xx [ 0 ] ; state [ 11 ] = xx [
0 ] ; state [ 12 ] = xx [ 0 ] ; state [ 13 ] = xx [ 0 ] ; state [ 14 ] = xx [
0 ] ; state [ 15 ] = xx [ 0 ] ; state [ 16 ] = xx [ 0 ] ; state [ 17 ] = xx [
0 ] ; state [ 18 ] = xx [ 0 ] ; state [ 19 ] = xx [ 0 ] ; state [ 20 ] = xx [
0 ] ; state [ 21 ] = xx [ 0 ] ; state [ 22 ] = xx [ 0 ] ; state [ 23 ] = xx [
0 ] ; state [ 24 ] = xx [ 0 ] ; state [ 25 ] = xx [ 0 ] ; state [ 26 ] = xx [
0 ] ; state [ 27 ] = xx [ 0 ] ; state [ 28 ] = xx [ 0 ] ; state [ 29 ] = xx [
0 ] ; } void series_link_blance_leg_ad6bcbee_1_initializeTrackedAngleState (
const void * mech , const RuntimeDerivedValuesBundle * rtdv , const int *
modeVector , const double * motionData , double * state ) { const double *
rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts .
mValues ; double xx [ 21 ] ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi
; ( void ) modeVector ; xx [ 0 ] = 2.0 ; xx [ 1 ] = motionData [ 77 ] ; xx [
2 ] = motionData [ 78 ] ; xx [ 3 ] = motionData [ 79 ] ; xx [ 4 ] =
motionData [ 80 ] ; xx [ 5 ] = motionData [ 63 ] ; xx [ 6 ] = motionData [ 64
] ; xx [ 7 ] = motionData [ 65 ] ; xx [ 8 ] = motionData [ 66 ] ;
pm_math_Quaternion_inverseCompose_ra ( xx + 1 , xx + 5 , xx + 9 ) ; xx [ 1 ]
= motionData [ 189 ] ; xx [ 2 ] = motionData [ 190 ] ; xx [ 3 ] = motionData
[ 191 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 9 , xx + 1 , xx + 4 ) ;
xx [ 1 ] = motionData [ 84 ] ; xx [ 2 ] = motionData [ 85 ] ; xx [ 3 ] =
motionData [ 86 ] ; xx [ 4 ] = motionData [ 87 ] ; xx [ 13 ] = motionData [
70 ] ; xx [ 14 ] = motionData [ 71 ] ; xx [ 15 ] = motionData [ 72 ] ; xx [
16 ] = motionData [ 73 ] ; pm_math_Quaternion_inverseCompose_ra ( xx + 1 , xx
+ 13 , xx + 17 ) ; xx [ 1 ] = motionData [ 171 ] ; xx [ 2 ] = motionData [
172 ] ; xx [ 3 ] = motionData [ 173 ] ; pm_math_Quaternion_inverseXform_ra (
xx + 17 , xx + 1 , xx + 13 ) ; state [ 26 ] = sm_core_canonicalAngle ( xx [ 0
] * atan2 ( sqrt ( xx [ 10 ] * xx [ 10 ] + xx [ 11 ] * xx [ 11 ] + xx [ 12 ]
* xx [ 12 ] ) , fabs ( - xx [ 9 ] ) ) * ( ( xx [ 9 ] * xx [ 12 ] ) < 0.0 ? -
1.0 : + 1.0 ) ) ; state [ 27 ] = motionData [ 203 ] - xx [ 6 ] ; state [ 28 ]
= sm_core_canonicalAngle ( xx [ 0 ] * atan2 ( sqrt ( xx [ 18 ] * xx [ 18 ] +
xx [ 19 ] * xx [ 19 ] + xx [ 20 ] * xx [ 20 ] ) , fabs ( - xx [ 17 ] ) ) * (
( xx [ 17 ] * xx [ 20 ] ) < 0.0 ? - 1.0 : + 1.0 ) ) ; state [ 29 ] =
motionData [ 209 ] - xx [ 15 ] ; } void
series_link_blance_leg_ad6bcbee_1_computeDiscreteState ( const void * mech ,
const RuntimeDerivedValuesBundle * rtdv , double * state ) { const double *
rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts .
mValues ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi ; ( void ) state ;
} void series_link_blance_leg_ad6bcbee_1_adjustPosition ( const void * mech ,
const double * dofDeltas , double * state ) { ( void ) mech ; state [ 0 ] =
state [ 0 ] + dofDeltas [ 0 ] ; state [ 1 ] = state [ 1 ] + dofDeltas [ 1 ] ;
state [ 2 ] = state [ 2 ] + dofDeltas [ 2 ] ; state [ 6 ] = state [ 6 ] +
dofDeltas [ 3 ] ; state [ 8 ] = state [ 8 ] + dofDeltas [ 4 ] ; state [ 10 ]
= state [ 10 ] + dofDeltas [ 5 ] ; state [ 12 ] = state [ 12 ] + dofDeltas [
6 ] ; state [ 14 ] = state [ 14 ] + dofDeltas [ 7 ] ; state [ 16 ] = state [
16 ] + dofDeltas [ 8 ] ; state [ 18 ] = state [ 18 ] + dofDeltas [ 9 ] ;
state [ 20 ] = state [ 20 ] + dofDeltas [ 10 ] ; state [ 22 ] = state [ 22 ]
+ dofDeltas [ 11 ] ; state [ 24 ] = state [ 24 ] + dofDeltas [ 12 ] ; }
static void perturbAsmJointPrimitiveState_0_0 ( double mag , double * state )
{ state [ 0 ] = state [ 0 ] + mag ; } static void
perturbAsmJointPrimitiveState_0_0v ( double mag , double * state ) { state [
0 ] = state [ 0 ] + mag ; state [ 3 ] = state [ 3 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_0_1 ( double mag , double * state ) {
state [ 1 ] = state [ 1 ] + mag ; } static void
perturbAsmJointPrimitiveState_0_1v ( double mag , double * state ) { state [
1 ] = state [ 1 ] + mag ; state [ 4 ] = state [ 4 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_0_2 ( double mag , double * state ) {
state [ 2 ] = state [ 2 ] + mag ; } static void
perturbAsmJointPrimitiveState_0_2v ( double mag , double * state ) { state [
2 ] = state [ 2 ] + mag ; state [ 5 ] = state [ 5 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_1_0 ( double mag , double * state ) {
state [ 6 ] = state [ 6 ] + mag ; } static void
perturbAsmJointPrimitiveState_1_0v ( double mag , double * state ) { state [
6 ] = state [ 6 ] + mag ; state [ 7 ] = state [ 7 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_2_0 ( double mag , double * state ) {
state [ 8 ] = state [ 8 ] + mag ; } static void
perturbAsmJointPrimitiveState_2_0v ( double mag , double * state ) { state [
8 ] = state [ 8 ] + mag ; state [ 9 ] = state [ 9 ] - 0.875 * mag ; } static
void perturbAsmJointPrimitiveState_3_0 ( double mag , double * state ) {
state [ 10 ] = state [ 10 ] + mag ; } static void
perturbAsmJointPrimitiveState_3_0v ( double mag , double * state ) { state [
10 ] = state [ 10 ] + mag ; state [ 11 ] = state [ 11 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_4_0 ( double mag , double * state )
{ state [ 12 ] = state [ 12 ] + mag ; } static void
perturbAsmJointPrimitiveState_4_0v ( double mag , double * state ) { state [
12 ] = state [ 12 ] + mag ; state [ 13 ] = state [ 13 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_5_0 ( double mag , double * state )
{ state [ 14 ] = state [ 14 ] + mag ; } static void
perturbAsmJointPrimitiveState_5_0v ( double mag , double * state ) { state [
14 ] = state [ 14 ] + mag ; state [ 15 ] = state [ 15 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_6_0 ( double mag , double * state )
{ state [ 16 ] = state [ 16 ] + mag ; } static void
perturbAsmJointPrimitiveState_6_0v ( double mag , double * state ) { state [
16 ] = state [ 16 ] + mag ; state [ 17 ] = state [ 17 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_7_0 ( double mag , double * state )
{ state [ 18 ] = state [ 18 ] + mag ; } static void
perturbAsmJointPrimitiveState_7_0v ( double mag , double * state ) { state [
18 ] = state [ 18 ] + mag ; state [ 19 ] = state [ 19 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_8_0 ( double mag , double * state )
{ state [ 20 ] = state [ 20 ] + mag ; } static void
perturbAsmJointPrimitiveState_8_0v ( double mag , double * state ) { state [
20 ] = state [ 20 ] + mag ; state [ 21 ] = state [ 21 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_9_0 ( double mag , double * state )
{ state [ 22 ] = state [ 22 ] + mag ; } static void
perturbAsmJointPrimitiveState_9_0v ( double mag , double * state ) { state [
22 ] = state [ 22 ] + mag ; state [ 23 ] = state [ 23 ] - 0.875 * mag ; }
static void perturbAsmJointPrimitiveState_10_0 ( double mag , double * state
) { state [ 24 ] = state [ 24 ] + mag ; } static void
perturbAsmJointPrimitiveState_10_0v ( double mag , double * state ) { state [
24 ] = state [ 24 ] + mag ; state [ 25 ] = state [ 25 ] - 0.875 * mag ; }
void series_link_blance_leg_ad6bcbee_1_perturbAsmJointPrimitiveState ( const
void * mech , size_t stageIdx , size_t primIdx , double mag , boolean_T
doPerturbVelocity , double * state ) { ( void ) mech ; ( void ) stageIdx ; (
void ) primIdx ; ( void ) mag ; ( void ) doPerturbVelocity ; ( void ) state ;
switch ( ( stageIdx * 6 + primIdx ) * 2 + ( doPerturbVelocity ? 1 : 0 ) ) {
case 0 : perturbAsmJointPrimitiveState_0_0 ( mag , state ) ; break ; case 1 :
perturbAsmJointPrimitiveState_0_0v ( mag , state ) ; break ; case 2 :
perturbAsmJointPrimitiveState_0_1 ( mag , state ) ; break ; case 3 :
perturbAsmJointPrimitiveState_0_1v ( mag , state ) ; break ; case 4 :
perturbAsmJointPrimitiveState_0_2 ( mag , state ) ; break ; case 5 :
perturbAsmJointPrimitiveState_0_2v ( mag , state ) ; break ; case 12 :
perturbAsmJointPrimitiveState_1_0 ( mag , state ) ; break ; case 13 :
perturbAsmJointPrimitiveState_1_0v ( mag , state ) ; break ; case 24 :
perturbAsmJointPrimitiveState_2_0 ( mag , state ) ; break ; case 25 :
perturbAsmJointPrimitiveState_2_0v ( mag , state ) ; break ; case 36 :
perturbAsmJointPrimitiveState_3_0 ( mag , state ) ; break ; case 37 :
perturbAsmJointPrimitiveState_3_0v ( mag , state ) ; break ; case 48 :
perturbAsmJointPrimitiveState_4_0 ( mag , state ) ; break ; case 49 :
perturbAsmJointPrimitiveState_4_0v ( mag , state ) ; break ; case 60 :
perturbAsmJointPrimitiveState_5_0 ( mag , state ) ; break ; case 61 :
perturbAsmJointPrimitiveState_5_0v ( mag , state ) ; break ; case 72 :
perturbAsmJointPrimitiveState_6_0 ( mag , state ) ; break ; case 73 :
perturbAsmJointPrimitiveState_6_0v ( mag , state ) ; break ; case 84 :
perturbAsmJointPrimitiveState_7_0 ( mag , state ) ; break ; case 85 :
perturbAsmJointPrimitiveState_7_0v ( mag , state ) ; break ; case 96 :
perturbAsmJointPrimitiveState_8_0 ( mag , state ) ; break ; case 97 :
perturbAsmJointPrimitiveState_8_0v ( mag , state ) ; break ; case 108 :
perturbAsmJointPrimitiveState_9_0 ( mag , state ) ; break ; case 109 :
perturbAsmJointPrimitiveState_9_0v ( mag , state ) ; break ; case 120 :
perturbAsmJointPrimitiveState_10_0 ( mag , state ) ; break ; case 121 :
perturbAsmJointPrimitiveState_10_0v ( mag , state ) ; break ; } } void
series_link_blance_leg_ad6bcbee_1_computePosDofBlendMatrix ( const void *
mech , size_t stageIdx , size_t primIdx , const double * state , int
partialType , double * matrix ) { ( void ) mech ; ( void ) stageIdx ; ( void
) primIdx ; ( void ) state ; ( void ) partialType ; ( void ) matrix ; switch
( ( stageIdx * 6 + primIdx ) ) { } } void
series_link_blance_leg_ad6bcbee_1_computeVelDofBlendMatrix ( const void *
mech , size_t stageIdx , size_t primIdx , const double * state , int
partialType , double * matrix ) { ( void ) mech ; ( void ) stageIdx ; ( void
) primIdx ; ( void ) state ; ( void ) partialType ; ( void ) matrix ; switch
( ( stageIdx * 6 + primIdx ) ) { } } void
series_link_blance_leg_ad6bcbee_1_projectPartiallyTargetedPos ( const void *
mech , size_t stageIdx , size_t primIdx , const double * origState , int
partialType , double * state ) { ( void ) mech ; ( void ) stageIdx ; ( void )
primIdx ; ( void ) origState ; ( void ) partialType ; ( void ) state ; switch
( ( stageIdx * 6 + primIdx ) ) { } } void
series_link_blance_leg_ad6bcbee_1_propagateMotion ( const void * mech , const
RuntimeDerivedValuesBundle * rtdv , const double * state , double *
motionData ) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int
* rtdvi = rtdv -> mInts . mValues ; double xx [ 195 ] ; ( void ) mech ; (
void ) rtdvd ; ( void ) rtdvi ; xx [ 0 ] = 0.7071067811865476 ; xx [ 1 ] = -
xx [ 0 ] ; xx [ 2 ] = 0.0 ; xx [ 3 ] = 0.8 - state [ 0 ] ; xx [ 4 ] = 0.5 ;
xx [ 5 ] = xx [ 4 ] * state [ 6 ] ; xx [ 6 ] = xx [ 0 ] * cos ( xx [ 5 ] ) ;
xx [ 7 ] = xx [ 0 ] * sin ( xx [ 5 ] ) ; xx [ 5 ] = 0.4090518191766045 ; xx [
8 ] = xx [ 4 ] * state [ 8 ] ; xx [ 9 ] = cos ( xx [ 8 ] ) ; xx [ 10 ] = xx [
5 ] * xx [ 9 ] ; xx [ 11 ] = 0.5767812490262756 ; xx [ 12 ] =
0.9437336767246086 ; xx [ 13 ] = sin ( xx [ 8 ] ) ; xx [ 8 ] = xx [ 12 ] * xx
[ 13 ] ; xx [ 14 ] = xx [ 11 ] * xx [ 8 ] ; xx [ 15 ] = 0.3307064369132422 ;
xx [ 16 ] = xx [ 15 ] * xx [ 13 ] ; xx [ 13 ] = xx [ 5 ] * xx [ 16 ] ; xx [
17 ] = xx [ 10 ] - ( xx [ 14 ] - xx [ 13 ] ) ; xx [ 18 ] = xx [ 11 ] * xx [
16 ] ; xx [ 16 ] = xx [ 11 ] * xx [ 9 ] ; xx [ 9 ] = xx [ 5 ] * xx [ 8 ] ; xx
[ 5 ] = xx [ 18 ] - xx [ 16 ] + xx [ 9 ] ; xx [ 8 ] = xx [ 9 ] + xx [ 16 ] +
xx [ 18 ] ; xx [ 9 ] = - xx [ 8 ] ; xx [ 11 ] = xx [ 10 ] - xx [ 13 ] + xx [
14 ] ; xx [ 10 ] = 9.889425053924039e-3 ; xx [ 13 ] = 0.0284344275538308 ; xx
[ 14 ] = xx [ 11 ] * xx [ 10 ] - xx [ 13 ] * xx [ 8 ] ; xx [ 18 ] = xx [ 5 ]
; xx [ 19 ] = xx [ 9 ] ; xx [ 20 ] = xx [ 11 ] ; xx [ 16 ] = xx [ 13 ] * xx [
5 ] ; xx [ 21 ] = xx [ 10 ] * xx [ 5 ] ; xx [ 22 ] = xx [ 14 ] ; xx [ 23 ] =
- xx [ 16 ] ; xx [ 24 ] = - xx [ 21 ] ; pm_math_Vector3_cross_ra ( xx + 18 ,
xx + 22 , xx + 25 ) ; xx [ 18 ] = 2.0 ; xx [ 19 ] = ( xx [ 14 ] * xx [ 17 ] +
xx [ 25 ] ) * xx [ 18 ] ; xx [ 14 ] = - xx [ 19 ] ; xx [ 20 ] = - ( xx [ 18 ]
* ( xx [ 26 ] - xx [ 16 ] * xx [ 17 ] ) - xx [ 10 ] ) ; xx [ 10 ] = xx [ 13 ]
+ ( xx [ 27 ] - xx [ 21 ] * xx [ 17 ] ) * xx [ 18 ] ; xx [ 13 ] = - xx [ 10 ]
; xx [ 16 ] = 0.6970892476441968 ; xx [ 21 ] = xx [ 4 ] * state [ 10 ] ; xx [
22 ] = cos ( xx [ 21 ] ) ; xx [ 23 ] = 0.1186026172512557 ; xx [ 24 ] = sin (
xx [ 21 ] ) ; xx [ 21 ] = xx [ 16 ] * xx [ 22 ] - xx [ 23 ] * xx [ 24 ] ; xx
[ 25 ] = xx [ 23 ] * xx [ 22 ] ; xx [ 22 ] = xx [ 16 ] * xx [ 24 ] ; xx [ 24
] = xx [ 25 ] + xx [ 22 ] ; xx [ 26 ] = xx [ 22 ] + xx [ 25 ] ; xx [ 22 ] =
0.175 ; xx [ 25 ] = 0.08603840402471528 ; xx [ 27 ] = xx [ 25 ] * xx [ 21 ] ;
xx [ 28 ] = xx [ 27 ] * xx [ 21 ] ; xx [ 29 ] = xx [ 26 ] * xx [ 25 ] ; xx [
30 ] = ( xx [ 28 ] + xx [ 26 ] * xx [ 29 ] ) * xx [ 18 ] - xx [ 25 ] ; xx [
31 ] = - ( xx [ 22 ] + xx [ 30 ] ) ; xx [ 32 ] = 0.02318121863740014 ; xx [
33 ] = ( xx [ 29 ] * xx [ 21 ] + xx [ 24 ] * xx [ 27 ] ) * xx [ 18 ] ; xx [
27 ] = xx [ 32 ] + xx [ 33 ] ; xx [ 34 ] = 0.06593894011863007 ; xx [ 35 ] =
xx [ 18 ] * ( xx [ 28 ] - xx [ 24 ] * xx [ 29 ] ) ; xx [ 28 ] = - ( xx [ 34 ]
+ xx [ 35 ] ) ; xx [ 29 ] = xx [ 4 ] * state [ 12 ] ; xx [ 36 ] = xx [ 0 ] *
sin ( xx [ 29 ] ) ; xx [ 37 ] = xx [ 0 ] * cos ( xx [ 29 ] ) ; xx [ 29 ] = xx
[ 36 ] - xx [ 37 ] ; xx [ 38 ] = xx [ 36 ] + xx [ 37 ] ; xx [ 36 ] =
0.07871159597528472 ; xx [ 37 ] = 0.02913743527133955 ; xx [ 39 ] = xx [ 38 ]
* xx [ 37 ] ; xx [ 40 ] = xx [ 36 ] - ( xx [ 18 ] * xx [ 38 ] * xx [ 39 ] -
xx [ 37 ] ) ; xx [ 41 ] = xx [ 18 ] * xx [ 39 ] * xx [ 29 ] ; xx [ 39 ] = xx
[ 4 ] * state [ 14 ] ; xx [ 42 ] = cos ( xx [ 39 ] ) ; xx [ 43 ] = sin ( xx [
39 ] ) ; xx [ 39 ] = 0.1339025647286604 ; xx [ 44 ] = 0.03007944796046594 ;
xx [ 45 ] = xx [ 4 ] * state [ 16 ] ; xx [ 46 ] = cos ( xx [ 45 ] ) ; xx [ 47
] = sin ( xx [ 45 ] ) ; xx [ 45 ] = xx [ 16 ] * xx [ 46 ] - xx [ 23 ] * xx [
47 ] ; xx [ 48 ] = xx [ 23 ] * xx [ 46 ] ; xx [ 46 ] = xx [ 16 ] * xx [ 47 ]
; xx [ 47 ] = xx [ 48 ] + xx [ 46 ] ; xx [ 49 ] = xx [ 46 ] + xx [ 48 ] ; xx
[ 46 ] = xx [ 25 ] * xx [ 45 ] ; xx [ 48 ] = xx [ 46 ] * xx [ 45 ] ; xx [ 50
] = xx [ 49 ] * xx [ 25 ] ; xx [ 51 ] = ( xx [ 48 ] + xx [ 49 ] * xx [ 50 ] )
* xx [ 18 ] - xx [ 25 ] ; xx [ 52 ] = xx [ 22 ] - xx [ 51 ] ; xx [ 53 ] = (
xx [ 50 ] * xx [ 45 ] + xx [ 47 ] * xx [ 46 ] ) * xx [ 18 ] ; xx [ 46 ] = xx
[ 32 ] + xx [ 53 ] ; xx [ 54 ] = xx [ 18 ] * ( xx [ 48 ] - xx [ 47 ] * xx [
50 ] ) ; xx [ 48 ] = - ( xx [ 34 ] + xx [ 54 ] ) ; xx [ 50 ] = xx [ 4 ] *
state [ 18 ] ; xx [ 55 ] = xx [ 0 ] * sin ( xx [ 50 ] ) ; xx [ 56 ] = xx [ 0
] * cos ( xx [ 50 ] ) ; xx [ 50 ] = xx [ 55 ] - xx [ 56 ] ; xx [ 57 ] = xx [
55 ] + xx [ 56 ] ; xx [ 55 ] = xx [ 57 ] * xx [ 37 ] ; xx [ 56 ] = xx [ 36 ]
- ( xx [ 18 ] * xx [ 57 ] * xx [ 55 ] - xx [ 37 ] ) ; xx [ 36 ] = xx [ 18 ] *
xx [ 55 ] * xx [ 50 ] ; xx [ 55 ] = xx [ 4 ] * state [ 20 ] ; xx [ 58 ] = cos
( xx [ 55 ] ) ; xx [ 59 ] = sin ( xx [ 55 ] ) ; xx [ 55 ] = xx [ 4 ] * state
[ 22 ] ; xx [ 60 ] = sin ( xx [ 55 ] ) ; xx [ 61 ] = cos ( xx [ 55 ] ) ; xx [
55 ] = xx [ 23 ] * xx [ 60 ] - xx [ 16 ] * xx [ 61 ] ; xx [ 62 ] = xx [ 23 ]
* xx [ 61 ] ; xx [ 61 ] = xx [ 16 ] * xx [ 60 ] ; xx [ 60 ] = xx [ 62 ] + xx
[ 61 ] ; xx [ 63 ] = - xx [ 60 ] ; xx [ 64 ] = xx [ 61 ] + xx [ 62 ] ; xx [
61 ] = - xx [ 64 ] ; xx [ 62 ] = 0.085075 ; xx [ 65 ] = xx [ 62 ] * xx [ 55 ]
; xx [ 66 ] = xx [ 65 ] * xx [ 55 ] ; xx [ 67 ] = xx [ 64 ] * xx [ 62 ] ; xx
[ 68 ] = xx [ 22 ] - ( ( xx [ 66 ] + xx [ 64 ] * xx [ 67 ] ) * xx [ 18 ] - xx
[ 62 ] ) ; xx [ 64 ] = 0.04846143235075162 ; xx [ 69 ] = - ( xx [ 64 ] + ( xx
[ 67 ] * xx [ 55 ] + xx [ 60 ] * xx [ 65 ] ) * xx [ 18 ] ) ; xx [ 65 ] =
0.03147761383263407 ; xx [ 70 ] = - ( xx [ 65 ] + xx [ 18 ] * ( xx [ 66 ] -
xx [ 60 ] * xx [ 67 ] ) ) ; xx [ 60 ] = xx [ 4 ] * state [ 24 ] ; xx [ 4 ] =
sin ( xx [ 60 ] ) ; xx [ 66 ] = cos ( xx [ 60 ] ) ; xx [ 60 ] = xx [ 23 ] *
xx [ 4 ] - xx [ 16 ] * xx [ 66 ] ; xx [ 67 ] = xx [ 23 ] * xx [ 66 ] ; xx [
23 ] = xx [ 16 ] * xx [ 4 ] ; xx [ 4 ] = xx [ 67 ] + xx [ 23 ] ; xx [ 16 ] =
- xx [ 4 ] ; xx [ 66 ] = xx [ 23 ] + xx [ 67 ] ; xx [ 23 ] = - xx [ 66 ] ; xx
[ 67 ] = xx [ 62 ] * xx [ 60 ] ; xx [ 71 ] = xx [ 67 ] * xx [ 60 ] ; xx [ 72
] = xx [ 66 ] * xx [ 62 ] ; xx [ 73 ] = - ( xx [ 22 ] + ( xx [ 71 ] + xx [ 66
] * xx [ 72 ] ) * xx [ 18 ] - xx [ 62 ] ) ; xx [ 66 ] = - ( xx [ 64 ] + ( xx
[ 72 ] * xx [ 60 ] + xx [ 4 ] * xx [ 67 ] ) * xx [ 18 ] ) ; xx [ 64 ] = - (
xx [ 65 ] + xx [ 18 ] * ( xx [ 71 ] - xx [ 4 ] * xx [ 72 ] ) ) ; xx [ 4 ] =
xx [ 45 ] * xx [ 50 ] ; xx [ 65 ] = xx [ 57 ] * xx [ 45 ] ; xx [ 67 ] = xx [
49 ] * xx [ 36 ] ; xx [ 74 ] = xx [ 47 ] ; xx [ 75 ] = xx [ 45 ] ; xx [ 76 ]
= xx [ 49 ] ; xx [ 71 ] = xx [ 49 ] * xx [ 56 ] ; xx [ 72 ] = xx [ 47 ] * xx
[ 36 ] + xx [ 56 ] * xx [ 45 ] ; xx [ 77 ] = xx [ 67 ] ; xx [ 78 ] = xx [ 71
] ; xx [ 79 ] = - xx [ 72 ] ; pm_math_Vector3_cross_ra ( xx + 74 , xx + 77 ,
xx + 80 ) ; xx [ 74 ] = xx [ 21 ] * xx [ 29 ] ; xx [ 75 ] = xx [ 38 ] * xx [
21 ] ; xx [ 76 ] = xx [ 26 ] * xx [ 41 ] ; xx [ 77 ] = xx [ 24 ] ; xx [ 78 ]
= xx [ 21 ] ; xx [ 79 ] = xx [ 26 ] ; xx [ 83 ] = xx [ 26 ] * xx [ 40 ] ; xx
[ 84 ] = xx [ 24 ] * xx [ 41 ] + xx [ 40 ] * xx [ 21 ] ; xx [ 85 ] = xx [ 76
] ; xx [ 86 ] = xx [ 83 ] ; xx [ 87 ] = - xx [ 84 ] ;
pm_math_Vector3_cross_ra ( xx + 77 , xx + 85 , xx + 88 ) ; xx [ 77 ] = xx [ 0
] * xx [ 7 ] ; xx [ 78 ] = xx [ 0 ] * xx [ 6 ] ; xx [ 0 ] = xx [ 77 ] - xx [
78 ] ; xx [ 79 ] = - ( xx [ 78 ] + xx [ 77 ] ) ; xx [ 85 ] = - ( xx [ 77 ] +
xx [ 78 ] ) ; xx [ 86 ] = xx [ 78 ] - xx [ 77 ] ; xx [ 91 ] = xx [ 0 ] ; xx [
92 ] = xx [ 79 ] ; xx [ 93 ] = xx [ 85 ] ; xx [ 94 ] = xx [ 86 ] ; xx [ 95 ]
= xx [ 17 ] ; xx [ 96 ] = xx [ 5 ] ; xx [ 97 ] = xx [ 9 ] ; xx [ 98 ] = xx [
11 ] ; pm_math_Quaternion_compose_ra ( xx + 91 , xx + 95 , xx + 99 ) ; xx [
103 ] = xx [ 14 ] ; xx [ 104 ] = xx [ 20 ] ; xx [ 105 ] = xx [ 13 ] ;
pm_math_Quaternion_xform_ra ( xx + 91 , xx + 103 , xx + 106 ) ; xx [ 77 ] =
xx [ 106 ] + state [ 2 ] ; xx [ 78 ] = xx [ 107 ] + state [ 1 ] ; xx [ 87 ] =
xx [ 108 ] + xx [ 3 ] ; xx [ 91 ] = xx [ 21 ] ; xx [ 92 ] = xx [ 24 ] ; xx [
93 ] = xx [ 21 ] ; xx [ 94 ] = xx [ 26 ] ; pm_math_Quaternion_compose_ra ( xx
+ 99 , xx + 91 , xx + 103 ) ; xx [ 107 ] = xx [ 31 ] ; xx [ 108 ] = xx [ 27 ]
; xx [ 109 ] = xx [ 28 ] ; pm_math_Quaternion_xform_ra ( xx + 99 , xx + 107 ,
xx + 110 ) ; xx [ 113 ] = xx [ 110 ] + xx [ 77 ] ; xx [ 114 ] = xx [ 111 ] +
xx [ 78 ] ; xx [ 110 ] = xx [ 112 ] + xx [ 87 ] ; xx [ 111 ] = xx [ 103 ] *
xx [ 29 ] + xx [ 38 ] * xx [ 106 ] ; xx [ 112 ] = xx [ 104 ] * xx [ 29 ] - xx
[ 38 ] * xx [ 105 ] ; xx [ 115 ] = xx [ 105 ] * xx [ 29 ] + xx [ 38 ] * xx [
104 ] ; xx [ 116 ] = xx [ 106 ] * xx [ 29 ] - xx [ 38 ] * xx [ 103 ] ; xx [
117 ] = xx [ 106 ] * xx [ 41 ] ; xx [ 118 ] = xx [ 106 ] * xx [ 40 ] ; xx [
119 ] = xx [ 104 ] * xx [ 41 ] + xx [ 105 ] * xx [ 40 ] ; xx [ 120 ] = xx [
117 ] ; xx [ 121 ] = xx [ 118 ] ; xx [ 122 ] = - xx [ 119 ] ;
pm_math_Vector3_cross_ra ( xx + 104 , xx + 120 , xx + 123 ) ; xx [ 120 ] = xx
[ 40 ] + ( xx [ 103 ] * xx [ 117 ] + xx [ 123 ] ) * xx [ 18 ] ; xx [ 117 ] =
( xx [ 103 ] * xx [ 118 ] + xx [ 124 ] ) * xx [ 18 ] - xx [ 41 ] + xx [ 114 ]
; xx [ 118 ] = xx [ 18 ] * ( xx [ 125 ] - xx [ 119 ] * xx [ 103 ] ) ; xx [
121 ] = xx [ 112 ] ; xx [ 122 ] = xx [ 115 ] ; xx [ 123 ] = xx [ 116 ] ; xx [
119 ] = xx [ 44 ] * xx [ 115 ] ; xx [ 124 ] = xx [ 116 ] * xx [ 39 ] + xx [
112 ] * xx [ 44 ] ; xx [ 125 ] = xx [ 39 ] * xx [ 115 ] ; xx [ 126 ] = - xx [
119 ] ; xx [ 127 ] = xx [ 124 ] ; xx [ 128 ] = - xx [ 125 ] ;
pm_math_Vector3_cross_ra ( xx + 121 , xx + 126 , xx + 129 ) ; xx [ 132 ] = xx
[ 45 ] ; xx [ 133 ] = xx [ 47 ] ; xx [ 134 ] = xx [ 45 ] ; xx [ 135 ] = xx [
49 ] ; pm_math_Quaternion_compose_ra ( xx + 99 , xx + 132 , xx + 136 ) ; xx [
121 ] = xx [ 52 ] ; xx [ 122 ] = xx [ 46 ] ; xx [ 123 ] = xx [ 48 ] ;
pm_math_Quaternion_xform_ra ( xx + 99 , xx + 121 , xx + 126 ) ; xx [ 140 ] =
xx [ 126 ] + xx [ 77 ] ; xx [ 141 ] = xx [ 127 ] + xx [ 78 ] ; xx [ 126 ] =
xx [ 128 ] + xx [ 87 ] ; xx [ 127 ] = xx [ 136 ] * xx [ 50 ] + xx [ 57 ] * xx
[ 139 ] ; xx [ 128 ] = xx [ 137 ] * xx [ 50 ] - xx [ 57 ] * xx [ 138 ] ; xx [
142 ] = xx [ 138 ] * xx [ 50 ] + xx [ 57 ] * xx [ 137 ] ; xx [ 143 ] = xx [
139 ] * xx [ 50 ] - xx [ 57 ] * xx [ 136 ] ; xx [ 144 ] = xx [ 139 ] * xx [
36 ] ; xx [ 145 ] = xx [ 139 ] * xx [ 56 ] ; xx [ 146 ] = xx [ 137 ] * xx [
36 ] + xx [ 138 ] * xx [ 56 ] ; xx [ 147 ] = xx [ 144 ] ; xx [ 148 ] = xx [
145 ] ; xx [ 149 ] = - xx [ 146 ] ; pm_math_Vector3_cross_ra ( xx + 137 , xx
+ 147 , xx + 150 ) ; xx [ 147 ] = xx [ 56 ] + ( xx [ 136 ] * xx [ 144 ] + xx
[ 150 ] ) * xx [ 18 ] ; xx [ 144 ] = ( xx [ 136 ] * xx [ 145 ] + xx [ 151 ] )
* xx [ 18 ] - xx [ 36 ] + xx [ 141 ] ; xx [ 145 ] = xx [ 18 ] * ( xx [ 152 ]
- xx [ 146 ] * xx [ 136 ] ) ; xx [ 146 ] = xx [ 44 ] * xx [ 142 ] ; xx [ 148
] = xx [ 128 ] ; xx [ 149 ] = xx [ 142 ] ; xx [ 150 ] = xx [ 143 ] ; xx [ 151
] = xx [ 143 ] * xx [ 39 ] - xx [ 128 ] * xx [ 44 ] ; xx [ 152 ] = xx [ 39 ]
* xx [ 142 ] ; xx [ 153 ] = xx [ 146 ] ; xx [ 154 ] = xx [ 151 ] ; xx [ 155 ]
= - xx [ 152 ] ; pm_math_Vector3_cross_ra ( xx + 148 , xx + 153 , xx + 156 )
; xx [ 159 ] = xx [ 6 ] ; xx [ 160 ] = xx [ 6 ] ; xx [ 161 ] = xx [ 7 ] ; xx
[ 162 ] = xx [ 7 ] ; xx [ 148 ] = state [ 3 ] ; xx [ 149 ] = state [ 4 ] ; xx
[ 150 ] = state [ 5 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 159 , xx +
148 , xx + 153 ) ; xx [ 148 ] = xx [ 11 ] * state [ 7 ] ; xx [ 149 ] = xx [ 5
] * state [ 7 ] ; xx [ 150 ] = ( xx [ 148 ] * xx [ 17 ] - xx [ 149 ] * xx [ 8
] ) * xx [ 18 ] ; xx [ 159 ] = state [ 7 ] - ( xx [ 11 ] * xx [ 148 ] + xx [
149 ] * xx [ 5 ] ) * xx [ 18 ] - xx [ 12 ] * state [ 9 ] ; xx [ 12 ] = - ( xx
[ 18 ] * ( xx [ 148 ] * xx [ 8 ] + xx [ 149 ] * xx [ 17 ] ) + xx [ 15 ] *
state [ 9 ] ) ; xx [ 160 ] = xx [ 153 ] - xx [ 10 ] * state [ 7 ] ; xx [ 161
] = xx [ 154 ] ; xx [ 162 ] = xx [ 19 ] * state [ 7 ] + xx [ 155 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 95 , xx + 160 , xx + 163 ) ; xx [ 8
] = xx [ 163 ] + 0.03010502338364002 * state [ 9 ] ; xx [ 95 ] = xx [ 150 ] ;
xx [ 96 ] = xx [ 159 ] ; xx [ 97 ] = xx [ 12 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 91 , xx + 95 , xx + 160 ) ; xx [ 10
] = xx [ 162 ] + state [ 11 ] ; pm_math_Vector3_cross_ra ( xx + 95 , xx + 107
, xx + 166 ) ; xx [ 107 ] = xx [ 166 ] + xx [ 8 ] ; xx [ 108 ] = xx [ 167 ] +
xx [ 164 ] ; xx [ 109 ] = xx [ 168 ] + xx [ 165 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 91 , xx + 107 , xx + 166 ) ; xx [
15 ] = xx [ 167 ] + xx [ 25 ] * state [ 11 ] ; xx [ 19 ] = xx [ 38 ] * xx [
161 ] ; xx [ 91 ] = xx [ 38 ] * xx [ 160 ] ; xx [ 92 ] = xx [ 160 ] - xx [ 18
] * ( xx [ 19 ] * xx [ 29 ] + xx [ 38 ] * xx [ 91 ] ) ; xx [ 93 ] = xx [ 161
] - ( xx [ 38 ] * xx [ 19 ] - xx [ 91 ] * xx [ 29 ] ) * xx [ 18 ] ; xx [ 19 ]
= xx [ 10 ] + state [ 13 ] ; xx [ 91 ] = xx [ 10 ] * xx [ 41 ] + xx [ 166 ] ;
xx [ 94 ] = xx [ 10 ] * xx [ 40 ] + xx [ 15 ] ; xx [ 98 ] = xx [ 94 ] * xx [
38 ] ; xx [ 107 ] = xx [ 91 ] * xx [ 38 ] ; xx [ 108 ] = xx [ 91 ] - xx [ 18
] * ( xx [ 98 ] * xx [ 29 ] + xx [ 38 ] * xx [ 107 ] ) ; xx [ 91 ] = xx [ 94
] - ( xx [ 38 ] * xx [ 98 ] - xx [ 107 ] * xx [ 29 ] ) * xx [ 18 ] + xx [ 37
] * state [ 13 ] ; xx [ 94 ] = xx [ 168 ] - ( xx [ 160 ] * xx [ 41 ] + xx [
161 ] * xx [ 40 ] ) ; xx [ 98 ] = xx [ 43 ] * xx [ 93 ] ; xx [ 107 ] = xx [
92 ] * xx [ 43 ] ; xx [ 109 ] = xx [ 108 ] - xx [ 44 ] * xx [ 93 ] ; xx [ 148
] = xx [ 19 ] * xx [ 39 ] + xx [ 92 ] * xx [ 44 ] + xx [ 91 ] ; xx [ 149 ] =
xx [ 148 ] * xx [ 43 ] ; xx [ 162 ] = xx [ 109 ] * xx [ 43 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 132 , xx + 95 , xx + 169 ) ; xx [
163 ] = xx [ 171 ] + state [ 17 ] ; pm_math_Vector3_cross_ra ( xx + 95 , xx +
121 , xx + 171 ) ; xx [ 121 ] = xx [ 171 ] + xx [ 8 ] ; xx [ 122 ] = xx [ 172
] + xx [ 164 ] ; xx [ 123 ] = xx [ 173 ] + xx [ 165 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 132 , xx + 121 , xx + 171 ) ; xx [
121 ] = xx [ 172 ] + xx [ 25 ] * state [ 17 ] ; xx [ 25 ] = xx [ 57 ] * xx [
170 ] ; xx [ 122 ] = xx [ 57 ] * xx [ 169 ] ; xx [ 123 ] = xx [ 169 ] - xx [
18 ] * ( xx [ 25 ] * xx [ 50 ] + xx [ 57 ] * xx [ 122 ] ) ; xx [ 132 ] = xx [
170 ] - ( xx [ 57 ] * xx [ 25 ] - xx [ 122 ] * xx [ 50 ] ) * xx [ 18 ] ; xx [
25 ] = xx [ 163 ] + state [ 19 ] ; xx [ 122 ] = xx [ 163 ] * xx [ 36 ] + xx [
171 ] ; xx [ 133 ] = xx [ 163 ] * xx [ 56 ] + xx [ 121 ] ; xx [ 134 ] = xx [
133 ] * xx [ 57 ] ; xx [ 135 ] = xx [ 122 ] * xx [ 57 ] ; xx [ 167 ] = xx [
122 ] - xx [ 18 ] * ( xx [ 134 ] * xx [ 50 ] + xx [ 57 ] * xx [ 135 ] ) ; xx
[ 122 ] = xx [ 133 ] - ( xx [ 57 ] * xx [ 134 ] - xx [ 135 ] * xx [ 50 ] ) *
xx [ 18 ] + xx [ 37 ] * state [ 19 ] ; xx [ 37 ] = xx [ 173 ] - ( xx [ 169 ]
* xx [ 36 ] + xx [ 170 ] * xx [ 56 ] ) ; xx [ 133 ] = xx [ 59 ] * xx [ 132 ]
; xx [ 134 ] = xx [ 123 ] * xx [ 59 ] ; xx [ 135 ] = xx [ 44 ] * xx [ 132 ] +
xx [ 167 ] ; xx [ 172 ] = xx [ 25 ] * xx [ 39 ] - xx [ 123 ] * xx [ 44 ] + xx
[ 122 ] ; xx [ 174 ] = xx [ 172 ] * xx [ 59 ] ; xx [ 175 ] = xx [ 135 ] * xx
[ 59 ] ; xx [ 176 ] = xx [ 55 ] ; xx [ 177 ] = xx [ 63 ] ; xx [ 178 ] = xx [
55 ] ; xx [ 179 ] = xx [ 61 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 176
, xx + 95 , xx + 180 ) ; pm_math_Vector3_cross_ra ( xx + 95 , xx + 68 , xx +
183 ) ; xx [ 186 ] = xx [ 183 ] + xx [ 8 ] ; xx [ 187 ] = xx [ 184 ] + xx [
164 ] ; xx [ 188 ] = xx [ 185 ] + xx [ 165 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 176 , xx + 186 , xx + 183 ) ; xx [
176 ] = xx [ 60 ] ; xx [ 177 ] = xx [ 16 ] ; xx [ 178 ] = xx [ 60 ] ; xx [
179 ] = xx [ 23 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 176 , xx + 95 ,
xx + 186 ) ; xx [ 189 ] = xx [ 73 ] ; xx [ 190 ] = xx [ 66 ] ; xx [ 191 ] =
xx [ 64 ] ; pm_math_Vector3_cross_ra ( xx + 95 , xx + 189 , xx + 192 ) ; xx [
95 ] = xx [ 192 ] + xx [ 8 ] ; xx [ 96 ] = xx [ 193 ] + xx [ 164 ] ; xx [ 97
] = xx [ 194 ] + xx [ 165 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 176 ,
xx + 95 , xx + 189 ) ; motionData [ 0 ] = xx [ 1 ] ; motionData [ 1 ] = xx [
2 ] ; motionData [ 2 ] = xx [ 1 ] ; motionData [ 3 ] = xx [ 2 ] ; motionData
[ 4 ] = state [ 2 ] ; motionData [ 5 ] = state [ 1 ] ; motionData [ 6 ] = xx
[ 3 ] ; motionData [ 7 ] = xx [ 6 ] ; motionData [ 8 ] = xx [ 6 ] ;
motionData [ 9 ] = xx [ 7 ] ; motionData [ 10 ] = xx [ 7 ] ; motionData [ 11
] = xx [ 2 ] ; motionData [ 12 ] = xx [ 2 ] ; motionData [ 13 ] = xx [ 2 ] ;
motionData [ 14 ] = xx [ 17 ] ; motionData [ 15 ] = xx [ 5 ] ; motionData [
16 ] = xx [ 9 ] ; motionData [ 17 ] = xx [ 11 ] ; motionData [ 18 ] = xx [ 14
] ; motionData [ 19 ] = xx [ 20 ] ; motionData [ 20 ] = xx [ 13 ] ;
motionData [ 21 ] = xx [ 21 ] ; motionData [ 22 ] = xx [ 24 ] ; motionData [
23 ] = xx [ 21 ] ; motionData [ 24 ] = xx [ 26 ] ; motionData [ 25 ] = xx [
31 ] ; motionData [ 26 ] = xx [ 27 ] ; motionData [ 27 ] = xx [ 28 ] ;
motionData [ 28 ] = xx [ 29 ] ; motionData [ 29 ] = xx [ 2 ] ; motionData [
30 ] = xx [ 2 ] ; motionData [ 31 ] = - xx [ 38 ] ; motionData [ 32 ] = xx [
40 ] ; motionData [ 33 ] = - xx [ 41 ] ; motionData [ 34 ] = xx [ 2 ] ;
motionData [ 35 ] = - xx [ 42 ] ; motionData [ 36 ] = xx [ 2 ] ; motionData [
37 ] = xx [ 2 ] ; motionData [ 38 ] = - xx [ 43 ] ; motionData [ 39 ] = xx [
39 ] ; motionData [ 40 ] = xx [ 2 ] ; motionData [ 41 ] = - xx [ 44 ] ;
motionData [ 42 ] = xx [ 45 ] ; motionData [ 43 ] = xx [ 47 ] ; motionData [
44 ] = xx [ 45 ] ; motionData [ 45 ] = xx [ 49 ] ; motionData [ 46 ] = xx [
52 ] ; motionData [ 47 ] = xx [ 46 ] ; motionData [ 48 ] = xx [ 48 ] ;
motionData [ 49 ] = xx [ 50 ] ; motionData [ 50 ] = xx [ 2 ] ; motionData [
51 ] = xx [ 2 ] ; motionData [ 52 ] = - xx [ 57 ] ; motionData [ 53 ] = xx [
56 ] ; motionData [ 54 ] = - xx [ 36 ] ; motionData [ 55 ] = xx [ 2 ] ;
motionData [ 56 ] = - xx [ 58 ] ; motionData [ 57 ] = xx [ 2 ] ; motionData [
58 ] = xx [ 2 ] ; motionData [ 59 ] = - xx [ 59 ] ; motionData [ 60 ] = xx [
39 ] ; motionData [ 61 ] = xx [ 2 ] ; motionData [ 62 ] = xx [ 44 ] ;
motionData [ 63 ] = xx [ 55 ] ; motionData [ 64 ] = xx [ 63 ] ; motionData [
65 ] = xx [ 55 ] ; motionData [ 66 ] = xx [ 61 ] ; motionData [ 67 ] = xx [
68 ] ; motionData [ 68 ] = xx [ 69 ] ; motionData [ 69 ] = xx [ 70 ] ;
motionData [ 70 ] = xx [ 60 ] ; motionData [ 71 ] = xx [ 16 ] ; motionData [
72 ] = xx [ 60 ] ; motionData [ 73 ] = xx [ 23 ] ; motionData [ 74 ] = xx [
73 ] ; motionData [ 75 ] = xx [ 66 ] ; motionData [ 76 ] = xx [ 64 ] ;
motionData [ 77 ] = xx [ 4 ] + xx [ 49 ] * xx [ 57 ] ; motionData [ 78 ] = xx
[ 47 ] * xx [ 50 ] - xx [ 65 ] ; motionData [ 79 ] = xx [ 4 ] + xx [ 47 ] *
xx [ 57 ] ; motionData [ 80 ] = xx [ 49 ] * xx [ 50 ] - xx [ 65 ] ;
motionData [ 81 ] = xx [ 56 ] + ( xx [ 67 ] * xx [ 45 ] + xx [ 80 ] ) * xx [
18 ] - xx [ 51 ] + xx [ 22 ] ; motionData [ 82 ] = ( xx [ 71 ] * xx [ 45 ] +
xx [ 81 ] ) * xx [ 18 ] - ( xx [ 36 ] - xx [ 53 ] ) + xx [ 32 ] ; motionData
[ 83 ] = xx [ 18 ] * ( xx [ 82 ] - xx [ 72 ] * xx [ 45 ] ) - xx [ 54 ] - xx [
34 ] ; motionData [ 84 ] = xx [ 74 ] + xx [ 26 ] * xx [ 38 ] ; motionData [
85 ] = xx [ 24 ] * xx [ 29 ] - xx [ 75 ] ; motionData [ 86 ] = xx [ 74 ] + xx
[ 24 ] * xx [ 38 ] ; motionData [ 87 ] = xx [ 26 ] * xx [ 29 ] - xx [ 75 ] ;
motionData [ 88 ] = xx [ 40 ] + ( xx [ 76 ] * xx [ 21 ] + xx [ 88 ] ) * xx [
18 ] - xx [ 30 ] - xx [ 22 ] ; motionData [ 89 ] = ( xx [ 83 ] * xx [ 21 ] +
xx [ 89 ] ) * xx [ 18 ] - ( xx [ 41 ] - xx [ 33 ] ) + xx [ 32 ] ; motionData
[ 90 ] = xx [ 18 ] * ( xx [ 90 ] - xx [ 84 ] * xx [ 21 ] ) - xx [ 35 ] - xx [
34 ] ; motionData [ 91 ] = xx [ 0 ] ; motionData [ 92 ] = xx [ 79 ] ;
motionData [ 93 ] = xx [ 85 ] ; motionData [ 94 ] = xx [ 86 ] ; motionData [
95 ] = state [ 2 ] ; motionData [ 96 ] = state [ 1 ] ; motionData [ 97 ] = xx
[ 3 ] ; motionData [ 98 ] = xx [ 99 ] ; motionData [ 99 ] = xx [ 100 ] ;
motionData [ 100 ] = xx [ 101 ] ; motionData [ 101 ] = xx [ 102 ] ;
motionData [ 102 ] = xx [ 77 ] ; motionData [ 103 ] = xx [ 78 ] ; motionData
[ 104 ] = xx [ 87 ] ; motionData [ 105 ] = xx [ 103 ] ; motionData [ 106 ] =
xx [ 104 ] ; motionData [ 107 ] = xx [ 105 ] ; motionData [ 108 ] = xx [ 106
] ; motionData [ 109 ] = xx [ 113 ] ; motionData [ 110 ] = xx [ 114 ] ;
motionData [ 111 ] = xx [ 110 ] ; motionData [ 112 ] = xx [ 111 ] ;
motionData [ 113 ] = xx [ 112 ] ; motionData [ 114 ] = xx [ 115 ] ;
motionData [ 115 ] = xx [ 116 ] ; motionData [ 116 ] = xx [ 120 ] + xx [ 113
] ; motionData [ 117 ] = xx [ 117 ] ; motionData [ 118 ] = xx [ 118 ] + xx [
110 ] ; motionData [ 119 ] = xx [ 116 ] * xx [ 43 ] - xx [ 42 ] * xx [ 111 ]
; motionData [ 120 ] = - ( xx [ 112 ] * xx [ 42 ] + xx [ 43 ] * xx [ 115 ] )
; motionData [ 121 ] = xx [ 112 ] * xx [ 43 ] - xx [ 42 ] * xx [ 115 ] ;
motionData [ 122 ] = - ( xx [ 43 ] * xx [ 111 ] + xx [ 116 ] * xx [ 42 ] ) ;
motionData [ 123 ] = ( xx [ 129 ] - xx [ 119 ] * xx [ 111 ] ) * xx [ 18 ] +
xx [ 120 ] + xx [ 113 ] + xx [ 39 ] ; motionData [ 124 ] = ( xx [ 124 ] * xx
[ 111 ] + xx [ 130 ] ) * xx [ 18 ] + xx [ 117 ] ; motionData [ 125 ] = xx [
18 ] * ( xx [ 131 ] - xx [ 125 ] * xx [ 111 ] ) + xx [ 118 ] + xx [ 110 ] -
xx [ 44 ] ; motionData [ 126 ] = xx [ 136 ] ; motionData [ 127 ] = xx [ 137 ]
; motionData [ 128 ] = xx [ 138 ] ; motionData [ 129 ] = xx [ 139 ] ;
motionData [ 130 ] = xx [ 140 ] ; motionData [ 131 ] = xx [ 141 ] ;
motionData [ 132 ] = xx [ 126 ] ; motionData [ 133 ] = xx [ 127 ] ;
motionData [ 134 ] = xx [ 128 ] ; motionData [ 135 ] = xx [ 142 ] ;
motionData [ 136 ] = xx [ 143 ] ; motionData [ 137 ] = xx [ 147 ] + xx [ 140
] ; motionData [ 138 ] = xx [ 144 ] ; motionData [ 139 ] = xx [ 145 ] + xx [
126 ] ; motionData [ 140 ] = xx [ 143 ] * xx [ 59 ] - xx [ 58 ] * xx [ 127 ]
; motionData [ 141 ] = - ( xx [ 128 ] * xx [ 58 ] + xx [ 59 ] * xx [ 142 ] )
; motionData [ 142 ] = xx [ 128 ] * xx [ 59 ] - xx [ 58 ] * xx [ 142 ] ;
motionData [ 143 ] = - ( xx [ 59 ] * xx [ 127 ] + xx [ 143 ] * xx [ 58 ] ) ;
motionData [ 144 ] = ( xx [ 146 ] * xx [ 127 ] + xx [ 156 ] ) * xx [ 18 ] +
xx [ 147 ] + xx [ 140 ] + xx [ 39 ] ; motionData [ 145 ] = ( xx [ 151 ] * xx
[ 127 ] + xx [ 157 ] ) * xx [ 18 ] + xx [ 144 ] ; motionData [ 146 ] = xx [
18 ] * ( xx [ 158 ] - xx [ 152 ] * xx [ 127 ] ) + xx [ 145 ] + xx [ 126 ] +
xx [ 44 ] ; motionData [ 147 ] = xx [ 2 ] ; motionData [ 148 ] = xx [ 2 ] ;
motionData [ 149 ] = xx [ 2 ] ; motionData [ 150 ] = state [ 3 ] ; motionData
[ 151 ] = state [ 4 ] ; motionData [ 152 ] = state [ 5 ] ; motionData [ 153 ]
= xx [ 2 ] ; motionData [ 154 ] = state [ 7 ] ; motionData [ 155 ] = xx [ 2 ]
; motionData [ 156 ] = xx [ 153 ] ; motionData [ 157 ] = xx [ 154 ] ;
motionData [ 158 ] = xx [ 155 ] ; motionData [ 159 ] = xx [ 150 ] ;
motionData [ 160 ] = xx [ 159 ] ; motionData [ 161 ] = xx [ 12 ] ; motionData
[ 162 ] = xx [ 8 ] ; motionData [ 163 ] = xx [ 164 ] ; motionData [ 164 ] =
xx [ 165 ] ; motionData [ 165 ] = xx [ 160 ] ; motionData [ 166 ] = xx [ 161
] ; motionData [ 167 ] = xx [ 10 ] ; motionData [ 168 ] = xx [ 166 ] ;
motionData [ 169 ] = xx [ 15 ] ; motionData [ 170 ] = xx [ 168 ] ; motionData
[ 171 ] = xx [ 92 ] ; motionData [ 172 ] = xx [ 93 ] ; motionData [ 173 ] =
xx [ 19 ] ; motionData [ 174 ] = xx [ 108 ] ; motionData [ 175 ] = xx [ 91 ]
; motionData [ 176 ] = xx [ 94 ] ; motionData [ 177 ] = xx [ 92 ] + xx [ 18 ]
* ( xx [ 42 ] * xx [ 98 ] - xx [ 107 ] * xx [ 43 ] ) ; motionData [ 178 ] =
xx [ 93 ] - ( xx [ 42 ] * xx [ 107 ] + xx [ 98 ] * xx [ 43 ] ) * xx [ 18 ] ;
motionData [ 179 ] = xx [ 19 ] + state [ 15 ] ; motionData [ 180 ] = xx [ 109
] + xx [ 18 ] * ( xx [ 42 ] * xx [ 149 ] - xx [ 162 ] * xx [ 43 ] ) ;
motionData [ 181 ] = xx [ 148 ] - ( xx [ 42 ] * xx [ 162 ] + xx [ 149 ] * xx
[ 43 ] ) * xx [ 18 ] ; motionData [ 182 ] = xx [ 94 ] - xx [ 39 ] * xx [ 93 ]
; motionData [ 183 ] = xx [ 169 ] ; motionData [ 184 ] = xx [ 170 ] ;
motionData [ 185 ] = xx [ 163 ] ; motionData [ 186 ] = xx [ 171 ] ;
motionData [ 187 ] = xx [ 121 ] ; motionData [ 188 ] = xx [ 173 ] ;
motionData [ 189 ] = xx [ 123 ] ; motionData [ 190 ] = xx [ 132 ] ;
motionData [ 191 ] = xx [ 25 ] ; motionData [ 192 ] = xx [ 167 ] ; motionData
[ 193 ] = xx [ 122 ] ; motionData [ 194 ] = xx [ 37 ] ; motionData [ 195 ] =
xx [ 123 ] + xx [ 18 ] * ( xx [ 58 ] * xx [ 133 ] - xx [ 134 ] * xx [ 59 ] )
; motionData [ 196 ] = xx [ 132 ] - ( xx [ 58 ] * xx [ 134 ] + xx [ 133 ] *
xx [ 59 ] ) * xx [ 18 ] ; motionData [ 197 ] = xx [ 25 ] + state [ 21 ] ;
motionData [ 198 ] = xx [ 135 ] + xx [ 18 ] * ( xx [ 58 ] * xx [ 174 ] - xx [
175 ] * xx [ 59 ] ) ; motionData [ 199 ] = xx [ 172 ] - ( xx [ 58 ] * xx [
175 ] + xx [ 174 ] * xx [ 59 ] ) * xx [ 18 ] ; motionData [ 200 ] = xx [ 37 ]
- xx [ 39 ] * xx [ 132 ] ; motionData [ 201 ] = xx [ 180 ] ; motionData [ 202
] = xx [ 181 ] ; motionData [ 203 ] = xx [ 182 ] + state [ 23 ] ; motionData
[ 204 ] = xx [ 183 ] ; motionData [ 205 ] = xx [ 184 ] + xx [ 62 ] * state [
23 ] ; motionData [ 206 ] = xx [ 185 ] ; motionData [ 207 ] = xx [ 186 ] ;
motionData [ 208 ] = xx [ 187 ] ; motionData [ 209 ] = xx [ 188 ] + state [
25 ] ; motionData [ 210 ] = xx [ 189 ] ; motionData [ 211 ] = xx [ 190 ] + xx
[ 62 ] * state [ 25 ] ; motionData [ 212 ] = xx [ 191 ] ; } static size_t
computeAssemblyError_0 ( const RuntimeDerivedValuesBundle * rtdv , const int
* modeVector , const double * motionData , double * error ) { const double *
rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts .
mValues ; double xx [ 12 ] ; ( void ) rtdvd ; ( void ) rtdvi ; ( void )
modeVector ; xx [ 0 ] = - motionData [ 77 ] ; xx [ 1 ] = - motionData [ 78 ]
; xx [ 2 ] = - motionData [ 79 ] ; xx [ 3 ] = - motionData [ 80 ] ; xx [ 4 ]
= motionData [ 63 ] ; xx [ 5 ] = motionData [ 64 ] ; xx [ 6 ] = motionData [
65 ] ; xx [ 7 ] = motionData [ 66 ] ; pm_math_Quaternion_inverseCompose_ra (
xx + 0 , xx + 4 , xx + 8 ) ; xx [ 0 ] = 0.085075 ; xx [ 1 ] = xx [ 0 ] *
motionData [ 65 ] ; xx [ 2 ] = xx [ 0 ] * motionData [ 66 ] ; xx [ 0 ] = 2.0
; xx [ 3 ] = 0.06918743527133955 ; xx [ 4 ] = xx [ 3 ] * motionData [ 79 ] ;
xx [ 5 ] = xx [ 3 ] * motionData [ 80 ] ; error [ 0 ] = xx [ 9 ] ; error [ 1
] = xx [ 10 ] ; error [ 2 ] = motionData [ 67 ] - ( xx [ 1 ] * motionData [
65 ] + xx [ 2 ] * motionData [ 66 ] ) * xx [ 0 ] - ( motionData [ 81 ] + ( xx
[ 4 ] * motionData [ 79 ] + xx [ 5 ] * motionData [ 80 ] ) * xx [ 0 ] ) +
0.1542624352713395 ; error [ 3 ] = ( xx [ 2 ] * motionData [ 63 ] + xx [ 1 ]
* motionData [ 64 ] ) * xx [ 0 ] + motionData [ 68 ] - ( motionData [ 82 ] -
( xx [ 5 ] * motionData [ 77 ] + xx [ 4 ] * motionData [ 78 ] ) * xx [ 0 ] )
; error [ 4 ] = xx [ 0 ] * ( xx [ 2 ] * motionData [ 64 ] - xx [ 1 ] *
motionData [ 63 ] ) + motionData [ 69 ] - ( xx [ 0 ] * ( xx [ 4 ] *
motionData [ 77 ] - xx [ 5 ] * motionData [ 78 ] ) + motionData [ 83 ] ) ;
return 5 ; } static size_t computeAssemblyError_1 ( const
RuntimeDerivedValuesBundle * rtdv , const int * modeVector , const double *
motionData , double * error ) { const double * rtdvd = rtdv -> mDoubles .
mValues ; const int * rtdvi = rtdv -> mInts . mValues ; double xx [ 12 ] ; (
void ) rtdvd ; ( void ) rtdvi ; ( void ) modeVector ; xx [ 0 ] = - motionData
[ 84 ] ; xx [ 1 ] = - motionData [ 85 ] ; xx [ 2 ] = - motionData [ 86 ] ; xx
[ 3 ] = - motionData [ 87 ] ; xx [ 4 ] = motionData [ 70 ] ; xx [ 5 ] =
motionData [ 71 ] ; xx [ 6 ] = motionData [ 72 ] ; xx [ 7 ] = motionData [ 73
] ; pm_math_Quaternion_inverseCompose_ra ( xx + 0 , xx + 4 , xx + 8 ) ; xx [
0 ] = 0.085075 ; xx [ 1 ] = xx [ 0 ] * motionData [ 72 ] ; xx [ 2 ] = xx [ 0
] * motionData [ 73 ] ; xx [ 0 ] = 2.0 ; xx [ 3 ] = 0.06918743527133955 ; xx
[ 4 ] = xx [ 3 ] * motionData [ 86 ] ; xx [ 5 ] = xx [ 3 ] * motionData [ 87
] ; error [ 0 ] = xx [ 9 ] ; error [ 1 ] = xx [ 10 ] ; error [ 2 ] =
motionData [ 74 ] - ( xx [ 1 ] * motionData [ 72 ] + xx [ 2 ] * motionData [
73 ] ) * xx [ 0 ] - ( motionData [ 88 ] + ( xx [ 4 ] * motionData [ 86 ] + xx
[ 5 ] * motionData [ 87 ] ) * xx [ 0 ] ) + 0.1542624352713395 ; error [ 3 ] =
( xx [ 2 ] * motionData [ 70 ] + xx [ 1 ] * motionData [ 71 ] ) * xx [ 0 ] +
motionData [ 75 ] - ( motionData [ 89 ] - ( xx [ 5 ] * motionData [ 84 ] + xx
[ 4 ] * motionData [ 85 ] ) * xx [ 0 ] ) ; error [ 4 ] = xx [ 0 ] * ( xx [ 2
] * motionData [ 71 ] - xx [ 1 ] * motionData [ 70 ] ) + motionData [ 76 ] -
( xx [ 0 ] * ( xx [ 4 ] * motionData [ 84 ] - xx [ 5 ] * motionData [ 85 ] )
+ motionData [ 90 ] ) ; return 5 ; } size_t
series_link_blance_leg_ad6bcbee_1_computeAssemblyError ( const void * mech ,
const RuntimeDerivedValuesBundle * rtdv , size_t constraintIdx , const int *
modeVector , const double * motionData , double * error ) { ( void ) mech ; (
void ) rtdv ; ( void ) modeVector ; ( void ) motionData ; ( void ) error ;
switch ( constraintIdx ) { case 0 : return computeAssemblyError_0 ( rtdv ,
modeVector , motionData , error ) ; case 1 : return computeAssemblyError_1 (
rtdv , modeVector , motionData , error ) ; } return 0 ; } static size_t
computeAssemblyJacobian_0 ( const RuntimeDerivedValuesBundle * rtdv , const
double * state , const int * modeVector , const double * motionData , double
* J ) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi
= rtdv -> mInts . mValues ; double xx [ 56 ] ; ( void ) rtdvd ; ( void )
rtdvi ; ( void ) modeVector ; xx [ 0 ] = 9.87654321 ; xx [ 1 ] = - motionData
[ 77 ] ; xx [ 2 ] = - motionData [ 78 ] ; xx [ 3 ] = - motionData [ 79 ] ; xx
[ 4 ] = - motionData [ 80 ] ; xx [ 5 ] = motionData [ 63 ] ; xx [ 6 ] =
motionData [ 64 ] ; xx [ 7 ] = motionData [ 65 ] ; xx [ 8 ] = motionData [ 66
] ; pm_math_Quaternion_inverseCompose_ra ( xx + 1 , xx + 5 , xx + 9 ) ; xx [
1 ] = motionData [ 77 ] ; xx [ 2 ] = motionData [ 78 ] ; xx [ 3 ] =
motionData [ 79 ] ; xx [ 4 ] = motionData [ 80 ] ; xx [ 13 ] = 2.0 ; xx [ 14
] = motionData [ 49 ] * motionData [ 50 ] + motionData [ 51 ] * motionData [
52 ] ; xx [ 15 ] = 1.0 ; xx [ 16 ] = xx [ 15 ] - ( motionData [ 50 ] *
motionData [ 50 ] + motionData [ 51 ] * motionData [ 51 ] ) * xx [ 13 ] ; xx
[ 17 ] = xx [ 13 ] * ( motionData [ 50 ] * motionData [ 52 ] - motionData [
49 ] * motionData [ 51 ] ) ; xx [ 18 ] = xx [ 14 ] * xx [ 13 ] ; xx [ 19 ] =
xx [ 16 ] ; pm_math_Quaternion_xform_ra ( xx + 1 , xx + 17 , xx + 20 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 5 , xx + 20 , xx + 1 ) ; xx [ 17 ]
= - xx [ 1 ] ; xx [ 18 ] = - xx [ 2 ] ; xx [ 19 ] = - xx [ 3 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 17 , xx + 1 ) ; xx [ 17 ] = (
motionData [ 77 ] * motionData [ 79 ] + motionData [ 78 ] * motionData [ 80 ]
) * xx [ 13 ] ; xx [ 18 ] = xx [ 13 ] * ( motionData [ 79 ] * motionData [ 80
] - motionData [ 77 ] * motionData [ 78 ] ) ; xx [ 19 ] = xx [ 15 ] - (
motionData [ 78 ] * motionData [ 78 ] + motionData [ 79 ] * motionData [ 79 ]
) * xx [ 13 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 5 , xx + 17 , xx +
20 ) ; xx [ 5 ] = - xx [ 20 ] ; xx [ 6 ] = - xx [ 21 ] ; xx [ 7 ] = - xx [ 22
] ; pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 5 , xx + 17 ) ; xx [ 5 ]
= 0.0 ; xx [ 6 ] = xx [ 5 ] ; xx [ 7 ] = xx [ 5 ] ; xx [ 8 ] = xx [ 15 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 6 , xx + 21 ) ; xx [ 1 ] =
0.6970892476441968 ; xx [ 4 ] = 0.5 ; xx [ 5 ] = xx [ 4 ] * state [ 16 ] ; xx
[ 6 ] = cos ( xx [ 5 ] ) ; xx [ 7 ] = 0.1186026172512557 ; xx [ 8 ] = sin (
xx [ 5 ] ) ; xx [ 5 ] = xx [ 1 ] * xx [ 6 ] - xx [ 7 ] * xx [ 8 ] ; xx [ 9 ]
= xx [ 7 ] * xx [ 6 ] ; xx [ 6 ] = xx [ 1 ] * xx [ 8 ] ; xx [ 8 ] = xx [ 9 ]
+ xx [ 6 ] ; xx [ 10 ] = xx [ 6 ] + xx [ 9 ] ; xx [ 24 ] = xx [ 5 ] ; xx [ 25
] = xx [ 8 ] ; xx [ 26 ] = xx [ 5 ] ; xx [ 27 ] = xx [ 10 ] ; xx [ 28 ] =
motionData [ 49 ] ; xx [ 29 ] = motionData [ 50 ] ; xx [ 30 ] = motionData [
51 ] ; xx [ 31 ] = motionData [ 52 ] ; pm_math_Quaternion_compose_ra ( xx +
24 , xx + 28 , xx + 32 ) ; xx [ 6 ] = xx [ 14 ] * 0.1383748705426791 ; xx [ 9
] = 0.06918743527133955 ; xx [ 11 ] = xx [ 9 ] * xx [ 16 ] ; xx [ 12 ] = xx [
34 ] * xx [ 6 ] + xx [ 35 ] * xx [ 11 ] ; xx [ 14 ] = xx [ 33 ] * xx [ 6 ] ;
xx [ 15 ] = xx [ 33 ] * xx [ 11 ] ; xx [ 24 ] = xx [ 12 ] ; xx [ 25 ] = - xx
[ 14 ] ; xx [ 26 ] = - xx [ 15 ] ; pm_math_Vector3_cross_ra ( xx + 33 , xx +
24 , xx + 27 ) ; xx [ 24 ] = xx [ 8 ] ; xx [ 25 ] = xx [ 5 ] ; xx [ 26 ] = xx
[ 10 ] ; xx [ 16 ] = xx [ 10 ] * motionData [ 53 ] ; xx [ 17 ] = xx [ 10 ] *
motionData [ 54 ] ; xx [ 20 ] = xx [ 8 ] * motionData [ 53 ] + xx [ 5 ] *
motionData [ 54 ] ; xx [ 33 ] = - xx [ 16 ] ; xx [ 34 ] = - xx [ 17 ] ; xx [
35 ] = xx [ 20 ] ; pm_math_Vector3_cross_ra ( xx + 24 , xx + 33 , xx + 36 ) ;
xx [ 21 ] = 0.08603840402471528 ; xx [ 24 ] = xx [ 8 ] * xx [ 21 ] ; xx [ 25
] = xx [ 24 ] * xx [ 5 ] ; xx [ 26 ] = xx [ 10 ] * xx [ 21 ] ; xx [ 30 ] = xx
[ 26 ] * xx [ 5 ] ; xx [ 31 ] = 0.7071067811865476 ; xx [ 33 ] = xx [ 4 ] *
state [ 18 ] ; xx [ 34 ] = xx [ 31 ] * sin ( xx [ 33 ] ) ; xx [ 35 ] = xx [
31 ] * cos ( xx [ 33 ] ) ; xx [ 31 ] = xx [ 34 ] - xx [ 35 ] ; xx [ 33 ] = xx
[ 34 ] + xx [ 35 ] ; xx [ 34 ] = xx [ 31 ] * motionData [ 45 ] - xx [ 33 ] *
motionData [ 42 ] ; xx [ 35 ] = xx [ 34 ] * xx [ 9 ] ; xx [ 39 ] = xx [ 31 ]
* motionData [ 42 ] + xx [ 33 ] * motionData [ 45 ] ; xx [ 40 ] = xx [ 31 ] *
motionData [ 43 ] - xx [ 33 ] * motionData [ 44 ] ; xx [ 41 ] = xx [ 40 ] *
xx [ 9 ] ; xx [ 42 ] = xx [ 31 ] * motionData [ 44 ] + xx [ 33 ] * motionData
[ 43 ] ; xx [ 43 ] = motionData [ 43 ] ; xx [ 44 ] = motionData [ 44 ] ; xx [
45 ] = motionData [ 45 ] ; xx [ 46 ] = 0.02913743527133955 ; xx [ 47 ] = xx [
33 ] * xx [ 46 ] ; xx [ 48 ] = xx [ 46 ] - xx [ 13 ] * xx [ 33 ] * xx [ 47 ]
; xx [ 33 ] = xx [ 48 ] * motionData [ 45 ] ; xx [ 46 ] = xx [ 13 ] * xx [ 47
] * xx [ 31 ] ; xx [ 31 ] = xx [ 46 ] * motionData [ 45 ] ; xx [ 47 ] = xx [
48 ] * motionData [ 43 ] - xx [ 46 ] * motionData [ 44 ] ; xx [ 49 ] = - xx [
33 ] ; xx [ 50 ] = xx [ 31 ] ; xx [ 51 ] = xx [ 47 ] ;
pm_math_Vector3_cross_ra ( xx + 43 , xx + 49 , xx + 52 ) ; xx [ 43 ] = xx [ 4
] * state [ 22 ] ; xx [ 4 ] = sin ( xx [ 43 ] ) ; xx [ 44 ] = xx [ 1 ] * xx [
4 ] ; xx [ 45 ] = cos ( xx [ 43 ] ) ; xx [ 43 ] = xx [ 7 ] * xx [ 45 ] ; xx [
49 ] = xx [ 44 ] + xx [ 43 ] ; xx [ 50 ] = 0.085075 ; xx [ 51 ] = xx [ 49 ] *
xx [ 50 ] ; xx [ 55 ] = xx [ 7 ] * xx [ 4 ] - xx [ 1 ] * xx [ 45 ] ; xx [ 1 ]
= xx [ 51 ] * xx [ 55 ] ; xx [ 4 ] = xx [ 43 ] + xx [ 44 ] ; xx [ 7 ] = xx [
4 ] * xx [ 50 ] ; xx [ 43 ] = xx [ 7 ] * xx [ 55 ] ; xx [ 44 ] = xx [ 13 ] *
( xx [ 1 ] - xx [ 43 ] ) ; xx [ 45 ] = ( xx [ 49 ] * xx [ 51 ] + xx [ 4 ] *
xx [ 7 ] ) * xx [ 13 ] ; xx [ 4 ] = ( xx [ 43 ] + xx [ 1 ] ) * xx [ 13 ] ; J
[ 8 ] = xx [ 2 ] ; J [ 9 ] = xx [ 18 ] ; J [ 11 ] = xx [ 22 ] ; J [ 21 ] = xx
[ 3 ] ; J [ 22 ] = xx [ 19 ] ; J [ 24 ] = xx [ 23 ] ; J [ 34 ] = - ( xx [ 13
] * ( xx [ 27 ] + xx [ 12 ] * xx [ 32 ] ) + xx [ 13 ] * ( xx [ 36 ] - xx [ 16
] * xx [ 5 ] ) - motionData [ 54 ] + xx [ 13 ] * ( xx [ 25 ] - xx [ 30 ] ) )
; J [ 35 ] = - ( xx [ 13 ] * ( xx [ 35 ] * xx [ 39 ] - xx [ 41 ] * xx [ 42 ]
) + xx [ 13 ] * ( xx [ 52 ] - xx [ 33 ] * motionData [ 42 ] ) + xx [ 46 ] ) ;
J [ 37 ] = xx [ 44 ] + xx [ 44 ] ; J [ 47 ] = - ( ( xx [ 28 ] - xx [ 32 ] *
xx [ 14 ] ) * xx [ 13 ] - xx [ 11 ] + motionData [ 53 ] + xx [ 13 ] * ( xx [
37 ] - xx [ 17 ] * xx [ 5 ] ) - ( xx [ 10 ] * xx [ 26 ] + xx [ 8 ] * xx [ 24
] ) * xx [ 13 ] + xx [ 21 ] ) ; J [ 48 ] = - ( xx [ 48 ] + xx [ 13 ] * ( xx [
53 ] + xx [ 31 ] * motionData [ 42 ] ) + ( xx [ 34 ] * xx [ 35 ] + xx [ 40 ]
* xx [ 41 ] ) * xx [ 13 ] - xx [ 9 ] ) ; J [ 50 ] = 0.17015 - ( xx [ 45 ] +
xx [ 45 ] ) ; J [ 60 ] = - ( ( xx [ 29 ] - xx [ 32 ] * xx [ 15 ] ) * xx [ 13
] + xx [ 6 ] + ( xx [ 20 ] * xx [ 5 ] + xx [ 38 ] ) * xx [ 13 ] + ( xx [ 25 ]
+ xx [ 30 ] ) * xx [ 13 ] ) ; J [ 61 ] = - ( ( xx [ 47 ] * motionData [ 42 ]
+ xx [ 54 ] ) * xx [ 13 ] - ( xx [ 41 ] * xx [ 39 ] + xx [ 35 ] * xx [ 42 ] )
* xx [ 13 ] ) ; J [ 63 ] = - ( xx [ 4 ] + xx [ 4 ] ) ; return 5 ; } static
size_t computeAssemblyJacobian_1 ( const RuntimeDerivedValuesBundle * rtdv ,
const double * state , const int * modeVector , const double * motionData ,
double * J ) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int
* rtdvi = rtdv -> mInts . mValues ; double xx [ 56 ] ; ( void ) rtdvd ; (
void ) rtdvi ; ( void ) modeVector ; xx [ 0 ] = 9.87654321 ; xx [ 1 ] = -
motionData [ 84 ] ; xx [ 2 ] = - motionData [ 85 ] ; xx [ 3 ] = - motionData
[ 86 ] ; xx [ 4 ] = - motionData [ 87 ] ; xx [ 5 ] = motionData [ 70 ] ; xx [
6 ] = motionData [ 71 ] ; xx [ 7 ] = motionData [ 72 ] ; xx [ 8 ] =
motionData [ 73 ] ; pm_math_Quaternion_inverseCompose_ra ( xx + 1 , xx + 5 ,
xx + 9 ) ; xx [ 1 ] = motionData [ 84 ] ; xx [ 2 ] = motionData [ 85 ] ; xx [
3 ] = motionData [ 86 ] ; xx [ 4 ] = motionData [ 87 ] ; xx [ 13 ] = 2.0 ; xx
[ 14 ] = motionData [ 28 ] * motionData [ 29 ] + motionData [ 30 ] *
motionData [ 31 ] ; xx [ 15 ] = 1.0 ; xx [ 16 ] = xx [ 15 ] - ( motionData [
29 ] * motionData [ 29 ] + motionData [ 30 ] * motionData [ 30 ] ) * xx [ 13
] ; xx [ 17 ] = xx [ 13 ] * ( motionData [ 29 ] * motionData [ 31 ] -
motionData [ 28 ] * motionData [ 30 ] ) ; xx [ 18 ] = xx [ 14 ] * xx [ 13 ] ;
xx [ 19 ] = xx [ 16 ] ; pm_math_Quaternion_xform_ra ( xx + 1 , xx + 17 , xx +
20 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 5 , xx + 20 , xx + 1 ) ; xx
[ 17 ] = - xx [ 1 ] ; xx [ 18 ] = - xx [ 2 ] ; xx [ 19 ] = - xx [ 3 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 17 , xx + 1 ) ; xx [ 17 ] = (
motionData [ 84 ] * motionData [ 86 ] + motionData [ 85 ] * motionData [ 87 ]
) * xx [ 13 ] ; xx [ 18 ] = xx [ 13 ] * ( motionData [ 86 ] * motionData [ 87
] - motionData [ 84 ] * motionData [ 85 ] ) ; xx [ 19 ] = xx [ 15 ] - (
motionData [ 85 ] * motionData [ 85 ] + motionData [ 86 ] * motionData [ 86 ]
) * xx [ 13 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 5 , xx + 17 , xx +
20 ) ; xx [ 5 ] = - xx [ 20 ] ; xx [ 6 ] = - xx [ 21 ] ; xx [ 7 ] = - xx [ 22
] ; pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 5 , xx + 17 ) ; xx [ 5 ]
= 0.0 ; xx [ 6 ] = xx [ 5 ] ; xx [ 7 ] = xx [ 5 ] ; xx [ 8 ] = xx [ 15 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 6 , xx + 21 ) ; xx [ 1 ] =
0.6970892476441968 ; xx [ 4 ] = 0.5 ; xx [ 5 ] = xx [ 4 ] * state [ 10 ] ; xx
[ 6 ] = cos ( xx [ 5 ] ) ; xx [ 7 ] = 0.1186026172512557 ; xx [ 8 ] = sin (
xx [ 5 ] ) ; xx [ 5 ] = xx [ 1 ] * xx [ 6 ] - xx [ 7 ] * xx [ 8 ] ; xx [ 9 ]
= xx [ 7 ] * xx [ 6 ] ; xx [ 6 ] = xx [ 1 ] * xx [ 8 ] ; xx [ 8 ] = xx [ 9 ]
+ xx [ 6 ] ; xx [ 10 ] = xx [ 6 ] + xx [ 9 ] ; xx [ 24 ] = xx [ 5 ] ; xx [ 25
] = xx [ 8 ] ; xx [ 26 ] = xx [ 5 ] ; xx [ 27 ] = xx [ 10 ] ; xx [ 28 ] =
motionData [ 28 ] ; xx [ 29 ] = motionData [ 29 ] ; xx [ 30 ] = motionData [
30 ] ; xx [ 31 ] = motionData [ 31 ] ; pm_math_Quaternion_compose_ra ( xx +
24 , xx + 28 , xx + 32 ) ; xx [ 6 ] = xx [ 14 ] * 0.1383748705426791 ; xx [ 9
] = 0.06918743527133955 ; xx [ 11 ] = xx [ 9 ] * xx [ 16 ] ; xx [ 12 ] = xx [
34 ] * xx [ 6 ] + xx [ 35 ] * xx [ 11 ] ; xx [ 14 ] = xx [ 33 ] * xx [ 6 ] ;
xx [ 15 ] = xx [ 33 ] * xx [ 11 ] ; xx [ 24 ] = xx [ 12 ] ; xx [ 25 ] = - xx
[ 14 ] ; xx [ 26 ] = - xx [ 15 ] ; pm_math_Vector3_cross_ra ( xx + 33 , xx +
24 , xx + 27 ) ; xx [ 24 ] = xx [ 8 ] ; xx [ 25 ] = xx [ 5 ] ; xx [ 26 ] = xx
[ 10 ] ; xx [ 16 ] = xx [ 10 ] * motionData [ 32 ] ; xx [ 17 ] = xx [ 10 ] *
motionData [ 33 ] ; xx [ 20 ] = xx [ 8 ] * motionData [ 32 ] + xx [ 5 ] *
motionData [ 33 ] ; xx [ 33 ] = - xx [ 16 ] ; xx [ 34 ] = - xx [ 17 ] ; xx [
35 ] = xx [ 20 ] ; pm_math_Vector3_cross_ra ( xx + 24 , xx + 33 , xx + 36 ) ;
xx [ 21 ] = 0.08603840402471528 ; xx [ 24 ] = xx [ 8 ] * xx [ 21 ] ; xx [ 25
] = xx [ 24 ] * xx [ 5 ] ; xx [ 26 ] = xx [ 10 ] * xx [ 21 ] ; xx [ 30 ] = xx
[ 26 ] * xx [ 5 ] ; xx [ 31 ] = 0.7071067811865476 ; xx [ 33 ] = xx [ 4 ] *
state [ 12 ] ; xx [ 34 ] = xx [ 31 ] * sin ( xx [ 33 ] ) ; xx [ 35 ] = xx [
31 ] * cos ( xx [ 33 ] ) ; xx [ 31 ] = xx [ 34 ] - xx [ 35 ] ; xx [ 33 ] = xx
[ 34 ] + xx [ 35 ] ; xx [ 34 ] = xx [ 31 ] * motionData [ 24 ] - xx [ 33 ] *
motionData [ 21 ] ; xx [ 35 ] = xx [ 34 ] * xx [ 9 ] ; xx [ 39 ] = xx [ 31 ]
* motionData [ 21 ] + xx [ 33 ] * motionData [ 24 ] ; xx [ 40 ] = xx [ 31 ] *
motionData [ 22 ] - xx [ 33 ] * motionData [ 23 ] ; xx [ 41 ] = xx [ 40 ] *
xx [ 9 ] ; xx [ 42 ] = xx [ 31 ] * motionData [ 23 ] + xx [ 33 ] * motionData
[ 22 ] ; xx [ 43 ] = motionData [ 22 ] ; xx [ 44 ] = motionData [ 23 ] ; xx [
45 ] = motionData [ 24 ] ; xx [ 46 ] = 0.02913743527133955 ; xx [ 47 ] = xx [
33 ] * xx [ 46 ] ; xx [ 48 ] = xx [ 46 ] - xx [ 13 ] * xx [ 33 ] * xx [ 47 ]
; xx [ 33 ] = xx [ 48 ] * motionData [ 24 ] ; xx [ 46 ] = xx [ 13 ] * xx [ 47
] * xx [ 31 ] ; xx [ 31 ] = xx [ 46 ] * motionData [ 24 ] ; xx [ 47 ] = xx [
48 ] * motionData [ 22 ] - xx [ 46 ] * motionData [ 23 ] ; xx [ 49 ] = - xx [
33 ] ; xx [ 50 ] = xx [ 31 ] ; xx [ 51 ] = xx [ 47 ] ;
pm_math_Vector3_cross_ra ( xx + 43 , xx + 49 , xx + 52 ) ; xx [ 43 ] = xx [ 4
] * state [ 24 ] ; xx [ 4 ] = sin ( xx [ 43 ] ) ; xx [ 44 ] = xx [ 1 ] * xx [
4 ] ; xx [ 45 ] = cos ( xx [ 43 ] ) ; xx [ 43 ] = xx [ 7 ] * xx [ 45 ] ; xx [
49 ] = xx [ 44 ] + xx [ 43 ] ; xx [ 50 ] = 0.085075 ; xx [ 51 ] = xx [ 49 ] *
xx [ 50 ] ; xx [ 55 ] = xx [ 7 ] * xx [ 4 ] - xx [ 1 ] * xx [ 45 ] ; xx [ 1 ]
= xx [ 51 ] * xx [ 55 ] ; xx [ 4 ] = xx [ 43 ] + xx [ 44 ] ; xx [ 7 ] = xx [
4 ] * xx [ 50 ] ; xx [ 43 ] = xx [ 7 ] * xx [ 55 ] ; xx [ 44 ] = xx [ 13 ] *
( xx [ 1 ] - xx [ 43 ] ) ; xx [ 45 ] = ( xx [ 49 ] * xx [ 51 ] + xx [ 4 ] *
xx [ 7 ] ) * xx [ 13 ] ; xx [ 4 ] = ( xx [ 43 ] + xx [ 1 ] ) * xx [ 13 ] ; J
[ 5 ] = xx [ 2 ] ; J [ 6 ] = xx [ 18 ] ; J [ 12 ] = xx [ 22 ] ; J [ 18 ] = xx
[ 3 ] ; J [ 19 ] = xx [ 19 ] ; J [ 25 ] = xx [ 23 ] ; J [ 31 ] = - ( xx [ 13
] * ( xx [ 27 ] + xx [ 12 ] * xx [ 32 ] ) + xx [ 13 ] * ( xx [ 36 ] - xx [ 16
] * xx [ 5 ] ) - motionData [ 33 ] + xx [ 13 ] * ( xx [ 25 ] - xx [ 30 ] ) )
; J [ 32 ] = - ( xx [ 13 ] * ( xx [ 35 ] * xx [ 39 ] - xx [ 41 ] * xx [ 42 ]
) + xx [ 13 ] * ( xx [ 52 ] - xx [ 33 ] * motionData [ 21 ] ) + xx [ 46 ] ) ;
J [ 38 ] = xx [ 44 ] + xx [ 44 ] ; J [ 44 ] = - ( ( xx [ 28 ] - xx [ 32 ] *
xx [ 14 ] ) * xx [ 13 ] - xx [ 11 ] + motionData [ 32 ] + xx [ 13 ] * ( xx [
37 ] - xx [ 17 ] * xx [ 5 ] ) - ( xx [ 10 ] * xx [ 26 ] + xx [ 8 ] * xx [ 24
] ) * xx [ 13 ] + xx [ 21 ] ) ; J [ 45 ] = - ( xx [ 48 ] + xx [ 13 ] * ( xx [
53 ] + xx [ 31 ] * motionData [ 21 ] ) + ( xx [ 34 ] * xx [ 35 ] + xx [ 40 ]
* xx [ 41 ] ) * xx [ 13 ] - xx [ 9 ] ) ; J [ 51 ] = 0.17015 - ( xx [ 45 ] +
xx [ 45 ] ) ; J [ 57 ] = - ( ( xx [ 29 ] - xx [ 32 ] * xx [ 15 ] ) * xx [ 13
] + xx [ 6 ] + ( xx [ 20 ] * xx [ 5 ] + xx [ 38 ] ) * xx [ 13 ] + ( xx [ 25 ]
+ xx [ 30 ] ) * xx [ 13 ] ) ; J [ 58 ] = - ( ( xx [ 47 ] * motionData [ 21 ]
+ xx [ 54 ] ) * xx [ 13 ] - ( xx [ 41 ] * xx [ 39 ] + xx [ 35 ] * xx [ 42 ] )
* xx [ 13 ] ) ; J [ 64 ] = - ( xx [ 4 ] + xx [ 4 ] ) ; return 5 ; } size_t
series_link_blance_leg_ad6bcbee_1_computeAssemblyJacobian ( const void * mech
, const RuntimeDerivedValuesBundle * rtdv , size_t constraintIdx , boolean_T
forVelocitySatisfaction , const double * state , const int * modeVector ,
const double * motionData , double * J ) { ( void ) mech ; ( void ) rtdv ; (
void ) state ; ( void ) modeVector ; ( void ) forVelocitySatisfaction ; (
void ) motionData ; ( void ) J ; switch ( constraintIdx ) { case 0 : return
computeAssemblyJacobian_0 ( rtdv , state , modeVector , motionData , J ) ;
case 1 : return computeAssemblyJacobian_1 ( rtdv , state , modeVector ,
motionData , J ) ; } return 0 ; } size_t
series_link_blance_leg_ad6bcbee_1_computeFullAssemblyJacobian ( const void *
mech , const RuntimeDerivedValuesBundle * rtdv , const double * state , const
int * modeVector , const double * motionData , double * J ) { const double *
rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts .
mValues ; double xx [ 102 ] ; ( void ) mech ; ( void ) rtdvd ; ( void ) rtdvi
; ( void ) modeVector ; xx [ 0 ] = 9.87654321 ; xx [ 1 ] = - motionData [ 77
] ; xx [ 2 ] = - motionData [ 78 ] ; xx [ 3 ] = - motionData [ 79 ] ; xx [ 4
] = - motionData [ 80 ] ; xx [ 5 ] = motionData [ 63 ] ; xx [ 6 ] =
motionData [ 64 ] ; xx [ 7 ] = motionData [ 65 ] ; xx [ 8 ] = motionData [ 66
] ; pm_math_Quaternion_inverseCompose_ra ( xx + 1 , xx + 5 , xx + 9 ) ; xx [
1 ] = motionData [ 77 ] ; xx [ 2 ] = motionData [ 78 ] ; xx [ 3 ] =
motionData [ 79 ] ; xx [ 4 ] = motionData [ 80 ] ; xx [ 13 ] = 2.0 ; xx [ 14
] = motionData [ 49 ] * motionData [ 50 ] + motionData [ 51 ] * motionData [
52 ] ; xx [ 15 ] = 1.0 ; xx [ 16 ] = xx [ 15 ] - ( motionData [ 50 ] *
motionData [ 50 ] + motionData [ 51 ] * motionData [ 51 ] ) * xx [ 13 ] ; xx
[ 17 ] = xx [ 13 ] * ( motionData [ 50 ] * motionData [ 52 ] - motionData [
49 ] * motionData [ 51 ] ) ; xx [ 18 ] = xx [ 14 ] * xx [ 13 ] ; xx [ 19 ] =
xx [ 16 ] ; pm_math_Quaternion_xform_ra ( xx + 1 , xx + 17 , xx + 20 ) ;
pm_math_Quaternion_inverseXform_ra ( xx + 5 , xx + 20 , xx + 1 ) ; xx [ 17 ]
= - xx [ 1 ] ; xx [ 18 ] = - xx [ 2 ] ; xx [ 19 ] = - xx [ 3 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 17 , xx + 1 ) ; xx [ 17 ] = (
motionData [ 77 ] * motionData [ 79 ] + motionData [ 78 ] * motionData [ 80 ]
) * xx [ 13 ] ; xx [ 18 ] = xx [ 13 ] * ( motionData [ 79 ] * motionData [ 80
] - motionData [ 77 ] * motionData [ 78 ] ) ; xx [ 19 ] = xx [ 15 ] - (
motionData [ 78 ] * motionData [ 78 ] + motionData [ 79 ] * motionData [ 79 ]
) * xx [ 13 ] ; pm_math_Quaternion_inverseXform_ra ( xx + 5 , xx + 17 , xx +
20 ) ; xx [ 5 ] = - xx [ 20 ] ; xx [ 6 ] = - xx [ 21 ] ; xx [ 7 ] = - xx [ 22
] ; pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 5 , xx + 17 ) ; xx [ 5 ]
= 0.0 ; xx [ 6 ] = xx [ 5 ] ; xx [ 7 ] = xx [ 5 ] ; xx [ 8 ] = xx [ 15 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 9 , xx + 6 , xx + 21 ) ; xx [ 1 ] =
0.6970892476441968 ; xx [ 4 ] = 0.5 ; xx [ 5 ] = xx [ 4 ] * state [ 16 ] ; xx
[ 9 ] = cos ( xx [ 5 ] ) ; xx [ 10 ] = 0.1186026172512557 ; xx [ 11 ] = sin (
xx [ 5 ] ) ; xx [ 5 ] = xx [ 1 ] * xx [ 9 ] - xx [ 10 ] * xx [ 11 ] ; xx [ 12
] = xx [ 10 ] * xx [ 9 ] ; xx [ 9 ] = xx [ 1 ] * xx [ 11 ] ; xx [ 11 ] = xx [
12 ] + xx [ 9 ] ; xx [ 17 ] = xx [ 9 ] + xx [ 12 ] ; xx [ 24 ] = xx [ 5 ] ;
xx [ 25 ] = xx [ 11 ] ; xx [ 26 ] = xx [ 5 ] ; xx [ 27 ] = xx [ 17 ] ; xx [
28 ] = motionData [ 49 ] ; xx [ 29 ] = motionData [ 50 ] ; xx [ 30 ] =
motionData [ 51 ] ; xx [ 31 ] = motionData [ 52 ] ;
pm_math_Quaternion_compose_ra ( xx + 24 , xx + 28 , xx + 32 ) ; xx [ 9 ] =
0.1383748705426791 ; xx [ 12 ] = xx [ 14 ] * xx [ 9 ] ; xx [ 14 ] =
0.06918743527133955 ; xx [ 20 ] = xx [ 14 ] * xx [ 16 ] ; xx [ 16 ] = xx [ 34
] * xx [ 12 ] + xx [ 35 ] * xx [ 20 ] ; xx [ 21 ] = xx [ 33 ] * xx [ 12 ] ;
xx [ 24 ] = xx [ 33 ] * xx [ 20 ] ; xx [ 25 ] = xx [ 16 ] ; xx [ 26 ] = - xx
[ 21 ] ; xx [ 27 ] = - xx [ 24 ] ; pm_math_Vector3_cross_ra ( xx + 33 , xx +
25 , xx + 28 ) ; xx [ 25 ] = xx [ 11 ] ; xx [ 26 ] = xx [ 5 ] ; xx [ 27 ] =
xx [ 17 ] ; xx [ 31 ] = xx [ 17 ] * motionData [ 53 ] ; xx [ 33 ] = xx [ 17 ]
* motionData [ 54 ] ; xx [ 34 ] = xx [ 11 ] * motionData [ 53 ] + xx [ 5 ] *
motionData [ 54 ] ; xx [ 35 ] = - xx [ 31 ] ; xx [ 36 ] = - xx [ 33 ] ; xx [
37 ] = xx [ 34 ] ; pm_math_Vector3_cross_ra ( xx + 25 , xx + 35 , xx + 38 ) ;
xx [ 25 ] = 0.08603840402471528 ; xx [ 26 ] = xx [ 11 ] * xx [ 25 ] ; xx [ 27
] = xx [ 26 ] * xx [ 5 ] ; xx [ 35 ] = xx [ 17 ] * xx [ 25 ] ; xx [ 36 ] = xx
[ 35 ] * xx [ 5 ] ; xx [ 37 ] = 0.7071067811865476 ; xx [ 41 ] = xx [ 4 ] *
state [ 18 ] ; xx [ 42 ] = xx [ 37 ] * sin ( xx [ 41 ] ) ; xx [ 43 ] = xx [
37 ] * cos ( xx [ 41 ] ) ; xx [ 41 ] = xx [ 42 ] - xx [ 43 ] ; xx [ 44 ] = xx
[ 42 ] + xx [ 43 ] ; xx [ 42 ] = xx [ 41 ] * motionData [ 45 ] - xx [ 44 ] *
motionData [ 42 ] ; xx [ 43 ] = xx [ 42 ] * xx [ 14 ] ; xx [ 45 ] = xx [ 41 ]
* motionData [ 42 ] + xx [ 44 ] * motionData [ 45 ] ; xx [ 46 ] = xx [ 41 ] *
motionData [ 43 ] - xx [ 44 ] * motionData [ 44 ] ; xx [ 47 ] = xx [ 46 ] *
xx [ 14 ] ; xx [ 48 ] = xx [ 41 ] * motionData [ 44 ] + xx [ 44 ] *
motionData [ 43 ] ; xx [ 49 ] = motionData [ 43 ] ; xx [ 50 ] = motionData [
44 ] ; xx [ 51 ] = motionData [ 45 ] ; xx [ 52 ] = 0.02913743527133955 ; xx [
53 ] = xx [ 44 ] * xx [ 52 ] ; xx [ 54 ] = xx [ 52 ] - xx [ 13 ] * xx [ 44 ]
* xx [ 53 ] ; xx [ 44 ] = xx [ 54 ] * motionData [ 45 ] ; xx [ 55 ] = xx [ 13
] * xx [ 53 ] * xx [ 41 ] ; xx [ 41 ] = xx [ 55 ] * motionData [ 45 ] ; xx [
53 ] = xx [ 54 ] * motionData [ 43 ] - xx [ 55 ] * motionData [ 44 ] ; xx [
56 ] = - xx [ 44 ] ; xx [ 57 ] = xx [ 41 ] ; xx [ 58 ] = xx [ 53 ] ;
pm_math_Vector3_cross_ra ( xx + 49 , xx + 56 , xx + 59 ) ; xx [ 49 ] = xx [ 4
] * state [ 22 ] ; xx [ 50 ] = sin ( xx [ 49 ] ) ; xx [ 51 ] = xx [ 1 ] * xx
[ 50 ] ; xx [ 56 ] = cos ( xx [ 49 ] ) ; xx [ 49 ] = xx [ 10 ] * xx [ 56 ] ;
xx [ 57 ] = xx [ 51 ] + xx [ 49 ] ; xx [ 58 ] = 0.085075 ; xx [ 62 ] = xx [
57 ] * xx [ 58 ] ; xx [ 63 ] = xx [ 10 ] * xx [ 50 ] - xx [ 1 ] * xx [ 56 ] ;
xx [ 50 ] = xx [ 62 ] * xx [ 63 ] ; xx [ 56 ] = xx [ 49 ] + xx [ 51 ] ; xx [
49 ] = xx [ 56 ] * xx [ 58 ] ; xx [ 51 ] = xx [ 49 ] * xx [ 63 ] ; xx [ 63 ]
= xx [ 13 ] * ( xx [ 50 ] - xx [ 51 ] ) ; xx [ 64 ] = 0.17015 ; xx [ 65 ] = (
xx [ 57 ] * xx [ 62 ] + xx [ 56 ] * xx [ 49 ] ) * xx [ 13 ] ; xx [ 49 ] = (
xx [ 51 ] + xx [ 50 ] ) * xx [ 13 ] ; xx [ 66 ] = - motionData [ 84 ] ; xx [
67 ] = - motionData [ 85 ] ; xx [ 68 ] = - motionData [ 86 ] ; xx [ 69 ] = -
motionData [ 87 ] ; xx [ 70 ] = motionData [ 70 ] ; xx [ 71 ] = motionData [
71 ] ; xx [ 72 ] = motionData [ 72 ] ; xx [ 73 ] = motionData [ 73 ] ;
pm_math_Quaternion_inverseCompose_ra ( xx + 66 , xx + 70 , xx + 74 ) ; xx [
66 ] = motionData [ 84 ] ; xx [ 67 ] = motionData [ 85 ] ; xx [ 68 ] =
motionData [ 86 ] ; xx [ 69 ] = motionData [ 87 ] ; xx [ 50 ] = motionData [
28 ] * motionData [ 29 ] + motionData [ 30 ] * motionData [ 31 ] ; xx [ 51 ]
= xx [ 15 ] - ( motionData [ 29 ] * motionData [ 29 ] + motionData [ 30 ] *
motionData [ 30 ] ) * xx [ 13 ] ; xx [ 78 ] = xx [ 13 ] * ( motionData [ 29 ]
* motionData [ 31 ] - motionData [ 28 ] * motionData [ 30 ] ) ; xx [ 79 ] =
xx [ 50 ] * xx [ 13 ] ; xx [ 80 ] = xx [ 51 ] ; pm_math_Quaternion_xform_ra (
xx + 66 , xx + 78 , xx + 81 ) ; pm_math_Quaternion_inverseXform_ra ( xx + 70
, xx + 81 , xx + 66 ) ; xx [ 78 ] = - xx [ 66 ] ; xx [ 79 ] = - xx [ 67 ] ;
xx [ 80 ] = - xx [ 68 ] ; pm_math_Quaternion_compDeriv_ra ( xx + 74 , xx + 78
, xx + 66 ) ; xx [ 78 ] = ( motionData [ 84 ] * motionData [ 86 ] +
motionData [ 85 ] * motionData [ 87 ] ) * xx [ 13 ] ; xx [ 79 ] = xx [ 13 ] *
( motionData [ 86 ] * motionData [ 87 ] - motionData [ 84 ] * motionData [ 85
] ) ; xx [ 80 ] = xx [ 15 ] - ( motionData [ 85 ] * motionData [ 85 ] +
motionData [ 86 ] * motionData [ 86 ] ) * xx [ 13 ] ;
pm_math_Quaternion_inverseXform_ra ( xx + 70 , xx + 78 , xx + 81 ) ; xx [ 70
] = - xx [ 81 ] ; xx [ 71 ] = - xx [ 82 ] ; xx [ 72 ] = - xx [ 83 ] ;
pm_math_Quaternion_compDeriv_ra ( xx + 74 , xx + 70 , xx + 78 ) ;
pm_math_Quaternion_compDeriv_ra ( xx + 74 , xx + 6 , xx + 70 ) ; xx [ 6 ] =
xx [ 4 ] * state [ 10 ] ; xx [ 7 ] = cos ( xx [ 6 ] ) ; xx [ 8 ] = sin ( xx [
6 ] ) ; xx [ 6 ] = xx [ 1 ] * xx [ 7 ] - xx [ 10 ] * xx [ 8 ] ; xx [ 15 ] =
xx [ 10 ] * xx [ 7 ] ; xx [ 7 ] = xx [ 1 ] * xx [ 8 ] ; xx [ 8 ] = xx [ 15 ]
+ xx [ 7 ] ; xx [ 56 ] = xx [ 7 ] + xx [ 15 ] ; xx [ 73 ] = xx [ 6 ] ; xx [
74 ] = xx [ 8 ] ; xx [ 75 ] = xx [ 6 ] ; xx [ 76 ] = xx [ 56 ] ; xx [ 81 ] =
motionData [ 28 ] ; xx [ 82 ] = motionData [ 29 ] ; xx [ 83 ] = motionData [
30 ] ; xx [ 84 ] = motionData [ 31 ] ; pm_math_Quaternion_compose_ra ( xx +
73 , xx + 81 , xx + 85 ) ; xx [ 7 ] = xx [ 50 ] * xx [ 9 ] ; xx [ 9 ] = xx [
14 ] * xx [ 51 ] ; xx [ 15 ] = xx [ 87 ] * xx [ 7 ] + xx [ 88 ] * xx [ 9 ] ;
xx [ 50 ] = xx [ 86 ] * xx [ 7 ] ; xx [ 51 ] = xx [ 86 ] * xx [ 9 ] ; xx [ 73
] = xx [ 15 ] ; xx [ 74 ] = - xx [ 50 ] ; xx [ 75 ] = - xx [ 51 ] ;
pm_math_Vector3_cross_ra ( xx + 86 , xx + 73 , xx + 76 ) ; xx [ 73 ] = xx [ 8
] ; xx [ 74 ] = xx [ 6 ] ; xx [ 75 ] = xx [ 56 ] ; xx [ 57 ] = xx [ 56 ] *
motionData [ 32 ] ; xx [ 62 ] = xx [ 56 ] * motionData [ 33 ] ; xx [ 66 ] =
xx [ 8 ] * motionData [ 32 ] + xx [ 6 ] * motionData [ 33 ] ; xx [ 81 ] = -
xx [ 57 ] ; xx [ 82 ] = - xx [ 62 ] ; xx [ 83 ] = xx [ 66 ] ;
pm_math_Vector3_cross_ra ( xx + 73 , xx + 81 , xx + 86 ) ; xx [ 69 ] = xx [ 8
] * xx [ 25 ] ; xx [ 70 ] = xx [ 69 ] * xx [ 6 ] ; xx [ 73 ] = xx [ 56 ] * xx
[ 25 ] ; xx [ 74 ] = xx [ 73 ] * xx [ 6 ] ; xx [ 75 ] = xx [ 4 ] * state [ 12
] ; xx [ 81 ] = xx [ 37 ] * sin ( xx [ 75 ] ) ; xx [ 82 ] = xx [ 37 ] * cos (
xx [ 75 ] ) ; xx [ 37 ] = xx [ 81 ] - xx [ 82 ] ; xx [ 75 ] = xx [ 81 ] + xx
[ 82 ] ; xx [ 81 ] = xx [ 37 ] * motionData [ 24 ] - xx [ 75 ] * motionData [
21 ] ; xx [ 82 ] = xx [ 81 ] * xx [ 14 ] ; xx [ 83 ] = xx [ 37 ] * motionData
[ 21 ] + xx [ 75 ] * motionData [ 24 ] ; xx [ 84 ] = xx [ 37 ] * motionData [
22 ] - xx [ 75 ] * motionData [ 23 ] ; xx [ 89 ] = xx [ 84 ] * xx [ 14 ] ; xx
[ 90 ] = xx [ 37 ] * motionData [ 23 ] + xx [ 75 ] * motionData [ 22 ] ; xx [
91 ] = motionData [ 22 ] ; xx [ 92 ] = motionData [ 23 ] ; xx [ 93 ] =
motionData [ 24 ] ; xx [ 94 ] = xx [ 75 ] * xx [ 52 ] ; xx [ 95 ] = xx [ 52 ]
- xx [ 13 ] * xx [ 75 ] * xx [ 94 ] ; xx [ 52 ] = xx [ 95 ] * motionData [ 24
] ; xx [ 75 ] = xx [ 13 ] * xx [ 94 ] * xx [ 37 ] ; xx [ 37 ] = xx [ 75 ] *
motionData [ 24 ] ; xx [ 94 ] = xx [ 95 ] * motionData [ 22 ] - xx [ 75 ] *
motionData [ 23 ] ; xx [ 96 ] = - xx [ 52 ] ; xx [ 97 ] = xx [ 37 ] ; xx [ 98
] = xx [ 94 ] ; pm_math_Vector3_cross_ra ( xx + 91 , xx + 96 , xx + 99 ) ; xx
[ 91 ] = xx [ 4 ] * state [ 24 ] ; xx [ 4 ] = sin ( xx [ 91 ] ) ; xx [ 92 ] =
xx [ 1 ] * xx [ 4 ] ; xx [ 93 ] = cos ( xx [ 91 ] ) ; xx [ 91 ] = xx [ 10 ] *
xx [ 93 ] ; xx [ 96 ] = xx [ 92 ] + xx [ 91 ] ; xx [ 97 ] = xx [ 96 ] * xx [
58 ] ; xx [ 98 ] = xx [ 10 ] * xx [ 4 ] - xx [ 1 ] * xx [ 93 ] ; xx [ 1 ] =
xx [ 97 ] * xx [ 98 ] ; xx [ 4 ] = xx [ 91 ] + xx [ 92 ] ; xx [ 10 ] = xx [ 4
] * xx [ 58 ] ; xx [ 58 ] = xx [ 10 ] * xx [ 98 ] ; xx [ 91 ] = xx [ 13 ] * (
xx [ 1 ] - xx [ 58 ] ) ; xx [ 92 ] = ( xx [ 96 ] * xx [ 97 ] + xx [ 4 ] * xx
[ 10 ] ) * xx [ 13 ] ; xx [ 4 ] = ( xx [ 58 ] + xx [ 1 ] ) * xx [ 13 ] ; J [
8 ] = xx [ 2 ] ; J [ 9 ] = xx [ 18 ] ; J [ 11 ] = xx [ 22 ] ; J [ 21 ] = xx [
3 ] ; J [ 22 ] = xx [ 19 ] ; J [ 24 ] = xx [ 23 ] ; J [ 34 ] = - ( xx [ 13 ]
* ( xx [ 28 ] + xx [ 16 ] * xx [ 32 ] ) + xx [ 13 ] * ( xx [ 38 ] - xx [ 31 ]
* xx [ 5 ] ) - motionData [ 54 ] + xx [ 13 ] * ( xx [ 27 ] - xx [ 36 ] ) ) ;
J [ 35 ] = - ( xx [ 13 ] * ( xx [ 43 ] * xx [ 45 ] - xx [ 47 ] * xx [ 48 ] )
+ xx [ 13 ] * ( xx [ 59 ] - xx [ 44 ] * motionData [ 42 ] ) + xx [ 55 ] ) ; J
[ 37 ] = xx [ 63 ] + xx [ 63 ] ; J [ 47 ] = - ( ( xx [ 29 ] - xx [ 32 ] * xx
[ 21 ] ) * xx [ 13 ] - xx [ 20 ] + motionData [ 53 ] + xx [ 13 ] * ( xx [ 39
] - xx [ 33 ] * xx [ 5 ] ) - ( xx [ 17 ] * xx [ 35 ] + xx [ 11 ] * xx [ 26 ]
) * xx [ 13 ] + xx [ 25 ] ) ; J [ 48 ] = - ( xx [ 54 ] + xx [ 13 ] * ( xx [
60 ] + xx [ 41 ] * motionData [ 42 ] ) + ( xx [ 42 ] * xx [ 43 ] + xx [ 46 ]
* xx [ 47 ] ) * xx [ 13 ] - xx [ 14 ] ) ; J [ 50 ] = xx [ 64 ] - ( xx [ 65 ]
+ xx [ 65 ] ) ; J [ 60 ] = - ( ( xx [ 30 ] - xx [ 32 ] * xx [ 24 ] ) * xx [
13 ] + xx [ 12 ] + ( xx [ 34 ] * xx [ 5 ] + xx [ 40 ] ) * xx [ 13 ] + ( xx [
27 ] + xx [ 36 ] ) * xx [ 13 ] ) ; J [ 61 ] = - ( ( xx [ 53 ] * motionData [
42 ] + xx [ 61 ] ) * xx [ 13 ] - ( xx [ 47 ] * xx [ 45 ] + xx [ 43 ] * xx [
48 ] ) * xx [ 13 ] ) ; J [ 63 ] = - ( xx [ 49 ] + xx [ 49 ] ) ; J [ 70 ] = xx
[ 67 ] ; J [ 71 ] = xx [ 79 ] ; J [ 77 ] = xx [ 71 ] ; J [ 83 ] = xx [ 68 ] ;
J [ 84 ] = xx [ 80 ] ; J [ 90 ] = xx [ 72 ] ; J [ 96 ] = - ( xx [ 13 ] * ( xx
[ 76 ] + xx [ 15 ] * xx [ 85 ] ) + xx [ 13 ] * ( xx [ 86 ] - xx [ 57 ] * xx [
6 ] ) - motionData [ 33 ] + xx [ 13 ] * ( xx [ 70 ] - xx [ 74 ] ) ) ; J [ 97
] = - ( xx [ 13 ] * ( xx [ 82 ] * xx [ 83 ] - xx [ 89 ] * xx [ 90 ] ) + xx [
13 ] * ( xx [ 99 ] - xx [ 52 ] * motionData [ 21 ] ) + xx [ 75 ] ) ; J [ 103
] = xx [ 91 ] + xx [ 91 ] ; J [ 109 ] = - ( ( xx [ 77 ] - xx [ 85 ] * xx [ 50
] ) * xx [ 13 ] - xx [ 9 ] + motionData [ 32 ] + xx [ 13 ] * ( xx [ 87 ] - xx
[ 62 ] * xx [ 6 ] ) - ( xx [ 56 ] * xx [ 73 ] + xx [ 8 ] * xx [ 69 ] ) * xx [
13 ] + xx [ 25 ] ) ; J [ 110 ] = - ( xx [ 95 ] + xx [ 13 ] * ( xx [ 100 ] +
xx [ 37 ] * motionData [ 21 ] ) + ( xx [ 81 ] * xx [ 82 ] + xx [ 84 ] * xx [
89 ] ) * xx [ 13 ] - xx [ 14 ] ) ; J [ 116 ] = xx [ 64 ] - ( xx [ 92 ] + xx [
92 ] ) ; J [ 122 ] = - ( ( xx [ 78 ] - xx [ 85 ] * xx [ 51 ] ) * xx [ 13 ] +
xx [ 7 ] + ( xx [ 66 ] * xx [ 6 ] + xx [ 88 ] ) * xx [ 13 ] + ( xx [ 70 ] +
xx [ 74 ] ) * xx [ 13 ] ) ; J [ 123 ] = - ( ( xx [ 94 ] * motionData [ 21 ] +
xx [ 101 ] ) * xx [ 13 ] - ( xx [ 89 ] * xx [ 83 ] + xx [ 82 ] * xx [ 90 ] )
* xx [ 13 ] ) ; J [ 129 ] = - ( xx [ 4 ] + xx [ 4 ] ) ; return 10 ; } static
boolean_T isInKinematicSingularity_0 ( const RuntimeDerivedValuesBundle *
rtdv , const int * modeVector , const double * motionData ) { const double *
rtdvd = rtdv -> mDoubles . mValues ; const int * rtdvi = rtdv -> mInts .
mValues ; ( void ) rtdvd ; ( void ) rtdvi ; ( void ) modeVector ; ( void )
motionData ; return 0 ; } static boolean_T isInKinematicSingularity_1 ( const
RuntimeDerivedValuesBundle * rtdv , const int * modeVector , const double *
motionData ) { const double * rtdvd = rtdv -> mDoubles . mValues ; const int
* rtdvi = rtdv -> mInts . mValues ; ( void ) rtdvd ; ( void ) rtdvi ; ( void
) modeVector ; ( void ) motionData ; return 0 ; } boolean_T
series_link_blance_leg_ad6bcbee_1_isInKinematicSingularity ( const void *
mech , const RuntimeDerivedValuesBundle * rtdv , size_t constraintIdx , const
int * modeVector , const double * motionData ) { ( void ) mech ; ( void )
rtdv ; ( void ) modeVector ; ( void ) motionData ; switch ( constraintIdx ) {
case 0 : return isInKinematicSingularity_0 ( rtdv , modeVector , motionData )
; case 1 : return isInKinematicSingularity_1 ( rtdv , modeVector , motionData
) ; } return 0 ; } void series_link_blance_leg_ad6bcbee_1_convertStateVector
( const void * asmMech , const RuntimeDerivedValuesBundle * rtdv , const void
* simMech , const double * asmState , const int * asmModeVector , const int *
simModeVector , double * simState ) { const double * rtdvd = rtdv -> mDoubles
. mValues ; const int * rtdvi = rtdv -> mInts . mValues ; ( void ) asmMech ;
( void ) rtdvd ; ( void ) rtdvi ; ( void ) simMech ; ( void ) asmModeVector ;
( void ) simModeVector ; simState [ 0 ] = asmState [ 0 ] ; simState [ 1 ] =
asmState [ 1 ] ; simState [ 2 ] = asmState [ 2 ] ; simState [ 3 ] = asmState
[ 3 ] ; simState [ 4 ] = asmState [ 4 ] ; simState [ 5 ] = asmState [ 5 ] ;
simState [ 6 ] = asmState [ 6 ] ; simState [ 7 ] = asmState [ 7 ] ; simState
[ 8 ] = asmState [ 8 ] ; simState [ 9 ] = asmState [ 9 ] ; simState [ 10 ] =
asmState [ 10 ] ; simState [ 11 ] = asmState [ 11 ] ; simState [ 12 ] =
asmState [ 12 ] ; simState [ 13 ] = asmState [ 13 ] ; simState [ 14 ] =
asmState [ 14 ] ; simState [ 15 ] = asmState [ 15 ] ; simState [ 16 ] =
asmState [ 16 ] ; simState [ 17 ] = asmState [ 17 ] ; simState [ 18 ] =
asmState [ 18 ] ; simState [ 19 ] = asmState [ 19 ] ; simState [ 20 ] =
asmState [ 20 ] ; simState [ 21 ] = asmState [ 21 ] ; simState [ 22 ] =
asmState [ 22 ] ; simState [ 23 ] = asmState [ 23 ] ; simState [ 24 ] =
asmState [ 24 ] ; simState [ 25 ] = asmState [ 25 ] ; simState [ 26 ] =
asmState [ 26 ] ; simState [ 27 ] = asmState [ 27 ] ; simState [ 28 ] =
asmState [ 28 ] ; simState [ 29 ] = asmState [ 29 ] ; }
