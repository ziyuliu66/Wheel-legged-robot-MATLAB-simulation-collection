#ifndef __series_link_blance_leg_ad6bcbee_1_gateway_h__
#define __series_link_blance_leg_ad6bcbee_1_gateway_h__
#ifdef __cplusplus
extern "C" {
#endif
extern void series_link_blance_leg_ad6bcbee_1_gateway ( void ) ;
#ifdef __cplusplus
}
#endif
#endif
