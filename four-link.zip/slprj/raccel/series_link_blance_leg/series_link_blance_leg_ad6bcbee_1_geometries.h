const sm_core_compiler_Cylinder *
series_link_blance_leg_ad6bcbee_1_geometry_0 ( const
RuntimeDerivedValuesBundle * rtdv ) ; const sm_core_compiler_Brick *
series_link_blance_leg_ad6bcbee_1_geometry_1 ( const
RuntimeDerivedValuesBundle * rtdv ) ; struct RuntimeDerivedValuesBundleTag ;
void series_link_blance_leg_ad6bcbee_1_initializeGeometries ( const struct
RuntimeDerivedValuesBundleTag * rtdv ) ;
