#include "series_link_blance_leg.h"
#include "rtwtypes.h"
#include "series_link_blance_leg_private.h"
#include "mwmathutil.h"
#include <string.h>
#include <stddef.h>
#include "rt_logging_mmi.h"
#include "series_link_blance_leg_capi.h"
#include "series_link_blance_leg_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 2 , & stopRequested ) ; }
rtExtModeShutdown ( 2 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 0 ; int_T gbl_raccel_NumST = 3 ; const char_T
* gbl_raccel_Version = "9.8 (R2022b) 13-May-2022" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes (
SimStruct * S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
B rtB ; X rtX ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS =
& model_S ; void chostctikr ( const real_T j5dtsvyddf [ 3 ] , real_T
hflgveddoz , jyjoxr5fwj * localB ) { localB -> g1y4drz24r = j5dtsvyddf [ 0 ]
; localB -> g1y4drz24r = hflgveddoz * localB -> g1y4drz24r + j5dtsvyddf [ 1 ]
; localB -> g1y4drz24r = hflgveddoz * localB -> g1y4drz24r + j5dtsvyddf [ 2 ]
; } void cxdl3p2hn2 ( const real_T ebf03v2ull [ 2 ] , real_T mnpaptzquf ,
nstzhfyemr * localB ) { localB -> ce51yimi3b = ebf03v2ull [ 0 ] ; localB ->
ce51yimi3b = mnpaptzquf * localB -> ce51yimi3b + ebf03v2ull [ 1 ] ; } void
fjhrpzveoe ( real_T dd1my3yebx , real_T lvb0fbexgi , p00rr42fc4 * localB ) {
real_T a ; real_T b_a ; real_T c_a ; a = muDoubleScalarSin ( lvb0fbexgi +
0.78539816339744828 ) ; b_a = muDoubleScalarSin ( lvb0fbexgi +
0.78539816339744828 ) ; c_a = ( ( ( 0.027225000000000003 - muDoubleScalarCos
( lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) -
0.028900000000000006 ) + 0.0064 ) + 0.0016 ; localB -> grfdzphf00 = ( ( ( (
muDoubleScalarCos ( lvb0fbexgi + 0.78539816339744828 ) * 0.08 /
muDoubleScalarSqrt ( ( 0.027225000000000003 - muDoubleScalarCos ( lvb0fbexgi
+ 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) + 0.0064 ) - a * a * 0.001056
/ muDoubleScalarPower ( ( 0.027225000000000003 - muDoubleScalarCos (
lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) + 0.0064 , 1.5 ) )
/ muDoubleScalarSqrt ( 1.0 - b_a * b_a * 0.0064 / ( ( 0.027225000000000003 -
muDoubleScalarCos ( lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 )
+ 0.0064 ) ) - ( muDoubleScalarSin ( lvb0fbexgi + 0.78539816339744828 ) *
0.013200000000000002 / ( muDoubleScalarSqrt ( ( 0.027225000000000003 -
muDoubleScalarCos ( lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 )
+ 0.0064 ) * 0.04 ) - ( ( ( ( 0.027225000000000003 - muDoubleScalarCos (
lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) -
0.028900000000000006 ) + 0.0064 ) + 0.0016 ) * ( muDoubleScalarSin (
lvb0fbexgi + 0.78539816339744828 ) * 0.013200000000000002 ) / (
muDoubleScalarPower ( ( 0.027225000000000003 - muDoubleScalarCos ( lvb0fbexgi
+ 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) + 0.0064 , 1.5 ) * 0.08 ) ) /
muDoubleScalarSqrt ( 1.0 - c_a * c_a / ( ( ( 0.027225000000000003 -
muDoubleScalarCos ( lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 )
+ 0.0064 ) * 0.0064 ) ) ) + 1.0 ) * ( muDoubleScalarCos ( (
muDoubleScalarAcos ( ( ( ( ( 0.027225000000000003 - muDoubleScalarCos (
lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) -
0.028900000000000006 ) + 0.0064 ) + 0.0016 ) / ( muDoubleScalarSqrt ( (
0.027225000000000003 - muDoubleScalarCos ( lvb0fbexgi + 0.78539816339744828 )
* 2.0 * 0.165 * 0.08 ) + 0.0064 ) * 0.08 ) ) + lvb0fbexgi ) +
muDoubleScalarAsin ( muDoubleScalarSin ( lvb0fbexgi + 0.78539816339744828 ) *
0.08 / muDoubleScalarSqrt ( ( 0.027225000000000003 - muDoubleScalarCos (
lvb0fbexgi + 0.78539816339744828 ) * 2.0 * 0.165 * 0.08 ) + 0.0064 ) ) ) *
0.163 ) + 0.165 * muDoubleScalarCos ( lvb0fbexgi ) ) * dd1my3yebx ; } void
lrfol15y4l ( real_T n03px11pkt , hgh2bvor5a * localB ) { real_T l5 ; l5 =
muDoubleScalarSqrt ( 0.033625 - muDoubleScalarCos ( n03px11pkt +
0.78539816339744828 ) * 0.026400000000000003 ) ; localB -> evq2mmxdxv =
muDoubleScalarSin ( ( muDoubleScalarAsin ( muDoubleScalarSin ( n03px11pkt +
0.78539816339744828 ) * 0.08 / l5 ) + n03px11pkt ) + muDoubleScalarAcos ( ( (
l5 * l5 + 0.0016 ) - 0.028900000000000006 ) / ( 0.08 * l5 ) ) ) * 0.163 +
0.165 * muDoubleScalarSin ( n03px11pkt ) ; } void MdlInitialize ( void ) {
rtX . jtjnlz2ruo = rtP . Integrator1_IC ; rtX . cvhtys1nmg = rtP .
Integrator2_IC ; rtX . k2pkguag0f = rtP .
PIDController2_InitialConditionForIntegrator ; rtX . enclntnpgb = rtP .
PIDController2_InitialConditionForFilter ; rtX . mgxiehzkbv = rtP .
PIDController1_InitialConditionForIntegrator ; rtX . bdi5kb2v3m = rtP .
PIDController1_InitialConditionForFilter ; rtX . m5olntpqfc = rtP .
Integrator_IC ; } void MdlStart ( void ) { CXPtMax * _rtXPerturbMax ; CXPtMin
* _rtXPerturbMin ; NeModelParameters modelParameters ; NeModelParameters
modelParameters_e ; NeModelParameters modelParameters_p ; NeslSimulationData
* simulationData ; NeslSimulator * tmp ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; NeuDiagnosticTree *
diagnosticTree_e ; NeuDiagnosticTree * diagnosticTree_i ; NeuDiagnosticTree *
diagnosticTree_p ; char * msg ; char * msg_e ; char * msg_i ; char * msg_p ;
real_T tmp_m [ 16 ] ; real_T time ; real_T tmp_e ; int32_T tmp_i ; int_T
tmp_g [ 5 ] ; boolean_T tmp_p ; boolean_T val ; { bool
externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} _rtXPerturbMax = ( ( CXPtMax * ) ssGetJacobianPerturbationBoundsMaxVec (
rtS ) ) ; _rtXPerturbMin = ( ( CXPtMin * )
ssGetJacobianPerturbationBoundsMinVec ( rtS ) ) ; tmp = nesl_lease_simulator
( "series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" ,
0 , 0 ) ; rtDW . bvcs1a5kon = ( void * ) tmp ; tmp_p = pointer_is_null ( rtDW
. bvcs1a5kon ) ; if ( tmp_p ) { series_link_blance_leg_ad6bcbee_1_gateway ( )
; tmp = nesl_lease_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" , 0
, 0 ) ; rtDW . bvcs1a5kon = ( void * ) tmp ; }
slsaSaveRawMemoryForSimTargetOP ( rtS ,
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_100" ,
( void * * ) ( & rtDW . bvcs1a5kon ) , 0U * sizeof ( real_T ) ,
nesl_save_simdata , nesl_restore_simdata ) ; simulationData =
nesl_create_simulation_data ( ) ; rtDW . na54detrfm = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; rtDW .
ewdahqbgsp = ( void * ) diagnosticManager ; modelParameters . mSolverType =
NE_SOLVER_TYPE_ODE ; modelParameters . mSolverAbsTol = 0.001 ;
modelParameters . mSolverRelTol = 0.001 ; modelParameters .
mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO ; modelParameters . mStartTime =
0.0 ; modelParameters . mLoadInitialState = false ; modelParameters .
mUseSimState = false ; modelParameters . mLinTrimCompile = false ;
modelParameters . mLoggingMode = SSC_LOGGING_NONE ; modelParameters .
mRTWModifiedTimeStamp = 6.26195369E+8 ; modelParameters . mZcDisabled = false
; tmp_e = 0.001 ; modelParameters . mSolverTolerance = tmp_e ; tmp_e = 0.0 ;
modelParameters . mFixedStepSize = tmp_e ; tmp_p = true ; modelParameters .
mVariableStepSolver = tmp_p ; tmp_p = false ; modelParameters . mIsUsingODEN
= tmp_p ; tmp_p = slIsRapidAcceleratorSimulating ( ) ; val =
ssGetGlobalInitialStatesAvailable ( rtS ) ; if ( tmp_p ) { val = ( val &&
ssIsFirstInitCond ( rtS ) ) ; } modelParameters . mLoadInitialState = val ;
modelParameters . mZcDisabled = false ; diagnosticManager = (
NeuDiagnosticManager * ) rtDW . ewdahqbgsp ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
nesl_initialize_simulator ( ( NeslSimulator * ) rtDW . bvcs1a5kon , &
modelParameters , diagnosticManager ) ; if ( tmp_i != 0 ) { tmp_p =
error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp_p ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( rtS , msg ) ; } }
simulationData = ( NeslSimulationData * ) rtDW . na54detrfm ; time = ssGetT (
rtS ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData
-> mTime . mX = & time ; simulationData -> mData -> mContStates . mN = 30 ;
simulationData -> mData -> mContStates . mX = & rtX . azpqecuyl0 [ 0 ] ;
simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData ->
mDiscStates . mX = & rtDW . dmkrz0jizc ; simulationData -> mData ->
mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX = & rtDW .
kfkrdvou4e ; tmp_p = ( ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS
) -> foundContZcEvents ) ; simulationData -> mData -> mFoundZcEvents = tmp_p
; simulationData -> mData -> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ;
tmp_p = ( ssGetMdlInfoPtr ( rtS ) -> mdlFlags . solverAssertCheck == 1U ) ;
simulationData -> mData -> mIsSolverAssertCheck = tmp_p ; tmp_p =
ssIsSolverCheckingCIC ( rtS ) ; simulationData -> mData ->
mIsSolverCheckingCIC = tmp_p ; tmp_p = ssIsSolverComputingJacobian ( rtS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp_p ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( rtS ) != 0 ) ;
tmp_p = ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = tmp_p ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_g [ 0 ] = 0 ;
tmp_m [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_m [ 1 ] = rtB . dxmcbrhf1p [ 1 ] ;
tmp_m [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_m [ 3 ] = rtB . dxmcbrhf1p [ 3 ] ;
tmp_g [ 1 ] = 4 ; tmp_m [ 4 ] = rtB . kwyo50invf [ 0 ] ; tmp_m [ 5 ] = rtB .
kwyo50invf [ 1 ] ; tmp_m [ 6 ] = rtB . kwyo50invf [ 2 ] ; tmp_m [ 7 ] = rtB .
kwyo50invf [ 3 ] ; tmp_g [ 2 ] = 8 ; tmp_m [ 8 ] = rtB . cgb3czccvw [ 0 ] ;
tmp_m [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_m [ 10 ] = rtB . cgb3czccvw [ 2 ]
; tmp_m [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_g [ 3 ] = 12 ; tmp_m [ 12 ] =
rtB . nq5uupkk3g [ 0 ] ; tmp_m [ 13 ] = rtB . nq5uupkk3g [ 1 ] ; tmp_m [ 14 ]
= rtB . nq5uupkk3g [ 2 ] ; tmp_m [ 15 ] = rtB . nq5uupkk3g [ 3 ] ; tmp_g [ 4
] = 16 ; simulationData -> mData -> mInputValues . mN = 16 ; simulationData
-> mData -> mInputValues . mX = & tmp_m [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 5 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_g [ 0 ] ; simulationData -> mData -> mNumjacDxLo . mN = 30 ;
simulationData -> mData -> mNumjacDxLo . mX = & _rtXPerturbMin -> azpqecuyl0
[ 0 ] ; simulationData -> mData -> mNumjacDxHi . mN = 30 ; simulationData ->
mData -> mNumjacDxHi . mX = & _rtXPerturbMax -> azpqecuyl0 [ 0 ] ;
diagnosticManager = ( NeuDiagnosticManager * ) rtDW . ewdahqbgsp ;
diagnosticTree_p = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW
. bvcs1a5kon , NESL_SIM_NUMJAC_DX_BOUNDS , simulationData , diagnosticManager
) ; if ( tmp_i != 0 ) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus (
rtS ) ) ; if ( tmp_p ) { msg_p = rtw_diagnostics_msg ( diagnosticTree_p ) ;
ssSetErrorStatus ( rtS , msg_p ) ; } } tmp = nesl_lease_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" , 1
, 0 ) ; rtDW . hjmyc4f4pq = ( void * ) tmp ; tmp_p = pointer_is_null ( rtDW .
hjmyc4f4pq ) ; if ( tmp_p ) { series_link_blance_leg_ad6bcbee_1_gateway ( ) ;
tmp = nesl_lease_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" , 1
, 0 ) ; rtDW . hjmyc4f4pq = ( void * ) tmp ; }
slsaSaveRawMemoryForSimTargetOP ( rtS ,
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_110" ,
( void * * ) ( & rtDW . hjmyc4f4pq ) , 0U * sizeof ( real_T ) ,
nesl_save_simdata , nesl_restore_simdata ) ; simulationData =
nesl_create_simulation_data ( ) ; rtDW . gfmsvy5x3x = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; rtDW .
bwqmy33xj5 = ( void * ) diagnosticManager ; modelParameters_p . mSolverType =
NE_SOLVER_TYPE_ODE ; modelParameters_p . mSolverAbsTol = 0.001 ;
modelParameters_p . mSolverRelTol = 0.001 ; modelParameters_p .
mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO ; modelParameters_p . mStartTime =
0.0 ; modelParameters_p . mLoadInitialState = false ; modelParameters_p .
mUseSimState = false ; modelParameters_p . mLinTrimCompile = false ;
modelParameters_p . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_p .
mRTWModifiedTimeStamp = 6.26195369E+8 ; modelParameters_p . mZcDisabled =
false ; tmp_e = 0.001 ; modelParameters_p . mSolverTolerance = tmp_e ; tmp_e
= 0.0 ; modelParameters_p . mFixedStepSize = tmp_e ; tmp_p = true ;
modelParameters_p . mVariableStepSolver = tmp_p ; tmp_p = false ;
modelParameters_p . mIsUsingODEN = tmp_p ; tmp_p =
slIsRapidAcceleratorSimulating ( ) ; val = ssGetGlobalInitialStatesAvailable
( rtS ) ; if ( tmp_p ) { val = ( val && ssIsFirstInitCond ( rtS ) ) ; }
modelParameters_p . mLoadInitialState = val ; modelParameters_p . mZcDisabled
= false ; diagnosticManager = ( NeuDiagnosticManager * ) rtDW . bwqmy33xj5 ;
diagnosticTree_e = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = nesl_initialize_simulator ( ( NeslSimulator * )
rtDW . hjmyc4f4pq , & modelParameters_p , diagnosticManager ) ; if ( tmp_i !=
0 ) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp_p
) { msg_e = rtw_diagnostics_msg ( diagnosticTree_e ) ; ssSetErrorStatus ( rtS
, msg_e ) ; } } tmp = nesl_lease_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" , 1
, 1 ) ; rtDW . azs3p32xzo = ( void * ) tmp ; tmp_p = pointer_is_null ( rtDW .
azs3p32xzo ) ; if ( tmp_p ) { series_link_blance_leg_ad6bcbee_1_gateway ( ) ;
tmp = nesl_lease_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" , 1
, 1 ) ; rtDW . azs3p32xzo = ( void * ) tmp ; }
slsaSaveRawMemoryForSimTargetOP ( rtS ,
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_111" ,
( void * * ) ( & rtDW . azs3p32xzo ) , 0U * sizeof ( real_T ) ,
nesl_save_simdata , nesl_restore_simdata ) ; simulationData =
nesl_create_simulation_data ( ) ; rtDW . aoqtp4iunx = ( void * )
simulationData ; diagnosticManager = rtw_create_diagnostics ( ) ; rtDW .
non5z2jdlx = ( void * ) diagnosticManager ; modelParameters_e . mSolverType =
NE_SOLVER_TYPE_ODE ; modelParameters_e . mSolverAbsTol = 0.001 ;
modelParameters_e . mSolverRelTol = 0.001 ; modelParameters_e .
mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO ; modelParameters_e . mStartTime =
0.0 ; modelParameters_e . mLoadInitialState = false ; modelParameters_e .
mUseSimState = false ; modelParameters_e . mLinTrimCompile = false ;
modelParameters_e . mLoggingMode = SSC_LOGGING_NONE ; modelParameters_e .
mRTWModifiedTimeStamp = 6.26195369E+8 ; modelParameters_e . mZcDisabled =
false ; tmp_e = 0.001 ; modelParameters_e . mSolverTolerance = tmp_e ; tmp_e
= 0.0 ; modelParameters_e . mFixedStepSize = tmp_e ; tmp_p = true ;
modelParameters_e . mVariableStepSolver = tmp_p ; tmp_p = false ;
modelParameters_e . mIsUsingODEN = tmp_p ; tmp_p =
slIsRapidAcceleratorSimulating ( ) ; val = ssGetGlobalInitialStatesAvailable
( rtS ) ; if ( tmp_p ) { val = ( val && ssIsFirstInitCond ( rtS ) ) ; }
modelParameters_e . mLoadInitialState = val ; modelParameters_e . mZcDisabled
= false ; diagnosticManager = ( NeuDiagnosticManager * ) rtDW . non5z2jdlx ;
diagnosticTree_i = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = nesl_initialize_simulator ( ( NeslSimulator * )
rtDW . azs3p32xzo , & modelParameters_e , diagnosticManager ) ; if ( tmp_i !=
0 ) { tmp_p = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp_p
) { msg_i = rtw_diagnostics_msg ( diagnosticTree_i ) ; ssSetErrorStatus ( rtS
, msg_i ) ; } } MdlInitialize ( ) ; } void MdlOutputs ( int_T tid ) { real_T
ezbbib1nrt ; real_T n2brah0n1g ; real_T jo0ayn0ziv ; real_T p2urj1vs2m ;
NeslSimulationData * simulationData ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; NeuDiagnosticTree *
diagnosticTree_e ; NeuDiagnosticTree * diagnosticTree_p ; char * msg ; char *
msg_e ; char * msg_p ; real_T tmp_j [ 46 ] ; real_T tmp_m [ 46 ] ; real_T
tmp_p [ 16 ] ; real_T cb0wfta1hx ; real_T gis3uzs0hi ; real_T hpcwngrjtp ;
real_T m2s3irkxks ; real_T mbuu4zh5ok ; real_T n0qruvuzgs ; real_T nryqhtzp0s
; real_T time ; real_T time_e ; real_T time_g ; real_T time_i ; real_T time_m
; real_T time_p ; real_T tmp_c ; real_T tmp_k ; int32_T tmp_i ; int_T tmp_f [
6 ] ; int_T tmp_g [ 6 ] ; int_T tmp_e [ 5 ] ; boolean_T tmp ; rtB .
pauztuh2hc = rtX . jtjnlz2ruo ; simulationData = ( NeslSimulationData * )
rtDW . na54detrfm ; time = ssGetT ( rtS ) ; simulationData -> mData -> mTime
. mN = 1 ; simulationData -> mData -> mTime . mX = & time ; simulationData ->
mData -> mContStates . mN = 30 ; simulationData -> mData -> mContStates . mX
= & rtX . azpqecuyl0 [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0
; simulationData -> mData -> mDiscStates . mX = & rtDW . dmkrz0jizc ;
simulationData -> mData -> mModeVector . mN = 0 ; simulationData -> mData ->
mModeVector . mX = & rtDW . kfkrdvou4e ; tmp = ( ssIsMajorTimeStep ( rtS ) &&
ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents ) ; simulationData -> mData
-> mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
ssIsMajorTimeStep ( rtS ) ; tmp = ( ssGetMdlInfoPtr ( rtS ) -> mdlFlags .
solverAssertCheck == 1U ) ; simulationData -> mData -> mIsSolverAssertCheck =
tmp ; tmp = ssIsSolverCheckingCIC ( rtS ) ; simulationData -> mData ->
mIsSolverCheckingCIC = tmp ; tmp = ssIsSolverComputingJacobian ( rtS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( rtS ) != 0 ) ;
tmp = ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = tmp ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_e [ 0 ] = 0 ;
tmp_p [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_p [ 1 ] = rtB . dxmcbrhf1p [ 1 ] ;
tmp_p [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_p [ 3 ] = rtB . dxmcbrhf1p [ 3 ] ;
tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = rtB . kwyo50invf [ 0 ] ; tmp_p [ 5 ] = rtB .
kwyo50invf [ 1 ] ; tmp_p [ 6 ] = rtB . kwyo50invf [ 2 ] ; tmp_p [ 7 ] = rtB .
kwyo50invf [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = rtB . cgb3czccvw [ 0 ] ;
tmp_p [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_p [ 10 ] = rtB . cgb3czccvw [ 2 ]
; tmp_p [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] =
rtB . nq5uupkk3g [ 0 ] ; tmp_p [ 13 ] = rtB . nq5uupkk3g [ 1 ] ; tmp_p [ 14 ]
= rtB . nq5uupkk3g [ 2 ] ; tmp_p [ 15 ] = rtB . nq5uupkk3g [ 3 ] ; tmp_e [ 4
] = 16 ; simulationData -> mData -> mInputValues . mN = 16 ; simulationData
-> mData -> mInputValues . mX = & tmp_p [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 5 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_e [ 0 ] ; simulationData -> mData -> mOutputs . mN = 30 ; simulationData
-> mData -> mOutputs . mX = & rtB . hn03iabqcv [ 0 ] ; simulationData ->
mData -> mTolerances . mN = 0 ; simulationData -> mData -> mTolerances . mX =
NULL ; simulationData -> mData -> mCstateHasChanged = false ; time_p =
ssGetTaskTime ( rtS , 0 ) ; simulationData -> mData -> mTime . mN = 1 ;
simulationData -> mData -> mTime . mX = & time_p ; simulationData -> mData ->
mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits . mX = NULL ;
simulationData -> mData -> mIsFundamentalSampleHit = false ;
diagnosticManager = ( NeuDiagnosticManager * ) rtDW . ewdahqbgsp ;
diagnosticTree = neu_diagnostic_manager_get_initial_tree ( diagnosticManager
) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW . bvcs1a5kon ,
NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if ( tmp_i != 0 ) {
tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp ) { msg =
rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( rtS , msg ) ; } }
if ( ssIsMajorTimeStep ( rtS ) && simulationData -> mData ->
mCstateHasChanged ) { ssSetBlockStateForSolverChangedAtMajorStep ( rtS ) ; }
simulationData = ( NeslSimulationData * ) rtDW . gfmsvy5x3x ; time_e = ssGetT
( rtS ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData -> mData
-> mTime . mX = & time_e ; simulationData -> mData -> mContStates . mN = 0 ;
simulationData -> mData -> mContStates . mX = NULL ; simulationData -> mData
-> mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = &
rtDW . i03vg33mpd ; simulationData -> mData -> mModeVector . mN = 0 ;
simulationData -> mData -> mModeVector . mX = & rtDW . ahf5rrmpuw ; tmp = (
ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents
) ; simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData
-> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ; tmp = ( ssGetMdlInfoPtr (
rtS ) -> mdlFlags . solverAssertCheck == 1U ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; tmp = ssIsSolverCheckingCIC ( rtS ) ;
simulationData -> mData -> mIsSolverCheckingCIC = tmp ; simulationData ->
mData -> mIsComputingJacobian = false ; simulationData -> mData ->
mIsEvaluatingF0 = false ; tmp = ssIsSolverRequestingReset ( rtS ) ;
simulationData -> mData -> mIsSolverRequestingReset = tmp ; simulationData ->
mData -> mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_g [ 0 ]
= 0 ; tmp_m [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_m [ 1 ] = rtB . dxmcbrhf1p [
1 ] ; tmp_m [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_m [ 3 ] = rtB . dxmcbrhf1p [
3 ] ; tmp_g [ 1 ] = 4 ; tmp_m [ 4 ] = rtB . kwyo50invf [ 0 ] ; tmp_m [ 5 ] =
rtB . kwyo50invf [ 1 ] ; tmp_m [ 6 ] = rtB . kwyo50invf [ 2 ] ; tmp_m [ 7 ] =
rtB . kwyo50invf [ 3 ] ; tmp_g [ 2 ] = 8 ; tmp_m [ 8 ] = rtB . cgb3czccvw [ 0
] ; tmp_m [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_m [ 10 ] = rtB . cgb3czccvw [
2 ] ; tmp_m [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_g [ 3 ] = 12 ; tmp_m [ 12 ]
= rtB . nq5uupkk3g [ 0 ] ; tmp_m [ 13 ] = rtB . nq5uupkk3g [ 1 ] ; tmp_m [ 14
] = rtB . nq5uupkk3g [ 2 ] ; tmp_m [ 15 ] = rtB . nq5uupkk3g [ 3 ] ; tmp_g [
4 ] = 16 ; memcpy ( & tmp_m [ 16 ] , & rtB . hn03iabqcv [ 0 ] , 30U * sizeof
( real_T ) ) ; tmp_g [ 5 ] = 46 ; simulationData -> mData -> mInputValues .
mN = 46 ; simulationData -> mData -> mInputValues . mX = & tmp_m [ 0 ] ;
simulationData -> mData -> mInputOffsets . mN = 6 ; simulationData -> mData
-> mInputOffsets . mX = & tmp_g [ 0 ] ; simulationData -> mData -> mOutputs .
mN = 6 ; simulationData -> mData -> mOutputs . mX = & rtB . lplw3b2kdf [ 0 ]
; simulationData -> mData -> mTolerances . mN = 0 ; simulationData -> mData
-> mTolerances . mX = NULL ; simulationData -> mData -> mCstateHasChanged =
false ; time_i = ssGetTaskTime ( rtS , 0 ) ; simulationData -> mData -> mTime
. mN = 1 ; simulationData -> mData -> mTime . mX = & time_i ; simulationData
-> mData -> mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits .
mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit = false ;
diagnosticManager = ( NeuDiagnosticManager * ) rtDW . bwqmy33xj5 ;
diagnosticTree_p = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW
. hjmyc4f4pq , NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if (
tmp_i != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if
( tmp ) { msg_p = rtw_diagnostics_msg ( diagnosticTree_p ) ; ssSetErrorStatus
( rtS , msg_p ) ; } } if ( ssIsMajorTimeStep ( rtS ) && simulationData ->
mData -> mCstateHasChanged ) { ssSetBlockStateForSolverChangedAtMajorStep (
rtS ) ; } mbuu4zh5ok = rtP . Gain7_Gain * rtB . lplw3b2kdf [ 4 ] ; rtB .
i2xmftevov = rtP . Gain3_Gain * mbuu4zh5ok ; n0qruvuzgs = rtP . Gain6_Gain *
rtB . lplw3b2kdf [ 3 ] ; rtB . l3wd5aalxa = rtP . Gain2_Gain * n0qruvuzgs ;
rtB . drli3hrk5h = rtX . cvhtys1nmg ; cb0wfta1hx = rtP . Gain5_Gain * rtB .
lplw3b2kdf [ 4 ] ; rtB . anpkxprbja = rtP . Gain1_Gain * cb0wfta1hx ;
hpcwngrjtp = rtP . Gain4_Gain * rtB . lplw3b2kdf [ 3 ] ; rtB . oy5xm3521d =
rtP . Gain22_Gain * hpcwngrjtp ; ezbbib1nrt = rtB . lplw3b2kdf [ 0 ] + rtP .
Constant12_Value ; lrfol15y4l ( ezbbib1nrt , & rtB . n0y0hxfk33 ) ;
m2s3irkxks = rtP . _Value_hav0saipvz - rtB . n0y0hxfk33 . evq2mmxdxv ; rtB .
p2phmituzf = ( rtP . PIDController2_D * m2s3irkxks - rtX . enclntnpgb ) * rtP
. PIDController2_N ; n2brah0n1g = ( ( ( rtP . PIDController2_P * m2s3irkxks +
rtX . k2pkguag0f ) + rtB . p2phmituzf ) + rtB . mpvlceiipn ) * ( 1.0 /
muDoubleScalarCos ( hpcwngrjtp ) ) ; jo0ayn0ziv = rtP . Constant12_Value +
rtB . lplw3b2kdf [ 1 ] ; lrfol15y4l ( jo0ayn0ziv , & rtB . fbsnblbyea ) ;
gis3uzs0hi = rtP . _Value_hav0saipvz - rtB . fbsnblbyea . evq2mmxdxv ; rtB .
gpm1tdppix = ( rtP . PIDController1_D * gis3uzs0hi - rtX . bdi5kb2v3m ) * rtP
. PIDController1_N ; p2urj1vs2m = ( ( ( rtP . PIDController1_P * gis3uzs0hi +
rtX . mgxiehzkbv ) + rtB . gpm1tdppix ) + rtB . mpvlceiipn ) /
muDoubleScalarCos ( n0qruvuzgs ) ; rtB . gym3yhcqgm = rtP . PIDController1_I
* gis3uzs0hi ; rtB . colafue0bv = rtP . PIDController2_I * m2s3irkxks ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . i5etx1dvmm = ( ssGetTaskTime ( rtS ,
1 ) >= rtP . jump_control_jump_time ) ; rtDW . effr1n2tx3 = ( ssGetTaskTime (
rtS , 1 ) >= rtP . jump_control_jump_time + 0.15 ) ; rtDW . no0kde53nr = (
ssGetTaskTime ( rtS , 1 ) >= rtP . jump_control_jump_time + 0.2 ) ; rtDW .
muge3h4jv3 = ( ssGetTaskTime ( rtS , 1 ) >= rtP . jump_control_jump_time +
0.4 ) ; if ( rtDW . i5etx1dvmm == 1 ) { m2s3irkxks = rtP . Step8_YFinal ; }
else { m2s3irkxks = rtP . Step8_Y0 ; } if ( rtDW . effr1n2tx3 == 1 ) {
gis3uzs0hi = rtP . u_YFinal ; } else { gis3uzs0hi = rtP . u_Y0 ; } if ( rtDW
. no0kde53nr == 1 ) { tmp_c = rtP . Step9_YFinal ; } else { tmp_c = rtP .
Step9_Y0 ; } if ( rtDW . muge3h4jv3 == 1 ) { tmp_k = rtP .
u_YFinal_gbt5lirlne ; } else { tmp_k = rtP . u_Y0_hm53n5zp3n ; } rtB .
in3zcewtrh = m2s3irkxks * gis3uzs0hi - tmp_c * tmp_k ; } fjhrpzveoe (
p2urj1vs2m , jo0ayn0ziv , & rtB . kcvrgvdvjm ) ; rtB . ljulrgxuy2 = rtB .
in3zcewtrh + rtB . kcvrgvdvjm . grfdzphf00 ; if ( ssIsModeUpdateTimeStep (
rtS ) ) { rtDW . amfw1jrgpg = rtB . ljulrgxuy2 >= rtP . Saturation1_UpperSat
? 1 : rtB . ljulrgxuy2 > rtP . Saturation1_LowerSat ? 0 : - 1 ; } rtB .
g1jgegd4wm = rtDW . amfw1jrgpg == 1 ? rtP . Saturation1_UpperSat : rtDW .
amfw1jrgpg == - 1 ? rtP . Saturation1_LowerSat : rtB . ljulrgxuy2 ;
fjhrpzveoe ( n2brah0n1g , ezbbib1nrt , & rtB . apbu43ywav ) ; if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW . bfqulf4eav = ( ssGetTaskTime ( rtS ,
1 ) >= rtP . jump_control_jump_time ) ; rtDW . lycjneddx4 = ( ssGetTaskTime (
rtS , 1 ) >= rtP . jump_control_jump_time + 0.15 ) ; rtDW . m3oahjxm15 = (
ssGetTaskTime ( rtS , 1 ) >= rtP . jump_control_jump_time + 0.2 ) ; rtDW .
d4evikqooj = ( ssGetTaskTime ( rtS , 1 ) >= rtP . jump_control_jump_time +
0.4 ) ; if ( rtDW . bfqulf4eav == 1 ) { m2s3irkxks = rtP . Step_YFinal ; }
else { m2s3irkxks = rtP . Step_Y0 ; } if ( rtDW . lycjneddx4 == 1 ) {
gis3uzs0hi = rtP . u_YFinal_bx230hzb35 ; } else { gis3uzs0hi = rtP .
u_Y0_jhi1ifohxk ; } if ( rtDW . m3oahjxm15 == 1 ) { tmp_c = rtP .
Step1_YFinal ; } else { tmp_c = rtP . Step1_Y0 ; } if ( rtDW . d4evikqooj ==
1 ) { tmp_k = rtP . u_YFinal_mkca3g5pip ; } else { tmp_k = rtP .
u_Y0_l1hc11lifj ; } rtB . mpta0uzi4y = m2s3irkxks * gis3uzs0hi - tmp_c *
tmp_k ; } rtB . lpnlritbfn = rtB . apbu43ywav . grfdzphf00 + rtB . mpta0uzi4y
; if ( ssIsModeUpdateTimeStep ( rtS ) ) { rtDW . p5kcjqwpvc = rtB .
lpnlritbfn >= rtP . Saturation2_UpperSat ? 1 : rtB . lpnlritbfn > rtP .
Saturation2_LowerSat ? 0 : - 1 ; } rtB . iqaeo4od0g = rtDW . p5kcjqwpvc == 1
? rtP . Saturation2_UpperSat : rtDW . p5kcjqwpvc == - 1 ? rtP .
Saturation2_LowerSat : rtB . lpnlritbfn ; chostctikr ( rtP . a11 , rtB .
fbsnblbyea . evq2mmxdxv , & rtB . joitgv4v2v ) ; chostctikr ( rtP . a12 , rtB
. fbsnblbyea . evq2mmxdxv , & rtB . l3xole44kr ) ; cxdl3p2hn2 ( rtP . a13 ,
rtB . fbsnblbyea . evq2mmxdxv , & rtB . avniujwdse ) ; chostctikr ( rtP . a14
, rtB . fbsnblbyea . evq2mmxdxv , & rtB . b2hrormsfx ) ; m2s3irkxks = rtB .
lplw3b2kdf [ 5 ] ; rtB . c02iymmqlh = ( ( rtB . joitgv4v2v . g1y4drz24r *
n0qruvuzgs + rtB . l3xole44kr . g1y4drz24r * mbuu4zh5ok ) + rtB . avniujwdse
. ce51yimi3b * rtX . m5olntpqfc ) + rtB . b2hrormsfx . g1y4drz24r *
m2s3irkxks ; if ( ssIsModeUpdateTimeStep ( rtS ) ) { rtDW . e1ol1lizf2 = rtB
. c02iymmqlh >= rtP . Saturation3_UpperSat ? 1 : rtB . c02iymmqlh > rtP .
Saturation3_LowerSat ? 0 : - 1 ; } rtB . fnbcd50axg = rtDW . e1ol1lizf2 == 1
? rtP . Saturation3_UpperSat : rtDW . e1ol1lizf2 == - 1 ? rtP .
Saturation3_LowerSat : rtB . c02iymmqlh ; chostctikr ( rtP . a11 , rtB .
n0y0hxfk33 . evq2mmxdxv , & rtB . jopkzmxn1u ) ; chostctikr ( rtP . a12 , rtB
. n0y0hxfk33 . evq2mmxdxv , & rtB . mkj4rrinwg ) ; cxdl3p2hn2 ( rtP . a13 ,
rtB . n0y0hxfk33 . evq2mmxdxv , & rtB . fquyezsxxj ) ; chostctikr ( rtP . a14
, rtB . n0y0hxfk33 . evq2mmxdxv , & rtB . au2mpwffvh ) ; m2s3irkxks = rtB .
lplw3b2kdf [ 5 ] ; rtB . oy2snck5ps = ( ( rtB . jopkzmxn1u . g1y4drz24r *
hpcwngrjtp + rtB . mkj4rrinwg . g1y4drz24r * cb0wfta1hx ) + rtB . fquyezsxxj
. ce51yimi3b * rtX . m5olntpqfc ) + rtB . au2mpwffvh . g1y4drz24r *
m2s3irkxks ; if ( ssIsModeUpdateTimeStep ( rtS ) ) { rtDW . d24f0oxkxa = rtB
. oy2snck5ps >= rtP . Saturation7_UpperSat ? 1 : rtB . oy2snck5ps > rtP .
Saturation7_LowerSat ? 0 : - 1 ; } rtB . htrlclaxg3 = rtDW . d24f0oxkxa == 1
? rtP . Saturation7_UpperSat : rtDW . d24f0oxkxa == - 1 ? rtP .
Saturation7_LowerSat : rtB . oy2snck5ps ; if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtDW . j5rkxjl2e3 = ( ssGetTaskTime ( rtS , 1 ) >= rtP . Step2_Time ) ;
rtDW . ocvfy0qejk = ( ssGetTaskTime ( rtS , 1 ) >= rtP . Step3_Time ) ; if (
rtDW . j5rkxjl2e3 == 1 ) { m2s3irkxks = rtP . Step2_YFinal ; } else {
m2s3irkxks = rtP . Step2_Y0 ; } if ( rtDW . ocvfy0qejk == 1 ) { gis3uzs0hi =
rtP . Step3_YFinal ; } else { gis3uzs0hi = rtP . Step3_Y0 ; } rtB .
glbg2zc0s5 = m2s3irkxks - gis3uzs0hi ; } rtB . oujjbnqnp0 = rtB . lplw3b2kdf
[ 5 ] - rtB . glbg2zc0s5 ; rtB . dxmcbrhf1p [ 0 ] = rtB . iqaeo4od0g ; rtB .
dxmcbrhf1p [ 1 ] = 0.0 ; rtB . dxmcbrhf1p [ 2 ] = 0.0 ; rtB . dxmcbrhf1p [ 3
] = 0.0 ; rtB . kwyo50invf [ 0 ] = rtB . g1jgegd4wm ; rtB . kwyo50invf [ 1 ]
= 0.0 ; rtB . kwyo50invf [ 2 ] = 0.0 ; rtB . kwyo50invf [ 3 ] = 0.0 ; rtB .
cgb3czccvw [ 0 ] = rtB . htrlclaxg3 ; rtB . cgb3czccvw [ 1 ] = 0.0 ; rtB .
cgb3czccvw [ 2 ] = 0.0 ; rtB . cgb3czccvw [ 3 ] = 0.0 ; rtB . nq5uupkk3g [ 0
] = rtB . fnbcd50axg ; rtB . nq5uupkk3g [ 1 ] = 0.0 ; rtB . nq5uupkk3g [ 2 ]
= 0.0 ; rtB . nq5uupkk3g [ 3 ] = 0.0 ; simulationData = ( NeslSimulationData
* ) rtDW . aoqtp4iunx ; time_m = ssGetT ( rtS ) ; simulationData -> mData ->
mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time_m ;
simulationData -> mData -> mContStates . mN = 0 ; simulationData -> mData ->
mContStates . mX = NULL ; simulationData -> mData -> mDiscStates . mN = 0 ;
simulationData -> mData -> mDiscStates . mX = & rtDW . b1yqxpaqhl ;
simulationData -> mData -> mModeVector . mN = 0 ; simulationData -> mData ->
mModeVector . mX = & rtDW . jjruupxboh ; tmp = ( ssIsMajorTimeStep ( rtS ) &&
ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents ) ; simulationData -> mData
-> mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
ssIsMajorTimeStep ( rtS ) ; tmp = ( ssGetMdlInfoPtr ( rtS ) -> mdlFlags .
solverAssertCheck == 1U ) ; simulationData -> mData -> mIsSolverAssertCheck =
tmp ; tmp = ssIsSolverCheckingCIC ( rtS ) ; simulationData -> mData ->
mIsSolverCheckingCIC = tmp ; simulationData -> mData -> mIsComputingJacobian
= false ; simulationData -> mData -> mIsEvaluatingF0 = false ; tmp =
ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = tmp ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_f [ 0 ] = 0 ;
tmp_j [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_j [ 1 ] = rtB . dxmcbrhf1p [ 1 ] ;
tmp_j [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_j [ 3 ] = rtB . dxmcbrhf1p [ 3 ] ;
tmp_f [ 1 ] = 4 ; tmp_j [ 4 ] = rtB . kwyo50invf [ 0 ] ; tmp_j [ 5 ] = rtB .
kwyo50invf [ 1 ] ; tmp_j [ 6 ] = rtB . kwyo50invf [ 2 ] ; tmp_j [ 7 ] = rtB .
kwyo50invf [ 3 ] ; tmp_f [ 2 ] = 8 ; tmp_j [ 8 ] = rtB . cgb3czccvw [ 0 ] ;
tmp_j [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_j [ 10 ] = rtB . cgb3czccvw [ 2 ]
; tmp_j [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_f [ 3 ] = 12 ; tmp_j [ 12 ] =
rtB . nq5uupkk3g [ 0 ] ; tmp_j [ 13 ] = rtB . nq5uupkk3g [ 1 ] ; tmp_j [ 14 ]
= rtB . nq5uupkk3g [ 2 ] ; tmp_j [ 15 ] = rtB . nq5uupkk3g [ 3 ] ; tmp_f [ 4
] = 16 ; memcpy ( & tmp_j [ 16 ] , & rtB . hn03iabqcv [ 0 ] , 30U * sizeof (
real_T ) ) ; tmp_f [ 5 ] = 46 ; simulationData -> mData -> mInputValues . mN
= 46 ; simulationData -> mData -> mInputValues . mX = & tmp_j [ 0 ] ;
simulationData -> mData -> mInputOffsets . mN = 6 ; simulationData -> mData
-> mInputOffsets . mX = & tmp_f [ 0 ] ; simulationData -> mData -> mOutputs .
mN = 1 ; simulationData -> mData -> mOutputs . mX = & nryqhtzp0s ;
simulationData -> mData -> mTolerances . mN = 0 ; simulationData -> mData ->
mTolerances . mX = NULL ; simulationData -> mData -> mCstateHasChanged =
false ; time_g = ssGetTaskTime ( rtS , 0 ) ; simulationData -> mData -> mTime
. mN = 1 ; simulationData -> mData -> mTime . mX = & time_g ; simulationData
-> mData -> mSampleHits . mN = 0 ; simulationData -> mData -> mSampleHits .
mX = NULL ; simulationData -> mData -> mIsFundamentalSampleHit = false ;
diagnosticManager = ( NeuDiagnosticManager * ) rtDW . non5z2jdlx ;
diagnosticTree_e = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW
. azs3p32xzo , NESL_SIM_OUTPUTS , simulationData , diagnosticManager ) ; if (
tmp_i != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if
( tmp ) { msg_e = rtw_diagnostics_msg ( diagnosticTree_e ) ; ssSetErrorStatus
( rtS , msg_e ) ; } } if ( ssIsMajorTimeStep ( rtS ) && simulationData ->
mData -> mCstateHasChanged ) { ssSetBlockStateForSolverChangedAtMajorStep (
rtS ) ; } UNUSED_PARAMETER ( tid ) ; } void MdlOutputsTID2 ( int_T tid ) {
rtB . mpvlceiipn = rtP . Gain8_Gain * rtP . _Value ; UNUSED_PARAMETER ( tid )
; } void MdlUpdate ( int_T tid ) { NeslSimulationData * simulationData ;
NeuDiagnosticManager * diagnosticManager ; NeuDiagnosticTree * diagnosticTree
; char * msg ; real_T tmp_p [ 16 ] ; real_T time ; int32_T tmp_i ; int_T
tmp_e [ 5 ] ; boolean_T tmp ; simulationData = ( NeslSimulationData * ) rtDW
. na54detrfm ; time = ssGetT ( rtS ) ; simulationData -> mData -> mTime . mN
= 1 ; simulationData -> mData -> mTime . mX = & time ; simulationData ->
mData -> mContStates . mN = 30 ; simulationData -> mData -> mContStates . mX
= & rtX . azpqecuyl0 [ 0 ] ; simulationData -> mData -> mDiscStates . mN = 0
; simulationData -> mData -> mDiscStates . mX = & rtDW . dmkrz0jizc ;
simulationData -> mData -> mModeVector . mN = 0 ; simulationData -> mData ->
mModeVector . mX = & rtDW . kfkrdvou4e ; tmp = ( ssIsMajorTimeStep ( rtS ) &&
ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents ) ; simulationData -> mData
-> mFoundZcEvents = tmp ; simulationData -> mData -> mIsMajorTimeStep =
ssIsMajorTimeStep ( rtS ) ; tmp = ( ssGetMdlInfoPtr ( rtS ) -> mdlFlags .
solverAssertCheck == 1U ) ; simulationData -> mData -> mIsSolverAssertCheck =
tmp ; tmp = ssIsSolverCheckingCIC ( rtS ) ; simulationData -> mData ->
mIsSolverCheckingCIC = tmp ; tmp = ssIsSolverComputingJacobian ( rtS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( rtS ) != 0 ) ;
tmp = ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = tmp ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_e [ 0 ] = 0 ;
tmp_p [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_p [ 1 ] = rtB . dxmcbrhf1p [ 1 ] ;
tmp_p [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_p [ 3 ] = rtB . dxmcbrhf1p [ 3 ] ;
tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = rtB . kwyo50invf [ 0 ] ; tmp_p [ 5 ] = rtB .
kwyo50invf [ 1 ] ; tmp_p [ 6 ] = rtB . kwyo50invf [ 2 ] ; tmp_p [ 7 ] = rtB .
kwyo50invf [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = rtB . cgb3czccvw [ 0 ] ;
tmp_p [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_p [ 10 ] = rtB . cgb3czccvw [ 2 ]
; tmp_p [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] =
rtB . nq5uupkk3g [ 0 ] ; tmp_p [ 13 ] = rtB . nq5uupkk3g [ 1 ] ; tmp_p [ 14 ]
= rtB . nq5uupkk3g [ 2 ] ; tmp_p [ 15 ] = rtB . nq5uupkk3g [ 3 ] ; tmp_e [ 4
] = 16 ; simulationData -> mData -> mInputValues . mN = 16 ; simulationData
-> mData -> mInputValues . mX = & tmp_p [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 5 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_e [ 0 ] ; diagnosticManager = ( NeuDiagnosticManager * ) rtDW .
ewdahqbgsp ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW
. bvcs1a5kon , NESL_SIM_UPDATE , simulationData , diagnosticManager ) ; if (
tmp_i != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if
( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus (
rtS , msg ) ; } } UNUSED_PARAMETER ( tid ) ; } void MdlUpdateTID2 ( int_T tid
) { UNUSED_PARAMETER ( tid ) ; } void MdlDerivatives ( void ) {
NeslSimulationData * simulationData ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; XDot * _rtXdot ;
char * msg ; real_T tmp_p [ 16 ] ; real_T time ; int32_T tmp_i ; int_T tmp_e
[ 5 ] ; boolean_T tmp ; _rtXdot = ( ( XDot * ) ssGetdX ( rtS ) ) ; _rtXdot ->
jtjnlz2ruo = rtB . lplw3b2kdf [ 5 ] ; simulationData = ( NeslSimulationData *
) rtDW . na54detrfm ; time = ssGetT ( rtS ) ; simulationData -> mData ->
mTime . mN = 1 ; simulationData -> mData -> mTime . mX = & time ;
simulationData -> mData -> mContStates . mN = 30 ; simulationData -> mData ->
mContStates . mX = & rtX . azpqecuyl0 [ 0 ] ; simulationData -> mData ->
mDiscStates . mN = 0 ; simulationData -> mData -> mDiscStates . mX = & rtDW .
dmkrz0jizc ; simulationData -> mData -> mModeVector . mN = 0 ; simulationData
-> mData -> mModeVector . mX = & rtDW . kfkrdvou4e ; tmp = (
ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS ) -> foundContZcEvents
) ; simulationData -> mData -> mFoundZcEvents = tmp ; simulationData -> mData
-> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ; tmp = ( ssGetMdlInfoPtr (
rtS ) -> mdlFlags . solverAssertCheck == 1U ) ; simulationData -> mData ->
mIsSolverAssertCheck = tmp ; tmp = ssIsSolverCheckingCIC ( rtS ) ;
simulationData -> mData -> mIsSolverCheckingCIC = tmp ; tmp =
ssIsSolverComputingJacobian ( rtS ) ; simulationData -> mData ->
mIsComputingJacobian = tmp ; simulationData -> mData -> mIsEvaluatingF0 = (
ssGetEvaluatingF0ForJacobian ( rtS ) != 0 ) ; tmp = ssIsSolverRequestingReset
( rtS ) ; simulationData -> mData -> mIsSolverRequestingReset = tmp ;
simulationData -> mData -> mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep (
rtS ) ; tmp_e [ 0 ] = 0 ; tmp_p [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_p [ 1 ]
= rtB . dxmcbrhf1p [ 1 ] ; tmp_p [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_p [ 3 ]
= rtB . dxmcbrhf1p [ 3 ] ; tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = rtB . kwyo50invf [
0 ] ; tmp_p [ 5 ] = rtB . kwyo50invf [ 1 ] ; tmp_p [ 6 ] = rtB . kwyo50invf [
2 ] ; tmp_p [ 7 ] = rtB . kwyo50invf [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] =
rtB . cgb3czccvw [ 0 ] ; tmp_p [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_p [ 10 ]
= rtB . cgb3czccvw [ 2 ] ; tmp_p [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_e [ 3
] = 12 ; tmp_p [ 12 ] = rtB . nq5uupkk3g [ 0 ] ; tmp_p [ 13 ] = rtB .
nq5uupkk3g [ 1 ] ; tmp_p [ 14 ] = rtB . nq5uupkk3g [ 2 ] ; tmp_p [ 15 ] = rtB
. nq5uupkk3g [ 3 ] ; tmp_e [ 4 ] = 16 ; simulationData -> mData ->
mInputValues . mN = 16 ; simulationData -> mData -> mInputValues . mX = &
tmp_p [ 0 ] ; simulationData -> mData -> mInputOffsets . mN = 5 ;
simulationData -> mData -> mInputOffsets . mX = & tmp_e [ 0 ] ;
simulationData -> mData -> mDx . mN = 30 ; simulationData -> mData -> mDx .
mX = & _rtXdot -> azpqecuyl0 [ 0 ] ; diagnosticManager = (
NeuDiagnosticManager * ) rtDW . ewdahqbgsp ; diagnosticTree =
neu_diagnostic_manager_get_initial_tree ( diagnosticManager ) ; tmp_i =
ne_simulator_method ( ( NeslSimulator * ) rtDW . bvcs1a5kon ,
NESL_SIM_DERIVATIVES , simulationData , diagnosticManager ) ; if ( tmp_i != 0
) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) ) ; if ( tmp ) {
msg = rtw_diagnostics_msg ( diagnosticTree ) ; ssSetErrorStatus ( rtS , msg )
; } } _rtXdot -> cvhtys1nmg = rtB . lplw3b2kdf [ 5 ] ; _rtXdot -> k2pkguag0f
= rtB . colafue0bv ; _rtXdot -> enclntnpgb = rtB . p2phmituzf ; _rtXdot ->
mgxiehzkbv = rtB . gym3yhcqgm ; _rtXdot -> bdi5kb2v3m = rtB . gpm1tdppix ;
_rtXdot -> m5olntpqfc = rtB . oujjbnqnp0 ; } void MdlProjection ( void ) {
NeslSimulationData * simulationData ; NeuDiagnosticManager *
diagnosticManager ; NeuDiagnosticTree * diagnosticTree ; char * msg ; real_T
tmp_p [ 16 ] ; real_T time ; int32_T tmp_i ; int_T tmp_e [ 5 ] ; boolean_T
tmp ; simulationData = ( NeslSimulationData * ) rtDW . na54detrfm ; time =
ssGetT ( rtS ) ; simulationData -> mData -> mTime . mN = 1 ; simulationData
-> mData -> mTime . mX = & time ; simulationData -> mData -> mContStates . mN
= 30 ; simulationData -> mData -> mContStates . mX = & rtX . azpqecuyl0 [ 0 ]
; simulationData -> mData -> mDiscStates . mN = 0 ; simulationData -> mData
-> mDiscStates . mX = & rtDW . dmkrz0jizc ; simulationData -> mData ->
mModeVector . mN = 0 ; simulationData -> mData -> mModeVector . mX = & rtDW .
kfkrdvou4e ; tmp = ( ssIsMajorTimeStep ( rtS ) && ssGetRTWSolverInfo ( rtS )
-> foundContZcEvents ) ; simulationData -> mData -> mFoundZcEvents = tmp ;
simulationData -> mData -> mIsMajorTimeStep = ssIsMajorTimeStep ( rtS ) ; tmp
= ( ssGetMdlInfoPtr ( rtS ) -> mdlFlags . solverAssertCheck == 1U ) ;
simulationData -> mData -> mIsSolverAssertCheck = tmp ; tmp =
ssIsSolverCheckingCIC ( rtS ) ; simulationData -> mData ->
mIsSolverCheckingCIC = tmp ; tmp = ssIsSolverComputingJacobian ( rtS ) ;
simulationData -> mData -> mIsComputingJacobian = tmp ; simulationData ->
mData -> mIsEvaluatingF0 = ( ssGetEvaluatingF0ForJacobian ( rtS ) != 0 ) ;
tmp = ssIsSolverRequestingReset ( rtS ) ; simulationData -> mData ->
mIsSolverRequestingReset = tmp ; simulationData -> mData ->
mIsModeUpdateTimeStep = ssIsModeUpdateTimeStep ( rtS ) ; tmp_e [ 0 ] = 0 ;
tmp_p [ 0 ] = rtB . dxmcbrhf1p [ 0 ] ; tmp_p [ 1 ] = rtB . dxmcbrhf1p [ 1 ] ;
tmp_p [ 2 ] = rtB . dxmcbrhf1p [ 2 ] ; tmp_p [ 3 ] = rtB . dxmcbrhf1p [ 3 ] ;
tmp_e [ 1 ] = 4 ; tmp_p [ 4 ] = rtB . kwyo50invf [ 0 ] ; tmp_p [ 5 ] = rtB .
kwyo50invf [ 1 ] ; tmp_p [ 6 ] = rtB . kwyo50invf [ 2 ] ; tmp_p [ 7 ] = rtB .
kwyo50invf [ 3 ] ; tmp_e [ 2 ] = 8 ; tmp_p [ 8 ] = rtB . cgb3czccvw [ 0 ] ;
tmp_p [ 9 ] = rtB . cgb3czccvw [ 1 ] ; tmp_p [ 10 ] = rtB . cgb3czccvw [ 2 ]
; tmp_p [ 11 ] = rtB . cgb3czccvw [ 3 ] ; tmp_e [ 3 ] = 12 ; tmp_p [ 12 ] =
rtB . nq5uupkk3g [ 0 ] ; tmp_p [ 13 ] = rtB . nq5uupkk3g [ 1 ] ; tmp_p [ 14 ]
= rtB . nq5uupkk3g [ 2 ] ; tmp_p [ 15 ] = rtB . nq5uupkk3g [ 3 ] ; tmp_e [ 4
] = 16 ; simulationData -> mData -> mInputValues . mN = 16 ; simulationData
-> mData -> mInputValues . mX = & tmp_p [ 0 ] ; simulationData -> mData ->
mInputOffsets . mN = 5 ; simulationData -> mData -> mInputOffsets . mX = &
tmp_e [ 0 ] ; diagnosticManager = ( NeuDiagnosticManager * ) rtDW .
ewdahqbgsp ; diagnosticTree = neu_diagnostic_manager_get_initial_tree (
diagnosticManager ) ; tmp_i = ne_simulator_method ( ( NeslSimulator * ) rtDW
. bvcs1a5kon , NESL_SIM_PROJECTION , simulationData , diagnosticManager ) ;
if ( tmp_i != 0 ) { tmp = error_buffer_is_empty ( ssGetErrorStatus ( rtS ) )
; if ( tmp ) { msg = rtw_diagnostics_msg ( diagnosticTree ) ;
ssSetErrorStatus ( rtS , msg ) ; } } } void MdlZeroCrossings ( void ) { ZCV *
_rtZCSV ; _rtZCSV = ( ( ZCV * ) ssGetSolverZcSignalVector ( rtS ) ) ; _rtZCSV
-> daem1w2nyu = ssGetT ( rtS ) - rtP . jump_control_jump_time ; _rtZCSV ->
pzqlk5b4b1 = ssGetT ( rtS ) - ( rtP . jump_control_jump_time + 0.15 ) ;
_rtZCSV -> gw3dyruvn2 = ssGetT ( rtS ) - ( rtP . jump_control_jump_time + 0.2
) ; _rtZCSV -> nhskplzz2c = ssGetT ( rtS ) - ( rtP . jump_control_jump_time +
0.4 ) ; _rtZCSV -> phfuy52u3z = rtB . ljulrgxuy2 - rtP . Saturation1_UpperSat
; _rtZCSV -> pjgyedrbrt = rtB . ljulrgxuy2 - rtP . Saturation1_LowerSat ;
_rtZCSV -> hpli5tgenp = ssGetT ( rtS ) - rtP . jump_control_jump_time ;
_rtZCSV -> hbmlkbktge = ssGetT ( rtS ) - ( rtP . jump_control_jump_time +
0.15 ) ; _rtZCSV -> ayequtj1je = ssGetT ( rtS ) - ( rtP .
jump_control_jump_time + 0.2 ) ; _rtZCSV -> efl0mxynv3 = ssGetT ( rtS ) - (
rtP . jump_control_jump_time + 0.4 ) ; _rtZCSV -> hio0henvjn = rtB .
lpnlritbfn - rtP . Saturation2_UpperSat ; _rtZCSV -> clorgzschh = rtB .
lpnlritbfn - rtP . Saturation2_LowerSat ; _rtZCSV -> b0rja0ysvo = rtB .
c02iymmqlh - rtP . Saturation3_UpperSat ; _rtZCSV -> nzbtchguz1 = rtB .
c02iymmqlh - rtP . Saturation3_LowerSat ; _rtZCSV -> p21yw5fdoc = rtB .
oy2snck5ps - rtP . Saturation7_UpperSat ; _rtZCSV -> pselqrc4px = rtB .
oy2snck5ps - rtP . Saturation7_LowerSat ; _rtZCSV -> asmvqpgpln = ssGetT (
rtS ) - rtP . Step2_Time ; _rtZCSV -> irqkjkbrov = ssGetT ( rtS ) - rtP .
Step3_Time ; } void MdlTerminate ( void ) { neu_destroy_diagnostic_manager (
( NeuDiagnosticManager * ) rtDW . ewdahqbgsp ) ; nesl_destroy_simulation_data
( ( NeslSimulationData * ) rtDW . na54detrfm ) ; nesl_erase_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" ) ;
nesl_destroy_registry ( ) ; neu_destroy_diagnostic_manager ( (
NeuDiagnosticManager * ) rtDW . bwqmy33xj5 ) ; nesl_destroy_simulation_data (
( NeslSimulationData * ) rtDW . gfmsvy5x3x ) ; nesl_erase_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" ) ;
nesl_destroy_registry ( ) ; neu_destroy_diagnostic_manager ( (
NeuDiagnosticManager * ) rtDW . non5z2jdlx ) ; nesl_destroy_simulation_data (
( NeslSimulationData * ) rtDW . aoqtp4iunx ) ; nesl_erase_simulator (
"series_link_blance_leg/series_blance_leg_model/Solver Configuration1_1" ) ;
nesl_destroy_registry ( ) ; } static void
mr_series_link_blance_leg_cacheDataAsMxArray ( mxArray * destArray , mwIndex
i , int j , const void * srcData , size_t numBytes ) ; static void
mr_series_link_blance_leg_cacheDataAsMxArray ( mxArray * destArray , mwIndex
i , int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_series_link_blance_leg_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ;
static void mr_series_link_blance_leg_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) {
memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_series_link_blance_leg_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) ; static void
mr_series_link_blance_leg_cacheBitFieldToMxArray ( mxArray * destArray ,
mwIndex i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j
, mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_series_link_blance_leg_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_series_link_blance_leg_extractBitFieldFromMxArray ( const mxArray *
srcArray , mwIndex i , int j , uint_T numBits ) { const uint_T varVal = (
uint_T ) mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return
varVal & ( ( 1u << numBits ) - 1u ) ; } static void
mr_series_link_blance_leg_cacheDataToMxArrayWithOffset ( mxArray * destArray
, mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes
) ; static void mr_series_link_blance_leg_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_series_link_blance_leg_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_series_link_blance_leg_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_series_link_blance_leg_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_series_link_blance_leg_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_series_link_blance_leg_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ;
static uint_T
mr_series_link_blance_leg_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_series_link_blance_leg_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "NULL_PrevZCX"
, } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void *
) & ( rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [
27 ] = { "rtDW.hm5500fwpw" , "rtDW.i0se4p4hlw" , "rtDW.k5pjuqqisf" ,
"rtDW.h3nbvzy4um" , "rtDW.dmkrz0jizc" , "rtDW.i03vg33mpd" , "rtDW.b1yqxpaqhl"
, "rtDW.kfkrdvou4e" , "rtDW.ahf5rrmpuw" , "rtDW.jjruupxboh" ,
"rtDW.i5etx1dvmm" , "rtDW.effr1n2tx3" , "rtDW.no0kde53nr" , "rtDW.muge3h4jv3"
, "rtDW.amfw1jrgpg" , "rtDW.bfqulf4eav" , "rtDW.lycjneddx4" ,
"rtDW.m3oahjxm15" , "rtDW.d4evikqooj" , "rtDW.p5kcjqwpvc" , "rtDW.e1ol1lizf2"
, "rtDW.d24f0oxkxa" , "rtDW.j5rkxjl2e3" , "rtDW.ocvfy0qejk" ,
"rtDW.puzm4xqe0p" , "rtDW.nadulzitq3" , "rtDW.el2uob1lxb" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 27 , rtdwDataFieldNames ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const
void * ) & ( rtDW . hm5500fwpw ) , sizeof ( rtDW . hm5500fwpw ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const
void * ) & ( rtDW . i0se4p4hlw ) , sizeof ( rtDW . i0se4p4hlw ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const
void * ) & ( rtDW . k5pjuqqisf ) , sizeof ( rtDW . k5pjuqqisf ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const
void * ) & ( rtDW . h3nbvzy4um ) , sizeof ( rtDW . h3nbvzy4um ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const
void * ) & ( rtDW . dmkrz0jizc ) , sizeof ( rtDW . dmkrz0jizc ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const
void * ) & ( rtDW . i03vg33mpd ) , sizeof ( rtDW . i03vg33mpd ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const
void * ) & ( rtDW . b1yqxpaqhl ) , sizeof ( rtDW . b1yqxpaqhl ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const
void * ) & ( rtDW . kfkrdvou4e ) , sizeof ( rtDW . kfkrdvou4e ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const
void * ) & ( rtDW . ahf5rrmpuw ) , sizeof ( rtDW . ahf5rrmpuw ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const
void * ) & ( rtDW . jjruupxboh ) , sizeof ( rtDW . jjruupxboh ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const
void * ) & ( rtDW . i5etx1dvmm ) , sizeof ( rtDW . i5etx1dvmm ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const
void * ) & ( rtDW . effr1n2tx3 ) , sizeof ( rtDW . effr1n2tx3 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const
void * ) & ( rtDW . no0kde53nr ) , sizeof ( rtDW . no0kde53nr ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const
void * ) & ( rtDW . muge3h4jv3 ) , sizeof ( rtDW . muge3h4jv3 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const
void * ) & ( rtDW . amfw1jrgpg ) , sizeof ( rtDW . amfw1jrgpg ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const
void * ) & ( rtDW . bfqulf4eav ) , sizeof ( rtDW . bfqulf4eav ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const
void * ) & ( rtDW . lycjneddx4 ) , sizeof ( rtDW . lycjneddx4 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const
void * ) & ( rtDW . m3oahjxm15 ) , sizeof ( rtDW . m3oahjxm15 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const
void * ) & ( rtDW . d4evikqooj ) , sizeof ( rtDW . d4evikqooj ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const
void * ) & ( rtDW . p5kcjqwpvc ) , sizeof ( rtDW . p5kcjqwpvc ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const
void * ) & ( rtDW . e1ol1lizf2 ) , sizeof ( rtDW . e1ol1lizf2 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const
void * ) & ( rtDW . d24f0oxkxa ) , sizeof ( rtDW . d24f0oxkxa ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const
void * ) & ( rtDW . j5rkxjl2e3 ) , sizeof ( rtDW . j5rkxjl2e3 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const
void * ) & ( rtDW . ocvfy0qejk ) , sizeof ( rtDW . ocvfy0qejk ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const
void * ) & ( rtDW . puzm4xqe0p ) , sizeof ( rtDW . puzm4xqe0p ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const
void * ) & ( rtDW . nadulzitq3 ) , sizeof ( rtDW . nadulzitq3 ) ) ;
mr_series_link_blance_leg_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const
void * ) & ( rtDW . el2uob1lxb ) , sizeof ( rtDW . el2uob1lxb ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void
mr_series_link_blance_leg_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtB ) ,
ssDW , 0 , 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hm5500fwpw ) , rtdwData , 0 , 0 , sizeof ( rtDW . hm5500fwpw ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i0se4p4hlw ) , rtdwData , 0 , 1 , sizeof ( rtDW . i0se4p4hlw ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
k5pjuqqisf ) , rtdwData , 0 , 2 , sizeof ( rtDW . k5pjuqqisf ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
h3nbvzy4um ) , rtdwData , 0 , 3 , sizeof ( rtDW . h3nbvzy4um ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dmkrz0jizc ) , rtdwData , 0 , 4 , sizeof ( rtDW . dmkrz0jizc ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i03vg33mpd ) , rtdwData , 0 , 5 , sizeof ( rtDW . i03vg33mpd ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
b1yqxpaqhl ) , rtdwData , 0 , 6 , sizeof ( rtDW . b1yqxpaqhl ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kfkrdvou4e ) , rtdwData , 0 , 7 , sizeof ( rtDW . kfkrdvou4e ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ahf5rrmpuw ) , rtdwData , 0 , 8 , sizeof ( rtDW . ahf5rrmpuw ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jjruupxboh ) , rtdwData , 0 , 9 , sizeof ( rtDW . jjruupxboh ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i5etx1dvmm ) , rtdwData , 0 , 10 , sizeof ( rtDW . i5etx1dvmm ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
effr1n2tx3 ) , rtdwData , 0 , 11 , sizeof ( rtDW . effr1n2tx3 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
no0kde53nr ) , rtdwData , 0 , 12 , sizeof ( rtDW . no0kde53nr ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
muge3h4jv3 ) , rtdwData , 0 , 13 , sizeof ( rtDW . muge3h4jv3 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
amfw1jrgpg ) , rtdwData , 0 , 14 , sizeof ( rtDW . amfw1jrgpg ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bfqulf4eav ) , rtdwData , 0 , 15 , sizeof ( rtDW . bfqulf4eav ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lycjneddx4 ) , rtdwData , 0 , 16 , sizeof ( rtDW . lycjneddx4 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
m3oahjxm15 ) , rtdwData , 0 , 17 , sizeof ( rtDW . m3oahjxm15 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
d4evikqooj ) , rtdwData , 0 , 18 , sizeof ( rtDW . d4evikqooj ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
p5kcjqwpvc ) , rtdwData , 0 , 19 , sizeof ( rtDW . p5kcjqwpvc ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
e1ol1lizf2 ) , rtdwData , 0 , 20 , sizeof ( rtDW . e1ol1lizf2 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
d24f0oxkxa ) , rtdwData , 0 , 21 , sizeof ( rtDW . d24f0oxkxa ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
j5rkxjl2e3 ) , rtdwData , 0 , 22 , sizeof ( rtDW . j5rkxjl2e3 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ocvfy0qejk ) , rtdwData , 0 , 23 , sizeof ( rtDW . ocvfy0qejk ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
puzm4xqe0p ) , rtdwData , 0 , 24 , sizeof ( rtDW . puzm4xqe0p ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nadulzitq3 ) , rtdwData , 0 , 25 , sizeof ( rtDW . nadulzitq3 ) ) ;
mr_series_link_blance_leg_restoreDataFromMxArray ( ( void * ) & ( rtDW .
el2uob1lxb ) , rtdwData , 0 , 26 , sizeof ( rtDW . el2uob1lxb ) ) ; } }
mxArray * mr_series_link_blance_leg_GetSimStateDisallowedBlocks ( ) { mxArray
* data = mxCreateCellMatrix ( 10 , 3 ) ; mwIndex subs [ 2 ] , offset ; {
static const char * blockType [ 10 ] = { "Scope" , "SimscapeExecutionBlock" ,
"SimscapeExecutionBlock" , "Scope" , "Scope" , "Scope" , "Scope" , "Scope" ,
"SimscapeSinkBlock" , "SimscapeExecutionBlock" , } ; static const char *
blockPath [ 10 ] = { "series_link_blance_leg/L_X" ,
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/STATE_1"
,
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/OUTPUT_1_0"
, "series_link_blance_leg/L_d_phi" , "series_link_blance_leg/L_phi" ,
"series_link_blance_leg/R_X" , "series_link_blance_leg/R_d_phi" ,
"series_link_blance_leg/R_phi" ,
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/SINK_1"
,
 "series_link_blance_leg/series_blance_leg_model/Solver Configuration1/EVAL_KEY/OUTPUT_1_1"
, } ; static const int reason [ 10 ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] < 10 ; ++ ( subs [ 0 ] ) ) { subs [
1 ] = 0 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell (
data , offset , mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] =
1 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } }
return data ; } void MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS ,
37 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ; ssSetNumY ( rtS , 0 ) ;
ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS , 0 ) ;
ssSetNumSampleTimes ( rtS , 2 ) ; ssSetNumBlocks ( rtS , 190 ) ;
ssSetNumBlockIO ( rtS , 41 ) ; ssSetNumBlockParams ( rtS , 69 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 0.0 ) ; ssSetOffsetTime ( rtS , 0 , 0.0 ) ;
ssSetOffsetTime ( rtS , 1 , 1.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 3704303775U ) ; ssSetChecksumVal ( rtS , 1 ,
570096350U ) ; ssSetChecksumVal ( rtS , 2 , 4269575092U ) ; ssSetChecksumVal
( rtS , 3 , 1976976561U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; static struct _ssBlkInfo2 blkInfo2 ;
static struct _ssBlkInfoSLSize blkInfoSLSize ; ( void ) memset ( ( char * )
rtS , 0 , sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0
, sizeof ( struct _ssMdlInfo ) ) ; ( void ) memset ( ( char * ) & blkInfo2 ,
0 , sizeof ( struct _ssBlkInfo2 ) ) ; ( void ) memset ( ( char * ) &
blkInfoSLSize , 0 , sizeof ( struct _ssBlkInfoSLSize ) ) ; ssSetBlkInfo2Ptr (
rtS , & blkInfo2 ) ; ssSetBlkInfoSLSizePtr ( rtS , & blkInfoSLSize ) ;
ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; ssSetExecutionInfo ( rtS ,
executionInfo ) ; slsaAllocOPModelData ( rtS ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 23 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
series_link_blance_leg_InitializeDataMapInfo ( ) ;
ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS ) ;
ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"series_link_blance_leg" ) ; ssSetPath ( rtS , "series_link_blance_leg" ) ;
ssSetTStart ( rtS , 0.0 ) ; ssSetTFinal ( rtS , 20.0 ) ; { static RTWLogInfo
rt_DataLoggingInfo ; rt_DataLoggingInfo . loggingInterval = ( NULL ) ;
ssSetRTWLogInfo ( rtS , & rt_DataLoggingInfo ) ; } { { static int_T
rt_LoggedStateWidths [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 2 , 2 , 2 , 2 } ; static int_T
rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T
rt_LoggedStateDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 2 , 2 , 2 , 2 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE } ; static int_T rt_LoggedStateComplexSignals [ ] = { 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 } ; static RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [ ]
= { ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL
) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL
) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL
) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL
) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL
) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ;
static const char_T * rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"Discrete" , "Discrete" , "Discrete" , "Discrete" } ; static const char_T *
rt_LoggedStateBlockNames [ ] = { "series_link_blance_leg/Integrator1" ,
"series_link_blance_leg/series_blance_leg_model/Cartesian Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Cartesian Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Cartesian Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Cartesian Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Cartesian Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Cartesian Joint1" ,
"series_link_blance_leg/series_blance_leg_model/pitch" ,
"series_link_blance_leg/series_blance_leg_model/pitch" ,
"series_link_blance_leg/series_blance_leg_model/Roll" ,
"series_link_blance_leg/series_blance_leg_model/Roll" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint2" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint2" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint4" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint4" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint1" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint3" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint3" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint5" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint5" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint7" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint7" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint8" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint8" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint6" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint6" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint9" ,
"series_link_blance_leg/series_blance_leg_model/Revolute Joint9" ,
"series_link_blance_leg/Integrator2" ,
"series_link_blance_leg/PID Controller2/Integrator/Continuous/Integrator" ,
"series_link_blance_leg/PID Controller2/Filter/Cont. Filter/Filter" ,
"series_link_blance_leg/PID Controller1/Integrator/Continuous/Integrator" ,
"series_link_blance_leg/PID Controller1/Filter/Cont. Filter/Filter" ,
"series_link_blance_leg/Integrator" ,
 "series_link_blance_leg/series_blance_leg_model/Solver\nConfiguration1/EVAL_KEY/INPUT_2_1_1"
,
 "series_link_blance_leg/series_blance_leg_model/Solver\nConfiguration1/EVAL_KEY/INPUT_3_1_1"
,
 "series_link_blance_leg/series_blance_leg_model/Solver\nConfiguration1/EVAL_KEY/INPUT_1_1_1"
,
 "series_link_blance_leg/series_blance_leg_model/Solver\nConfiguration1/EVAL_KEY/INPUT_4_1_1"
} ; static const char_T * rt_LoggedStateNames [ ] = { "" ,
"series_link_blance_leg.series_blance_leg_model.Cartesian_Joint1.Px.p" ,
"series_link_blance_leg.series_blance_leg_model.Cartesian_Joint1.Py.p" ,
"series_link_blance_leg.series_blance_leg_model.Cartesian_Joint1.Pz.p" ,
"series_link_blance_leg.series_blance_leg_model.Cartesian_Joint1.Px.v" ,
"series_link_blance_leg.series_blance_leg_model.Cartesian_Joint1.Py.v" ,
"series_link_blance_leg.series_blance_leg_model.Cartesian_Joint1.Pz.v" ,
"series_link_blance_leg.series_blance_leg_model.pitch.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.pitch.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Roll.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Roll.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint2.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint2.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint4.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint4.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint1.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint1.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint3.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint3.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint5.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint5.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint7.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint7.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint8.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint8.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint6.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint6.Rz.w" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint9.Rz.q" ,
"series_link_blance_leg.series_blance_leg_model.Revolute_Joint9.Rz.w" , "" ,
"" , "" , "" , "" , "" , "Discrete" , "Discrete" , "Discrete" , "Discrete" }
; static boolean_T rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWLogDataTypeConvert rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } } ; static int_T
rt_LoggedStateIdxList [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 0 , 1 , 2 , 3 }
; static RTWLogSignalInfo rt_LoggedStateSignalInfo = { 41 ,
rt_LoggedStateWidths , rt_LoggedStateNumDimensions , rt_LoggedStateDimensions
, rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 41 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . jtjnlz2ruo ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . azpqecuyl0 [ 0 ] ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . azpqecuyl0 [ 1 ] ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . azpqecuyl0 [ 2 ] ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . azpqecuyl0 [ 3 ] ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . azpqecuyl0 [ 4 ] ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtX . azpqecuyl0 [ 5 ] ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtX . azpqecuyl0 [ 6 ] ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtX . azpqecuyl0 [ 7 ] ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtX . azpqecuyl0 [ 8 ] ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtX . azpqecuyl0 [ 9 ] ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtX . azpqecuyl0 [ 10 ] ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtX . azpqecuyl0 [ 11 ] ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtX . azpqecuyl0 [ 12 ] ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtX . azpqecuyl0 [ 13 ] ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtX . azpqecuyl0 [ 14 ] ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) & rtX . azpqecuyl0 [ 15 ] ;
rt_LoggedStateSignalPtrs [ 17 ] = ( void * ) & rtX . azpqecuyl0 [ 16 ] ;
rt_LoggedStateSignalPtrs [ 18 ] = ( void * ) & rtX . azpqecuyl0 [ 17 ] ;
rt_LoggedStateSignalPtrs [ 19 ] = ( void * ) & rtX . azpqecuyl0 [ 18 ] ;
rt_LoggedStateSignalPtrs [ 20 ] = ( void * ) & rtX . azpqecuyl0 [ 19 ] ;
rt_LoggedStateSignalPtrs [ 21 ] = ( void * ) & rtX . azpqecuyl0 [ 20 ] ;
rt_LoggedStateSignalPtrs [ 22 ] = ( void * ) & rtX . azpqecuyl0 [ 21 ] ;
rt_LoggedStateSignalPtrs [ 23 ] = ( void * ) & rtX . azpqecuyl0 [ 22 ] ;
rt_LoggedStateSignalPtrs [ 24 ] = ( void * ) & rtX . azpqecuyl0 [ 23 ] ;
rt_LoggedStateSignalPtrs [ 25 ] = ( void * ) & rtX . azpqecuyl0 [ 24 ] ;
rt_LoggedStateSignalPtrs [ 26 ] = ( void * ) & rtX . azpqecuyl0 [ 25 ] ;
rt_LoggedStateSignalPtrs [ 27 ] = ( void * ) & rtX . azpqecuyl0 [ 26 ] ;
rt_LoggedStateSignalPtrs [ 28 ] = ( void * ) & rtX . azpqecuyl0 [ 27 ] ;
rt_LoggedStateSignalPtrs [ 29 ] = ( void * ) & rtX . azpqecuyl0 [ 28 ] ;
rt_LoggedStateSignalPtrs [ 30 ] = ( void * ) & rtX . azpqecuyl0 [ 29 ] ;
rt_LoggedStateSignalPtrs [ 31 ] = ( void * ) & rtX . cvhtys1nmg ;
rt_LoggedStateSignalPtrs [ 32 ] = ( void * ) & rtX . k2pkguag0f ;
rt_LoggedStateSignalPtrs [ 33 ] = ( void * ) & rtX . enclntnpgb ;
rt_LoggedStateSignalPtrs [ 34 ] = ( void * ) & rtX . mgxiehzkbv ;
rt_LoggedStateSignalPtrs [ 35 ] = ( void * ) & rtX . bdi5kb2v3m ;
rt_LoggedStateSignalPtrs [ 36 ] = ( void * ) & rtX . m5olntpqfc ;
rt_LoggedStateSignalPtrs [ 37 ] = ( void * ) rtDW . hm5500fwpw ;
rt_LoggedStateSignalPtrs [ 38 ] = ( void * ) rtDW . i0se4p4hlw ;
rt_LoggedStateSignalPtrs [ 39 ] = ( void * ) rtDW . k5pjuqqisf ;
rt_LoggedStateSignalPtrs [ 40 ] = ( void * ) rtDW . h3nbvzy4um ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"xFinal" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static struct _ssSFcnModelMethods3 mdlMethods3
; static struct _ssSFcnModelMethods2 mdlMethods2 ; static boolean_T
contStatesDisabled [ 37 ] ; static real_T absTol [ 37 ] = { 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 , 1.0E-6 ,
1.0E-6 , 1.0E-6 , 1.0E-6 } ; static uint8_T absTolControl [ 37 ] = { 0U , 0U
, 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U ,
0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U , 0U
, 0U , 0U , 0U , 0U } ; static real_T contStateJacPerturbBoundMinVec [ 37 ] ;
static real_T contStateJacPerturbBoundMaxVec [ 37 ] ; static uint8_T
zcAttributes [ 18 ] = { ( ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL )
, ( ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL_UP ) , (
ZC_EVENT_ALL_UP ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) ,
( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL ) , ( ZC_EVENT_ALL_UP )
, ( ZC_EVENT_ALL_UP ) } ; static uint8_T zcEvents [ 18 ] = { ( 0x40 |
ZC_EVENT_ALL_UP ) , ( 0x40 | ZC_EVENT_ALL_UP ) , ( 0x40 | ZC_EVENT_ALL_UP ) ,
( 0x40 | ZC_EVENT_ALL_UP ) , ( 0x40 | ZC_EVENT_ALL ) , ( 0x40 | ZC_EVENT_ALL
) , ( 0x40 | ZC_EVENT_ALL_UP ) , ( 0x40 | ZC_EVENT_ALL_UP ) , ( 0x40 |
ZC_EVENT_ALL_UP ) , ( 0x40 | ZC_EVENT_ALL_UP ) , ( 0x40 | ZC_EVENT_ALL ) , (
0x40 | ZC_EVENT_ALL ) , ( 0x40 | ZC_EVENT_ALL ) , ( 0x40 | ZC_EVENT_ALL ) , (
0x40 | ZC_EVENT_ALL ) , ( 0x40 | ZC_EVENT_ALL ) , ( 0x40 | ZC_EVENT_ALL_UP )
, ( 0x40 | ZC_EVENT_ALL_UP ) } ; static ssNonContDerivSigInfo
nonContDerivSigInfo [ 3 ] = { { 1 * sizeof ( real_T ) , ( char * ) ( & rtB .
glbg2zc0s5 ) , ( NULL ) } , { 1 * sizeof ( real_T ) , ( char * ) ( & rtB .
mpta0uzi4y ) , ( NULL ) } , { 1 * sizeof ( real_T ) , ( char * ) ( & rtB .
in3zcewtrh ) , ( NULL ) } } ; { int i ; for ( i = 0 ; i < 37 ; ++ i ) {
contStateJacPerturbBoundMinVec [ i ] = 0 ; contStateJacPerturbBoundMaxVec [ i
] = rtGetInf ( ) ; } } ssSetSolverRelTol ( rtS , 0.001 ) ; ssSetStepSize (
rtS , 0.0 ) ; ssSetMinStepSize ( rtS , 0.0 ) ; ssSetMaxNumMinSteps ( rtS , -
1 ) ; ssSetMinStepViolatedError ( rtS , 0 ) ; ssSetMaxStepSize ( rtS , 0.2 )
; ssSetSolverMaxOrder ( rtS , - 1 ) ; ssSetSolverRefineFactor ( rtS , 1 ) ;
ssSetOutputTimes ( rtS , ( NULL ) ) ; ssSetNumOutputTimes ( rtS , 0 ) ;
ssSetOutputTimesOnly ( rtS , 0 ) ; ssSetOutputTimesIndex ( rtS , 0 ) ;
ssSetZCCacheNeedsReset ( rtS , 1 ) ; ssSetDerivCacheNeedsReset ( rtS , 0 ) ;
ssSetNumNonContDerivSigInfos ( rtS , 3 ) ; ssSetNonContDerivSigInfos ( rtS ,
nonContDerivSigInfo ) ; ssSetSolverInfo ( rtS , & slvrInfo ) ;
ssSetSolverName ( rtS , "ode45" ) ; ssSetVariableStepSolver ( rtS , 1 ) ;
ssSetSolverConsistencyChecking ( rtS , 0 ) ; ssSetSolverAdaptiveZcDetection (
rtS , 0 ) ; ssSetSolverRobustResetMethod ( rtS , 0 ) ;
_ssSetSolverUpdateJacobianAtReset ( rtS , true ) ; ssSetAbsTolVector ( rtS ,
absTol ) ; ssSetAbsTolControlVector ( rtS , absTolControl ) ;
ssSetSolverAbsTol_Obsolete ( rtS , absTol ) ;
ssSetSolverAbsTolControl_Obsolete ( rtS , absTolControl ) ;
ssSetJacobianPerturbationBoundsMinVec ( rtS , contStateJacPerturbBoundMinVec
) ; ssSetJacobianPerturbationBoundsMaxVec ( rtS ,
contStateJacPerturbBoundMaxVec ) ; ssSetSolverStateProjection ( rtS , 1 ) ; (
void ) memset ( ( void * ) & mdlMethods2 , 0 , sizeof ( mdlMethods2 ) ) ;
ssSetModelMethods2 ( rtS , & mdlMethods2 ) ; ( void ) memset ( ( void * ) &
mdlMethods3 , 0 , sizeof ( mdlMethods3 ) ) ; ssSetModelMethods3 ( rtS , &
mdlMethods3 ) ; ssSetModelProjection ( rtS , MdlProjection ) ;
ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetSolverZcSignalAttrib ( rtS , zcAttributes ) ;
ssSetSolverNumZcSignals ( rtS , 18 ) ; ssSetModelZeroCrossings ( rtS ,
MdlZeroCrossings ) ; ssSetSolverZcEventsVector ( rtS , zcEvents ) ;
ssSetSolverConsecutiveZCsStepRelTol ( rtS , 2.8421709430404007E-13 ) ;
ssSetSolverMaxConsecutiveZCs ( rtS , 1000 ) ; ssSetSolverConsecutiveZCsError
( rtS , 2 ) ; ssSetSolverMaskedZcDiagnostic ( rtS , 1 ) ;
ssSetSolverIgnoredZcDiagnostic ( rtS , 1 ) ; ssSetSolverMaxConsecutiveMinStep
( rtS , 1 ) ; ssSetSolverShapePreserveControl ( rtS , 2 ) ; ssSetTNextTid (
rtS , INT_MIN ) ; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset (
rtS ) ; ssSetNumNonsampledZCs ( rtS , 18 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; ssSetSolverMaxConsecutiveMinStep ( rtS , 1 ) ; }
ssSetChecksumVal ( rtS , 0 , 3704303775U ) ; ssSetChecksumVal ( rtS , 1 ,
570096350U ) ; ssSetChecksumVal ( rtS , 2 , 4269575092U ) ; ssSetChecksumVal
( rtS , 3 , 1976976561U ) ; { static const sysRanDType rtAlwaysEnabled =
SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo rt_ExtModeInfo ; static const
sysRanDType * systemRan [ 13 ] ; gblRTWExtModeInfo = & rt_ExtModeInfo ;
ssSetRTWExtModeInfo ( rtS , & rt_ExtModeInfo ) ;
rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo , systemRan ) ;
systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = & rtAlwaysEnabled ;
systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = & rtAlwaysEnabled ;
systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = & rtAlwaysEnabled ;
systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = & rtAlwaysEnabled ;
systemRan [ 8 ] = & rtAlwaysEnabled ; systemRan [ 9 ] = & rtAlwaysEnabled ;
systemRan [ 10 ] = & rtAlwaysEnabled ; systemRan [ 11 ] = & rtAlwaysEnabled ;
systemRan [ 12 ] = & rtAlwaysEnabled ; rteiSetModelMappingInfoPtr (
ssGetRTWExtModeInfo ( rtS ) , & ssGetModelMappingInfo ( rtS ) ) ;
rteiSetChecksumsPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetChecksums ( rtS ) )
; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetTPtr ( rtS ) ) ; }
slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_series_link_blance_leg_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_series_link_blance_leg_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_series_link_blance_leg_SetDWork ) ;
rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if ( ssGetErrorStatus ( rtS ) )
{ return rtS ; } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 2 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID2 ( tid ) ; }
