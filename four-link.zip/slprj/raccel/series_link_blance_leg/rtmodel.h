#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "series_link_blance_leg.h"
#define GRTINTERFACE 1
#endif
