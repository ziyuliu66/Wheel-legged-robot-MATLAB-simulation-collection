#ifndef RTW_HEADER_series_link_blance_leg_capi_h_
#define RTW_HEADER_series_link_blance_leg_capi_h_
#include "series_link_blance_leg.h"
extern void series_link_blance_leg_InitializeDataMapInfo ( void ) ;
#endif
