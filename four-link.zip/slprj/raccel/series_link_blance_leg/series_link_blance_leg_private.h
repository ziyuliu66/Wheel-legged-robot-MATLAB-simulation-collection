#ifndef RTW_HEADER_series_link_blance_leg_private_h_
#define RTW_HEADER_series_link_blance_leg_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "series_link_blance_leg.h"
#include "series_link_blance_leg_types.h"
#if !defined(rt_VALIDATE_MEMORY)
#define rt_VALIDATE_MEMORY(S, ptr)     if(!(ptr)) {\
    ssSetErrorStatus(rtS, RT_MEMORY_ALLOCATION_ERROR);\
    }
#endif
#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)     if((ptr) != (NULL)) {\
    free((ptr));\
    (ptr) = (NULL);\
    }
#else
#define rt_FREE(ptr)     if((ptr) != (NULL)) {\
    free((void *)(ptr));\
    (ptr) = (NULL);\
    }
#endif
#endif
extern void chostctikr ( const real_T j5dtsvyddf [ 3 ] , real_T hflgveddoz ,
jyjoxr5fwj * localB ) ; extern void cxdl3p2hn2 ( const real_T ebf03v2ull [ 2
] , real_T mnpaptzquf , nstzhfyemr * localB ) ; extern void fjhrpzveoe (
real_T dd1my3yebx , real_T lvb0fbexgi , p00rr42fc4 * localB ) ; extern void
lrfol15y4l ( real_T n03px11pkt , hgh2bvor5a * localB ) ;
#if defined(MULTITASKING)
#error Models using the variable step solvers cannot define MULTITASKING
#endif
#endif
