syms l1 l2 m1 m2 theta1 theta2 y1 y2 x1 x2 yg
y1 = l1*sin(theta1)/2;
y2 = l1*sin(theta1)+l2*sin(pi-theta2)/2;
yg = (y1*m1 + y2*m2)/(m1 + m2)

